/************************************************************************************
 * cGraphics.cpp - Implementation of the Graphics class which is part of GR8 Graphics
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info
 * Copyright � Revolt 2008
 ************************************************************************************/

#include "cGraphics.h"

using namespace std;

namespace GR8 {

/* -----------------------------------
   - Static functions Implementation -
   ----------------------------------- */

sPosition GetCenterPosition(sSize source, sRect destination)
{
    return sPosition(destination.x + (destination.w - source.w) / 2, destination.y + (destination.h - source.h) / 2);
}

GLuint* ConvertSurfaceToOpenGLTexture(SDL_Surface *surface)
{
	if (surface == NULL) {
        return NULL;
    }

    cout << "Entered OpenGL texture convert" << endl;

    GLenum texture_format;

    cout << "Checking surface properties" << endl;

    // Check that the image's width is a power of 2
	if ( (surface->w & (surface->w - 1)) != 0 ) {
		printf("warning: Surface's width is not a power of 2\n");
	}

	// Also check if the height is a power of 2
	if ( (surface->h & (surface->h - 1)) != 0 ) {
		printf("warning: Surface's height is not a power of 2\n");
	}

    // get the number of channels in the SDL surface
    int nOfColors = surface->format->BytesPerPixel;
    if (nOfColors == 4) { // contains an alpha channel
        if (surface->format->Rmask == 0x000000ff)
                texture_format = GL_RGBA;
        else
                texture_format = GL_BGRA;
    }
    else if (nOfColors == 3) { // no alpha channel
        if (surface->format->Rmask == 0x000000ff)
                texture_format = GL_RGB;
        else
                texture_format = GL_BGR;
    } else {
        cerr << "Error: surface is not truecolor" << endl;
        return NULL;
    }

    GLuint *texture = new GLuint;

    cout << "Generating texture" << endl;
	// Have OpenGL generate a texture object handle for us
	glGenTextures( 1, texture );

    cout << "Setting texture properties" << endl;
	// Bind the texture object
	glBindTexture( GL_TEXTURE_2D, *texture );

    cout << "Render texture" << endl;
	// Edit the texture object's image data using the information SDL_Surface gives us
	glTexImage2D( GL_TEXTURE_2D, 0, nOfColors, surface->w, surface->h, 0, texture_format, GL_UNSIGNED_BYTE, surface->pixels );

	//Set the texture's stretching properties
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	SDL_FreeSurface(surface);

	cout << "Left OpenGL texture convert" << endl;

	return texture;
}

cGraphics::cGraphics()
{
    _mainWindow = NULL;
}

cGraphics::~cGraphics()
{
    Shutdown();
}

/* Function Initialize
 * Initializes the Video subsystem and creates the main game window */
bool cGraphics::Initialize(const string &windowTitle, int windowW, int windowH, int windowBPP, bool fullScreen, int fps)
{
    _fpsLimit = 0;
    _fps = 0;
    _frame = 0;

    _frameTimer = new cTimer();
    _fpsTimer = new cTimer();

    _camera = NULL;
    _cameraBounds = NULL;

    _width = windowW;
    _height = windowH;
    _bpp = windowBPP;
    _title = windowTitle;

    if (SDL_Init(SDL_INIT_VIDEO) == -1) {
        cerr << "Unable to initialize SDL Video: " << SDL_GetError() << endl;
        return false;
    }

    _sdlFlags = SDL_ANYFORMAT | SDL_OPENGL;
    if (fullScreen) {
        _sdlFlags |= SDL_FULLSCREEN;
    }

    const SDL_VideoInfo* videoInfo = SDL_GetVideoInfo();

    cout << "Video Properties" << endl
         << "----------------" << endl;

    SDL_Rect **modes = SDL_ListModes(NULL, _sdlFlags);
    /* Check is there are any modes available */
    if (modes == (SDL_Rect **)0) {
        cout << "No Resolutions Available" << endl;
        return false;
    }

    /* Check if or resolution is restricted */
    if (modes == (SDL_Rect **)-1) {
        cout << "Any Resolution Available" << endl;
    } else {
      /* Print valid modes */
      cout << "Available Modes for " << (int)videoInfo->vfmt->BitsPerPixel << "bpp" << endl;
      for(int i=0;modes[i];++i) {
        cout << "  " << modes[i]->w << "x" <<  modes[i]->h << endl;
      }
    }

    SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );
    SDL_GL_SetAttribute( SDL_GL_ACCELERATED_VISUAL, 1 );
    //SDL_GL_SetAttribute( SDL_GL_SWAP_CONTROL, 0 );
    _mainWindow = SDL_SetVideoMode(_width, _height, _bpp, _sdlFlags);

    if (_mainWindow == NULL) {
        cerr << "Unable to create main window: " << SDL_GetError() << endl;
        return false;
    }

    if (!InitializeOpenGL()) {
        return false;
    }

    SDL_WM_SetCaption(_title.c_str(), NULL);

    textureManager = new cTextureManager();
    fontManager = new cFontManager();

    if (fps > 0) {
        CapFPS(fps);
    }

    _fpsTimer->Start();

    return true;
}

/* Function Shutdown()
 * Cleans up by freeing the main window surface, deleting objects and unloading the video subsystem */
void cGraphics::Shutdown()
{
    cout << "Entering cGraphics Shutdown" << endl;
    delete textureManager;
    delete fontManager;
    delete _fpsTimer;
    delete _frameTimer;
    SDL_FreeSurface(_mainWindow);
    SDL_QuitSubSystem(SDL_INIT_VIDEO);
	cout << "Leaving cGraphics Shutdown" << endl;
}

/* Function DrawLine()
 * Draws a line starting at pos1 and ending at pos 2 with the
   specified color */
void cGraphics::DrawLine(const sPosition &pos1, const sPosition &pos2, const sColor &color, bool useCamera)
{
    glLoadIdentity();
    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(pos1) || IsInCameraArea(pos2)) {
            sPosition camPos1 = RealToCameraCoordinates(pos1);
            sPosition camPos2 = RealToCameraCoordinates(pos2);

            glTranslatef(0, 0, 0);
			float *openGlValues = color.GetOpenGLValues();
            glColor4fv(openGlValues);
			delete[] openGlValues;
            glBegin(GL_LINES);
                glVertex3f(camPos1.x, camPos1.y, 0);
                glVertex3f(camPos2.x, camPos2.y, 0);
            glEnd();
        }
    } else {
        glTranslatef(0, 0, 0);
		float *glValues = color.GetOpenGLValues();
        glColor4fv(glValues);
		delete[] glValues;
        glBegin(GL_LINES);
            glVertex3f(pos1.x, pos1.y, 0);
            glVertex3f(pos2.x, pos2.y, 0);
        glEnd();
    }
}

/* Function DrawRectangle()
 * Draws a simple rectangle at the specified position and of
   the specified size with a border of the specified color */
void cGraphics::DrawRectangle(const sRect &rect, const sColor &color, bool useCamera, float rotation)
{
    glLoadIdentity();
    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(rect)) {
            sPosition camRectPos = RealToCameraCoordinates(sPosition(rect.x, rect.y));
            glTranslatef(camRectPos.x, camRectPos.y, 0);
            glRotatef(rotation ,0,0,-1);
            float *glValues = color.GetOpenGLValues();
			glColor4fv(glValues);
			delete[] glValues;
            glBegin(GL_LINE_LOOP);
                glVertex3f(0, 0, 0);
                glVertex3f(rect.w, 0, 0);
                glVertex3f(rect.w, rect.h, 0);
                glVertex3f(0, rect.h, 0);
            glEnd();
        }
    } else {
        glTranslatef(rect.x, rect.y, 0);
        glRotatef(rotation ,0,0,-1);
        float *glValues = color.GetOpenGLValues();
        glColor4fv(glValues);
		delete[] glValues;
        glBegin(GL_LINE_LOOP);
            glVertex3f(0, 0, 0);
            glVertex3f(rect.w, 0, 0);
            glVertex3f(rect.w, rect.h, 0);
            glVertex3f(0, rect.h, 0);
        glEnd();
    }
}

/* Function DrawFilledRectangle()
 * Draws a simple rectangle (filled with the specified color) at the
   specified position and of the specified size */
void cGraphics::DrawFilledRectangle(const sRect &rect, const sColor &color, bool useCamera, float rotation)
{
    glLoadIdentity();
    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(rect)) {
            sPosition camRectPos = RealToCameraCoordinates(sPosition(rect.x, rect.y));
            glTranslatef(camRectPos.x, camRectPos.y, 0);
            glRotatef(rotation ,0,0,-1);
            float *glValues = color.GetOpenGLValues();
			glColor4fv(glValues);
			delete[] glValues;
            glBegin(GL_QUADS);
                glVertex3f(0, 0, 0);
                glVertex3f(rect.w, 0, 0);
                glVertex3f(rect.w, rect.h, 0);
                glVertex3f(0, rect.h, 0);
            glEnd();
        }
    } else {
        glTranslatef(rect.x, rect.y, 0);
        glRotatef(rotation ,0,0,-1);
        float *glValues = color.GetOpenGLValues();
        glColor4fv(glValues);
		delete[] glValues;
        glBegin(GL_QUADS);
            glVertex3f(0, 0, 0);
            glVertex3f(rect.w, 0, 0);
            glVertex3f(rect.w, rect.h, 0);
            glVertex3f(0, rect.h, 0);
        glEnd();
    }
}

void cGraphics::DrawTexturedRectangle(const sPosition &pos, const std::string &filepath, bool useCamera, float rotation)
{
    cTexture *texture = textureManager->GetTexture(filepath);
    sRect rect(pos.x, pos.y, texture->GetSize().w, texture->GetSize().h);
    DrawTexturedRectangle(rect, texture, useCamera, rotation);
}

void cGraphics::DrawTexturedRectangle(const sRect &rect, const std::string &filepath, bool useCamera, float rotation)
{
    cTexture *texture = textureManager->GetTexture(filepath);
    DrawTexturedRectangle(rect, texture, useCamera, rotation);
}

void cGraphics::DrawTexturedRectangle(const sPosition &pos, cTexture *texture, bool useCamera, float rotation)
{
    sRect rect(pos.x, pos.y, texture->GetSize().w, texture->GetSize().h);
    DrawTexturedRectangle(rect, texture, useCamera, rotation);
}

void cGraphics::DrawTexturedRectangle(const sRect &rect, cTexture *texture, bool useCamera, float rotation)
{
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glColor4f(1, 1, 1, 1);
    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(rect)) {
            sPosition camRectPos = RealToCameraCoordinates(sPosition(rect.x, rect.y));
            sSize texSize = texture->GetOpenGLSize();

            //cout << "OpenGL tex size: " << texSize.w << "x" << texSize.h << endl;

            glTranslatef(camRectPos.x, camRectPos.y, 0);
            glRotatef(rotation ,0,0,-1);
            glBindTexture (GL_TEXTURE_2D, *texture->GetOpenGLTexture());
            glBegin(GL_QUADS);
                glTexCoord2f(0, 0); glVertex3f(0, 0, 0);
                glTexCoord2f(texSize.w, 0); glVertex3f(rect.w, 0, 0);
                glTexCoord2f(texSize.w, texSize.h); glVertex3f(rect.w, rect.h, 0);
                glTexCoord2f(0, texSize.h); glVertex3f(0, rect.h, 0);
            glEnd();
        }
    } else {
        sSize texSize = texture->GetOpenGLSize();

        //cout << "OpenGL tex size: " << texSize.w << "x" << texSize.h << endl;

        glTranslatef(rect.x, rect.y, 0);
        glRotatef(rotation ,0,0,-1);
        glBindTexture (GL_TEXTURE_2D, *texture->GetOpenGLTexture());
        glBegin(GL_QUADS);
            glTexCoord2f(0, 0); glVertex3f(0, 0, 0);
            glTexCoord2f(texSize.w, 0); glVertex3f(rect.w, 0, 0);
            glTexCoord2f(texSize.w, texSize.h); glVertex3f(rect.w, rect.h, 0);
            glTexCoord2f(0, texSize.h); glVertex3f(0, rect.h, 0);
        glEnd();
    }
    glDisable(GL_TEXTURE_2D);
}

/* Function DrawCircle
 * Draws a circle at the specified position, with the specified radius
   with a border of the specified color */
void cGraphics::DrawCircle(const sCircle &circle, const sColor &color, bool useCamera)
{
    glLoadIdentity();
    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(circle)) {
            sPosition camCirclePos = RealToCameraCoordinates(sPosition(circle.x, circle.y));
            glTranslatef(camCirclePos.x, camCirclePos.y, 0);
            float *glValues = color.GetOpenGLValues();
			glColor4fv(glValues);
			delete[] glValues;
            glBegin(GL_LINE_LOOP);
                float x = 0, y = 0;
                for (int i = 0; i < 360; i++) {
                    x = cos((float) i) * circle.r;
                    y = sin((float) i) * circle.r;
                    glVertex3f(x, y, 0);
                }
            glEnd();
        }
    } else {
        glTranslatef(circle.x, circle.y, 0);
        float *glValues = color.GetOpenGLValues();
        glColor4fv(glValues);
		delete[] glValues;
        glBegin(GL_LINE_LOOP);
            float x = 0, y = 0;
            for (int i = 0; i < 360; i++) {
                x = cos((float) i) * circle.r;
                y = sin((float) i) * circle.r;
                glVertex3f(x, y, 0);
            }
        glEnd();
    }
}

/* Function DrawFilledCircle
 * Draws a circle (filled with the specified color) at the specified
   position, with the specified radius */
void cGraphics::DrawFilledCircle(const sCircle &circle, const sColor &color, bool useCamera)
{
    glLoadIdentity();
    if (useCamera && IsCameraSet()) {
        sPosition camCirclePos = RealToCameraCoordinates(sPosition(circle.x, circle.y));
        if (IsInCameraArea(circle)) {
            glTranslatef(camCirclePos.x, camCirclePos.y, 0);
            float *glValues = color.GetOpenGLValues();
			glColor4fv(glValues);
			delete[] glValues;
            glBegin(GL_TRIANGLE_FAN);
                float x = 0, y = 0;
                glVertex3f(-circle.r, 0, 0);
                glVertex3f(circle.r, 0, 0);
                for (int i = 1; i < 360; i++) {
                    x = cos((float) i) * circle.r;
                    y = sin((float) i) * circle.r;
                    glVertex3f(x, y, 0);
                }
            glEnd();
        }
    } else {
        glTranslatef(circle.x, circle.y, 0);
        float *glValues = color.GetOpenGLValues();
        glColor4fv(glValues);
		delete[] glValues;
        glBegin(GL_TRIANGLE_FAN);
            float x = 0, y = 0;
            glVertex3f(-circle.r, 0, 0);
            glVertex3f(circle.r, 0, 0);
            for (int i = 1; i < 360; i++) {
                x = cos((float) i) * circle.r;
                y = sin((float) i) * circle.r;
                glVertex3f(x, y, 0);
            }
        glEnd();
    }
}

void cGraphics::DrawTexturedCircle(const sCircle &circle, cTexture *texture, bool useCamera, float rotation)
{
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    glColor4f(1, 1, 1, 1);
    if (useCamera && IsCameraSet()) {
        sPosition camCirclePos = RealToCameraCoordinates(sPosition(circle.x, circle.y));
        if (IsInCameraArea(circle)) {
            sSize glTexSize = texture->GetOpenGLSize();
            sPosition middle = sPosition(glTexSize.w / 2, glTexSize.h / 2);

            glBindTexture (GL_TEXTURE_2D, *texture->GetOpenGLTexture());
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
            glTranslatef(camCirclePos.x, camCirclePos.y, 0);
            glRotatef(rotation ,0,0,-1);
            glBegin(GL_TRIANGLE_FAN);
                float x = 0, y = 0;
                glTexCoord2f(0.0, middle.y); glVertex3f(-circle.r, 0, 0);
                glTexCoord2f(glTexSize.w, middle.y); glVertex3f(circle.r, 0, 0);
                for (int i = 1; i < 360; i++) {
                    x = cos((float) i) * circle.r;
                    y = sin((float) i) * circle.r;
                    glTexCoord2f(middle.x + (x / circle.r / 2) * glTexSize.w, middle.y + (y / circle.r / 2) * glTexSize.h); glVertex3f(x, y, 0);
                }
            glEnd();
        }
    } else {
        sSize glTexSize = texture->GetOpenGLSize();
        sPosition middle = sPosition(glTexSize.w / 2, glTexSize.h / 2);

        glBindTexture (GL_TEXTURE_2D, *texture->GetOpenGLTexture());
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        glTranslatef(circle.x, circle.y, 0);
        glRotatef(rotation ,0,0,-1);
        glBegin(GL_TRIANGLE_FAN);
            float x = 0, y = 0;
            glTexCoord2f(0.0, middle.y); glVertex3f(-circle.r, 0, 0);
            glTexCoord2f(glTexSize.w, middle.y); glVertex3f(circle.r, 0, 0);
            for (int i = 1; i < 360; i++) {
                x = cos((float) i) * circle.r;
                y = sin((float) i) * circle.r;
                glTexCoord2f(middle.x + (x / circle.r / 2) * glTexSize.w, middle.y + (y / circle.r / 2) * glTexSize.h); glVertex3f(x, y, 0);
            }
        glEnd();
    }
    glDisable(GL_TEXTURE_2D);
}

/* Function DrawPolygon
 * Draws a polygon containing the specified vertices with a border
   of the specified color */
void cGraphics::DrawPolygon(const sPolygon &polygon, const sColor &color, bool useCamera, float rotation)
{
    vector< sPosition >::const_iterator it;
    glLoadIdentity();
    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(polygon)) {
            glTranslatef(0, 0, 0);
            glRotatef(rotation ,0,0,-1);
            float *glValues = color.GetOpenGLValues();
			glColor4fv(glValues);
			delete[] glValues;
            glBegin(GL_LINE_LOOP);
                sPosition currentCamPos;
                for (it = polygon.vertices.begin(); it != polygon.vertices.end(); it++) {
                    currentCamPos = RealToCameraCoordinates(*it);
                    glVertex3f(currentCamPos.x, currentCamPos.y, 0);
                }
            glEnd();
        }
    } else {
        glTranslatef(0, 0, 0);
        glRotatef(rotation ,0,0,-1);
        float *glValues = color.GetOpenGLValues();
        glColor4fv(glValues);
		delete[] glValues;
        glBegin(GL_LINE_LOOP);
            sPosition currentPos;
            for (it = polygon.vertices.begin(); it != polygon.vertices.end(); it++) {
                currentPos = *it;
                glVertex3f(currentPos.x, currentPos.y, 0);
            }
        glEnd();
    }
}

/* Function DrawFilledPolygon
 * Draws a polygon containing the specified vertices filled with
   the specified color */
void cGraphics::DrawFilledPolygon(const sPolygon &polygon, const sColor &color, bool useCamera, float rotation)
{
    vector< sPosition >::const_iterator it;
    glLoadIdentity();
    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(polygon)) {
            glTranslatef(0, 0, 0);
            glRotatef(rotation ,0,0,-1);
            float *glValues = color.GetOpenGLValues();
			glColor4fv(glValues);
			delete[] glValues;
            glBegin(GL_POLYGON);
                sPosition currentCamPos;
                for (it = polygon.vertices.begin(); it != polygon.vertices.end(); it++) {
                    currentCamPos = RealToCameraCoordinates(*it);
                    glVertex3f(currentCamPos.x, currentCamPos.y, 0);
                }
            glEnd();
        }
    } else {
        glTranslatef(0, 0, 0);
        glRotatef(rotation ,0,0,-1);
        float *glValues = color.GetOpenGLValues();
        glColor4fv(glValues);
		delete[] glValues;
        glBegin(GL_POLYGON);
            sPosition currentPos;
            for (it = polygon.vertices.begin(); it != polygon.vertices.end(); it++) {
                currentPos = *it;
                glVertex3f(currentPos.x, currentPos.y, 0);
            }
        glEnd();
    }
}

void cGraphics::DrawTexturedPolygon(const sPolygon &polygon, const std::string &filepath, bool useCamera, float rotation)
{
    cTexture *texture = textureManager->GetTexture(filepath);
    DrawTexturedPolygon(polygon, texture, useCamera, rotation);
}

void cGraphics::DrawTexturedPolygon(const sPolygon &polygon, cTexture *texture, bool useCamera, float rotation)
{
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    glColor4f(1, 1, 1, 1);
    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(polygon)) {
            vector< sPosition >::const_iterator it;

            sSize texSize = texture->GetOpenGLSize();
            //sPosition camPolyCenter = RealToCameraCoordinates(polygon.GetVirtualRect().GetCenter());
            glBindTexture (GL_TEXTURE_2D, *texture->GetOpenGLTexture());
            sRect camPolyRect = RealToCameraCoordinates(polygon.GetVirtualRect());
            glTranslatef(0, 0, 0);
            glRotatef(rotation ,0,0,-1);
            glBegin(GL_POLYGON);
                sPosition currentCamPos;
                for (it = polygon.vertices.begin(); it != polygon.vertices.end(); it++) {
                    currentCamPos = RealToCameraCoordinates(*it);
                    glTexCoord2f((currentCamPos.x - camPolyRect.x) / camPolyRect.w * texSize.w, (currentCamPos.y - camPolyRect.y) / camPolyRect.h * texSize.h); glVertex3f(currentCamPos.x, currentCamPos.y, 0);
                }
            glEnd();
        }
    } else {
        sSize glTexSize = texture->GetOpenGLSize();
        sRect polyRect = polygon.GetVirtualRect();

        vector< sPosition >::const_iterator it;

        sSize texSize = texture->GetOpenGLSize();
        glBindTexture (GL_TEXTURE_2D, *texture->GetOpenGLTexture());

        glTranslatef(0, 0, 0);
        glRotatef(rotation ,0,0,-1);
        glBegin(GL_POLYGON);
            sPosition currentPos;
            for (it = polygon.vertices.begin(); it != polygon.vertices.end(); it++) {
                currentPos = *it;
                glTexCoord2f((currentPos.x - polyRect.x) / polyRect.w * texSize.w, (currentPos.y - polyRect.y) / polyRect.h * texSize.h); glVertex3f(currentPos.x, currentPos.y, 0);
            }
        glEnd();
    }
    glDisable(GL_TEXTURE_2D);
}

void cGraphics::RectFillTexture(const sRect &rect, const std::string &filepath, bool useCamera)
{
    cTexture *texture = textureManager->GetTexture(filepath);
    RectFillTexture(rect, texture, useCamera);
}

void cGraphics::RectFillTexture(const sRect &rect, cTexture *texture, bool useCamera)
{
    sSize textureSize = texture->GetSize();
    if (useCamera) {
        if (IsInCameraArea(rect)) {
            sRect rectInCamera = RealToCameraCoordinates(rect);
            float initialXPos = max((float)(0.0 + fmod(rectInCamera.x, textureSize.w)), rectInCamera.x);
            float initialYPos = max((float)(0.0 + fmod(rectInCamera.y, textureSize.h)), rectInCamera.y);
            float currentXPos = initialXPos;
            float currentYPos = initialYPos;
            //Vertical Fill
            while (currentYPos < rectInCamera.y + rectInCamera.h && currentYPos < _height) {
                //Horizontal Fill
                while(currentXPos < rectInCamera.x + rectInCamera.w && currentXPos < _width) {
                    DrawTexturedRectangle(sRect(sPosition(currentXPos, currentYPos), textureSize), texture, false);
                    currentXPos += textureSize.w;
                }
                currentYPos += textureSize.h;
                currentXPos = initialXPos;
            }
        }
    } else {
        float currentXPos = rect.x;
        float currentYPos = rect.y;
        //Vertical Fill
        while (currentYPos < rect.y + rect.h && currentYPos < _height) {
            //Horizontal Fill
            while(currentXPos < rect.x + rect.w && currentXPos < _width) {
                DrawTexturedRectangle(sRect(sPosition(currentXPos, currentYPos), textureSize), texture, false);
                currentXPos += textureSize.w;
            }
            currentYPos += textureSize.h;
            currentXPos = rect.x;
        }
    }
}

void cGraphics::PolyFillTexture(const sPolygon &polygon, const std::string &filepath, bool useCamera, sVector offset)
{
    cTexture *texture = textureManager->GetTexture(filepath);
    PolyFillTexture(polygon, texture, useCamera, offset);
}

void cGraphics::PolyFillTexture(const sPolygon &polygon, cTexture *texture, bool useCamera, sVector offset)
{
    sSize openGLTexSize = texture->GetOpenGLSize();
    sSize realTexSize = texture->GetSize();

    //Check if openGL size refers to the entire texture. If not, the texture is padded which means it was not a power of 2
    if (openGLTexSize.h != 1.0 || openGLTexSize.w != 1.0) {
        cerr << "PolyFillTexture() can only handle textures whose height and width are powers of 2" << endl;
		return;
    }

    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glColor4f(1, 1, 1, 1);
    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(polygon)) {
            vector< sPosition >::const_iterator it;

            //sPosition camPolyCenter = RealToCameraCoordinates(polygon.GetVirtualRect().GetCenter());
            glBindTexture (GL_TEXTURE_2D, *texture->GetOpenGLTexture());
            sRect camPolyRect = RealToCameraCoordinates(polygon.GetVirtualRect());
            glTranslatef(0, 0, 0);
            glBegin(GL_POLYGON);
                sPosition currentCamPos;
                for (it = polygon.vertices.begin(); it != polygon.vertices.end(); it++) {
                    currentCamPos = RealToCameraCoordinates(*it);
                    //cout << "Polygon tex offset: " << offset.x << "x" << offset.y << endl;
                    //cout << "Polygon tex coord: " << ((currentCamPos.x - camPolyRect.x + offset.x) / realTexSize.w) << "x" << ((currentCamPos.y - camPolyRect.y + offset.y) / realTexSize.h) << endl;
                    glTexCoord2f((currentCamPos.x - camPolyRect.x + offset.x) / realTexSize.w, (currentCamPos.y - camPolyRect.y + offset.y) / realTexSize.h); glVertex3f(currentCamPos.x, currentCamPos.y, 0);
                }
            glEnd();
        }
    } else {
        sSize glTexSize = texture->GetOpenGLSize();
        sRect polyRect = polygon.GetVirtualRect();

        vector< sPosition >::const_iterator it;

        sSize texSize = texture->GetOpenGLSize();
        glBindTexture (GL_TEXTURE_2D, *texture->GetOpenGLTexture());

        glTranslatef(0, 0, 0);
        glBegin(GL_POLYGON);
            sPosition currentPos;
            for (it = polygon.vertices.begin(); it != polygon.vertices.end(); it++) {
                currentPos = *it;
                //cout << "Polygon tex coord: " << ((currentPos.x - polyRect.x + offset.x) / realTexSize.w) << "x" << ((currentPos.y - polyRect.y + offset.y) / realTexSize.h) << endl;
                glTexCoord2f((currentPos.x - polyRect.x + offset.x) / realTexSize.w, (currentPos.y - polyRect.y + offset.y) / realTexSize.h); glVertex3f(currentPos.x, currentPos.y, 0);
            }
        glEnd();
    }
    glDisable(GL_TEXTURE_2D);
}

void cGraphics::DrawText(const sPosition &pos, const std::string &text, const std::string &fontname, int fontsize, const sColor &color, bool useCamera, sRect *clipArea)
{
    //cout << "Drawing text: " << endl;
    cFont *font = fontManager->GetFont(fontname, fontsize);

    DrawText(pos, text, font, color, useCamera, clipArea);
}

void cGraphics::DrawText(const sPosition &pos, const std::string &text, cFont *font, const sColor &color, bool useCamera, sRect *clipArea)
{
    //cout << "Drawing text at " << pos.x << "x" << pos.y << endl;

    if (font == NULL) {
        return;
    }

    if (clipArea != NULL) {
        glLoadIdentity();
        glTranslatef(floor(clipArea->x), floor(clipArea->y), 0);

        double top[] = {0.0, 1.0, 0.0, 0.0};
        double bottom[] = {0.0, -1.0, 0.0, clipArea->h};
        double left[] = {1.0, 0.0, 0.0, 0.0};
        double right[] = {-1.0, 0.0, 0.0, clipArea->w};

        glClipPlane(GL_CLIP_PLANE0, top);
        glClipPlane(GL_CLIP_PLANE1, bottom);
        glClipPlane(GL_CLIP_PLANE2, left);
        glClipPlane(GL_CLIP_PLANE3, right);

        glEnable(GL_CLIP_PLANE0);
        glEnable(GL_CLIP_PLANE1);
        glEnable(GL_CLIP_PLANE2);
        glEnable(GL_CLIP_PLANE3);
    }

    glPushAttrib(GL_LIST_BIT | GL_CURRENT_BIT  | GL_ENABLE_BIT | GL_TRANSFORM_BIT);
	glMatrixMode(GL_MODELVIEW);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glListBase(font->GetDisplayList());

	glLoadIdentity();

    glTranslatef(floor(pos.x), floor(pos.y), 0);

    float *glValues = color.GetOpenGLValues();
    glColor4fv(glValues);
	delete[] glValues;
    glCallLists(text.length(), GL_UNSIGNED_BYTE, text.c_str());

    glPopAttrib();
    glDisable(GL_TEXTURE_2D);
    if (clipArea != NULL) {
        glDisable(GL_CLIP_PLANE0);
        glDisable(GL_CLIP_PLANE1);
        glDisable(GL_CLIP_PLANE2);
        glDisable(GL_CLIP_PLANE3);
    }
    //cout << "Finished Drawing text: " << endl;
}

/* Function UpdateScreen()
 * Flips the game window surface so that changes made in memory appear on the screen. */
bool cGraphics::UpdateScreen()
{
    /*if ( SDL_MUSTLOCK(_mainWindow) ) {
        SDL_UnlockSurface(_mainWindow);
    }*/

    SDL_GL_SwapBuffers();

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //Clear OpenGL Screen and Depth buffers
    glLoadIdentity(); //Reload modelview matrix

    /*if ( SDL_MUSTLOCK(_mainWindow) ) {
        SDL_LockSurface(_mainWindow);
    }*/

    _frame++;

    if (_fpsTimer->GetTicks() > 1000) {
        _fps = _frame - 1;
        _frame = 0;
        _fpsTimer->Start();
    }

    if (_fpsLimit > 0 && _frameTimer->GetTicks() < (1000 / _fpsLimit)) {
        Sleep((1000 / _fpsLimit) - _frameTimer->GetTicks());
    }

    _frameTimer->Start();
    return true;
}

/* Function CapFPS
 * Sets the value at which to cap the fps. If it is set to 0
   then fps aren't capped. */
void cGraphics::CapFPS(int fps)
{
    if (fps >= 0) {
        _fpsLimit = fps;
        _frameTimer->Start();
    }
}

/* Function GetFPSCap
 * Returns the value at which fps are capped */
int cGraphics::GetFPSCap()
{
    return _fpsLimit;
}

/* Function GetCurrentFPS
 * Returns the current number of frames per second */
int cGraphics::GetCurrentFPS()
{
    return _fps;
}

/* Function SetCamera
 * Sets a camera (default area = screen area) that is able to
   move around a level of the specified bounds */
void cGraphics::SetCamera(sRect *bounds, sRect *area)
{
    if (area != NULL) {
        _camera = new sRect(area->x, area->y, area->w, area->h);
    } else {
        _camera = new sRect(0, 0, _width, _height);
    }
    if (bounds != NULL) {
        //If the bound box isn't smaller than the camera
        _cameraBounds = new sRect(bounds->x, bounds->y, bounds->w, bounds->h);
        if (_cameraBounds->w < _camera->w) {
            _cameraBounds->w = _camera->w;
        }
        else if (_cameraBounds->h < _camera->h) {
            _cameraBounds->h = _camera->h;
        }
        MoveCamera(sPosition(bounds->x, bounds->y));
    }
}

sPosition cGraphics::GetCameraPosition()
{
    return _camera->GetCenter();
}

/* Function UnsetCamera
 * Unsets the set camera and its bounds */
void cGraphics::UnsetCamera()
{
    _camera = NULL;
    _cameraBounds = NULL;
}

/* Function IsCameraSet
 * Checks if the camera is set */
bool cGraphics::IsCameraSet()
{
    return _camera != NULL;
}

/* Function MoveCamera
 * Moves the camera to the specified position or to the
   closest position if bounds are set */
void cGraphics::MoveCamera(const sPosition &pos)
{
    if (_camera == NULL) {
        return;
    }

    _camera->x = pos.x;
    _camera->y = pos.y;

    //cout << "Camera Bounds - X:" << _cameraBounds->x << " Y:" << _cameraBounds->y << " W:" << _cameraBounds->w << " H:" << _cameraBounds->h << endl;
    //cout << "Move camera - X:" << _camera->x << " Y:" << _camera->y << endl;

    if (_cameraBounds != NULL) {
        if (_camera->x < _cameraBounds->x) {
            _camera->x = _cameraBounds->x;
        }
        if (_camera->y < _cameraBounds->y) {
            _camera->y = _cameraBounds->y;
        }
        if (_camera->x + _camera->w > _cameraBounds->x + _cameraBounds->w) {
            _camera->x = (_cameraBounds->x + _cameraBounds->w) - _camera->w;
        }
        if (_camera->y + _camera->h > _cameraBounds->y + _cameraBounds->h) {
            _camera->y = (_cameraBounds->y + _cameraBounds->h) - _camera->h;
        }
    }
    //cout << "After Move camera - X:" << _camera->x << " Y:" << _camera->y << endl;
}

/* Function CenterCameraOnPosition
 * Centers the camera on the specified position (or the closest one
   if camera bounds are breached) */
void cGraphics::CenterCameraOnPosition(const sPosition &pos)
{
    if (_camera == NULL) {
        return;
    }

    int x = pos.x - _camera->w / 2;
    int y = pos.y - _camera->h / 2;

    MoveCamera(sPosition(x, y));
}

/* Function IsInCameraArea
 * Checks if the specified object (sRect, sCircle, sPolygon, sPosition) is
   inside the current camera area */
bool cGraphics::IsInCameraArea(const sPosition &pos)
{
    if (pos.x < _camera->x || pos.y < _camera->y || pos.x > _camera->x + _camera->w || pos.y > _camera->y + _camera->h) {
        return false;
    } else {
        return true;
    }
}

bool cGraphics::IsInCameraArea(const sRect &rect)
{
    /*cout << "Camera Area Test **************" << endl;
    cout << "Area: " << rect.x << "-" << rect.y << "-" << rect.w << "-" << rect.h << endl;
    cout << "Camera: " << _camera->x << "-" << _camera->y << "-" << _camera->w << "-" << _camera->h << endl;
    cout << (rect.x + rect.w < _camera->x) << endl;
    cout << (rect.y + rect.h < _camera->y) << endl;
    cout << (rect.x > _camera->x + _camera->w) << endl;
    cout << (rect.y > _camera->y + _camera->h) << endl;*/
    if (rect.x + rect.w < _camera->x || rect.y + rect.h < _camera->y || rect.x > _camera->x + _camera->w || rect.y > _camera->y + _camera->h) {
        return false;
    } else {
        return true;
    }
}

bool cGraphics::IsInCameraArea(const sCircle &circle)
{
    if (circle.x + circle.r < _camera->x || circle.y + circle.r < _camera->y || circle.x - circle.r > _camera->x + _camera->w || circle.y - circle.r > _camera->y + _camera->h) {
        return false;
    } else {
        return true;
    }
}

bool cGraphics::IsInCameraArea(const sPolygon &poly)
{
    sRect virtualRect = poly.GetVirtualRect();
    return IsInCameraArea(virtualRect);
}

/* Function GetWindowArea
 * Returns the dimensions of the application window */
sRect cGraphics::GetWindowArea()
{
    return sRect(0, 0, _width, _height);
}

bool cGraphics::InitializeOpenGL()
{
    glClearColor( 1, 1, 1, 0);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_BLEND);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, _width, _height, 0, -1, 1);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    if (glGetError() != GL_NO_ERROR) {
        cerr << "Unable to initialize OpenGL: " << glGetError() << endl;
    }

    return true;
}

/* Function DrawSurface
 * Draws the specified surface at the specified position.

 * Note: This function is for eternal use. Use one of the public Draw
   functions instead */
void cGraphics::DrawSurface(int x, int y, SDL_Surface *surface, bool useCamera, sRect *clipArea)
{
    return;
    if (surface == NULL) {
        return;
    }

    SDL_Rect position;
    SDL_Rect *clip = NULL;
    if (clipArea != NULL) {
        clip = new SDL_Rect();
        clip->x = clipArea->x;
        clip->y = clipArea->y;
        clip->h = clipArea->h;
        clip->w = clipArea->w;
    }

    if (useCamera && IsCameraSet()) {
        if (IsInCameraArea(sRect(x, y, surface->w, surface->h))) {
            sPosition camPos = RealToCameraCoordinates(sPosition(x, y));
            position.x = camPos.x;
            position.y = camPos.y;
        }
    } else {
        position.x = x;
        position.y = y;

    }

    int result = SDL_BlitSurface(surface, clip, _mainWindow, &position);

    if (result!= 0) {
        cerr << "Blit failed: " << result << endl;
    }

    delete clip;
}

/* Function RealToCameraCoordinates
 * Transforms the real coordinates of a position to the coordinates relative
   to the current camera */
sPosition cGraphics::RealToCameraCoordinates(const sPosition &realPos)
{
    if (_camera == NULL) {
        return realPos;
    } else {
        return sPosition(realPos.x - _camera->x, realPos.y - _camera->y);
    }
}

sRect cGraphics::RealToCameraCoordinates(const sRect &realRect)
{
    if (_camera == NULL) {
        return realRect;
    } else {
        return sRect(realRect.x - _camera->x, realRect.y - _camera->y, realRect.w, realRect.h);
    }
}

}

