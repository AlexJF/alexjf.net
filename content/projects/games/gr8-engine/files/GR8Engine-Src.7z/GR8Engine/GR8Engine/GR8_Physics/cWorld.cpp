/**\file cWorld.cpp
   \author Revolt
   \brief Implements the cWorld class defined on cWorld.h.
*/

#include "cWorld.h"

using namespace std;

namespace GR8 {

cWorld::cWorld()
{
    _worldArea = sRect(0, 0, 0, 0);
    _world = NULL;
    _screen = NULL;
    _pixelMeterScale = 30.0;
    _timestep = (float32)1.0 / 60.0;
    _iterations = 10;
}

cWorld::~cWorld()
{
    Shutdown();
}

bool cWorld::Initialize(cScreen *owner, const sRect &area, float pixelMeterScale, const sVector &globalAccel, bool sleepInactive)
{
    if (_world != NULL) {
        return false;
    }
    _screen = owner;
    _pixelMeterScale = pixelMeterScale;

    b2AABB worldAABB;
    worldAABB.lowerBound.Set(area.x, area.y);
    worldAABB.upperBound.Set(area.x + area.w, area.y + area.h);

    b2Vec2 gAccel(globalAccel.x , globalAccel.y);

    _world = new b2World(worldAABB, gAccel, sleepInactive);

    _worldArea = area;
    _bodies.clear();

    return true;
}

void cWorld::Update()
{
    if (_world != NULL) {
        _world->Step(1.0/60.0, 10);
        vector< cBody* >::iterator it;
        for (it = _bodies.begin(); it != _bodies.end(); it++) {
            cBody *currentBody = *it;
            currentBody->Update();
        }
    }
}

void cWorld::HandleEvent(cEvent *event)
{
	cout << "Enter World handle event" << endl;
    if (_world != NULL) {
        vector< cBody* >::iterator it;
        for (it = _bodies.begin(); it != _bodies.end(); it++) {
            cBody *currentBody = *it;
            currentBody->HandleEvent(event);
        }
    }
	cout << "Begin World handle event" << endl;
}

void cWorld::DrawBodies()
{
    if (_world != NULL) {
        vector< cBody* >::iterator it;
        for (it = _bodies.begin(); it != _bodies.end(); it++) {
            cBody *currentBody = *it;
            currentBody->Draw();
        }
    }
}

void cWorld::Shutdown()
{
	cout << "Entering World Shutdown" << endl;
    if (_world != NULL) {
        RemoveAllBodies();
        delete _world;
        _screen = NULL;
    }
	cout << "Leaving World Shutdown" << endl;
}

bool cWorld::AddBody(cBody *body)
{
    if (_world == NULL) {
        return false;
    }

    //Add body to the world and set the internal pointer (_body) of the cBody object to the resulting b2Body object
    body->_body = _world->CreateBody(&(body->_bodydef));
    body->Initialize(this);

    //Add body to the vector
    _bodies.push_back(body);

    return true;
}

cBody* cWorld::GetBody(const std::string &bodyID)
{
    vector< cBody* >::iterator it;
    for (it = _bodies.begin(); it != _bodies.end(); it++) {
        cBody *currentBody = *it;
        if (currentBody->GetID() == bodyID) {
            return currentBody;
        }
    }

    return NULL;
}

void cWorld::RemoveBody(const std::string &bodyID)
{
    vector< cBody* >::iterator it;
    for (it = _bodies.begin(); it != _bodies.end(); it++) {
        cBody *currentBody = *it;
        if (currentBody->GetID() == bodyID) {
            _world->DestroyBody(currentBody->_body);
            delete currentBody;
            _bodies.erase(it);
        }
    }
}

void cWorld::RemoveAllBodies()
{
	cout << "Removing " << _bodies.size() << " bodies" << endl;
    vector< cBody* >::iterator it;
    for (it = _bodies.begin(); it != _bodies.end(); ++it) {
		cout << "Removing body" << endl;
        cBody *currentBody = *it;
        _world->DestroyBody(currentBody->_body);
        delete currentBody;
    }
	_bodies.clear();
}

void cWorld::ChangeGlobalAccel(const sVector &globalAccel)
{
    if (_world != NULL) {
        _world->SetGravity(b2Vec2(globalAccel.x, globalAccel.y));
    }
}

float cWorld::ChangePixelMeterScale(float pixelMeterScale)
{
    if (pixelMeterScale > 0) {
       _pixelMeterScale = pixelMeterScale;
    }

    return _pixelMeterScale;
}

sPosition cWorld::ToScreen(const sPosition &pos)
{
    sRect worldArea = _worldArea;
    sPosition screenPos;
    screenPos.x = ToScreen(pos.x);
    screenPos.y = ToScreen((worldArea.y + worldArea.h) - pos.y);

    return screenPos;
}

sCircle cWorld::ToScreen(const sCircle &circle)
{
    sRect worldArea = _worldArea;
    sCircle screenCircle;
    screenCircle.x = ToScreen(circle.x);
    screenCircle.y = ToScreen((worldArea.y + worldArea.h) - circle.y);
    screenCircle.r = ToScreen(circle.r);

    return screenCircle;
}

sRect cWorld::ToScreen(const sRect &rect)
{
    sRect screenRect;
    sRect worldArea = _worldArea;
    screenRect.x = ToScreen(rect.x);
    screenRect.y = ToScreen((worldArea.y + worldArea.h) - rect.y);
    screenRect.w = ToScreen(rect.w);
    screenRect.h = ToScreen(rect.h);

    return screenRect;
}

sPolygon cWorld::ToScreen(const sPolygon &poly)
{
    sPolygon screenPoly;
    vector< sPosition >::const_iterator it;

    for (it = poly.vertices.begin(); it != poly.vertices.end(); it++) {
        sPosition currentVertice = *it;
        screenPoly.vertices.push_back(ToScreen(currentVertice));
    }

    return screenPoly;
}

sPosition cWorld::ToWorld(const sPosition &pos)
{
    sRect worldArea = _worldArea;
    sPosition worldPos;
    worldPos.x = ToWorld(pos.x);
    worldPos.y = (worldArea.y + worldArea.h) - ToWorld(pos.y);

    return worldPos;
}

sCircle cWorld::ToWorld(const sCircle &circle)
{
    sRect worldArea = _worldArea;
    sCircle worldCircle;
    worldCircle.x = ToWorld(circle.x);
    worldCircle.y = (worldArea.y + worldArea.h) - ToWorld(circle.y);
    worldCircle.r = ToWorld(circle.r);

    return worldCircle;
}

sRect cWorld::ToWorld(const sRect &rect)
{
    sRect worldArea = _worldArea;
    sRect worldRect;
    worldRect.x = ToWorld(rect.x);
    worldRect.y = (worldArea.y + worldArea.h) - ToWorld(rect.y);
    worldRect.w = ToWorld(rect.w);
    worldRect.h = ToWorld(rect.h);

    return worldRect;
}

sPolygon cWorld::ToWorld(const sPolygon &poly)
{
    sPolygon worldPoly;
    vector< sPosition >::const_iterator it;

    for (it = poly.vertices.begin(); it != poly.vertices.end(); it++) {
        sPosition currentVertice = *it;
        worldPoly.vertices.push_back(ToWorld(currentVertice));
    }

    return worldPoly;
}

float cWorld::ToScreen(float number)
{
    return number * _pixelMeterScale;
}

float cWorld::ToWorld(float number)
{
    return number / _pixelMeterScale;
}

sRect cWorld::GetArea()
{
    return _worldArea;
}

cScreen* cWorld::GetScreen()
{
    return _screen;
}

}
