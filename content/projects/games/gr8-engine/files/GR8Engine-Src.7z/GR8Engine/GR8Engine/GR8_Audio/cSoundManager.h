/*****************************************************************************************
 * cSoundManager.h - Declaration of the SoundManager, SoundEffect and Music class which  *
 *                   are part of GR8 Audio.                                             *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info                  *
 *                               Copyright � Revolt 2008                                 *
 *---------------------------------------------------------------------------------------*
 * Definition: Represents the class which loads and manages sound effects and background *
 * music and the classes that wrap around the 2 mentioned types of sounds                *
 *****************************************************************************************/

#ifndef CSOUNDMANAGER_H_INCLUDED
#define CSOUNDMANAGER_H_INCLUDED

#include "..\Global.h"

namespace GR8 {

class cSoundEffect
{
    friend class cSoundManager;

    public:
        cSoundEffect(const std::string &ID, Mix_Chunk *soundData);
        ~cSoundEffect();

        std::string GetID();
        Mix_Chunk* GetChunk();

    private:
        Mix_Chunk *_sound;

        std::string _id;
};

class cMusic
{
    friend class cSoundManager;

    public:
        cMusic(const std::string &ID, Mix_Music *musicData, double startingPos = 0.0);
        ~cMusic();

        std::string GetID();
        int GetType();
        double GetMusicStartPosition();
        Mix_Music* GetMusic();

        void SetMusicStartPosition(double pos);

    private:
        Mix_Music *_music;

        std::string _id;
        double _startingPos;
};

class cSoundManager
{
    friend class cSoundEffect;
    friend class cMusic;

    public:
        cSoundManager();
        ~cSoundManager();

        //When managed by the sound manager the ID of the sound effects
        //and musics is the same as their filepath
        cSoundEffect* GetSoundEffect(const std::string &filepath);
        cMusic* GetMusic(const std::string &filepath);

        void ReloadSoundEffects();
        void ReloadMusics();
        void ReloadAll();

        bool RemoveSoundEffect(const std::string &filepath);
        bool RemoveMusic(const std::string &filepath);

        void RemoveSoundEffects();
        void RemoveMusics();
        void RemoveAll();

    private:
        std::vector< cSoundEffect* > _soundEffects;
        std::vector< cMusic* > _musics;
};

}

#endif // CSOUNDMANAGER_H_INCLUDED
