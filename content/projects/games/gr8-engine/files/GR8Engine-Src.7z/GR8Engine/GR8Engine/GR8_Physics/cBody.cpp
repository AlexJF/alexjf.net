/**\file cBody.cpp
   \author Revolt
   \brief Contains the implementation of the cBody class defined in cBody.h.
*/

#include "cBody.h"
#define M_PI 3.14

using namespace std;

namespace GR8 {

cBody::cBody(const std::string &ID, const sPosition &pos, float angle)
{
    _world = NULL;
    _body = NULL;
    _ID = ID;
    _bodydef.position.Set(pos.x, pos.y);
    _bodydef.angle = angle;
}

cBody::~cBody()
{
	cout << "Entering Body Destructor" << endl;
    RemoveAllShapes();
    Shutdown();
	cout << "Leaving Body Destructor" << endl;
}

/*------------- Properties - GET ----------------*/

std::string cBody::GetID()
{
    return _ID;
}

sPosition cBody::GetPosition()
{
    if (_body != NULL) {
        b2Vec2 bodyPos = _body->GetPosition();
        return sPosition(bodyPos.x, bodyPos.y);
    } else {
        return sPosition(_bodydef.position.x, _bodydef.position.y);
    }
}

float cBody::GetAngle(bool degrees)
{
    float rotation = 0;

    if (_body != NULL) {
        rotation = _body->GetAngle();
    } else {
        rotation = _bodydef.angle;
    }

    if (degrees) {
        rotation = (rotation * 180) / M_PI;
    }

    return rotation;
}

cWorld* cBody::GetWorld()
{
    return _world;
}

float cBody::GetMass()
{
    if (_body != NULL) {
        return _body->GetMass();
    } else {
        return _bodydef.massData.mass;
    }
}


/*------------- Properties - SET ----------------*/

bool cBody::SetID(const std::string &ID)
{
    if (_body != NULL) {
        return false;
    }
    _ID = ID;
    return true;
}

bool cBody::SetPosition(const sPosition &pos)
{
    if (_body != NULL) {
        return false;
    }
    _bodydef.position.Set(pos.x, pos.y);
    return true;
}

bool cBody::SetAngle(float angle, bool degree)
{
    if (_body != NULL) {
        return false;
    }
    if (degree) {
        _bodydef.angle = (angle * M_PI) / 180;
    } else {
        _bodydef.angle = angle;
    }
    return true;
}

bool cBody::SetCanRotate(bool rotate)
{
    if (_body != NULL) {
        return false;
    }
    _bodydef.fixedRotation = rotate;
    return true;
}

bool cBody::SetLinearDamping(float value)
{
    if (_body != NULL) {
        return false;
    }
    _bodydef.linearDamping = value;
    return true;
}

bool cBody::SetAngularDamping(float value)
{
    if (_body != NULL) {
        return false;
    }
    _bodydef.angularDamping = value;
    return true;
}

bool cBody::SetCanSleep(bool sleep)
{
    if (_body != NULL) {
        return false;
    }
    _bodydef.allowSleep = sleep;
    return true;
}

bool cBody::SetStartSleep(bool sleep)
{
    if (_body != NULL) {
        return false;
    }
    _bodydef.isSleeping = sleep;
    return true;
}

bool cBody::SetIsBullet(bool bullet)
{
    if (_body != NULL) {
        return false;
    }
    _bodydef.isBullet = bullet;
    return true;
}

void cBody::SetMassProperties(const sPosition &centerOfMass, float mass, float rotationalInertia)
{
    if (_body == NULL) {
        _bodydef.massData.center.Set(centerOfMass.x, centerOfMass.y);
        _bodydef.massData.mass = mass;
        _bodydef.massData.I = rotationalInertia;
    } else {
        b2MassData massData;
        massData.center.Set(centerOfMass.x, centerOfMass.y);
        massData.mass = mass;
        massData.I = rotationalInertia;
        _body->SetMass(&massData);
    }
}


/* -------------------- Methods ----------------- */

bool cBody::AddShape(cShape *shape)
{
    _shapes.push_back(shape);
    if (_body != NULL) {
        shape->_shape = _body->CreateShape(shape->_shapedef);
    }

    return true;
}

cShape* cBody::GetShape(const std::string &ID)
{
    vector< cShape* >::iterator it;
    for (it = _shapes.begin(); it != _shapes.end(); it++) {
        cShape *currentShape = *it;
        if (currentShape->GetID() == ID) {
            return currentShape;
        }
    }

    return NULL;
}

std::vector< cShape* >* cBody::GetShapeList()
{
    return &_shapes;
}

void cBody::RemoveShape(const std::string &ID)
{
    vector< cShape* >::iterator it;
    for (it = _shapes.begin(); it != _shapes.end(); it++) {
        cShape *currentShape = *it;
        if (currentShape->GetID() == ID) {
            if (_body != NULL) {
                _body->DestroyShape(currentShape->_shape);
            }
            delete currentShape;
            _shapes.erase(it);
        }
    }
}

void cBody::RemoveAllShapes()
{
	cout << "Deleting " << _shapes.size() << " shapes" << endl;
    vector< cShape* >::iterator it;
    for (it = _shapes.begin(); it != _shapes.end(); ++it) {
		cout << "Deleting shape" << endl;
        cShape *currentShape = *it;
        delete currentShape;
    }
	_shapes.clear();
}

void cBody::ApplyForce(const sVector &force, const sPosition &pos)
{
    if (_body != NULL) {
        _body->ApplyForce(b2Vec2(force.x, force.y), b2Vec2(pos.x, pos.y));
    }
}

/* -------------- Protected Methods ------------------ */
bool cBody::Initialize(cWorld *owner)
{
    if (_world != NULL) {
        return false;
    }

    _world = owner;
    vector< cShape* >::iterator it;
    for (it = _shapes.begin(); it != _shapes.end(); it++) {
        cShape *currentShape = *it;
        currentShape->_shape = _body->CreateShape(currentShape->_shapedef);
    }


    _body->SetMassFromShapes();

    return true;
}

void cBody::Shutdown()
{
    _body = NULL;
    _world = NULL;
}

}

