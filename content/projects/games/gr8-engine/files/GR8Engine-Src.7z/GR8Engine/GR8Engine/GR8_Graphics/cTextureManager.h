/**************************************************************************************************
 * cTextureManager.h - Declaration of the Texture Manager class which is part of the GR8 Graphics *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info                           *
 *                               Copyright � Revolt 2008                                          *
 *------------------------------------------------------------------------------------------------*
 * Description: TextureManager is a class responsible for loading the required textures and       *
 * saving them in memory until they aren't needed anymore.                                        *
 **************************************************************************************************/

#ifndef CTEXTUREMANAGER_H_INCLUDED
#define CTEXTUREMANAGER_H_INCLUDED

#include "..\Global.h"

namespace GR8 {

class cTexture
{
    friend class cTextureManager;

    public:
        cTexture(const std::string &ID);
        ~cTexture();

        bool LoadTexture(const std::string &filepath);

        std::string GetFilepath();
        GLuint* GetOpenGLTexture();

        sSize GetSize();
        sSize GetOpenGLSize();

    private:
        std::string _id;
        std::string _filepath;
        GLuint *_texture;
        sSize _textureSize;
        sSize _realSize;
};

class cTextureManager
{
    friend class cTexture;

    public:
        cTextureManager();
        ~cTextureManager();

        cTexture* GetTexture(const std::string &filepath);

        void ReloadTextures();

        bool RemoveTexture(const std::string &filepath);
        void RemoveAllTextures();

    private:
        std::vector< cTexture* > _textures; //Surface container

        SDL_Surface* LoadImage(const std::string &filename);
};

}

#endif // CTEXTUREMANAGER_H_INCLUDED
