/****************************************************************************
 * cButton.h - Declares the Button class and the ButtonStyle struct         *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info     *
 *                       Copyright � Revolt 2008                            *
 *--------------------------------------------------------------------------*
 * Description: Button class represents a generic button and ButtonStyle    *
 * structure represents the style of the button, thus enabling for easy and *
 * quick style selection for multiple buttons                               *
 ****************************************************************************/

#ifndef CBUTTON_H_INCLUDED
#define CBUTTON_H_INCLUDED

#include "..\Global.h"
#include "..\GR8_Core\cControlManager.h"
#include "..\GR8_Graphics\cGraphics.h"

namespace GR8 {

class cButton : public cControl
{
    public:
        cButton(const std::string &ID, const sPosition &pos, const std::string &text, void (*Callback)(eMouseButton mouseBtn, const sPosition &mousePos, cButton *caller) = NULL, sControlStyle style = sControlStyle());
        ~cButton();

        void SetAllText(const std::string &text);
        void SetIdleText(const std::string &text);
        void SetHoverText(const std::string &text);
        void SetClickText(const std::string &text);
        void SetTextFont(const std::string &fontName, int fontSize);
        void SetBackgroundColor(const sColor &color);
        void SetForegroundColor(const sColor &color);
        void SetBackgroundHoverColor(const sColor &color);
        void SetForegroundHoverColor(const sColor &color);
        void SetBackgroundClickColor(const sColor &color);
        void SetForegroundClickColor(const sColor &color);

        std::string GetIdleText();
        std::string GetHoverText();
        std::string GetClickText();
        cFont* GetTextFont();
        sColor GetBackgroundHoverColor();
        sColor GetForegroundHoverColor();
        sColor GetBackgroundClickColor();
        sColor GetForegroundClickColor();

        //External event handlers.
        void (*OnClickHandler)(eMouseButton mouseBtn, const sPosition &mousePos, cButton *caller);

        virtual bool OnFocusGained();
        virtual bool OnFocusLost();

    protected:
        //Functions called by the Control Manager
        virtual bool Initialize();
        virtual bool HandleEvent(cEvent *event);
        virtual void Update();
        virtual void Draw();

    private:
        std::string _idleText;
        std::string _hoverText;
        std::string _clickText;

        cFont *_textFont;

        sColor _hoverBackColor;
        sColor _hoverForeColor;

        sColor _clickBackColor;
        sColor _clickForeColor;
};

}


#endif // CBUTTON_H_INCLUDED
