/**\file cBody.h
   \author Revolt
   \brief Defines the cBody class which acts as a wrapper around the b2Body class of
   the Box2D library.
*/

#ifndef CBODY_H_INCLUDED
#define CBODY_H_INCLUDED

#include "..\Global.h"
#include "Box2D.h"
#include "cShape.h"

namespace GR8 {

class cBody
{
    friend class cWorld;
    public:
        ///Creates a new cBody object with the specified ID, set to start at the specified position and rotated by the specified angle (the last 2 are optional).
        cBody(const std::string &ID, const sPosition &pos = sPosition(0, 0), float angle = 0);
        virtual ~cBody();

        /** \name Properties - GET.
            \brief Functions that allow you to retrieve specific values of this body object. */
        //@{
        std::string GetID(); ///< Gets the ID of the body.
        sPosition GetPosition(); ///< Gets the current position of the body.
        float GetAngle(bool degrees = true); ///< Gets the rotation angle of the body in degrees (if degrees = true) or in radians.
        cWorld* GetWorld(); ///< Get the cWorld object that owns this body.

        float GetMass(); ///< Returns the mass of the body.
        //@}


        /** \name Properties - SET (unmanaged).
            \brief Functions that allow you to set specific values of this body object when it isn't being managed by a cWorld object. */
        //@{
        bool SetID(const std::string &ID); ///< Sets the ID of this body.
        bool SetPosition(const sPosition &pos); ///< Sets the initial position of this body in the cWorld class that is going to manage it.
        bool SetAngle(float angle, bool degrees = true); ///< Sets the initial angle of the body in degrees (if degrees = true) or radians.
        bool SetCanRotate(bool rotate); ///< Determines if the body is able to rotate (useful for character objects).

        bool SetLinearDamping(float value); ///< Sets the value of Linear Damping to apply to the object in simulation (Normally between 0 and 0.1).
        bool SetAngularDamping(float value); ///< Sets the value of Angular Damping to apply to the object in simulation (Normally between 0 and 0.1).

        bool SetCanSleep(bool sleep); ///< Determines if the body has the ability to sleep.
        bool SetStartSleep(bool sleep); ///< Determines if the body starts in a sleeping state.

        bool SetIsBullet(bool bullet); ///< Determines if the body will act as a bullet object (in order to use Continuous Collision Detection) or not.
        //@}

        /** \name Properties - SET.
            \brief Functions that allow you to set specific values of this body object. */
        //@{
        void SetMassProperties(const sPosition &centerOfMass, float mass, float rotationalInertia); ///< Sets the center of mass of the body object.
        //@}

        /** \name Methods.
            \brief Functions that provide enhanced capabilities to this cBody object. */
        //@{
        bool AddShape(cShape *shape); ///< Adds a shape to the body.
        cShape* GetShape(const std::string &ID); ///< Gets the shape that is contained in this body and that has the specified ID.
        std::vector< cShape* >* GetShapeList(); ///< Returns a vector containing all body's shapes.
        void RemoveShape(const std::string &ID); ///< Removes a shape from the body.
        void RemoveAllShapes(); ///< Removes all shapes associated with this body.
        //@}


        void ApplyForce(const sVector &force, const sPosition &pos); ///< Applies the force spcified in the force vector to the body at the selected position.

    protected:
        /** \name Protected Methods.
            \brief These functions are called by the cWorld object that owns this body. You normally won't need to call them directly. */
        //@{
        virtual bool Initialize(cWorld *owner); ///< A Body is initialized when it is added to a cWorld class. You should load all body textures, sounds and such in this stage. \note Make sure to call the cBody default Initialize for automatic handling of ownerships and added shapes.
        virtual void Update() = 0; ///< Here you should add all calculations/actions that should be ran frequently and independently of any event. This function is called whenever the cWorld object that owns this body runs its own Update function.
        virtual void HandleEvent(cEvent *event) = 0; ///< This function is called whenever a new event is sent to the cWorld object that owns this body, so that you can process events (keyboard, mouse, etc.)
        virtual void Draw() = 0; ///< This function is called whenever the owner of this body receives a request to draw its contents on the screen. You should apply all the drawing related to this object here.
        virtual void Shutdown(); ///< This function is called whenever a body is removed from a cWorld object that contains it and you should clean any specific variables relating to that cWorld object (_owner for example)
        //@}

    private:
        b2Body *_body;
        b2BodyDef _bodydef;

        std::string _ID;

        std::vector< cShape* > _shapes;

        cWorld *_world;
};

}

#endif // CBODY_H_INCLUDED
