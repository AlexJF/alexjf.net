/** \file cGraphics.h
    \author Revolt
    \brief Declares the cGraphics class that manages all graphic related functions. */

#ifndef CGRAPHICS_H_INCLUDED
#define CGRAPHICS_H_INCLUDED

#include "..\Global.h"
#include "..\GR8_Controls\cTimer.h"
#include "cTextureManager.h"
#include "cFontManager.h"

namespace GR8 {

//Useful static functions
sPosition GetCenterPosition(sSize source, sRect destination);

class cGraphics
{
    friend class cTextureManager;

    public:
        cGraphics();
        ~cGraphics();

        bool Initialize(const std::string &windowTitle, int windowW, int windowH, int windowBPP = 0, bool fullScreen = false, int fpsCap = 0); ///< Initializes the graphics component of the GR8 Engine by creating a window and calling all the necessary initializers.
        void Shutdown();

        /** \name Draw Functions
            \brief Functions responsible for drawing into the screen.
            \note All of these functions contain a special camera flag. If the camera flag is set to true, the coordinates will be modified according to the current position of the camera. */
        //@{
        void DrawLine(const sPosition &pos1, const sPosition &pos2, const sColor &color, bool useCamera = 1);

        void DrawRectangle(const sRect &rect, const sColor &color, bool useCamera = 1, float rotation = 0); ///< Draws a rectangle with the specified properties with a border of the specified color.
        void DrawFilledRectangle(const sRect &rect, const sColor &color, bool useCamera = 1, float rotation = 0); ///< Draws a rectangle with the specified properties filled with the specified color.
        void DrawTexturedRectangle(const sPosition &pos, const std::string &filepath, bool useCamera = 1, float rotation = 0); ///< Draws a textured rectangle with the specified properties.
        void DrawTexturedRectangle(const sRect &rect, const std::string &filepath, bool useCamera = 1, float rotation = 0); ///< Draws a textured rectangle with the specified properties.
        void DrawTexturedRectangle(const sPosition &pos, cTexture *texture, bool useCamera = 1, float rotation = 0); ///< Draws a textured rectangle with the specified properties.
        void DrawTexturedRectangle(const sRect &rect, cTexture *texture, bool useCamera = 1, float rotation = 0); ///< Draws a textured rectangle with the specified properties.

        void DrawCircle(const sCircle &circle, const sColor &color, bool useCamera = 1); ///< Draws a circle with no fill and a border of the specified color
        void DrawFilledCircle(const sCircle &circle, const sColor &color, bool useCamera = 1); ///< Draws a circle filled with the specified color
        void DrawTexturedCircle(const sCircle &circle, cTexture *texture, bool useCamera = 1, float rotation = 0); ///< Draws a textured circle using the specified properties

        void DrawPolygon(const sPolygon &polygon, const sColor &color, bool useCamera = 1, float rotation = 0); ///< Draws a polygon with no fill and a border of the specified color with the specified properties.
        void DrawFilledPolygon(const sPolygon &polygon, const sColor &color, bool useCamera = 1, float rotation = 0); ///< Draws a polygon filled with the specified color with the specified properties.
        void DrawTexturedPolygon(const sPolygon &polygon, const std::string &filepath, bool useCamera = 1, float rotation = 0); ///< Draws a textured polygon with the specified properties.
        void DrawTexturedPolygon(const sPolygon &polygon, cTexture *texture, bool useCamera = 1, float rotation = 0); ///< Draws a textured polygon with the specified properties.

        void RectFillTexture(const sRect &rect, const std::string &filepath, bool useCamera = 1); ///< Tiles the specified rectangular area with the specified texture.
        void RectFillTexture(const sRect &rect, cTexture *texture, bool useCamera = 1); ///< Tiles the specified rectangular area with the specified texture.

        void PolyFillTexture(const sPolygon &polygon, const std::string &filepath, bool useCamera = 1, sVector offset = 0); ///< Tiles the specified polygonal area with the specified texture. \warning Only use textures whose width and height are powers of 2.
        void PolyFillTexture(const sPolygon &polygon, cTexture *texture, bool useCamera = 1, sVector offset = 0); ///< Tiles the specified polygonal area with the specified texture. \warning Only use textures whose width and height are powers of 2.

        /* -------- Text Functions ------------ */
        void DrawText(const sPosition &pos, const std::string &text, const std::string &fontname, int fontsize, const sColor &color, bool useCamera = 1, sRect *clipArea = NULL); ///< Draws a string of text with the specified properties. \note clipArea represents an area outisde which all text will be clipped.
        void DrawText(const sPosition &pos, const std::string &text, cFont *font, const sColor &color, bool useCamera = 1, sRect *clipArea = NULL); ///< Draws a string of text with the specified properties. \note clipArea represents an area outisde which all text will be clipped.

        //@}

        /* --------- Misc Functions ---------- */
        bool UpdateScreen(); ///< Updates the current screen buffer with the new content.

        //FPS
        void CapFPS(int fps); ///< Caps FPS at a certain value.
        int GetFPSCap(); ///< Retrieves the value at which FPS is currently capped.
        int GetCurrentFPS(); ///< Retrieves current FPS (average) value.

        //Camera
        void SetCamera(sRect *bounds = NULL, sRect *area = NULL);
        sPosition GetCameraPosition();
        void UnsetCamera();

        bool IsCameraSet();

        void MoveCamera(const sPosition &pos);
        void CenterCameraOnPosition(const sPosition &pos);

        bool IsInCameraArea(const sPosition &pos);
        bool IsInCameraArea(const sRect &rect);
        bool IsInCameraArea(const sCircle &circle);
        bool IsInCameraArea(const sPolygon &poly);

        //Other
        sRect GetWindowArea();

        cTextureManager *textureManager;
        cFontManager *fontManager;

    protected:
        int _width; //Width of the game window
        int _height; //Height of the game window
        int _bpp; //Bits per pixel of the game window
        std::string _title; //Title of the game window

        //Framerate variables
        int _fpsLimit; //If = 0 then don't cap FPS. Otherwise, if > 0 cap
        cTimer *_frameTimer;
        int _frame;
        cTimer *_fpsTimer;
        int _fps;

        //Camera variables
        sRect *_camera;
        sRect *_cameraBounds;

        SDL_Surface *_mainWindow; //Game Window Surface
        Uint32 _sdlFlags; //SDL flags (used in Initialize)

    private:
        bool InitializeOpenGL(); ///< Initializes the OpenGL system by setting the coordinate and model viewing matrixes.

        void DrawSurface(int x, int y, SDL_Surface *surface, bool useCamera = 1, sRect *clipArea = NULL);

        sPosition RealToCameraCoordinates(const sPosition &realPos);
        sRect RealToCameraCoordinates(const sRect &realRect);
};

}

#endif // CGRAPHICS_H_INCLUDED
