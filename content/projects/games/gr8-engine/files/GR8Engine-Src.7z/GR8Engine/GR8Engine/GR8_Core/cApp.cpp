/******************************************************************************
 * cApp.h - Implementation of the Application class which is part of GR8 Core *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info       *
 *                      Copyright � Revolt 2008                               *
 ******************************************************************************/

#include "cApp.h"

namespace GR8 {

int GetCurrentTicks()
{
    return SDL_GetTicks();
}
void Sleep(int miliseconds)
{
    SDL_Delay(miliseconds);
}

cApp::cApp()
{
}

cApp::~cApp()
{
}

}
