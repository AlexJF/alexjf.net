#ifndef CLABEL_H_INCLUDED
#define CLABEL_H_INCLUDED

#include "..\Global.h"
#include "..\GR8_Core\cControlManager.h"
#include "..\GR8_Graphics\cGraphics.h"

namespace GR8 {

class cLabel : public cControl
{
    public:
        cLabel(const std::string &ID, const sPosition &pos, const std::string &text = "", sControlStyle style = sControlStyle());
        ~cLabel();

        void SetText(const std::string &text);
        void SetTextFont(const std::string &fontName, int fontSize);
        void SetTextFont(cFont *font);
        void SetTextAlignment(const eHorizontalAlign &hori, const eVerticalAlign &vert);
        void SetTextAlignment(const eVerticalAlign &vert, const eHorizontalAlign &hori);
        void SetTextAlignment(const eVerticalAlign &vert);
        void SetTextAlignment(const eHorizontalAlign &hori);
        void SetBackgroundColor(const sColor &color);
        void SetForegroundColor(const sColor &color);
        void SetBackgroundHoverColor(const sColor &color);
        void SetBackgroundClickColor(const sColor &color);

        std::string GetText();
        cFont* GetTextFont();
        int GetTextAlignment(const eOrientation &ori);

        sColor GetBackgroundHoverColor();
        sColor GetBackgroundClickColor();

        virtual bool OnFocusGained();
        virtual bool OnFocusLost();

    protected:
        //Functions called by the Control Manager
        virtual bool Initialize();
        virtual bool HandleEvent(cEvent *event);
        virtual void Update();
        virtual void Draw();

    private:
        bool _enabled;

        std::string _text;

        cFont *_textFont;

        sColor _hoverBackColor;
        sColor _clickBackColor;

        eHorizontalAlign _horiAlign;
        eVerticalAlign _vertAlign;
};

}

#endif // CLABEL_H_INCLUDED
