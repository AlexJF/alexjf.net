/**\file cWorld.h
   \brief Contains the cWorld class.
*/

#ifndef CPHYSIC_H_INCLUDED
#define CPHYSIC_H_INCLUDED

#include "..\Global.h"
#include "Box2D.h"
#include "cBody.h"
#include "..\GR8_Controls\cTimer.h"

namespace GR8 {

///Represents a physical world where bodies coexist and react in a life-like manner
/**By using the Box2D physics engine, the world class is able to accurately determine
   the behaviour of the bodies it manages, automatically handling all collisions, forces
   and accelerations.
   \warning All x, y, w and h units in this class refer to the metric system and not to
   screen pixels.*/
class cWorld
{
    public:
        cWorld();
        virtual ~cWorld();

        /** \name Methods.
            \brief Functions that provide enchanced capabilities to the world object. */
        //@{
        virtual bool Initialize(cScreen *owner, const sRect &area, float pixelMeterScale = 30, const sVector &globalAccel = sVector(0.0, -10.0), bool sleepInactive = true); ///< Initializes the world, setting its area (in meters), its global acceleration and if bodies go to sleep when no movement is detected.
        virtual void Update(); ///< Calls the update functions of every managed object and then calculates their new positions based on physical aspects.
        virtual void HandleEvent(cEvent *event); ///< Sends the specified event to all world objects so they can handle it.
        void DrawBodies(); ///< Sends a draw message to the entire collection of bodies so they can properly draw themselves.
        virtual void Shutdown(); ///< Shutsdown the world, deleting and freeing all resources allocated by it and by the bodies that inhabit in it.

        bool AddBody(cBody *body); ///< Adds a new body to the world.

        cBody* GetBody(const std::string &bodyID); ///< Get the body with the specified ID. \warning Returns NULL if object doesn't exist in this world.
        std::vector< cBody* >* GetBodyList(); ///< Returns a vector containing all the bodies managed by this world object.

        void RemoveBody(const std::string &bodyID); ///< Removes a body from the world, freeing all resources occupied by it.
        void RemoveAllBodies(); ///< Removes all bodies currently inhabiting the world and frees their resources.

        void ChangeGlobalAccel(const sVector &globalAccel); ///< Changes the global acceleration vector of the world
        float ChangePixelMeterScale(float pixelMeterScale); ///< Changes the value used for World<->Screen calculations. Specified value represents x pixels per meter. \note If you just want to check the current scale use a parameter equal or inferior to 0.

        virtual float ToScreen(float number); ///< Converts the specified float value in a world scale (in metric units) to screen float value (in pixels) according to the PixelMeterScale specified at the initialization of this cWorld class.
        virtual float ToWorld(float number); ///< Converts the specified float values in a screen scale (in pixels) to world float values (in metric units) according to the PixelMeterScale specified at the initialization of this cWorld class.

        virtual sPosition ToScreen(const sPosition &pos); ///< Converts a given set of world coordinates (in metric units) to screen coordinates (in pixels) according to the PixelMeterScale specified at the initialization of this cWorld class.
        virtual sRect ToScreen(const sRect &rect); ///< Converts the world values (in metric units) of the specified rect to screen values (in pixels) according to the PixelMeterScale specified at the initialization of this cWorld class.
        virtual sCircle ToScreen(const sCircle &circle); ///< Converts the given sCircle world values (in metric units) to screen values (in pixels) according to the PixelMeterScale specified at the initialization of this cWorld class.
        virtual sPolygon ToScreen(const sPolygon &pos); ///< Converts a given set of world coordinates (in metric units) to screen coordinates (in pixels) according to the PixelMeterScale specified at the initialization of this cWorld class.


        virtual sPosition ToWorld(const sPosition &pos); ///< Converts a given set of screen coordinates (in pixels) to real coordinates (in metric units) according to the PixelMeterScale specified at the initialization of this cWorld class.
        virtual sRect ToWorld(const sRect &rect); ///< Converts the screen values (in pixels) of the specified rect to world values (in metric units) according to the PixelMeterScale specified at the initialization of this cWorld class.
        virtual sCircle ToWorld(const sCircle &circle); ///< Converts the given sCircle screen values (in pixels) to world values (in metric units) according to the PixelMeterScale specified at the initialization of this cWorld class.
        virtual sPolygon ToWorld(const sPolygon &pos); ///< Converts a given set of screen coordinates (in pixels) to world coordinates (in metric units) according to the PixelMeterScale specified at the initialization of this cWorld class.
        //@}

        /** \name Properties - GET.
            \brief Functions that allow you to retrieve specific details of this cWorld object. */
        //@{
        sRect GetArea(); ///< Returns the area of this world object in SI units.
        cScreen* GetScreen(); ///< Returns a pointer to the cScreen class that owns this World object.
        //@}

    private:
        b2World *_world;
        sRect _worldArea;

        float32 _timestep;
        int32 _iterations;

        float _pixelMeterScale;

        std::vector< cBody* > _bodies;

        cScreen *_screen;
};

}

#endif // CPHYSIC_H_INCLUDED
