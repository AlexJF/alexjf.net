/*****************************************************************************************
 * cScreenManager.h - Declaration of the Screen Manager class and Screen class           *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info                  *
 *                            Copyright � Revolt 2008                                    *
 *---------------------------------------------------------------------------------------*
 * Description: ScreenManager is a class responsible for the proper initialization and   *
 * execution of screens such as the Main Menu, the Game Screen, the Pause Menu, etc.     *
 *****************************************************************************************/

#ifndef CSCREENMANAGER_H_INCLUDED
#define CSCREENMANAGER_H_INCLUDED

#include "..\Global.h"
#include "cControlManager.h"

namespace GR8 {

class cApp;
class cEvent;
class cControlManager;

class cScreen
{
    friend class cScreenManager;

    public:
        cScreen();
        virtual ~cScreen();

        virtual bool Initialize() = 0;

        virtual bool HandleEvent(cEvent *event) = 0;

        virtual void Update() = 0;
        virtual void Draw() = 0;

        sRect GetScreenArea();
        bool InsideScreen(const sPosition &pos, const sSize &size = sSize(0, 0));

        cScreenManager* GetManager();

    protected:
        //These 2 bool flags are useful when you want the previous screens to draw/update before
        //this screen so as to implement transparency effects or if this screen won't occupy the entire
        //gaming area.
        bool _blockupdate;
        bool _blockdraw;

        cScreenManager *_screenManager;

        cControlManager *_controlManager;

        sRect _screenArea;
};

class cScreenManager
{
    friend class cScreen;

    public:
        cScreenManager(cApp *app);
        ~cScreenManager();

        bool Initialize(cScreen *startingScreen);

        bool Push(cScreen *newScreen);
        bool Pop();

        void HandleEvent(cEvent *event);

        void Update();
        void Draw();

        cApp* GetApplication();

    private:
        bool _initialized;

        std::vector< cScreen* > _screens;
        std::vector< cScreen* > _screensToDraw;
        cApp *_app;
};

}

#endif // CSCREENMANAGER_H_INCLUDED
