/********************************************************************************************
 * cSoundManager.h - Implementation of the SoundManager, SoundEffect and Music class which  *
 *                   are part of GR8 Sounds.                                                *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info                     *
 *                               Copyright � Revolt 2008                                    *
 ********************************************************************************************/

#include "cSoundManager.h"

using namespace std;

namespace GR8 {

/* -------------------------------
   - Sound Effect Implementation -
   -------------------------------*/

cSoundEffect::cSoundEffect(const std::string &ID, Mix_Chunk *soundData)
{
    _id = ID;
    _sound = soundData;
}

cSoundEffect::~cSoundEffect()
{
    Mix_FreeChunk(_sound);
}

std::string cSoundEffect::GetID()
{
    return _id;
}

Mix_Chunk* cSoundEffect::GetChunk()
{
    return _sound;
}

/* ------------------------
   - Music Implementation -
   ------------------------*/

cMusic::cMusic(const std::string &ID, Mix_Music *musicData, double startingPos)
{
    _id = ID;
    _music = musicData;
    _startingPos = startingPos;
}

cMusic::~cMusic()
{
    Mix_FreeMusic(_music);
}

std::string cMusic::GetID()
{
    return _id;
}

int cMusic::GetType()
{
    return Mix_GetMusicType(_music);
}

double cMusic::GetMusicStartPosition()
{
    return _startingPos;
}

Mix_Music* cMusic::GetMusic()
{
    return _music;
}

void cMusic::SetMusicStartPosition(double pos)
{
    if (pos >= 0) {
        _startingPos = pos;
    }
}

/* --------------------------------
   - Sound Manager Implementation -
   --------------------------------*/

cSoundManager::cSoundManager()
{
    _soundEffects.clear();
    _musics.clear();
}

cSoundManager::~cSoundManager()
{
    RemoveAll();
}

/* Function GetSoundEffect
 * Returns a previously loaded sound effect or loads a new one and returns it based on filepath */
cSoundEffect* cSoundManager::GetSoundEffect(const std::string &filepath)
{
    vector< cSoundEffect* >::iterator it;
    for (it = _soundEffects.begin(); it != _soundEffects.end(); it++) {
        cSoundEffect *currentEffect = *it;
        if (currentEffect->GetID() == filepath) {
            return currentEffect;
        }
    }

    Mix_Chunk *soundChunk = Mix_LoadWAV(filepath.c_str());

    if (soundChunk != NULL) {
        cSoundEffect *newSoundEffect = new cSoundEffect(filepath, soundChunk);
        _soundEffects.push_back(newSoundEffect);
        return newSoundEffect;
    } else {
        return NULL;
    }
}

/* Function GetMusic
 * Returns a previously loaded music or loads a new one and returns it based on filepath */
cMusic* cSoundManager::GetMusic(const std::string &filepath)
{
    vector< cMusic* >::iterator it;
    for (it = _musics.begin(); it != _musics.end(); it++) {
        cMusic *currentMusic = *it;
        if (currentMusic->GetID() == filepath) {
            return currentMusic;
        }
    }

    Mix_Music *musicData = Mix_LoadMUS(filepath.c_str());

    if (musicData != NULL) {
        cMusic *newMusic = new cMusic(filepath, musicData);
        _musics.push_back(newMusic);
        return newMusic;
    } else {
        return NULL;
    }
}

/* Function ReloadSoundEffects
 * Reloads all the sound effects managed by this class */
void cSoundManager::ReloadSoundEffects()
{
    vector< cSoundEffect* >::iterator it;
    for (it = _soundEffects.end() - 1; it >= _soundEffects.begin(); it--) {
        cSoundEffect *currentEffect = *it;

        Mix_FreeChunk(currentEffect->_sound);

        currentEffect->_sound = Mix_LoadWAV(currentEffect->GetID().c_str());

        if (currentEffect->_sound = NULL) {
            delete currentEffect;
            _soundEffects.erase(it);
        }
    }
}

/* Function ReloadMusics
 * Reloads all the musics managed by this class */
void cSoundManager::ReloadMusics()
{
    vector< cMusic* >::iterator it;
    for (it = _musics.end() - 1; it >= _musics.begin(); it--) {
        cMusic *currentMusic = *it;

        Mix_FreeMusic(currentMusic->_music);

        currentMusic->_music = Mix_LoadMUS(currentMusic->GetID().c_str());

        if (currentMusic->_music = NULL) {
            delete currentMusic;
            _musics.erase(it);
        }
    }
}

/* Function ReloadAll
 * Calls the previous 2 functions resulting in the reloading of every resource managed by this class */
void cSoundManager::ReloadAll()
{
    ReloadSoundEffects();
    ReloadMusics();
}

/* Function RemoveSoundEffect
 * Removes the specified sound effect from the management list returning true on success */
bool cSoundManager::RemoveSoundEffect(const std::string &filepath)
{
    vector< cSoundEffect* >::iterator it;
    for (it = _soundEffects.begin(); it != _soundEffects.end(); it++) {
        cSoundEffect *currentSoundEffect = *it;
        if (currentSoundEffect->GetID() == filepath) {
            delete currentSoundEffect;
            _soundEffects.erase(it);
            return true;
        }
    }
    return false;
}

/* Function RemoveMusic
 * Removes the specified music from the management list returning true on success */
bool cSoundManager::RemoveMusic(const std::string &filepath)
{
    vector< cMusic* >::iterator it;
    for (it = _musics.begin(); it != _musics.end(); it++) {
        cMusic *currentMusic = *it;
        if (currentMusic->GetID() == filepath) {
            delete currentMusic;
            _musics.erase(it);
            return true;
        }
    }
    return false;
}

/* Function RemoveSoundEffects
 * Removes all the sound effects managed by this class */
void cSoundManager::RemoveSoundEffects()
{
    vector< cSoundEffect* >::iterator it;
    for (it = _soundEffects.end() - 1; it >= _soundEffects.begin(); it--) {
        cSoundEffect *currentEffect = *it;

        delete currentEffect;
        _soundEffects.erase(it);
    }
}

/* Function RemoveMusics
 * Removes all the musics managed by this class */
void cSoundManager::RemoveMusics()
{
    vector< cMusic* >::iterator it;
    for (it = _musics.end() - 1; it >= _musics.begin(); it--) {
        cMusic *currentMusic = *it;

        delete currentMusic;
        _musics.erase(it);
    }
}

/* Function RemoveAll
 * Deletes every resource managed by this class by calling the previous 2 functions */
void cSoundManager::RemoveAll()
{
    RemoveSoundEffects();
    RemoveMusics();
}

}
