/**\file cTextureManager.h
   \author Revolt
   \brief Implements the cTexture and cTextureManager classes declared in cTextureManager.h.
*/

#include "cTextureManager.h"

using namespace std;

namespace GR8 {

/*--------------------------
  - Texture Implementation -
  --------------------------*/

cTexture::cTexture(const string &ID)
{
    _id = ID;
    _filepath = "";
    _textureSize.w = 0;
    _textureSize.h = 0;
    _texture = NULL;
}

cTexture::~cTexture()
{
    glDeleteTextures(1, _texture);
    delete _texture;
    _texture = NULL;
}

bool cTexture::LoadTexture(const std::string &filepath)
{
    SDL_Surface *newSurface = NULL;
    SDL_Surface *surface = NULL;

    newSurface = IMG_Load(filepath.c_str());

    if (newSurface == NULL) {
        cerr << "Error while opening image '" << filepath << "': " << IMG_GetError() << endl;
        return false;
    }

    if ((newSurface->flags & SDL_SRCALPHA) == SDL_SRCALPHA) {
        surface = SDL_DisplayFormatAlpha(newSurface);
    } else {
        surface = SDL_DisplayFormat(newSurface);
    }


    SDL_FreeSurface(newSurface);

    if (surface == NULL) {
        cerr << "Error while optimizing surface" << endl;
        return false;
    }

    _realSize.w = surface->w;
    _realSize.h = surface->h;

    cout << "Real Size: " << surface->w << "x" << surface->h << endl;

    if (_texture != NULL) {
        glDeleteTextures(1, _texture);
        delete _texture;
        _texture = NULL;
    }

    GLenum texture_format;

    int width = nextPowerOf2(surface->w);
    int height = nextPowerOf2(surface->h);

    _textureSize = sSize(width, height);
    cout << "Texture Size: " << width <<"x" << height << endl;

    Uint32 rmask, gmask, bmask, amask;

    #if SDL_BYTEORDER == SDL_BIG_ENDIAN
        rmask = 0xff000000;
        gmask = 0x00ff0000;
        bmask = 0x0000ff00;
        amask = 0x000000ff;
    #else
        rmask = 0x000000ff;
        gmask = 0x0000ff00;
        bmask = 0x00ff0000;
        amask = 0xff000000;
    #endif

    SDL_Surface *expandedSurface = NULL;
    expandedSurface = SDL_CreateRGBSurface(SDL_SWSURFACE, width, height, 32, rmask, gmask, bmask, amask);

    SDL_SetAlpha(surface,0,0);

    int msg = SDL_BlitSurface(surface, NULL, expandedSurface, NULL);

    if (msg != 0) {
        cerr << "Error while blitting textures: " << msg << endl;
    }

    SDL_FreeSurface(surface);

    int nOfColors = expandedSurface->format->BytesPerPixel;

    if (nOfColors == 4) { // contains an alpha channel
        if (expandedSurface->format->Rmask == 0x000000ff)
                texture_format = GL_RGBA;
        else
                texture_format = GL_BGRA;
    }
    else if (nOfColors == 3) { // no alpha channel
        if (expandedSurface->format->Rmask == 0x000000ff)
                texture_format = GL_RGB;
        else
                texture_format = GL_BGR;
    } else {
        cerr << "Error: surface is not truecolor" << endl;
        return false;
    }


    _texture = new GLuint;

    cout << "Generating texture" << endl;
	// Have OpenGL generate a texture object handle for us
	glGenTextures( 1, _texture );

    cout << "Setting texture properties" << endl;
	// Bind the texture object
	glBindTexture( GL_TEXTURE_2D, *_texture );

    cout << "Render texture" << endl;
	// Edit the texture object's image data using the information SDL_Surface gives us
	glTexImage2D( GL_TEXTURE_2D, 0, nOfColors, width, height, 0, texture_format, GL_UNSIGNED_BYTE, expandedSurface->pixels );
	//glTexImage2D( GL_TEXTURE_2D, 0, 4, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, surface->pixels );

	//Set the texture's stretching properties
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	SDL_FreeSurface(expandedSurface);
	//SDL_FreeSurface(surface);

    _filepath = filepath;

	return true;
}

string cTexture::GetFilepath()
{
    return _filepath;
}

GLuint* cTexture::GetOpenGLTexture()
{
    return _texture;
}

sSize cTexture::GetSize()
{
    return _realSize;
}

sSize cTexture::GetOpenGLSize()
{
    return sSize(_realSize.w / _textureSize.w, _realSize.h / _textureSize.h);
}

/*----------------------------------
  - Texture Manager Implementation -
  ----------------------------------*/

cTextureManager::cTextureManager()
{
    _textures.clear();
}

cTextureManager::~cTextureManager()
{
    cout << "Entering TextureManager shutdown" << endl;
    RemoveAllTextures();
}

/* Function GetTexture
 * Gets a SDL_Surface from a file and adds it to the texture container. If the texture is already
   loaded then the texture in memory is returned

 * NOTE: Texture ID is its filename so there can't be 2 textures with the same filepath */
cTexture* cTextureManager::GetTexture(const string &filepath)
{
    //If texture was already added return it
    vector< cTexture* >::iterator it;
    for (it = _textures.begin(); it != _textures.end(); it++) {
        cTexture *existingTexture = *it;
        if (existingTexture->GetFilepath() == filepath) {
            return existingTexture;
        }
    }

    cTexture *newTexture = new cTexture(filepath);

    if (newTexture->LoadTexture(filepath)) {
        _textures.push_back(newTexture);
        return newTexture;
    }

    delete newTexture;

    return NULL;
}

/* Function ReloadTextures
 * Iterates through every loaded texture, frees its resources then reloads it.
   If reload fails the texture is deleted from the container. */
void cTextureManager::ReloadTextures()
{
    vector< cTexture* >::iterator it;

    for (it = _textures.end() - 1; it >= _textures.begin(); it--) {
        cTexture *currentTexture = *it;

        //If reload failed remove texture
        if (!currentTexture->LoadTexture(currentTexture->GetFilepath())) {
            delete currentTexture;
            _textures.erase(it);
        }
    }
}

/* Function RemoveTexture
 * Removes and frees a texture from the container when it isn't needed anymore */
bool cTextureManager::RemoveTexture(const string &filepath)
{
    vector< cTexture* >::iterator it;

    for (it = _textures.begin(); it != _textures.end(); it++) {
        cTexture *currentTexture = *it;
        if (currentTexture->GetFilepath() == filepath) {
            delete currentTexture;
            _textures.erase(it);
            return true;
        }
    }

    return false;
}

/* Function RemoveAllTextures
 * Removes and frees all textures from the texture container */
void cTextureManager::RemoveAllTextures()
{
    vector< cTexture* >::iterator it;

    for (it = _textures.end() - 1; it >= _textures.begin(); --it) {
        cTexture *currentTexture = *it;
        cout << currentTexture->GetFilepath() << endl;
        delete currentTexture;
        _textures.erase(it);
    }
}

}
