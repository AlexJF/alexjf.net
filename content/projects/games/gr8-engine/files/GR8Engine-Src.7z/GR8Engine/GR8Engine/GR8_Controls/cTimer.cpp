/******************************************************************************
 * cTimer.h - Implements the Timer class                                      *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info       *
 *                       Copyright � Revolt 2008                              *
 ******************************************************************************/

#include "cTimer.h"

using namespace std;

namespace GR8 {

cTimer::cTimer(const std::string &ID, int ticks, void (*callback)(cTimer *caller)) : cControl()
{
    _controlID = ID;
    _startTicks = 0;
    _pausedTicks = 0;
    _paused = false;
    _running = false;
    _callback = callback;
    _targetTicks = ticks;
}

cTimer::~cTimer()
{
}

/* Function Start
 * Starts the timer and sets the appropriate states*/
void cTimer::Start()
{
    _startTicks = GetCurrentTicks();
    _running = true;
    _paused = false;
}

/* Function Stop
 * Stops and resets the timer*/
void cTimer::Stop()
{
    _startTicks = 0;
    _running = false;
    _paused = false;
}

/* Function Pause
 * Pauses the timer

 * Note: When paused the IsRunning function returns false*/
void cTimer::Pause()
{
    if (_running) {
        _pausedTicks = GetCurrentTicks() - _startTicks;
        _paused = true;
        _running = false;
    }
}

/* Function Resume
 * Resumes (unpauses) the timer */
void cTimer::Resume()
{
    if (!_running && _paused) {
        _startTicks = GetCurrentTicks() - _pausedTicks;
        _running = true;
        _paused = false;
        _pausedTicks = 0;
    }
}

/* Function GetTicks
 * Gets the number of miliseconds since the timer was started*/
int cTimer::GetTicks()
{
    if (_running) {
        return GetCurrentTicks() - _startTicks;
    }
    else if (_paused) {
        return _pausedTicks;
    }
    else {
        return 0;
    }
}

/* Function Is(State)
 * Checks if the timer is in the specified state */
bool cTimer::IsRunning()
{
    return _running;
}

bool cTimer::IsPaused()
{
    return _paused;
}

/* Function SetCallBackTimer
 * Allows the user to set a callback function that is called when
   the specified number of ticks is reached
 * Note: This only works if the timer is managed by a control manager */
void cTimer::SetCallBackTimer(int ticks, void (*callback)(cTimer *caller))
{
    _callback = callback;
    _targetTicks = ticks;
}

/* Function Initialize
 * Performs all the necessary actions when the control is initialized by a control manager */
bool cTimer::Initialize()
{
    Start();
    return true;
}

bool cTimer::HandleEvent(cEvent *event)
{
    return false;
}

/* Function Update
 * When the timer is managed by a control manager, this function
   checks if the desired number of ticks has been reached and if so
   it calls the previously specified callback function*/
void cTimer::Update()
{
    if (GetTicks() >= _targetTicks && _callback != NULL) {
        Stop();
        (*_callback)(this);
    }
}

void cTimer::Draw()
{
}

bool cTimer::OnFocusGained()
{
    return true;
}

bool cTimer::OnFocusLost()
{
    return true;
}

}


