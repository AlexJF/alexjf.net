/************************************************************************
 * cEventManager.h - Declares the Event Manager class                   *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info *
 *                   Copyright � Revolt 2008                            *
 ************************************************************************/

#include "cEventManager.h"
#include "..\GR8_Graphics\cGraphics.h"

using namespace std;

namespace GR8 {

/*-----------------------------------
  - Static functions implementation -
  -----------------------------------*/
bool CheckModKey(eModCode mod)
{
    return SDL_GetModState() & mod;
}

bool IsKeyDown(eKeyCode key)
{
    Uint8 *keyboardState = SDL_GetKeyState(NULL);
    return keyboardState[key];
}

bool IsMouseDown(eMouseButton btn)
{
    Uint8 mouseState = SDL_GetMouseState(NULL, NULL);
    return (mouseState & SDL_BUTTON(btn));
}

sPosition GetMousePosition()
{
    int x = 0; int y = 0;
    SDL_GetMouseState(&x, &y);
    return sPosition(x,y);
}


/*-------------------------------
  -    Event Implementation     -
  -------------------------------*/

cEvent::cEvent(eEventType type)
{
    _type = type;
    _treated = false;
}

cEvent::~cEvent()
{
}

/* Function IsTreated
 * Checks if a control/object has already processed the event. */
bool cEvent::IsTreated()
{
    return _treated;
}

/* Function Treat
 * Sets this event as treated */
void cEvent::Treat()
{
    _treated = true;
}

/* Function GetType
 * Gets the type of the event */
eEventType cEvent::GetType()
{
    return _type;
}

cKeyEvent::cKeyEvent(eEventType type, eKeyCode key, const char &translatedChar) : cEvent(type)
{
    _key = key;
    _char = translatedChar;
}

cKeyEvent::~cKeyEvent()
{
}

/* Function GetKeyCode
 * Returns the code of the key associated with the event */
eKeyCode cKeyEvent::GetKeyCode()
{
    return _key;
}

char cKeyEvent::GetChar()
{
    return _char;
}

cMouseEvent::cMouseEvent(eEventType type, sPosition mousepos, eMouseButton mousebtn, sPosition relpos) : cEvent(type)
{
    _position = mousepos;
    _button = mousebtn;
    _relposition = relpos;
}

cMouseEvent::~cMouseEvent()
{
}

/* Function GetMousePosition
 * Returns the position of the mouse when the event occured (or the final
   position when event type is EVENT_MOUSEMOVE) */
sPosition cMouseEvent::GetMousePosition()
{
    return _position;
}


sPosition cMouseEvent::GetRelativeMousePosition()
{
    return _relposition;
}

/* Function GetMouseButton
 * Returns the mouse button associated with the event or MOUSE_NONE if
   the event is of type EVENT_MOUSEMOVE */
eMouseButton cMouseEvent::GetMouseButton()
{
    return _button;
}

cWindowEvent::cWindowEvent(eEventType type, sSize newsize) : cEvent(type)
{
    _newsize = newsize;
}

cWindowEvent::~cWindowEvent()
{
}

/* Function GetNewSize
 * Returns the new size of the window when event type is EVENT_WRESIZED */
sSize cWindowEvent::GetNewSize()
{
    return _newsize;
}


/* --------------------------------
   - Event Manager Implementation -
   -------------------------------- */

cEventManager::cEventManager(cApp *app)
{
    _app = app;
    SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
}

cEventManager::~cEventManager()
{
}

void cEventManager::Process()
{
    SDL_Event SDLevent;
    while (SDL_PollEvent(&SDLevent)) {
        cEvent *event = NULL;
        sPosition mousePos;
        sSize newSize;

        switch (SDLevent.type)
        {
            case SDL_KEYDOWN:
                event = new cKeyEvent(EVENT_KEYDOWN, static_cast< eKeyCode >(SDLevent.key.keysym.sym), SDLevent.key.keysym.unicode);
                break;
            case SDL_KEYUP:
                event = new cKeyEvent(EVENT_KEYUP, static_cast< eKeyCode >(SDLevent.key.keysym.sym), SDLevent.key.keysym.unicode);
                break;

            case SDL_MOUSEMOTION:
                mousePos.x = SDLevent.motion.x, mousePos.y = SDLevent.motion.y;
                event = new cMouseEvent(EVENT_MOUSEMOVE, mousePos, MOUSE_NONE, sPosition(SDLevent.motion.xrel, SDLevent.motion.yrel));
                break;
            case SDL_MOUSEBUTTONDOWN:
                mousePos.x = SDLevent.button.x, mousePos.y = SDLevent.button.y;
                event = new cMouseEvent(EVENT_MOUSEDOWN, mousePos, static_cast< eMouseButton >(SDLevent.button.button));
                break;
            case SDL_MOUSEBUTTONUP:
                mousePos.x = SDLevent.button.x, mousePos.y = SDLevent.button.y;
                event = new cMouseEvent(EVENT_MOUSEUP, mousePos, static_cast< eMouseButton >(SDLevent.button.button));
                break;

            case SDL_ACTIVEEVENT:
                if (SDLevent.active.state & SDL_APPACTIVE) {
                    if (SDLevent.active.gain) {
                        event = new cWindowEvent(EVENT_WRESTORED);
                    } else {
                        event = new cWindowEvent(EVENT_WMINIMIZED);
                    }
                }
                break;
            case SDL_VIDEORESIZE:
                newSize.w = SDLevent.resize.w, newSize.h = SDLevent.resize.h;
                event = new cWindowEvent(EVENT_WRESIZE, newSize);
                break;
            case SDL_QUIT:
                event = new cWindowEvent(EVENT_WCLOSE);
                break;
            default:
                cout << "Untreated Event: " << SDLevent.type << endl;
        }
        if (event != NULL) {
            GetApplication()->HandleEvent(event);
            delete event;
        }
    }
}

cApp* cEventManager::GetApplication()
{
    return _app;
}

}
