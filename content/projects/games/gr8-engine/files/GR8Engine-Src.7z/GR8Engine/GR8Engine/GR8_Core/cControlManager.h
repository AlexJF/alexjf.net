/**\file cControlManager.h
   \brief Contains the cControl and cControlManager classes which allow
   simple management and creation of controls.
*/

#ifndef CCONTROLMANAGER_H_INCLUDED
#define CCONTROLMANAGER_H_INCLUDED

#include "..\Global.h"
#include "cScreenManager.h"
#include "cEventManager.h"

namespace GR8 {

///State of the control. \todo Maybe remove?
enum eControlState {
    CTRL_STATE_IDLE,
    CTRL_STATE_MOUSEBTNPRESSED,
    CTRL_STATE_MOUSEBTNRELEASED,
    CTRL_STATE_CLICK,
    CTRL_STATE_MOUSEHOVER,
    CTRL_STATE_DRAG
};

///Structure to hold control's style properties
struct sControlStyle {
    sControlStyle() {
        visible = true;
        enabled = true;
        allowDrag = false;

        size = sSize(100, 30);
        backgroundIdleColor = sColor(245, 245, 245);
        foregroundIdleColor = sColor(15, 15, 15);

        backgroundHoverColor = sColor(125, 125, 125);
        foregroundHoverColor = sColor(255, 255, 255);

        backgroundClickColor = sColor(70, 70, 70);
        foregroundClickColor = sColor(255, 255, 255);

        horizontalAlign = ALIGN_HORI_CENTER;
        verticalAlign = ALIGN_VERT_MIDDLE;

        textFont = NULL;

        borderColor = sColor(150, 150, 150);
        borderWidth = 1;
    }
    ~sControlStyle() { };

    bool visible;
    bool allowDrag;
    bool enabled;

    sSize size;

    sColor backgroundIdleColor;
    sColor backgroundHoverColor;
    sColor backgroundClickColor;

    sColor foregroundIdleColor;
    sColor foregroundHoverColor;
    sColor foregroundClickColor;

    eHorizontalAlign horizontalAlign;
    eVerticalAlign verticalAlign;

    cFont *textFont;

    sColor borderColor;
    int borderWidth;
};

///Represents the base class for every control.
/**The user should inherit this class when creating its own controls
   so that the cControlManager is able to create, manage and delete them.
   \warning Must inherit.*/
class cControl
{
    friend class cControlManager;

    public:
        cControl();
        virtual ~cControl();

        //Methods
        bool InsideControl(const sPosition &pos, const sSize &size = sSize(0, 0)); ///< Checks if the given area resides inside this control. \todo Change sPosition and sSize to sRect?
        virtual bool SetFocus(); ///< Sets the focus on this control.
        virtual bool HasFocus(); ///< Checks if control has focus.



        //Properties SET
        virtual bool SetID(const std::string &ID); ///< Sets the ID of the control. \warning Only works if control hasn't yet been associated with a control manager.
        virtual bool SetPosition(const sPosition &newPosition); ///< Sets the position of the control relative to the origin of the window.
        virtual bool SetPositionRelative(const sPosition &newPosition); ///< Sets the position of the control relative to the parent object.
        virtual bool SetDeltaPosition(float deltaX, float deltaY); ///< Increments the current position by deltaX and deltaY values.
        virtual bool SetSize(const sSize &newSize); ///< Sets the size of the control.
        virtual void SetBackgroundColor(const sColor &color); ///< Sets the background color of the control.
        virtual void SetForegroundColor(const sColor &color); ///< Sets the foreground color of the control.
        virtual void SetBorder(int width, const sColor &color); ///< Sets border properties of the control.

        //Properties GET
        std::string GetID(); ///< Gets the ID of the control.
        sPosition GetPosition(); ///< Gets the position of the control relative to the parent object.
        sPosition GetPositionRelative(); ///< Gets the position of the control relative to the main window.
        sSize GetSize(); ///< Gets the size of the control.
        sRect GetArea(); ///< Gets the area of the control.
        sRect GetAreaRelative(); ///< Gets the area of the control relative to the parent control.
        sColor GetBackgroundColor(); ///< Gets the background color of the control.
        sColor GetForegroundColor(); ///< Gets the foreground color of the control.
        sColor GetBorderColor(); ///< Gets the color of the control's border.
        int GetBorderWidth(); ///< Gets the width of the control's border.
        cControlManager* GetChildControlManager(); ///< Gets the control manager that handles all children of this control. \warning Returns NULL if control has no children.
        cControlManager* GetControlManager(); ///< Get the control manager that owns this control \warning Returns NULL if control is unmanaged

        bool IsDragging();

        //Public variables
        bool Visible; ///< Determines if the control is to be drawn or not.
        bool AllowDrag; ///< Determines if the control can be dragged.

        //Event Handlers
        void (*OnClickHandler)(eMouseButton mouseBtn, const sPosition &mousePos, cControl *caller);

    protected:
        //Main functions
        //Should only be called by the control manager
        virtual bool Initialize() = 0; ///< Actions to perform when control is added to a control manager.
        virtual void Draw() = 0; ///< Actions to perform when control manager asks the control to be drawn.
        virtual void Update() = 0; ///< Actions to perform when control manager asks the control to update.
        virtual void DrawBorders(); ///< Default border draw function (rectangles only).
        virtual bool HandleEvent(cEvent *event); ///< Actions to perform when control manager sends an event for the control to proccess.

        virtual bool OnFocusGained() = 0; ///< Actions to perform when control gains focus.
        virtual bool OnFocusLost() = 0; ///< Actions to perform when control loses focus.

        eControlState _state;

        bool _leftMousePressed;
        bool _rightMousePressed;
        bool _dragging;
        bool _insideControl;

        sColor _backgroundColor;
        sColor _foregroundColor;

        std::string _controlID;

        sRect _controlArea;

        int _borderWidth;
        sColor _borderColor;

        cControlManager *_childControlManager;
        cControlManager *_manager;

};

/*class cTextControl : public cControl
{
    public:
        cTextControl();
        virtual ~cTextControl();

        virtual bool SetText(const std::string &text);
        void SetTextFont(const std::string &fontName, int fontSize);
        virtual bool SetTextFont(cFont *font);
};*/


///Class responsible for managing controls
/**This class eases the management of several controls by grouping them together and allowing to call their
   Draw/Update/HandleEvent functions all at once.*/
class cControlManager
{
    friend class cControl;

    public:
        cControlManager(cScreen *owner);
        cControlManager(cControl *owner);
        ~cControlManager();

        bool AddControl(cControl *control); ///< Adds a control to the manager
        void DeleteControl(const std::string &ID); ///< Deletes the selected control. \warning Control is deleted from memory aswell so pointers become invalid.
        void DeleteAllControls(); ///< Deletes all managed controls. \warning Controls are deleted from memory aswell so pointers become invalid.

        cControl* GetControl(const std::string &ID); ///< Gets the control with the specified ID.
        std::vector< cControl* >* GetControlList(); ///< Gets a vector containing all controls managed by this object.

        void UpdateControls(); ///< Calls the update function of every managed control.
        void DrawControls(); ///< Calls the draw function of every managed control.
        void HandleEvent(cEvent *event); ///< Calls the handle event function of every managed control.

        void SetFocusedControl(cControl *control); ///< Sets the focus on the selected control. \todo Merge with cControl::SetFocus
        cControl* GetFocusedControl(); ///< Gets the currently focused control or NULL if all child controls are focused or none is.
        void FocusAllManagedControls(); ///< Sets all managed controls as focused. \note Use when (e.g) you want all the child controls to process events from the parent control as if they were their own.
        void UnfocusAllManagedControls(); ///< Sets all managed controls as unfocused.
        bool AllControlsFocused(); ///< Returns true if all managed controls are set as focused.
        bool ControlFocused(const std::string &ID); ///< Returns true if control is currently focused.

        cScreen* GetScreen(); ///< Gets the screen that manages this control manager. \note If manager is owned by another control, the entire chain is parsed until a cScreen object is reached and that object is returned.
        cControl* GetOwnerControl(); ///< Gets the control that manages this control manager. \note Returns NULL if manager is not owned by a control, that is, if it is a top level manager.

    private:
        std::vector< cControl* > _controls;
        cControl *_focusedControl;
        cScreen *_ownerScreen;
        cControl *_ownerControl;

        bool _focusAll;
};

}



#endif // CCONTROLMANAGER_H_INCLUDED
