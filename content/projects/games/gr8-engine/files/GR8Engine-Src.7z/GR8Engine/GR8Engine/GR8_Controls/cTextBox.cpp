/** \file cTextBox.cpp
    \author Revolt
    \brief Implements the TextBox control defined in cTextBox.h.
*/

#include "cTextBox.h"
#include "cLabel.h"

using namespace std;

namespace GR8 {

cTextBox::cTextBox(const std::string &ID, const sPosition &pos, const std::string &text, sControlStyle style) : cControl()
{
    _controlID = ID;
    _controlArea = sRect(pos.x, pos.y, style.size.w, style.size.h);

    _childControlManager = new cControlManager(this);
    cLabel *textLabel = new cLabel("typed_text", _controlArea.GetPosition(), text, style);
    _childControlManager->AddControl(textLabel);

    _enabled = style.enabled;
}

cTextBox::~cTextBox()
{
    delete _childControlManager;
}

void cTextBox::SetBackgroundHoverColor(const sColor &color)
{
    cControl *control = _childControlManager->GetControl("typed_text");
    if (control != NULL) {
        cLabel *label = static_cast< cLabel* >(control);
        label->SetBackgroundHoverColor(color);
    }
}

void cTextBox::SetBackgroundClickColor(const sColor &color)
{
    cControl *control = _childControlManager->GetControl("typed_text");
    if (control != NULL) {
        cLabel *label = static_cast< cLabel* >(control);
        label->SetBackgroundClickColor(color);
    }
}

/* Function Get(State)Text
 * Returns the text of the control in the specified state */
std::string cTextBox::GetText()
{
    cControl *control = _childControlManager->GetControl("typed_text");
    if (control != NULL) {
        cLabel *label = static_cast< cLabel* >(control);
        return label->GetText();
    } else {
        return "";
    }
}

/* Function GetTextFont
 * Returns the font that will be used in the rendering of the control's text */
cFont* cTextBox::GetTextFont()
{
    cControl *control = _childControlManager->GetControl("typed_text");
    if (control != NULL) {
        cLabel *label = static_cast< cLabel* >(control);
        return label->GetTextFont();
    } else {
        return NULL;
    }
}

/* Function Initialize
 * This function initializes the button and is automatically called when the control is added to the control manager */
bool cTextBox::Initialize()
{
    return true;
}

/* Function HandleEvent
 * If it handles the specified event true is returned. False otherwise */
bool cTextBox::HandleEvent(cEvent *event)
{
    cout << "Textbox Handle Event" << endl;

    cMouseEvent *mouseEvent = NULL;
    cKeyEvent *keyEvent = NULL;

    //_childControlManager->HandleEvent(event);

    bool eventTreatedByDefaultHandler = cControl::HandleEvent(event);

    cLabel *label = static_cast< cLabel* >(_childControlManager->GetControl("typed_text"));
    std::string typedText = label->GetText();

	int keyCode;
    bool SHIFT = CheckModKey(KEY_MOD_SHIFT);
    bool CAPS = CheckModKey(KEY_MOD_CAPS);

    switch (event->GetType())
    {
        case EVENT_KEYDOWN:
            keyEvent = static_cast< cKeyEvent* >(event);
			keyCode = keyEvent->GetKeyCode();
            if (!HasFocus()) {
				cout << "Textbox has no focus!" << endl;
                return false;
            }

            if (keyCode == KEY_BACKSPACE) {
                if (typedText.length() > 0)
                typedText = typedText.substr(0, typedText.length() - 1);
            }
            else if (keyCode == KEY_SPACE) {
                typedText += " ";
            }
            else if ((keyCode >= KEY_a && keyCode <= KEY_z)) {
                cout << "CAPS: " << CAPS << " SHIFT: " << SHIFT << endl;
                if ((SHIFT && !CAPS) || (CAPS && !SHIFT)) {
                    typedText = typedText + (char)(keyCode - 32);
                } else {
                    typedText = typedText + (char)(keyCode);
                }
            }
            label->SetText(typedText);
            event->Treat();
            return true;
            break;
        case EVENT_KEYUP:
            if (!HasFocus()) {
                return false;
            }
            keyEvent = static_cast< cKeyEvent* >(event);
            event->Treat();
            return true;
            break;

        default:
            break;
    }

    if (eventTreatedByDefaultHandler) {
        event->Treat();
        return true;
    }

    return false;
}

/* Function Update
 * Performs additional calculations/actions */
void cTextBox::Update()
{
}

/* Function Draw
 * Draws the control on the screen */
void cTextBox::Draw()
{
    if (!Visible) {
        return;
    }

    _childControlManager->DrawControls();
}

bool cTextBox::OnFocusGained()
{
    return true;
}

bool cTextBox::OnFocusLost()
{
    return true;
}
}
