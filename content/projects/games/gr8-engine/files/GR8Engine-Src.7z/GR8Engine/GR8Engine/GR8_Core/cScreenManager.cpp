/***************************************************************************************
 * cScreenManager.cpp - Implementation of the Screen Manager and Screen classes        *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info                *
 *                          Copyright � Revolt 2008                                    *
 ***************************************************************************************/

#include "cScreenManager.h"

using namespace std;

namespace GR8 {

/* -------------------------
   - Screen Implementation -
   ------------------------- */

cScreen::cScreen()
{
}

cScreen::~cScreen()
{
    delete _controlManager;
}

sRect cScreen::GetScreenArea()
{
    return _screenArea;
}

bool cScreen::InsideScreen(const sPosition &pos, const sSize &size)
{
    if (pos.x >= _screenArea.x && (pos.x + size.w) <= (_screenArea.x + _screenArea.w) && pos.y >= _screenArea.y && (pos.y + size.h) <= (_screenArea.y + _screenArea.h)) {
        return true;
    } else {
        return false;
    }
}

cScreenManager* cScreen::GetManager()
{
    //cout << "Get Screen Manager" << endl;
    return _screenManager;
}

/* ---------------------------------
   - Screen Manager Implementation -
   --------------------------------- */

cScreenManager::cScreenManager(cApp *app)
{
    _app = app;
    _screens.clear();
    _screensToDraw.clear();
    _initialized = false;
}

cScreenManager::~cScreenManager()
{
	cout << "Entering Screen Manager destructor" << endl;
	cout << _screens.size() << " screens to delete" << endl;
    while (_screens.size() != 0) {
		cout << "Deleting screen" << endl;
        _screens.pop_back();
    }
	cout << "Leaving Screen Manager destructor" << endl;
}

/* Function Initialize
 * Initializes the Screen Manager by setting and initializing its starting screen */
bool cScreenManager::Initialize(cScreen *startingScreen)
{
    startingScreen->_screenManager = this;
    if (startingScreen->Initialize() == true) {
        _screens.push_back(startingScreen);
        _initialized = true;
    }
    return _initialized;
}

/* Function Push
 * Adds a new Screen to the top of the stack which represents the
   last screen drawn to the window and thus, the topmost screen. */
bool cScreenManager::Push(cScreen *newScreen)
{
    if (newScreen != NULL) {
        newScreen->_screenManager = this;
        if (newScreen->Initialize() == true) {
            _screens.push_back(newScreen);
            return true;
        }
    }
    return false;
}

/* Function Pop
 * Deletes the top screen from the stack.

 * NOTE: You cannot pop the starting screen. To exit the application
   define a exit flag in your derived application class and use it on
   the main application cycle. */
bool cScreenManager::Pop()
{
    if (_screens.size() == 1) {
        return false;
    }
    delete _screens.back();
    _screens.pop_back();
    return true;
}

/* Function HandleEvent
 * Cycles through all stored screens calling their HandleEvent functions.

 * Note: If the HandleEvent function of one of the screens returns true then it
   has treated the event and it shouldn't propagate to the other screens */
void cScreenManager::HandleEvent(cEvent *event)
{
    //cout << "Entered ScreenManager Handle Event" << endl;
    for (int i = _screens.size() - 1; i >= 0 ; i--) {
        cScreen *curScreen = _screens.at(i);

        if (curScreen->HandleEvent(event)) {
            return;
        }
    }
}

/* Function Update
 * Updates all the screens, starting from the top one, until it has updated every single
   one of them or until one of them has blocked the remaining updates.

   NOTE: For performance reasons, the list of screens to draw is also populated in this
   function to avoid yet another iteration. */
void cScreenManager::Update()
{
    _screensToDraw.clear(); //Clear list of skins to draw since we'll reload it
    bool updateBlocked = false;
    bool drawBlocked = false;
    for (int i = _screens.size() - 1; i >= 0 ; i--) {
        cScreen *curScreen = _screens.at(i);

        if (!updateBlocked) {
            curScreen->Update();
        }

        if (curScreen->_blockupdate) {
            updateBlocked = true;
        }

        if (!drawBlocked) {
            _screensToDraw.push_back(curScreen);
        }

        if (curScreen->_blockdraw) {
            drawBlocked = true;
        }

        //If both flags are true then we can exit the cycle...
        if (updateBlocked && drawBlocked) {
            break;
        }
    }
}

/* Function Draw
 * Iterates through the list of screens to draw populated in the Update function and calls their
   Draw() methods */
void cScreenManager::Draw()
{
    for (int i = _screensToDraw.size() - 1; i >= 0; i--) {
        _screensToDraw.at(i)->Draw();
    }
}

/* Function GetApplication
 * Returns a pointer to the application that owns this manager. */
cApp* cScreenManager::GetApplication()
{
    //cout << "Get Application" << endl;
    return _app;
}

}
