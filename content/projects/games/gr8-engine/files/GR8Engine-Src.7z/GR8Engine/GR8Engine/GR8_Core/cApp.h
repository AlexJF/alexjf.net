/**\file cApp.h
   \brief Contains the application class and global functions related to the
   application.
*/


#ifndef CAPP_H_INCLUDED
#define CAPP_H_INCLUDED

#include "..\Global.h"
#include "cScreenManager.h"
#include "cEventManager.h"

namespace GR8 {

///Returns the current ticks of the app.
/**This function allows you to calculate time differences between different events
   or actions.*/
int GetCurrentTicks();

///Sleeps the application for the specified time
/**By calling Sleep you are freezing the application for the specified time (in
   seconds). During this period the application won't perform any actions and
   therefore it will consume less CPU.*/
void Sleep(int miliseconds);

///The main application class
/**cApp represents the base application class which must be overridden by the user.*/
class cApp
{
    public:
        cApp();
        virtual ~cApp();

        ///Initializes the application.
        /**\code
            //Example Implementation
            bool App::Init(std::string windowTitle, int windowW, int windowH, int windowBPP, bool fullScreen)
            {
                exit = false;
                screenManager = new cScreenManager(this);
                eventManager = new cEventManager(this);
                graphics = new cGraphics();
                audio = new cAudio();

                if (!graphics->Initialize(windowTitle, windowW, windowH, windowBPP, fullScreen) || !audio->Initialize()) {
                    return false;
                }

                MainWindow *mainwnd = new MainWindow();

                if (!screenManager->Initialize(mainwnd)) {
                    delete mainwnd;
                    return false;
                }

                return true;
            }
            \endcode
        */
        virtual bool Init(std::string windowTitle, int windowW, int windowH, int windowBPP, bool fullScreen) = 0;

        ///Handles an event.
        /**\code
            //Example Implementation
            void App::HandleEvent(cEvent *event)
            {
                switch (event->GetType())
                {
                    case EVENT_WCLOSE:
                        exit = true;
                        break;
                    default:
                        screenManager->HandleEvent(event);
                        break;
                }
            }
            \endcode
        */
        virtual void HandleEvent(cEvent *event) = 0;

        ///Application's main.
        /**\code
            //Example Implementation
            void App::Run()
            {
                while (!exit) {
                    eventManager->Process();
                    screenManager->Update();
                    screenManager->Draw();
                    graphics->UpdateScreen();
                }
            }
            \endcode
        */
        virtual void Run() = 0;

        ///Shutsdown the application.
        /**\code
            //Example Implementation
            void App::Shutdown()
            {
                delete graphics;
                delete eventManager;
                delete screenManager;
                SDL_Quit();
            }
            \endcode
        */
        virtual void Shutdown() = 0;
        //virtual void ResizeWindow() = 0;

        bool exit; ///< User should use this variable in cApp::Run as the cicle condition

        cScreenManager *screenManager;
        cEventManager *eventManager;
        cGraphics *graphics;
        cAudio *audio;

};

}

#endif // CAPP_H_INCLUDED
