/*******************************************************************************
 * cAudio.h - Implementation of the Audio class which is part of GR8 Audio.    *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info        *
 *                     Copyright � Revolt 2008                                 *
 *******************************************************************************/

#include "cAudio.h"

using namespace std;

namespace GR8 {

cAudio::cAudio()
{
    _currentMusic = NULL;
}

cAudio::~cAudio()
{
    Shutdown();
}

/* Function Initialize
 * Initializes the audio component of the engine */
bool cAudio::Initialize()
{
    if (SDL_Init(SDL_INIT_AUDIO) == -1) {
        cerr << "Unable to initialize SDL Audio: " << SDL_GetError() << endl;
        return false;
    }

    if (Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, 2, 4096) == -1) {
        cerr << "Unable to initialize SDL Mixer: " << SDL_GetError() << endl;
        return false;
    }

    soundManager = new cSoundManager;

    cout << "Sound System Initialized" << endl;

    return true;
}

/* Function Shutdown
 * Shuts the audio component down freeing all the resources managed by it */
void cAudio::Shutdown()
{
    cout << "Entering cAudio Shutdown" << endl;
    delete soundManager;
    Mix_CloseAudio();
    SDL_QuitSubSystem(SDL_INIT_AUDIO);
}

/* Function PlaySoundEffect
 * Plays the specified sound effect loop times in the specified channel
 * returning the number of the afore mentioned channel or -1 on error.*/
int cAudio::PlaySoundEffect(cSoundEffect *soundEffect, int loop, int channel)
{
    return Mix_PlayChannel(channel, soundEffect->GetChunk(), loop);
}

int cAudio::PlaySoundEffect(const std::string &filepath, int loop, int channel)
{
    cSoundEffect *soundEffect = soundManager->GetSoundEffect(filepath);
    if (soundEffect != NULL) {
        return Mix_PlayChannel(channel, soundEffect->GetChunk(), loop);
    } else {
        return -1;
    }
}

/* Function PauseSoundEffect
 * Pauses the sound effect playing at the specified channel*/
void cAudio::PauseSoundEffect(int channel)
{
    Mix_Pause(channel);
}

/* Function PauseAllSoundEffects
 * Pauses all the currently playing sound effects */
void cAudio::PauseAllSoundEffects()
{
    Mix_Pause(-1);
}

/* Function ResumeSoundEffect
 * Resumes the sound effect which was previously paused at the
   specified channel */
void cAudio::ResumeSoundEffect(int channel)
{
    Mix_Resume(channel);
}

/* Function ResumeAllSoundEffects
 * Resumes all the sound effects which were previously paused */
void cAudio::ResumeAllSoundEffects()
{
    Mix_Resume(-1);
}

/* Function StopSoundEffect
 * Stops the sound effect currently being played at the specified channel */
void cAudio::StopSoundEffect(int channel)
{
    Mix_HaltChannel(channel);
}

/* Function StopAllSoundEffects
 * Stops all currently playing sound effects */
void cAudio::StopAllSoundEffects()
{
    Mix_HaltChannel(-1);
}

/* Function IsSoundPlaying/IsSoundPaused
 * Checks the state of the sound effect at the specified channel */
bool IsSoundPlaying(int channel)
{
    return Mix_Playing(channel);
}

bool IsSoundPaused(int channel)
{
    return Mix_Paused(channel);
}


/* Function PlayMusic
 * Plays the specified music file 'loop' times returning true on
   success and false on failure */
bool cAudio::PlayMusic(cMusic *music, int loop)
{
    if (Mix_PlayMusic(music->GetMusic(), loop) == -1) {
        return false;
    } else {
        SetMusicPosition(music->GetMusicStartPosition());
        _currentMusic = music;
        return true;
    }
}

bool cAudio::PlayMusic(const std::string &filepath, int loop)
{
    cMusic *music = soundManager->GetMusic(filepath);
    if (music != NULL) {
        if (Mix_PlayMusic(music->GetMusic(), loop) == -1) {
            return false;
        } else {
            SetMusicPosition(music->GetMusicStartPosition());
            _currentMusic = music;
            return true;
        }
    } else {
        return false;
    }
}

/* Function PauseMusic
 * Pauses the currently playing music */
void cAudio::PauseMusic()
{
    Mix_PauseMusic();
}

/* Function ResumeMusic
 * Resumes the currently paused music */
void cAudio::ResumeMusic()
{
    Mix_ResumeMusic();
}

/* Function StopMusic
 * Stops the currently playing music */
void cAudio::StopMusic()
{
    Mix_HaltMusic();
}

/* Function SetMusicPosition
 * Sets the position of the currently playing music

 * Note: Only works with MOD, OGG and MP3 music sources */
bool cAudio::SetMusicPosition(double pos)
{
    Mix_RewindMusic();
    if (pos > 0) {
        switch (Mix_GetMusicType(NULL))
        {
            case MUSIC_MOD:
            case MUSIC_OGG:
            case MUSIC_MP3:
                Mix_SetMusicPosition(pos);
                return true;
            default:
                return false;
        }
    } else {
        return false;
    }
}

/* Function IsMusicPlaying/IsMusicPaused
 * Allows the user to check the state of the music */
bool cAudio::IsMusicPlaying()
{
    return Mix_PlayingMusic() && !Mix_PausedMusic();
}

bool cAudio::IsMusicPaused()
{
    return Mix_PausedMusic();
}

/* Function GetCurrentMusic
 * Returns a pointer to the last music played (or still playing) */
cMusic* cAudio::GetCurrentMusic()
{
    return _currentMusic;
}

/* Function GetNum(state)Channels
 * Returns the number of channels in the specified state */
int cAudio::GetNumPlayingChannels()
{
    return Mix_Playing(-1);
}

int cAudio::GetNumPausedChannels()
{
    return Mix_Paused(-1);
}

/* Function (Get/Set)Volume[All](Channel/Music)
 * Allows the user to manage the volume of both the sound
   effect channels and the music channel */
void cAudio::SetVolumeChannel(int channel, int volume)
{
    Mix_Volume(channel, volume);
}

void cAudio::SetVolumeAllChannels(int volume)
{
    Mix_Volume(-1, volume);
}

int cAudio::GetVolumeChannel(int channel)
{
    return Mix_Volume(channel, -1);
}

int cAudio::GetVolumeAllChannels()
{
    return Mix_Volume(-1, -1);
}

void cAudio::SetVolumeMusic(int volume)
{
    Mix_VolumeMusic(volume);
}

int cAudio::GetVolumeMusic()
{
    return Mix_VolumeMusic(-1);
}

}
