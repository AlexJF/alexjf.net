/**********************************************************************************************
 * cFontManager.cpp - Implementation of the Font Manager class which is part of GR8 Graphics  *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info                       *
 *                               Copyright � Revolt 2008                                      *
 **********************************************************************************************/

#include "cFontManager.h"

using namespace std;

namespace GR8 {

/*---------------------------------------
  -         Font Implementation         -
  ---------------------------------------*/

cFont::cFont(cFontManager *manager)
{
    _manager = manager;
    _fontPath = "";
    _size = 0;
    _textures = NULL;
    _glyphmetrics = NULL;
    _listbase = 0;
}

cFont::~cFont()
{
    Clear();
}

bool cFont::Init(const std::string &fontPath, int fontSize)
{
    _fontPath = fontPath;
    _size = fontSize;

    FT_Library library;
    if (FT_Init_FreeType(&library)) {
        cerr << "Unable to load freetype library" << endl;
        return false;
    }

    FT_Face face;
    if (FT_New_Face(library, fontPath.c_str(), 0, &face)) {
        cerr << "Unable to load freetype font" << endl;
        return false;
    }

    FT_Set_Char_Size(face, 0, fontSize * 64, 0, 0);

    _textures = new GLuint[128];
    _glyphmetrics = new sGlyphMetrics[128];
    _listbase = glGenLists(128);
    glGenTextures(128, _textures);

    for (int i = 0; i < 128; i++) {
        if (!MakeGLList(face, i)) {
            cerr << "Unable to load char " << static_cast< char >(i) << endl;
            return false;
        }
    }

    FT_Done_Face(face);
    FT_Done_FreeType(library);

    return true;
}

void cFont::Clear()
{
    glDeleteLists(_listbase,128);
	glDeleteTextures(128,_textures);
	delete[] _textures;
	_textures = NULL;
}

string cFont::GetPath()
{
    return _fontPath;
}

int cFont::GetSize()
{
    return _size;
}

GLuint cFont::GetDisplayList()
{
    return _listbase;
}

/* Function CalculateTextSize
 * Calculates the size of the given text using this font and returns it */
sSize cFont::CalculateTextSize(const string &text)
{
    float width = 0, height = 0;
    for (int i = 0; i < text.length(); i++) {
        char currentChar = text.c_str()[i];
        sGlyphMetrics metrics = _glyphmetrics[currentChar];
        width += metrics.advance;
        height = max(height, metrics.height + (metrics.height - metrics.top));
    }
    return sSize(width, height);
}

bool cFont::MakeGLList(FT_Face &face, const char &ch)
{
    if (FT_Load_Glyph(face, FT_Get_Char_Index(face, ch), FT_LOAD_DEFAULT)) {
        cerr << "Unable to load freetype glyph: " << static_cast< char >(ch) << endl;
        return false;
    }

    FT_GlyphSlot &glyph = face->glyph;

    if (FT_Render_Glyph(glyph, FT_RENDER_MODE_NORMAL)) {
        cerr << "Unable to render freetype glyph: " << static_cast< char >(ch) << endl;
    }
    FT_Bitmap &bitmap = face->glyph->bitmap;

    int width = nextPowerOf2(bitmap.width);
    int height = nextPowerOf2(bitmap.rows);

    GLubyte *expanded_data = new GLubyte[2 * width * height];

    for (int j=0; j <height;j++) {
		for (int i=0; i < width; i++){
			expanded_data[2*(i+j*width)]= expanded_data[2*(i+j*width)+1] =
				(i>=bitmap.width || j>=bitmap.rows) ?
				0 : bitmap.buffer[i + bitmap.width*j];
		}
    }

    _glyphmetrics[ch].width = bitmap.width;
    _glyphmetrics[ch].height = bitmap.rows;
    _glyphmetrics[ch].advance = glyph->advance.x / 64.0;
    _glyphmetrics[ch].top = glyph->bitmap_top;

    glBindTexture( GL_TEXTURE_2D, _textures[ch]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);

	// Here We Actually Create The Texture Itself, Notice
	// That We Are Using GL_LUMINANCE_ALPHA To Indicate That
	// We Are Using 2 Channel Data.
	glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, expanded_data );

	// With The Texture Created, We Don't Need The Expanded Data Anymore.
	delete [] expanded_data;

    //So now we can create the display list
	glNewList(_listbase+ch,GL_COMPILE);

	glBindTexture(GL_TEXTURE_2D, _textures[ch]);

	glPushMatrix();

	//first we need to move over a little so that
	//the character has the right amount of space
	//between it and the one before it.
	glTranslatef(glyph->bitmap_left,0,0);

	float globalHeight = (_size * 96) / 64.0;
	cout << "Global font height: " << globalHeight << endl;

	//Now we move down a little in the case that the
	//bitmap extends past the bottom of the line
	//(this is only true for characters like 'g' or 'y'.
	glTranslatef(0, globalHeight / 2 - glyph->bitmap_top,0);

	//Now we need to account for the fact that many of
	//our textures are filled with empty padding space.
	//We figure what portion of the texture is used by
	//the actual character and store that information in
	//the x and y variables, then when we draw the
	//quad, we will only reference the parts of the texture
	//that we contain the character itself.
	float	x=(float)bitmap.width / (float)width,
			y=(float)bitmap.rows / (float)height;

	//Here we draw the texturemaped quads.
	//The bitmap that we got from FreeType was not
	//oriented quite like we would like it to be,
	//so we need to link the texture to the quad
	//so that the result will be properly aligned.
	glBegin(GL_QUADS);
	glTexCoord2d(0,0); glVertex2f(0,0);
	glTexCoord2d(0,y); glVertex2f(0,bitmap.rows);
	glTexCoord2d(x,y); glVertex2f(bitmap.width,bitmap.rows);
	glTexCoord2d(x,0); glVertex2f(bitmap.width,0);
	glEnd();
	glPopMatrix();

	glTranslatef(glyph->advance.x / 64.0 ,0,0);


	//increment the raster position as if we were a bitmap font.
	//(only needed if you want to calculate text length)
	//glBitmap(0,0,0,0,face->glyph->advance.x >> 6,0,NULL);

	//Finnish the display list
	glEndList();

	return true;
}

/*---------------------------------------
  -     Font Manager Implementation     -
  ---------------------------------------*/

cFontManager::cFontManager()
{
}

cFontManager::~cFontManager()
{
    cout << "Entering Font Manager Shutdown" << endl;
    RemoveAllFonts();
}

/* Function GetFont
 * Loads a new font from a file and returns it or, in case a font with the
   specified details already exists, returns the existing font.

 * Note: fontName should not start with '\' */
cFont* cFontManager::GetFont(const std::string &fontPath, int fontSize)
{
    vector< cFont* >::iterator it;
    //Search existing fonts for a match and return it if found
    for (it = _fonts.begin(); it != _fonts.end(); it++) {
        cFont *existingFont = *it;
        if (existingFont->GetPath() == fontPath && existingFont->GetSize() == fontSize) {
            return existingFont;
        }
    }

    cFont *newFont = new cFont(this);

    //Load new font
    if (!newFont->Init(fontPath, fontSize)) {
        cerr << "Unable to load font object: " << fontPath << endl;
        return NULL;
    }

    _fonts.push_back(newFont);

    return newFont;
}

/* Function RemoveFont
 * Removes and deletes a single font that matches the provided details
   returning true on success and false on error */
bool cFontManager::RemoveFont(const string &fontName, int fontSize)
{
    vector< cFont* >::iterator it;
    for (it = _fonts.begin(); it != _fonts.end(); it++) {
        cFont *existingFont = *it;
        if (existingFont->GetPath() == fontName && existingFont->GetSize() == fontSize) {
            delete existingFont;
            _fonts.erase(it);
            return true;
        }
    }
    return false;
}

/* Function RemoveAllFonts
 * Removes and deletes all managed fonts */
void cFontManager::RemoveAllFonts()
{
    vector< cFont* >::iterator it;
    for (it = _fonts.end() - 1; it >= _fonts.begin(); --it) {
        cFont *existingFont = *it;
        delete existingFont;
        _fonts.erase(it);
    }
}

}
