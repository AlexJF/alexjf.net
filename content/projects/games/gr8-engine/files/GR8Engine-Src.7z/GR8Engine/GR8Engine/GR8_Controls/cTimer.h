/****************************************************************************
 * cTimer.h - Declares the Timer class                                      *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info     *
 *                       Copyright � Revolt 2008                            *
 *--------------------------------------------------------------------------*
 * Description: Timer class represents a generic timer that either informs  *
 * the caller of how much time has passed since the timer was activated or  *
 * calls the specfied function when the specified ticks are reached.        *
 ****************************************************************************/

#ifndef CTIMER_H_INCLUDED
#define CTIMER_H_INCLUDED

#include "..\Global.h"
#include "..\GR8_Core\cControlManager.h"

namespace GR8 {

class cTimer : public cControl
{
    public:
        cTimer(const std::string &ID = "", int ticks = 0, void (*callback)(cTimer *caller) = NULL);
        virtual ~cTimer();

        void Start();
        void Pause();
        void Resume();
        void Stop();

        int GetTicks();
        bool IsRunning();
        bool IsPaused();

        void SetCallBackTimer(int ticks, void (*callback)(cTimer *caller));

    protected:
        //Functions called by the Control Manager
        virtual bool Initialize();
        virtual bool HandleEvent(cEvent *event);
        virtual void Update();
        virtual void Draw();

        virtual bool OnFocusGained();
        virtual bool OnFocusLost();

    private:
        int _startTicks;
        int _pausedTicks;

        bool _running;
        bool _paused;

        void (*_callback)(cTimer *caller);
        int _targetTicks;
};

}

#endif // CTIMER_H_INCLUDED
