/*****************************************************************************************
 * cFontManager.h - Declaration of the Font Manager class which is part of GR8 Graphics  *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info                  *
 *                               Copyright � Revolt 2008                                 *
 *---------------------------------------------------------------------------------------*
 * Description: FontManager is a class responsible for loading the required fonts and    *
 * saving them in memory until they aren't needed anymore. Font is the wrapper around    *
 * the platform specified variable of a font                                             *
 *****************************************************************************************/

#ifndef CFONTMANAGER_H_INCLUDED
#define CFONTMANAGER_H_INCLUDED

#include "..\Global.h"

namespace GR8 {

struct sGlyphMetrics
{
    sGlyphMetrics(float w = 0, float h = 0, float a = 0, float t = 0) { width = w; height = h; advance = a; top = t;}
    ~sGlyphMetrics() {}

    float width;
    float height;

    float advance;
    float top;
};

class cFont
{
    friend class cFontManager;

    public:
        cFont(cFontManager *manager);
        ~cFont();

        bool Init(const std::string &fontPath, int fontSize);
        void Clear();

        std::string GetPath();
        int GetSize();
        GLuint GetDisplayList();

        sSize CalculateTextSize(const std::string &text);

    protected:
        std::string _fontPath;
        int _size;
        bool _ready;

        GLuint _listbase;
        GLuint *_textures;
        sGlyphMetrics *_glyphmetrics;

        cFontManager *_manager;

    private:
        bool MakeGLList(FT_Face &face, const char &ch);
};

class cFontManager
{
    friend class cFont;

    public:
        cFontManager();
        ~cFontManager();

        cFont* GetFont(const std::string &fontName, int fontSize);

        bool RemoveFont(const std::string &fontName, int fontSize);
        void RemoveAllFonts();

    private:
        std::vector< cFont* > _fonts;
};

}

#endif // CFONTMANAGER_H_INCLUDED
