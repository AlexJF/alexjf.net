/****************************************************************************
 * cButton.cpp - Implements the Button class                                *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info     *
 *                       Copyright � Revolt 2008                            *
 ****************************************************************************/

#include "cButton.h"

using namespace std;

namespace GR8 {

cButton::cButton(const std::string &ID, const sPosition &pos, const std::string &text, void (*Callback)(eMouseButton mouseBtn, const sPosition &mousePos, cButton *caller), sControlStyle style) : cControl()
{
    _controlID = ID;
    _controlArea = sRect(pos.x, pos.y, style.size.w, style.size.h);

    _textFont = style.textFont;

    _backgroundColor = style.backgroundIdleColor;
    _foregroundColor = style.foregroundIdleColor;
    _hoverBackColor = style.backgroundHoverColor;
    _hoverForeColor = style.foregroundHoverColor;
    _clickBackColor = style.backgroundClickColor;
    _clickForeColor = style.foregroundClickColor;

    _borderColor = style.borderColor;
    _borderWidth = style.borderWidth;

    _idleText = text;
    _hoverText = text;
    _clickText = text;

    OnClickHandler = Callback;
}

cButton::~cButton()
{
}

void cButton::SetAllText(const std::string &text)
{
    _idleText = text;
    _hoverText = text;
    _clickText = text;
}

/* Function Set(State)Text
 * Sets the text to show when the control is in the selected state */
void cButton::SetIdleText(const std::string &text)
{
    _idleText = text;
}

void cButton::SetHoverText(const std::string &text)
{
    _hoverText = text;
}

void cButton::SetClickText(const std::string &text)
{
    _clickText = text;
}

/* Function SetTextFont
 * Sets the font of the text to show in the control

 * Note: can only be called after adding the control to a control manager */

void cButton::SetTextFont(const std::string &fontName, int fontSize)
{
    cFontManager *fontManager = GetControlManager()->GetScreen()->GetManager()->GetApplication()->graphics->fontManager;
    _textFont = fontManager->GetFont(fontName, fontSize);
}

/* Function SetBackground(state)Color
 * Sets the color of the background of the control when the mouse hovers it */
void cButton::SetBackgroundColor(const sColor &color)
{
    _backgroundColor = color;
}

void cButton::SetBackgroundHoverColor(const sColor &color)
{
    _hoverBackColor = color;
}

void cButton::SetBackgroundClickColor(const sColor &color)
{
    _clickBackColor = color;
}

/* Function SetForeground(state)Color
 * Sets the color of the foreground of the control when the mouse hovers it */
void cButton::SetForegroundColor(const sColor &color)
{
    _foregroundColor = color;
}

void cButton::SetForegroundHoverColor(const sColor &color)
{
    _hoverForeColor = color;
}

void cButton::SetForegroundClickColor(const sColor &color)
{
    _clickForeColor = color;
}

/* Function Get(State)Text
 * Returns the text of the control in the specified state */
std::string cButton::GetIdleText()
{
    return _idleText;
}

std::string cButton::GetHoverText()
{
    return _hoverText;
}

std::string cButton::GetClickText()
{
    return _clickText;
}

/* Function GetTextFont
 * Returns the font that will be used in the rendering of the control's text */
cFont* cButton::GetTextFont()
{
    return _textFont;
}

/* Function GetBackground(state)Color
 * Gets the color of the background of the control when the mouse hovers it */
sColor cButton::GetBackgroundHoverColor()
{
    return _hoverBackColor;
}

sColor cButton::GetBackgroundClickColor()
{
    return _clickBackColor;
}

/* Function GetForeground(state)Color
 * Gets the color of the foreground of the control when the mouse hovers it */
sColor cButton::GetForegroundHoverColor()
{
    return _hoverForeColor;
}

sColor cButton::GetForegroundClickColor()
{
    return _clickForeColor;
}

/* Function Initialize
 * This function initializes the button and is automatically called when the control is added to the control manager */
bool cButton::Initialize()
{
    return true;
}

/* Function HandleEvent
 * If it handles the specified event true is returned. False otherwise */
bool cButton::HandleEvent(cEvent *event)
{
    cout << "Button Handle Event" << endl;

    cMouseEvent *mouseEvent = NULL;
    cKeyEvent *keyEvent = NULL;

    bool handled = false;

    switch (event->GetType())
    {
        case EVENT_MOUSEUP:
            mouseEvent = static_cast< cMouseEvent* >(event);

            //If mouse button is now up and there was no dragging then we've got a click
            //(since the click animation was performed on the down event we reset the state to
            //hover since the mouse is bound to be inside the control
            if (!_dragging && _state == CTRL_STATE_CLICK) {
                _state = CTRL_STATE_MOUSEHOVER;
                if (OnClickHandler != NULL) {
                    (*OnClickHandler)(mouseEvent->GetMouseButton(), mouseEvent->GetMousePosition(), this);
                }
                handled = true;
            }
            break;

        case EVENT_KEYDOWN:
            if (HasFocus()) {
                keyEvent = static_cast< cKeyEvent* >(event);
                switch (keyEvent->GetKeyCode())
                {
                    case KEY_RETURN:
                        _state = CTRL_STATE_CLICK;
                        handled = true;
                        break;
                    default: //Ignore all other key events and do not call the handler function
                        break;
                }
            }
            break;
        case EVENT_KEYUP:
            if (HasFocus()) {
                keyEvent = static_cast< cKeyEvent* >(event);
                switch (keyEvent->GetKeyCode())
                {
                    case KEY_RETURN:
                        _state = CTRL_STATE_IDLE;
                        handled = true;
                        //Call the OnClickHandler since this'll count as a click
                        if (OnClickHandler != NULL) {
                            (*OnClickHandler)(MOUSE_NONE, sPosition(0, 0), this);
                        }
                        break;
                    default:
                        break;
                }
            }
            break;

        default:
            break;
    }

    bool eventTreatedByDefaultHandler = cControl::HandleEvent(event);

    if (eventTreatedByDefaultHandler || handled) {
        event->Treat();
        return true;
    }

    return false;
}

/* Function Update
 * Performs additional calculations/actions */
void cButton::Update()
{
}

/* Function Draw
 * Draws the control on the screen */
void cButton::Draw()
{
    if (!Visible) {
        return;
    }
    cGraphics *graphics = GetControlManager()->GetScreen()->GetManager()->GetApplication()->graphics;
    sColor drawBackColor;
	string text;
    switch (_state)
    {
        case CTRL_STATE_IDLE:
			text = _idleText;
            drawBackColor = _backgroundColor;
            break;
        case CTRL_STATE_MOUSEHOVER:
			text = _hoverText;
            drawBackColor = _hoverBackColor;
            break;
        case CTRL_STATE_MOUSEBTNPRESSED:
        case CTRL_STATE_CLICK:
			text = _clickText;
            drawBackColor = _clickBackColor;
            break;
        default:
			text = _idleText;
            drawBackColor = _backgroundColor;
            break;
    }
    //Draw background
    graphics->DrawFilledRectangle(GetArea(), drawBackColor, false);
    //Draw text
    if (_textFont != NULL) {
        graphics->DrawText(GetCenterPosition(_textFont->CalculateTextSize(text), GetArea()), text,  _textFont, sColor(0, 0, 0), false);
    }

    //Draw borders
    DrawBorders();
}

bool cButton::OnFocusGained()
{
    return true;
}

bool cButton::OnFocusLost()
{
    return true;
}

}
