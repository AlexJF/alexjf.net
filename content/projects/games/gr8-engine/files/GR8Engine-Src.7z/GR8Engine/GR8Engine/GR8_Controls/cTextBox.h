/** \file cTextBox.h
    \author Revolt
    \brief Defines a TextBox control.
*/

#ifndef CTEXTBOX_H_INCLUDED
#define CTEXTBOX_H_INCLUDED

#include "..\Global.h"
#include "..\GR8_Core\cControlManager.h"
#include "..\GR8_Graphics\cGraphics.h"

namespace GR8 {

class cTextBox : public cControl
{
    public:
        cTextBox(const std::string &ID, const sPosition &pos, const std::string &text = "", sControlStyle style = sControlStyle());
        ~cTextBox();

        void SetBackgroundHoverColor(const sColor &color);
        void SetBackgroundClickColor(const sColor &color);

        std::string GetText();
        cFont* GetTextFont();

        sColor GetBackgroundHoverColor();
        sColor GetBackgroundClickColor();

        virtual bool OnFocusGained();
        virtual bool OnFocusLost();

    protected:
        //Functions called by the Control Manager
        virtual bool Initialize();
        virtual bool HandleEvent(cEvent *event);
        virtual void Update();
        virtual void Draw();

    private:
        bool _enabled;
};

}

#endif // CTEXTBOX_H_INCLUDED
