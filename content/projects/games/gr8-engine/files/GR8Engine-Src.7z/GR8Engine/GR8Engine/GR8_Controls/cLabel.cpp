/** \file cLabel.cpp
    \author Revolt
    \brief Implements the Label control defined in cLabel.h.
*/

#include "cLabel.h"

using namespace std;

namespace GR8 {

cLabel::cLabel(const std::string &ID, const sPosition &pos, const std::string &text, sControlStyle style) : cControl()
{
    _controlID = ID;
    _controlArea = sRect(pos.x, pos.y, style.size.w, style.size.h);

    _enabled = style.enabled;

    _textFont = style.textFont;

    _backgroundColor = style.backgroundIdleColor;
    _foregroundColor = style.foregroundIdleColor;
    _hoverBackColor = style.backgroundHoverColor;
    _clickBackColor = style.backgroundClickColor;

    _borderColor = style.borderColor;
    _borderWidth = style.borderWidth;

    _horiAlign = style.horizontalAlign;
    _vertAlign = style.verticalAlign;

    _text = text;
}

cLabel::~cLabel()
{
}

void cLabel::SetText(const std::string &text)
{
    _text = text;
}

/* Function SetTextFont
 * Sets the font of the text to show in the control

 * Note: can only be called after adding the control to a control manager */
void cLabel::SetTextFont(const std::string &fontName, int fontSize)
{
    cFontManager *fontManager = GetControlManager()->GetScreen()->GetManager()->GetApplication()->graphics->fontManager;
    _textFont = fontManager->GetFont(fontName, fontSize);
}

void cLabel::SetTextFont(cFont *font)
{
    _textFont = font;
}

/* Function SetBackground(state)Color
 * Sets the color of the background of the control when the mouse hovers it */
void cLabel::SetBackgroundColor(const sColor &color)
{
    _backgroundColor = color;
}

void cLabel::SetBackgroundHoverColor(const sColor &color)
{
    _hoverBackColor = color;
}

void cLabel::SetBackgroundClickColor(const sColor &color)
{
    _clickBackColor = color;
}

/* Function SetForeground(state)Color
 * Sets the color of the foreground of the control when the mouse hovers it */
void cLabel::SetForegroundColor(const sColor &color)
{
    _foregroundColor = color;
}

void cLabel::SetTextAlignment(const eHorizontalAlign &hori, const eVerticalAlign &vert) {
    _horiAlign = hori;
    _vertAlign = vert;
}

void cLabel::SetTextAlignment(const eVerticalAlign &vert, const eHorizontalAlign &hori) {
    _horiAlign = hori;
    _vertAlign = vert;
}

void cLabel::SetTextAlignment(const eHorizontalAlign &hori) {
    _horiAlign = hori;
}

void cLabel::SetTextAlignment(const eVerticalAlign &vert) {
    _vertAlign = vert;
}

/* Function Get(State)Text
 * Returns the text of the control in the specified state */
std::string cLabel::GetText()
{
    return _text;
}

/* Function GetTextFont
 * Returns the font that will be used in the rendering of the control's text */
cFont* cLabel::GetTextFont()
{
    return _textFont;
}

/* Function GetBackground(state)Color
 * Gets the color of the background of the control when the mouse hovers it */
sColor cLabel::GetBackgroundHoverColor()
{
    return _hoverBackColor;
}

sColor cLabel::GetBackgroundClickColor()
{
    return _clickBackColor;
}

int cLabel::GetTextAlignment(const eOrientation &ori) {
    if (ori == ORI_HORIZONTAL) {
        return _horiAlign;
    }
    else {
        return _vertAlign;
    }
}

/* Function Initialize
 * This function initializes the button and is automatically called when the control is added to the control manager */
bool cLabel::Initialize()
{
    return true;
}

/* Function HandleEvent
 * If it handles the specified event true is returned. False otherwise */
bool cLabel::HandleEvent(cEvent *event)
{
    cout << "Label Handle Event" << endl;

    bool eventTreatedByDefaultHandler = cControl::HandleEvent(event);

    cMouseEvent *mouseEvent = NULL;
    cKeyEvent *keyEvent = NULL;

    if (eventTreatedByDefaultHandler) {
        event->Treat();
        return true;
    }

    return false;
}

/* Function Update
 * Performs additional calculations/actions */
void cLabel::Update()
{
}

/* Function Draw
 * Draws the control on the screen */
void cLabel::Draw()
{
    if (!Visible) {
        return;
    }
    cGraphics *graphics = GetControlManager()->GetScreen()->GetManager()->GetApplication()->graphics;
    sColor drawBackColor;
    switch (_state)
    {
        case CTRL_STATE_IDLE:
            drawBackColor = _backgroundColor;
            break;
        case CTRL_STATE_MOUSEHOVER:
            drawBackColor = _hoverBackColor;
            break;
        case CTRL_STATE_MOUSEBTNPRESSED:
        case CTRL_STATE_CLICK:
            drawBackColor = _clickBackColor;
            break;
        default:
            drawBackColor = _backgroundColor;
            break;
    }
    //Draw background
    graphics->DrawFilledRectangle(GetArea(), drawBackColor, false);
    //Draw text
    if (_textFont != NULL) {
        sSize textSize = _textFont->CalculateTextSize(_text);
        sPosition textPosition = sPosition();
        sPosition labelAbsPosition = GetPosition();

        switch (_horiAlign)
        {
            case ALIGN_HORI_LEFT:
                textPosition.x = labelAbsPosition.x;
                break;
            case ALIGN_HORI_CENTER:
                textPosition.x = GetCenterPosition(textSize, GetArea()).x;
                break;
            case ALIGN_HORI_RIGHT:
                textPosition.x = labelAbsPosition.x + GetSize().w - textSize.w;
                break;
        }

        switch  (_vertAlign)
        {
            case ALIGN_VERT_TOP:
                textPosition.y = labelAbsPosition.y;
                break;
            case ALIGN_VERT_MIDDLE:
                textPosition.y = GetCenterPosition(textSize, GetArea()).y;
                break;
            case ALIGN_VERT_BOTTOM:
                textPosition.y = labelAbsPosition.y + GetSize().h - textSize.h;
                break;
        }

        graphics->DrawText(textPosition, _text,  _textFont, _foregroundColor, false, &GetArea());
    }
    //Draw borders
    DrawBorders();
}

bool cLabel::OnFocusGained()
{
    return true;
}

bool cLabel::OnFocusLost()
{
    return true;
}
}
