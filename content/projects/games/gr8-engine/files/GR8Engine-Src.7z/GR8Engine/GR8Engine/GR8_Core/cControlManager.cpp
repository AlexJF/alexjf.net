/********************************************************************************
 * cControlManager.cpp - Implements the Control Manager and Control classes     *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info         *
 *                       Copyright � Revolt 2008                                *
 ********************************************************************************/

#include "cControlManager.h"
#include "..\GR8_Graphics\cGraphics.h"

using namespace std;

namespace GR8 {

/* --------------------------
   - Control Implementation -
   -------------------------- */

cControl::cControl()
{
    //Set variables to default values
    _controlID = "";
    _controlArea = sRect();
    _backgroundColor = sColor();
    _foregroundColor = sColor();
    _leftMousePressed = false;
    _rightMousePressed = false;
    _dragging = false;
    _manager = NULL;
    _insideControl = false;
	_childControlManager = NULL;

    Visible = true;
    AllowDrag = false;

    _borderColor = sColor();
    _borderWidth = 0;

    _state = CTRL_STATE_IDLE;
}

cControl::~cControl()
{
}

void cControl::DrawBorders()
{
    cGraphics *graphics = GetControlManager()->GetScreen()->GetManager()->GetApplication()->graphics;
    if (_borderWidth > 0) {
        sRect area = GetArea();
        graphics->DrawRectangle(area, _borderColor, false);
    }
}

bool cControl::InsideControl(const sPosition &pos, const sSize &size)
{
    if (pos.x >= _controlArea.x && (pos.x + size.w) <= (_controlArea.x + _controlArea.w) && pos.y >= _controlArea.y && (pos.y + size.h) <= (_controlArea.y + _controlArea.h)) {
        return true;
    } else {
        return false;
    }
}

bool cControl::SetFocus()
{
    if (_manager != NULL) {
        _manager->SetFocusedControl(this);
        return true;
    } else {
        return false;
    }
}

bool cControl::HasFocus()
{
    if (_manager != NULL) {
        return _manager->ControlFocused(_controlID);
    }
    return false;
}

bool cControl::SetID(const std::string &ID)
{
    if (_manager == NULL) {
        _controlID = ID;
        return true;
    } else {
        return false;
    }
}

bool cControl::SetPosition(const sPosition &newPosition)
{
    _controlArea.x = newPosition.x;
    _controlArea.y = newPosition.y;
    return true;
}

bool cControl::SetPositionRelative(const sPosition &newPosition)
{
    if (GetControlManager() == NULL) {
        return false;
    }

    cControl *controlOwner = GetControlManager()->GetOwnerControl();
    cScreen *screenOwner = GetControlManager()->GetScreen();

    sPosition ownerPos = sPosition(0, 0);

    if (controlOwner != NULL) {
        ownerPos = controlOwner->GetPosition();
    }
    else if (screenOwner != NULL) {
        ownerPos = screenOwner->GetScreenArea().GetPosition();
    }

    _controlArea = sRect(ownerPos + newPosition, _controlArea.GetSize());
    return true;
}

bool cControl::SetDeltaPosition(float deltaX, float deltaY)
{
    if (_childControlManager != NULL) {
        vector< cControl* >::iterator it;
        vector< cControl* > *controls = GetChildControlManager()->GetControlList();
        for (it = controls->begin(); it != controls->end(); it++) {
            cControl *currentControl = *it;
            currentControl->SetDeltaPosition(deltaX, deltaY);
        }
    }

    _controlArea.x += deltaX;
    _controlArea.y += deltaY;
    return true;
}

bool cControl::SetSize(const sSize &newSize)
{
    if (newSize.h > 0 && newSize.w > 0) {
        _controlArea.h = newSize.h;
        _controlArea.w = newSize.w;
        return true;
    } else {
        return false;
    }
}

void cControl::SetBackgroundColor(const sColor &color)
{
    _backgroundColor = color;
}

void cControl::SetForegroundColor(const sColor &color)
{
    _foregroundColor = color;
}

void cControl::SetBorder(int width, const sColor &color)
{
    _borderColor = color;
    _borderWidth = width;
}

std::string cControl::GetID()
{
    return _controlID;
}

sPosition cControl::GetPosition()
{
    return _controlArea.GetPosition();
}

sPosition cControl::GetPositionRelative()
{
    if (GetControlManager() == NULL) {
        return _controlArea.GetPosition();
    }

    cControl *controlOwner = GetControlManager()->GetOwnerControl();
    cScreen *screenOwner = GetControlManager()->GetScreen();

    sPosition ownerPos = sPosition(0, 0);

    if (controlOwner != NULL) {
        ownerPos = controlOwner->GetPosition();
    }
    else if (screenOwner != NULL) {
        ownerPos = screenOwner->GetScreenArea().GetPosition();
    }

    return sPosition(GetPosition() - ownerPos);
}

sSize cControl::GetSize()
{
    return _controlArea.GetSize();
}

sRect cControl::GetArea()
{
    return _controlArea;
}

sRect cControl::GetAreaRelative()
{
    if (GetControlManager() == NULL) {
        return _controlArea;
    }

    sPosition parentPosition = sPosition();

    cControl *parentControl = GetControlManager()->GetOwnerControl();
    cScreen *parentScreen = GetControlManager()->GetScreen();

    if (parentControl != NULL) {
        parentPosition = parentControl->GetPosition();
    }
    else if (parentScreen != NULL) {
        parentPosition = GetControlManager()->GetScreen()->GetScreenArea().GetPosition();
    }
    else {
        parentPosition = sPosition(0, 0);
    }

    return sRect(GetPositionRelative(), _controlArea.GetSize());
}

sColor cControl::GetBackgroundColor()
{
    return _backgroundColor;
}

sColor cControl::GetForegroundColor()
{
    return _foregroundColor;
}

sColor cControl::GetBorderColor()
{
    return _borderColor;
}

int cControl::GetBorderWidth()
{
    return _borderWidth;
}

bool cControl::IsDragging()
{
    return _dragging;
}

cControlManager* cControl::GetChildControlManager()
{
    return _childControlManager;
}

cControlManager* cControl::GetControlManager()
{
    return _manager;
}

bool cControl::HandleEvent(cEvent *event)
{
    cMouseEvent *mouseEvent = NULL;
    cKeyEvent *keyEvent = NULL;

    switch (event->GetType())
    {
        case EVENT_MOUSEDOWN:
            mouseEvent = static_cast< cMouseEvent* >(event);
            //Exit if event is outside the control area or was already treated by another control
            if (!InsideControl(mouseEvent->GetMousePosition()) || event->IsTreated()) {
				if (HasFocus()) {
					_manager->SetFocusedControl(NULL);
				}
                return false;
            }

            SetFocus(); //Set focus on the button
            _state = CTRL_STATE_CLICK;

            switch (mouseEvent->GetMouseButton())
            {
                case MOUSE_LEFTBTN:
                    _leftMousePressed = true;
                    break;
                case MOUSE_RIGHTBTN:
                    _rightMousePressed = true;
                    break;
                default:
                    break;
            }
            return true;
            break;
        case EVENT_MOUSEUP:
            mouseEvent = static_cast< cMouseEvent* >(event);
            //Exit if event is outside the control area or was already treated by another control
            if (!InsideControl(mouseEvent->GetMousePosition()) || event->IsTreated()) {
                return false;
            }
            switch (mouseEvent->GetMouseButton())
            {
                case MOUSE_LEFTBTN:
                    _leftMousePressed = false;
                    break;
                case MOUSE_RIGHTBTN:
                    _rightMousePressed = false;
                    break;
                default:
                    break;
            }
            if (_dragging) {
                _dragging = false;
                _state = CTRL_STATE_MOUSEHOVER;
            }
            return true;
            break;
        case EVENT_MOUSEMOVE:
            mouseEvent = static_cast< cMouseEvent* >(event);
			cout << 0 << endl;
            //If we are dragging set the dragging variable to true and the state to drag
            if ((_leftMousePressed || _rightMousePressed) && AllowDrag && _insideControl && !event->IsTreated() && !_dragging) {
                _dragging = true;
                _state = CTRL_STATE_DRAG;
            }
            //On Drag perform the following:
            if (_dragging && !event->IsTreated()) {
				cout << 1 << endl;
                sPosition relMousePos = mouseEvent->GetRelativeMousePosition();
				cout << 2 << endl;
                SetDeltaPosition(relMousePos.x, relMousePos.y);
				cout << 3 << endl;
                return true;
            //If it is not a drag event perform the following:
            } else {
                //Mouse moved out of the area of the control or another control catched the event first then set button to Idle and call MouseOutHandler
                if (!InsideControl(mouseEvent->GetMousePosition()) && _insideControl) {
                    _insideControl = false;
                    _state = CTRL_STATE_IDLE;
                }
                //If mouse moved inside the control
                else if (!event->IsTreated() && InsideControl(mouseEvent->GetMousePosition()) && !_insideControl) {
                    _insideControl = true;
                    _state = CTRL_STATE_MOUSEHOVER;
                }
            }
            return false;
            break;
        case EVENT_KEYDOWN:
            return false;
            break;
        case EVENT_KEYUP:
            return false;
            break;

        default:
            break;
    }



    return false;
}

/* ----------------------------------
   - Control Manager Implementation -
   ---------------------------------- */

cControlManager::cControlManager(cScreen *owner)
{
    _ownerScreen = owner;
    _ownerControl = NULL;
    _focusedControl = NULL;
    _controls.clear();
    _focusAll = false;
}

cControlManager::cControlManager(cControl *owner)
{
    _ownerScreen = NULL;
    _ownerControl = owner;
    _focusedControl = NULL;
    _controls.clear();
    _focusAll = false;
}

cControlManager::~cControlManager()
{
	cout << "Entering Control Manager destructor" << endl;
    DeleteAllControls();
	cout << "Leaving Control Manager destructor" << endl;
}

/* Function AddControl
 * Adds a control to the manager list */
bool cControlManager::AddControl(cControl *control)
{
    //cout << "Add Control" << endl;
    if (GetControl(control->GetID()) == NULL) {
        control->_manager = this;
        if (control->Initialize()) {
            _controls.push_back(control);
            return true;
        }
    }
    return false;
}

/* Function DeleteControl
 * Removes a control from the manager list and deletes it */
void cControlManager::DeleteControl(const std::string &ID)
{
    if (_controls.size() == 0) {
        return;
    }
    vector< cControl* >::iterator it;
    for (it = _controls.end() - 1; it >= _controls.begin(); it--) {
        cControl *currentControl = *it;
        if (currentControl->GetID() == ID) {
            delete currentControl;
            _controls.erase(it);
            return;
        }
    }
}

/* Function DeleteAllControls
 * Removes and deletes all the controls associated with this control manager */
void cControlManager::DeleteAllControls()
{
	cout << "Deleting " << _controls.size() << " controls" << endl;
    vector< cControl* >::iterator it;
    for (it = _controls.begin(); it != _controls.end(); ++it) {
        delete *it;
    }
	_controls.clear();
}

/* Function GetControl
 * Returns a pointer to the control associated with this control manager
   with the specified ID. If no ID found then returns NULL

 * Note: Do not use this pointer after calling DeleteControl(pointer_ctrl_ID) or DeleteAllControls
   because application will crash */
cControl* cControlManager::GetControl(const std::string &ID)
{
    if (_controls.size() == 0) {
        return NULL;
    }
    vector< cControl* >::iterator it;
    for (it = _controls.end() - 1; it >= _controls.begin(); --it) {
        cControl *currentControl = *it;
        if (currentControl->GetID() == ID) {
            return currentControl;
        }
    }
    return NULL;
}

std::vector< cControl* >* cControlManager::GetControlList()
{
    return &_controls;
}

void cControlManager::UpdateControls()
{
    vector< cControl* >::iterator it;
    for (it = _controls.begin(); it < _controls.end(); ++it) {
        cControl *currentControl = *it;
            currentControl->Update();
    }
}

void cControlManager::DrawControls()
{
    vector< cControl* >::iterator it;
    for (it = _controls.begin(); it < _controls.end(); ++it) {
        cControl *currentControl = *it;
        if (!currentControl->HasFocus()) {
            currentControl->Draw();
        }
    }
    //Check to see if we have a control with focus and if we do paint him last so it is on top of all the others
    cControl *focusedControl = GetFocusedControl();
    if (focusedControl != NULL) {
        focusedControl->Draw();
    }
}

/* Function HandleEvent
 * Sends the event to all managed controls. Control with focus has top priority.
   If event is not processed by focused control then it is sent to all the other
   controls starting by those that were added to the manager in the last place */
void cControlManager::HandleEvent(cEvent *event)
{
    cout << "Control Manager Handle Event" << endl;
    //Check to see if we have a control with focus and if we do send the event to it first
    cControl *focusedControl = GetFocusedControl();
    if (focusedControl != NULL) {
        //If event was processed by control with focus then we can leave
        focusedControl->HandleEvent(event);
    }

    //iterate through all the other controls starting by the one at the top of the vector
    vector< cControl* >::reverse_iterator it;
    for (it = _controls.rbegin(); it < _controls.rend(); ++it) {
        cControl *currentControl = *it;
        if (focusedControl != NULL) {
            if (focusedControl->GetID() == currentControl->GetID()) continue;
        }
        currentControl->HandleEvent(event);
    }
    cout << "End Of Control Manager Handle Event" << endl;
}

/* Function SetFocusedControl
 * Sets the control with focus */
void cControlManager::SetFocusedControl(cControl *control)
{
    if (_focusAll) {
        return;
    }

    //If there was no previous focused control
    if (_focusedControl == NULL) {
        _focusedControl = control;
        _focusedControl->OnFocusGained();
    } else {
        _focusedControl->OnFocusLost();
        _focusedControl = control;
		if (_focusedControl != NULL) {
			_focusedControl->OnFocusGained();
		}
    }
}

cControl* cControlManager::GetFocusedControl()
{
    cout << "Get Focused Control" << endl;
    if (_focusAll) {
        cout << "All Focused" << endl;
        return NULL;
    } else {
        return _focusedControl;
    }
}

bool cControlManager::ControlFocused(const std::string &ID)
{
    if (_focusAll) {
        return true;
    }

    if (_focusedControl != NULL) {
        return _focusedControl->GetID() == ID;
    } else {
        return false;
    }
}

void cControlManager::FocusAllManagedControls()
{
    _focusAll = true;
}

void cControlManager::UnfocusAllManagedControls()
{
    _focusAll = false;
}

bool cControlManager::AllControlsFocused()
{
    return _focusAll;
}

/* Function GetScreen
 * Returns the screen that owns this manager */
cScreen* cControlManager::GetScreen()
{
    cout << "Get Screen" << endl;
    if (_ownerScreen == NULL && _ownerControl != NULL) {
        return _ownerControl->GetControlManager()->GetScreen();
    }
    else if (_ownerScreen != NULL && _ownerControl == NULL) {
        return _ownerScreen;
    }
    else { return NULL; }
}

cControl* cControlManager::GetOwnerControl()
{
    cout << "Get Owner Control" << endl;
    return _ownerControl;
}

}


