/************************************************************************
 * GR8Engine.h - Global variables and include declarations              *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info *
 *                   Copyright � Revolt 2008                            *
 *----------------------------------------------------------------------*
 * Description: Header to include when you want to use the engine in    *
 * your project.                                                        *
 ************************************************************************/
#ifndef GR8ENGINE_H_INCLUDED
#define GR8ENGINE_H_INCLUDED

#include "GR8_Controls\cButton.h"
#include "GR8_Controls\cTimer.h"
#include "GR8_Controls\cTextBox.h"

#include "GR8_Core\cApp.h"

#include "GR8_Graphics\cGraphics.h"
#include "GR8_Audio\cAudio.h"

#include "GR8_Physics\cWorld.h"

#endif // GLOBAL_H_INCLUDED
