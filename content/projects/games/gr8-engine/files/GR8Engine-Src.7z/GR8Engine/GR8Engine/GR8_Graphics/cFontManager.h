/*****************************************************************************************
 * cFontManager.h - Declaration of the Font Manager class which is part of GR8 Graphics  *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info                  *
 *                               Copyright � Revolt 2008                                 *
 *---------------------------------------------------------------------------------------*
 * Description: FontManager is a class responsible for loading the required fonts and    *
 * saving them in memory until they aren't needed anymore. Font is the wrapper around    *
 * the platform specified variable of a font                                             *
 *****************************************************************************************/

#ifndef CFONTMANAGER_H_INCLUDED
#define CFONTMANAGER_H_INCLUDED

#include "..\Global.h"

namespace GR8 {

struct sGlyphMetrics
{
    float advance;
    float minY;
    float maxY;
};

class cFont
{
    friend class cFontManager;

    public:
        cFont(cFontManager *manager);
        ~cFont();

        bool Init(const std::string &fontPath, int fontSize);
        void Clear();

        std::string GetPath();
        int GetSize();
        GLuint GetDisplayList();

        sSize CalculateTextSize(const std::string &text);

    protected:
        std::string _fontPath;
        int _size;
        bool _ready;

        GLuint _listbase;
        GLuint *_textures;
        //FT_BBox _globalBox;
        sGlyphMetrics *_glyphMetrics;
        float _globalAscender;
        float _globalDescender;

        cFontManager *_manager;

    private:
        bool LoadGlyphs(FT_Face &face, FT_Glyph *glyphs);
        bool MakeGLList(const char &ch, FT_Glyph *glyphs);
};

class cFontManager
{
    friend class cFont;

    public:
        cFontManager();
        ~cFontManager();

        cFont* GetFont(const std::string &fontName, int fontSize);

        bool RemoveFont(const std::string &fontName, int fontSize);
        void RemoveAllFonts();

    private:
        std::vector< cFont* > _fonts;
};

}

#endif // CFONTMANAGER_H_INCLUDED
