/************************************************************************
 * Global.h - Global variables and include declarations                 *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info *
 *                   Copyright � Revolt 2008                            *
 *----------------------------------------------------------------------*
 * Description: Necessary includes and global structures/classes        *
 ************************************************************************/
#ifndef GLOBAL_H_INCLUDED
#define GLOBAL_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>

#include <math.h>

#include <string>
#include <vector>
#include <map>

#include "SDL.h"
#include "SDL_image.h"
#include "SDL_Mixer.h"

#include "SDL_opengl.h"

#include "ft2build.h"
#include <freetype/freetype.h>
#include <freetype/ftglyph.h>
#include <freetype/ftoutln.h>
#include <freetype/fttrigon.h>

///Namespace of the GR8 Engine
namespace GR8 {

class cApp;
class cScreenManager;
class cScreen;
class cEventManager;
class cEvent;

class cGraphics;
class cAudio;
class cFont;


struct sPosition {
    float x;
    float y;

    sPosition(float xCoord = 0, float yCoord = 0) { x = xCoord; y = yCoord; }

    const sPosition operator+(const sPosition &pos) {return sPosition(this->x - pos.x, this->y - pos.y); }
    const sPosition operator-(const sPosition &pos) {return sPosition(this->x - pos.x, this->y - pos.y); }
};

typedef sPosition sVector;

struct sSize {
    float w;
    float h;

    sSize(float width = 0, float height = 0) { w = width; h = height; }
};

//Represents a rectangle
struct sRect {
    //Coordinates refer to the top-left corner
    float x;
    float y;

    float w;
    float h;

    sRect() { x = 0.0; y = 0.0; w = 0.0; h = 0.0; }
    sRect(float xC, float yC, float width, float height) { x = xC; y = yC; w = width; h = height; }
    sRect(const sPosition &pos, const sSize &size) { x = pos.x; y = pos.y; w = size.w; h = size.h; }

    //Gets the center position of the rectangle
    sPosition GetCenter() { return sPosition(x + w / 2, y + h / 2); }
    sPosition GetPosition() { return sPosition(x, y); }
    sSize GetSize() { return sSize(w, h); }
};

//Represents a circle
struct sCircle {
    //Coordinates refer to the center of the circle
    float x;
    float y;

    float r;

    sCircle() { x = 0; y = 0; r = 0; }
    sCircle(float xC, float yC, float radius) { x = xC; y = yC; r = radius; }
};

//Represents a polygon defined by its vertices
struct sPolygon {
    std::vector< sPosition > vertices;

    sPolygon() { vertices.clear(); }
    sPolygon(sPosition verts[], int numOfVerts) { for (int i = 0; i < numOfVerts; i++) { vertices.push_back(verts[i]); } }

    sRect GetVirtualRect() const {
        std::vector< sPosition >::const_iterator it;
        float highX = 0.0;
        float lowX = 0.0;
        float highY = 0.0;
        float lowY = 0.0;
        bool first = true;

        for (it = vertices.begin(); it != vertices.end(); it++) {
            sPosition currentVertice = *it;

            if (first) {
                highX = currentVertice.x;
                lowX = currentVertice.x;
                highY = currentVertice.y;
                lowY = currentVertice.y;
                first = false;
            }

            if (currentVertice.x < lowX) {
                lowX = currentVertice.x;
            }
            else if (currentVertice.x > highX) {
                highX = currentVertice.x;
            }

            if (currentVertice.y < lowY) {
                lowY = currentVertice.y;
            }
            else if (currentVertice.y > highY) {
                highY = currentVertice.y;
            }
        }
        return sRect(lowX, lowY, highX - lowX, highY - lowY);
    }

    int GetNumberOfVertices() const { return vertices.size(); }
};

inline int nextPowerOf2(float f)
{
	unsigned int x = ceil(f);
	--x;    
	x |= x >> 1;
	x |= x >> 2;    
	x |= x >> 4;    
	x |= x >> 8;    
	x |= x >> 16;    
	return ++x;
}

inline bool isPowerOf2(int x)
{
    return x && !(x & (x - 1));;
}


struct sColor {

    sColor() {
        red = 0;
        blue = 0;
        green = 0;
        alpha = 255;
    }

    sColor(int r, int g, int b, int a = 255) {
        red = r;
        green = g;
        blue = b;
        alpha = a;
    }

    float* GetOpenGLValues() const { 
		float *values = new float[4]; 
		values[0] = red / 255.0f;
		values[1] = green / 255.0f;
		values[2] = blue / 255.0f;
		values[3] = alpha / 255.0f; 
		return values; 
	}

    int red;
    int green;
    int blue;
    int alpha;
};

enum eEventType {
    EVENT_KEYDOWN,
    EVENT_KEYUP,
    EVENT_MOUSEDOWN,
    EVENT_MOUSEUP,
    EVENT_MOUSEMOVE,
    EVENT_WRESIZE,
    EVENT_WMINIMIZED,
    EVENT_WRESTORED,
    EVENT_WCLOSE
};

enum eModCode {
    KEY_MOD_NONE   = KMOD_NONE,
    KEY_MOD_SHIFT  = KMOD_SHIFT,
    KEY_MOD_ALT    = KMOD_ALT,
    KEY_MOD_CONTROL= KMOD_CTRL,
    KEY_MOD_CAPS   = KMOD_CAPS,
    KEY_MOD_NUM    = KMOD_NUM
};

enum eKeyCode {
    KEY_UNKNOWN		= SDLK_UNKNOWN,
    KEY_FIRST		= SDLK_FIRST,
    KEY_BACKSPACE	= SDLK_BACKSPACE,
    KEY_TAB			= SDLK_TAB,
    KEY_CLEAR		= SDLK_CLEAR,
    KEY_RETURN		= SDLK_RETURN,
    KEY_PAUSE		= SDLK_PAUSE,
    KEY_ESCAPE		= SDLK_ESCAPE,
    KEY_SPACE		= SDLK_SPACE,
    KEY_EXCLAIM		= SDLK_EXCLAIM,
    KEY_QUOTEDBL	= SDLK_QUOTEDBL,
    KEY_HASH		= SDLK_HASH,
    KEY_DOLLAR		= SDLK_DOLLAR,
    KEY_AMPERSAND		= SDLK_AMPERSAND,
    KEY_QUOTE		= SDLK_QUOTE,
    KEY_LEFTPAREN	= SDLK_LEFTPAREN,
    KEY_RIGHTPAREN	= SDLK_RIGHTPAREN,
    KEY_ASTERISK	= SDLK_ASTERISK,
    KEY_PLUS		= SDLK_PLUS,
    KEY_COMMA		= SDLK_COMMA,
    KEY_MINUS		= SDLK_MINUS,
    KEY_PERIOD		= SDLK_PERIOD,
    KEY_SLASH		= SDLK_SLASH,
    KEY_0			= SDLK_0,
    KEY_1			= SDLK_1,
    KEY_2			= SDLK_2,
    KEY_3			= SDLK_3,
    KEY_4			= SDLK_4,
    KEY_5			= SDLK_5,
    KEY_6			= SDLK_6,
    KEY_7			= SDLK_7,
    KEY_8			= SDLK_8,
    KEY_9			= SDLK_9,
    KEY_COLON		= SDLK_COLON,
    KEY_SEMICOLON	= SDLK_SEMICOLON,
    KEY_LESS		= SDLK_LESS,
    KEY_EQUALS		= SDLK_EQUALS,
    KEY_GREATER		= SDLK_GREATER,
    KEY_QUESTION	= SDLK_QUESTION,
    KEY_AT			= SDLK_AT,


    /*
    Skip uppercase letters
    */
    KEY_LEFTBRACKET		= SDLK_LEFTBRACKET,
    KEY_BACKSLASH		= SDLK_BACKSLASH,
    KEY_RIGHTBRACKET	= SDLK_RIGHTBRACKET,
    KEY_CARET			= SDLK_CARET,
    KEY_UNDERSCORE		= SDLK_UNDERSCORE,
    KEY_BACKQUOTE		= SDLK_BACKQUOTE,
    KEY_a			= SDLK_a,
    KEY_b			= SDLK_b,
    KEY_c			= SDLK_c,
    KEY_d			= SDLK_d,
    KEY_e			= SDLK_e,
    KEY_f			= SDLK_f,
    KEY_g			= SDLK_g,
    KEY_h			= SDLK_h,
    KEY_i			= SDLK_i,
    KEY_j			= SDLK_j,
    KEY_k			= SDLK_k,
    KEY_l			= SDLK_l,
    KEY_m			= SDLK_m,
    KEY_n			= SDLK_n,
    KEY_o			= SDLK_o,
    KEY_p			= SDLK_p,
    KEY_q			= SDLK_q,
    KEY_r			= SDLK_r,
    KEY_s			= SDLK_s,
    KEY_t			= SDLK_t,
    KEY_u			= SDLK_u,
    KEY_v			= SDLK_v,
    KEY_w			= SDLK_w,
    KEY_x			= SDLK_x,
    KEY_y			= SDLK_y,
    KEY_z			= SDLK_z,
    KEY_DELETE		= SDLK_DELETE,
    /* End of ASCII mapped keysyms */

    /* Numeric keypad */
    KEY_KP0			= SDLK_KP0,
    KEY_KP1			= SDLK_KP1,
    KEY_KP2			= SDLK_KP2,
    KEY_KP3			= SDLK_KP3,
    KEY_KP4			= SDLK_KP4,
    KEY_KP5			= SDLK_KP5,
    KEY_KP6			= SDLK_KP6,
    KEY_KP7			= SDLK_KP7,
    KEY_KP8			= SDLK_KP8,
    KEY_KP9			= SDLK_KP9,
    KEY_KP_PEROID		= SDLK_KP_PERIOD,
    KEY_KP_DIVIDE		= SDLK_KP_DIVIDE,
    KEY_KP_MULTIPLY		= SDLK_KP_MULTIPLY,
    KEY_KP_MINUS		= SDLK_KP_MINUS,
    KEY_KP_PLUS		= SDLK_KP_PLUS,
    KEY_KP_ENTER		= SDLK_KP_ENTER,
    KEY_KP_EQUALS		= SDLK_KP_EQUALS,

    /* Arrows + Home/End pad */
    KEY_UP			= SDLK_UP,
    KEY_DOWN		= SDLK_DOWN,
    KEY_RIGHT		= SDLK_RIGHT,
    KEY_LEFT		= SDLK_LEFT,
    KEY_INSERT		= SDLK_INSERT,
    KEY_HOME		= SDLK_HOME,
    KEY_END			= SDLK_END,
    KEY_PAGEUP		= SDLK_PAGEUP,
    KEY_PAGEDOWN		= SDLK_PAGEDOWN,

    /* Function keys */
    KEY_F1			= SDLK_F1,
    KEY_F2			= SDLK_F2,
    KEY_F3			= SDLK_F3,
    KEY_F4			= SDLK_F4,
    KEY_F5			= SDLK_F5,
    KEY_F6			= SDLK_F6,
    KEY_F7			= SDLK_F7,
    KEY_F8			= SDLK_F8,
    KEY_F9			= SDLK_F9,
    KEY_F10			= SDLK_F10,
    KEY_F11			= SDLK_F11,
    KEY_F12			= SDLK_F12,
    KEY_F13			= SDLK_F13,
    KEY_F14			= SDLK_F14,
    KEY_F15			= SDLK_F15,

    /* Key state modifier keys */
    KEY_NUMLOCK		= SDLK_NUMLOCK,
    KEY_CAPSLOCK		= SDLK_CAPSLOCK,
    KEY_SCROLLOCK		= SDLK_SCROLLOCK,
    KEY_RSHIFT		= SDLK_RSHIFT,
    KEY_LSHFIT		= SDLK_LSHIFT,
    KEY_RCTRL		= SDLK_RCTRL,
    KEY_LCTRL		= SDLK_LCTRL,
    KEY_RALT		= SDLK_RALT,
    KEY_LALT		= SDLK_LALT,
    KEY_RMETA		= SDLK_RMETA,
    KEY_LMETA		= SDLK_LMETA,
    KEY_LSUPER		= SDLK_LSUPER,		/* Left "Windows" key */
    KEY_RSUPER		= SDLK_RSUPER,		/* Right "Windows" key */

    /* Miscellaneous function keys */
    KEY_HELP		= SDLK_HELP,
    KEY_PRINT		= SDLK_PRINT,
    KEY_SYSREQ		= SDLK_SYSREQ,
    KEY_BREAK		= SDLK_BREAK,
    KEY_MENU		= SDLK_MENU,
};

enum eMouseButton {
    MOUSE_NONE      = -1,
    MOUSE_LEFTBTN   = SDL_BUTTON_LEFT,
    MOUSE_MIDBTN    = SDL_BUTTON_MIDDLE,
    MOUSE_RIGHTBTN  = SDL_BUTTON_RIGHT,
    MOUSE_WHEELUP   = SDL_BUTTON_WHEELUP,
    MOUSE_WHEELDOWN = SDL_BUTTON_WHEELDOWN
};

enum eMusicTypes {
    MUSIC_NONE = MUS_NONE,
    MUSIC_WAV  = MUS_WAV,
    MUSIC_MOD  = MUS_MOD,
    MUSIC_MID  = MUS_MID,
    MUSIC_OGG  = MUS_OGG,
    MUSIC_MP3  = MUS_MP3
};

enum eOrientation {
    ORI_HORIZONTAL,
    ORI_VERTICAL,
    ORI_DIAGONAL
};

enum eVerticalAlign {
    ALIGN_VERT_TOP,
    ALIGN_VERT_MIDDLE,
    ALIGN_VERT_BOTTOM
};

enum eHorizontalAlign {
    ALIGN_HORI_LEFT,
    ALIGN_HORI_CENTER,
    ALIGN_HORI_RIGHT
};

}


#endif // GLOBAL_H_INCLUDED
