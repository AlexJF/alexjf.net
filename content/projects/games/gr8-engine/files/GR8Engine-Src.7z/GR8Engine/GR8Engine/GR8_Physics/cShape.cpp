/** \file cShape.cpp
    \author Revolt
    \brief Implementation of the cShape, cCircularShape and cPolygonalShape declared in cShape.h
*/

#include "cShape.h"

using namespace std;

namespace GR8 {

/* ------ cShape ------ */
cShape::cShape(const std::string &ID, const eShapeType type)
{
    _ID = ID;
    _type = type;
    _shape = NULL;
    _shapedef = NULL;
}

cShape::~cShape()
{
	cout << "Entering Shape Destructor" << endl;
    _shape = NULL;
    delete _shapedef;
	cout << "Leaving Shape Destructor" << endl;
}

eShapeType cShape::GetType()
{
    return _type;
}

std::string cShape::GetID()
{
    return _ID;
}

void cShape::SetRestitution(float rest)
{
    if (_shape != NULL) {
        return;
    }
    _shapedef->restitution = rest;
}

void cShape::SetFriction(float fric)
{
    if (_shape != NULL) {
        return;
    }
    _shapedef->friction = fric;
}

void cShape::SetDensity(float dens)
{
    if (_shape != NULL) {
        return;
    }
    _shapedef->density = dens;
}

/* ------ cCircularShape ------- */
cCircularShape::cCircularShape(const std::string &ID, float radius, const sPosition &pos) : cShape(ID, SHAPE_CIRCULAR)
{
    b2CircleDef *circleDefinition = new b2CircleDef;
    circleDefinition->radius = radius;
    circleDefinition->localPosition.Set(pos.x, pos.y);

    _shapedef = circleDefinition;
}

sPosition cCircularShape::GetPosition()
{
    if (_shape == NULL) {
        b2CircleDef *circleDefinition = static_cast< b2CircleDef* >(_shapedef);
        return sPosition(circleDefinition->localPosition.x, circleDefinition->localPosition.y);
    } else {
        b2Body *body = _shape->GetBody();
        const b2Vec2 bodyPos = body->GetPosition();

        b2CircleShape *circleShape = static_cast< b2CircleShape* >(_shape);
        b2Vec2 pos = circleShape->GetLocalPosition();
        return sPosition(pos.x + bodyPos.x, pos.y + bodyPos.y);
    }
}

float cCircularShape::GetRadius()
{
    if (_shape == NULL) {
        b2CircleDef *circleDefinition = static_cast< b2CircleDef* >(_shapedef);
        return circleDefinition->radius;
    } else {
        b2CircleShape *circleShape = static_cast< b2CircleShape* >(_shape);
        return circleShape->GetRadius();
    }
}

sCircle cCircularShape::GetCircle()
{
    if (_shape == NULL) {
        b2CircleDef *circleDefinition = static_cast< b2CircleDef* >(_shapedef);
        return sCircle(circleDefinition->localPosition.x, circleDefinition->localPosition.y, circleDefinition->radius);
    } else {
        b2Body *body = _shape->GetBody();
        const b2Vec2 bodyPos = body->GetPosition();
        b2CircleShape *circleShape = static_cast< b2CircleShape* >(_shape);
        return sCircle(circleShape->GetLocalPosition().x + bodyPos.x, circleShape->GetLocalPosition().y + bodyPos.y, circleShape->GetRadius());
    }
}

/* ------- cPolygonalShape -------- */
cPolygonalShape::cPolygonalShape(const std::string &ID, const sPolygon &poly) : cShape(ID, SHAPE_POLYGONAL)
{
    b2PolygonDef *polyDefinition = new b2PolygonDef;
    vector< sPosition >::const_iterator it;

    int vertexCount = poly.vertices.size();
    int index = 0;


    for (it = poly.vertices.begin(); it != poly.vertices.end(); it++, index++) {
        sPosition currentVertex = *it;
        polyDefinition->vertices[index] = b2Vec2(currentVertex.x, currentVertex.y);
    }
    polyDefinition->vertexCount = vertexCount;

    _shapedef = polyDefinition;
}

cPolygonalShape::cPolygonalShape(const std::string &ID, const sRect &box, float angle) : cShape(ID, SHAPE_POLYGONAL)
{
    b2PolygonDef *polyDefinition = new b2PolygonDef;
    polyDefinition->SetAsBox(box.w / 2, box.h / 2, b2Vec2(box.x, box.y), angle);

    _shapedef = polyDefinition;
}

sPolygon cPolygonalShape::GetPolygon()
{
    if (_shape == NULL) {
        b2PolygonDef *polygonDef = static_cast< b2PolygonDef* >(_shapedef);

        sPolygon polygon;

        for (int i = 0; i < polygonDef->vertexCount; i++) {
            polygon.vertices.push_back(sPosition(polygonDef->vertices[i].x, polygonDef->vertices[i].y));
        }

        return polygon;
    } else {
        b2PolygonShape *polygonalShape = static_cast< b2PolygonShape* >(_shape);

        b2Body *body = _shape->GetBody();
        const b2Vec2 bodyPos = body->GetPosition();

        int vertexCount = polygonalShape->GetVertexCount();
        const b2Vec2 *vertices = polygonalShape->GetVertices();

        sPolygon polygon;

        for (int i = 0; i < vertexCount; i++) {
            polygon.vertices.push_back(sPosition(bodyPos.x + vertices[i].x, bodyPos.y + vertices[i].y));
        }

        return polygon;
    }
}

int cPolygonalShape::GetVertexCount()
{
    if (_shape == NULL) {
        b2PolygonDef *polygonDef = static_cast< b2PolygonDef* >(_shapedef);
        return polygonDef->vertexCount;
    } else {
        b2PolygonShape *polygonShape = static_cast< b2PolygonShape* >(_shape);
        return polygonShape->GetVertexCount();
    }
}

sPosition* cPolygonalShape::GetVertices()
{
    if (_shape == NULL) {
        b2PolygonDef *polygonDef = static_cast< b2PolygonDef* >(_shapedef);

        sPosition *vertices = new sPosition[polygonDef->vertexCount];
        b2Vec2 *verticesOld = polygonDef->vertices;

        for (int i = 0; i < polygonDef->vertexCount; i++) {
            vertices[i] = sPosition(verticesOld[i].x, verticesOld[i].y);
        }

        return vertices;
    } else {
        b2PolygonShape *polygonShape = static_cast< b2PolygonShape* >(_shape);

        sPosition *vertices = new sPosition[polygonShape->GetVertexCount()];
        const b2Vec2 *verticesOld = polygonShape->GetVertices();

        b2Body *body = _shape->GetBody();
        b2Vec2 bodyPos = body->GetPosition();

        for (int i = 0; i < polygonShape->GetVertexCount(); i++) {
            vertices[i] = sPosition(verticesOld[i].x + bodyPos.x, verticesOld[i].y + bodyPos.y);
        }

		delete[] verticesOld;

        return vertices;
    }
}

}
