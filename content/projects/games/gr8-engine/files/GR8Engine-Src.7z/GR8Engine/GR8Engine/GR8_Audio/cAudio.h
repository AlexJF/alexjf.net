/*****************************************************************************************
 * cAudio.h - Declaration of the Audio class which is part of GR8 Audio.                 *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info                  *
 *                               Copyright � Revolt 2008                                 *
 *---------------------------------------------------------------------------------------*
 * Definition: Enables the user to play/pause/stop/modify loaded audio resources such as *
 *             sound effects or music                                                    *
 *****************************************************************************************/

#ifndef CAUDIO_H_INCLUDED
#define CAUDIO_H_INCLUDED

#include "..\Global.h"
#include "cSoundManager.h"

namespace GR8 {

class cAudio
{
    public:
        cAudio();
        ~cAudio();

        bool Initialize();
        void Shutdown();

        /* ------------ Sound Effects ------------ */
        int PlaySoundEffect(cSoundEffect *soundEffect, int loop = 0, int channel = -1);
        int PlaySoundEffect(const std::string &filepath, int loop = 0, int channel = -1);

        void PauseSoundEffect(int channel);
        void PauseAllSoundEffects();

        void ResumeSoundEffect(int channel);
        void ResumeAllSoundEffects();

        void StopSoundEffect(int channel);
        void StopAllSoundEffects();

        bool IsSoundPlaying(int channel);
        bool IsSoundPaused(int channel);

        /* ------------ Music -------------- */
        bool PlayMusic(cMusic *music, int loop = -1);
        bool PlayMusic(const std::string &filename, int loop = -1);

        void PauseMusic();
        void ResumeMusic();
        void StopMusic();

        bool SetMusicPosition(double pos);

        bool IsMusicPlaying();
        bool IsMusicPaused();

        cMusic* GetCurrentMusic();

        /* ---------- Channels ------------- */
        int GetNumPlayingChannels();
        int GetNumPausedChannels();

        /* ---------- Volume ------------ */
        void SetVolumeChannel(int channel, int volume);
        void SetVolumeAllChannels(int volume);
        int GetVolumeChannel(int channel);
        int GetVolumeAllChannels();

        void SetVolumeMusic(int volume);
        int GetVolumeMusic();

        /*----------- Public Variables ----------*/
        cSoundManager *soundManager;

    private:
        cMusic *_currentMusic;
};

}



#endif // CAUDIO_H_INCLUDED
