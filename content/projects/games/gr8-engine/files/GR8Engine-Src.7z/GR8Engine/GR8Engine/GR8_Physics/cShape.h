/**\file cShape.h
   \author Revolt
   \brief Defines the parent cShape class and its children: the cCircularShape and
   cPolygonalShape.
*/

#ifndef CSHAPE_H_INCLUDED
#define CSHAPE_H_INCLUDED

#include "..\Global.h"
#include "Box2D.h"

namespace GR8 {

enum eShapeType {
    SHAPE_CIRCULAR,
    SHAPE_POLYGONAL
};

class cShape
{
    friend class cBody;

    public:
        cShape(const std::string &ID, const eShapeType type);
        ~cShape();

        /** \name Properties - GET.
            Functions that allow you to retrieve specific values of this shape object. */
        //@{
        eShapeType GetType(); ///< Allows you to cast this shape object into the correct children class.
        std::string GetID(); ///< Returns the ID of this cShape object.

        float GetRestitution(); ///< Returns the restitution value of this shape.
        float GetFriction(); ///< Returns the friction value of this shape.
        float GetDensity(); ///< Returns the density of this shape.
        //@}

        /** \name Properties - SET.
            \brief Functions that allow you to set specific values of this shape object.
            \warning These functions only work if the shape object hasn't yet been associated with a body object.*/
        //@{
        void SetRestitution(float rest); ///< Sets the restitution of this shape object
        void SetFriction(float fric); ///< Sets the friction of this shape object
        void SetDensity(float dens); ///< Sets the shape's density
        //@}

    protected:
        std::string _ID;
        eShapeType _type;
        b2Shape *_shape;
        b2ShapeDef *_shapedef;
};

class cCircularShape : public cShape
{
    public:
        cCircularShape(const std::string &ID, float radius = 1.0f, const sPosition &pos = sPosition(0,0)); ///< Creates a new circular shape with the specified radius and at the specified position (in relation to the parent body)
        ~cCircularShape();

        /** \name Properties - GET.
            \brief Functions that allow you to retrieve specific values of this shape object. */
        //@{
        float GetRadius(); ///< Returns the radius of this shape
        sPosition GetPosition(); ///< Returns the position of this shape inside the parent body
        sCircle GetCircle(); ///< Returns a sCircle structure for easier management of radius and position
        //@}
};

class cPolygonalShape : public cShape
{
    public:
        cPolygonalShape(const std::string &ID, const sRect &box, float angle = 0); ///< Creates a new polygonal shape as a rectangle with the properties specified in box and rotated according to specified angle.
        cPolygonalShape(const std::string &ID, const sPolygon &poly); ///< Creates a new polygon based on a list of vertices (sPolygon.vertices)

        /** \name Properties - GET.
            \brief Functions that allow you to retrieve specific values of this shape object. */
        //@{
        int GetVertexCount(); ///< Gets the number of vertices of this polygonal shape
        sPosition* GetVertices(); ///< Gets an array of sPosition that represents all the vertices of the polygon
        sPolygon GetPolygon(); ///< Gets a sPolygon struct for easier management of vertices
        //@}
};

}

#endif // CSHAPE_H_INCLUDED
