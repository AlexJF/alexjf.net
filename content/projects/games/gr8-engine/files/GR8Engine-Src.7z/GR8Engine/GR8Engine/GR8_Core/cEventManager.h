/****************************************************************************
 * cEventManager.h - Declares the Event Manager class and the Event classes *
 * Author: Revolt (aka Alexandre Fonseca) - http://revolt.hyperhub.info     *
 *                       Copyright � Revolt 2008                            *
 *--------------------------------------------------------------------------*
 * Description: Represents the Event Manager class that processes events and*
 * sends them to the specified handlers aswell as the 3 different types of  *
 * event classes (plus a base class)                                        *
 ****************************************************************************/

#ifndef CEVENTMANAGER_H_INCLUDED
#define CEVENTMANAGER_H_INCLUDED

#include "..\Global.h"
#include "cApp.h"

namespace GR8 {

//Useful static functions
bool IsKeyDown(eKeyCode key);
bool IsMouseDown(eMouseButton btn);
sPosition GetMousePosition();
bool CheckModKey(eModCode mod);

class cApp;

class cEvent
{
    public:
        cEvent(eEventType type);
        ~cEvent();

        bool IsTreated();
        void Treat();
        eEventType GetType();

        eEventType _type;

    protected:
        bool _treated;
};

class cKeyEvent : public cEvent
{
    public:
        cKeyEvent(eEventType type, eKeyCode key, const char &translatedChar);
        ~cKeyEvent();

        eKeyCode GetKeyCode();
        char GetChar();

    private:
        eKeyCode _key;
        char _char;
};

class cMouseEvent : public cEvent
{
    public:
        cMouseEvent(eEventType type, sPosition mousepos, eMouseButton mousebtn = MOUSE_NONE, sPosition relpos = sPosition(0, 0));
        ~cMouseEvent();


        sPosition GetMousePosition();
        sPosition GetRelativeMousePosition();
        eMouseButton GetMouseButton();

    private:
        sPosition _position;
        sPosition _relposition;
        eMouseButton _button;
};

class cWindowEvent : public cEvent
{
    public:
        cWindowEvent(eEventType type, sSize newsize = sSize(0,0));
        ~cWindowEvent();

        sSize GetNewSize();

    private:
        sSize _newsize;
};

class cEventManager
{
    public:
        cEventManager(cApp *app);
        ~cEventManager();

        void Process();

        cApp* GetApplication();

    private:
        cApp *_app;
};

}
#endif // CEVENTMANAGER_H_INCLUDED
