
#include "App.h"

using namespace std;

App::App()
{
}

App::~App()
{
}

bool App::Init(std::string windowTitle, int windowW, int windowH, int windowBPP, bool fullScreen)
{
    exit = false;
    screenManager = new cScreenManager(this);
    eventManager = new cEventManager(this);
    graphics = new cGraphics();

    if (!graphics->Initialize(windowTitle, windowW, windowH, windowBPP, fullScreen)) {
        return false;
    }

    graphics->CapFPS(60);

    MainWindow *mainwnd = new MainWindow();

    if (!screenManager->Initialize(mainwnd)) {
        delete mainwnd;
        return false;
    }

    return true;
}

void App::HandleEvent(cEvent *event)
{
	cout << "Enter App handle event" << endl;
	cKeyEvent *keyevent = static_cast< cKeyEvent* >(event);
    switch (event->GetType())
    {
        case EVENT_WCLOSE:
            cout << "Ask close" << endl;
            exit = true;
            break;
        case EVENT_KEYDOWN:
            cout << "Escape code " << keyevent->GetKeyCode() << endl;
            switch (keyevent->GetKeyCode())
            {
                case KEY_ESCAPE:
                    exit = true;
                    break;
                default:
                    screenManager->HandleEvent(event);
                    break;
            }
            break;
        default:
            screenManager->HandleEvent(event);
            break;
    }
	cout << "Leave App handle event" << endl;
}

void App::Run()
{
    while (!exit) {
        eventManager->Process();
        screenManager->Update();
        screenManager->Draw();
        graphics->UpdateScreen();
    }
}

void App::Shutdown()
{
	cout << "Entering App Shutdown" << endl;
    delete graphics;
    delete eventManager;
    delete screenManager;
    SDL_Quit();
	cout << "Leaving App Shutdown" << endl;
}

cBall::cBall(const std::string &ID) : cBody(ID)
{
    color = sColor(255, 255, 255);
    resultForce[0] = 0;
    resultForce[1] = 0;
}

cBall::~cBall()
{
}

void cBall::Update()
{
    cGraphics *graphics = GetWorld()->GetScreen()->GetManager()->GetApplication()->graphics;
    sPosition screenPos = GetWorld()->ToScreen(GetPosition());
    cout << "Ball World Position: " << GetPosition().x << " " << GetPosition().y << endl;
    cout << "Ball Screen Position: " << GetWorld()->ToScreen(GetPosition()).x << " " << GetWorld()->ToScreen(GetPosition()).y << endl;
    cout << "Ball Mass: " << GetMass() << " kg" << endl;
    ApplyForce(sVector(resultForce[0], resultForce[1]), GetPosition());
}

void cBall::HandleEvent(cEvent *event)
{
	cout << "Enter Ball handle event" << endl;
	if (event->IsTreated()) {
		return;
	}
	cKeyEvent *keyevent = static_cast< cKeyEvent* >(event);
    switch (event->GetType())
    {
        case EVENT_KEYDOWN:
            switch (keyevent->GetKeyCode())
            {
                case KEY_UP:
                    resultForce[1] += 20;
                    break;
                case KEY_DOWN:
                    resultForce[1] -= 20;
                    break;
                case KEY_LEFT:
                    resultForce[0] -= 10;
                    break;
                case KEY_RIGHT:
                    resultForce[0] += 10;
                    break;
                case KEY_SPACE:
                    resultForce[1] += 60;
                    break;
                default:
                    break;
            }
            break;
        case EVENT_KEYUP:
            switch (keyevent->GetKeyCode())
            {
                case KEY_UP:
                case KEY_DOWN:
                    resultForce[1] = 0;
                    break;
                case KEY_LEFT:
                case KEY_RIGHT:
                    resultForce[0] = 0;
                    break;
                case KEY_SPACE:
                    resultForce[1] = 0;
                default:
                    break;
            }
            break;
        default:
            break;
    }
	cout << "Leave Ball handle event" << endl;
}

void cBall::Draw()
{
	cout << "Enter Ball Draw" << endl;
    if (GetWorld() == NULL) {
        return;
    }

    cGraphics *graphics = GetWorld()->GetScreen()->GetManager()->GetApplication()->graphics;
    cCircularShape *circleShape = static_cast< cCircularShape* >(GetShape("ball_circle"));
    cWorld *world = GetWorld();

    cTexture *football = graphics->textureManager->GetTexture("football_256.png");

    graphics->DrawTexturedCircle(world->ToScreen(circleShape->GetCircle()), football, true, GetAngle());
	cout << "Leave Ball Draw" << endl;
}

cDyn::cDyn(const std::string &ID) : cBody(ID)
{
    color = sColor(255, 255, 255);
}

cDyn::~cDyn()
{
}

void cDyn::Update()
{
}

void cDyn::HandleEvent(cEvent *event)
{
	cout << "cDyn handle event" << endl;
}

void cDyn::Draw()
{
	cout << "Enter Dyn Draw" << endl;
    if (GetWorld() == NULL) {
        return;
    }

    cGraphics *graphics = GetWorld()->GetScreen()->GetManager()->GetApplication()->graphics;
    vector< cShape* > *shapes = GetShapeList();
    vector< cShape* >::iterator it;

    for (it = shapes->begin(); it != shapes->end(); it++) {
        if ((*it)->GetType() == SHAPE_POLYGONAL) {
            cPolygonalShape *polyShape = static_cast< cPolygonalShape* >(*it);
            cWorld *world = GetWorld();

            graphics->DrawFilledPolygon(world->ToScreen(polyShape->GetPolygon()), color, true);
        }
        else if ((*it)->GetType() == SHAPE_CIRCULAR) {
            cCircularShape *circleShape = static_cast< cCircularShape* >(*it);
            cWorld *world = GetWorld();

            graphics->DrawTexturedCircle(world->ToScreen(circleShape->GetCircle()), graphics->textureManager->GetTexture("basketball.png"), true, GetAngle());
        }
    }
	cout << "Leave Dyn Draw" << endl;
}

cStatic::cStatic(const std::string &ID) : cBody(ID)
{
    color = sColor(0, 0, 0);
}

cStatic::~cStatic()
{
}

void cStatic::Update()
{
}

void cStatic::HandleEvent(cEvent *event)
{
	cout << "cStatic handle event" << endl;
}

void cStatic::Draw()
{
	cout << "Enter Static Draw" << endl;
    if (GetWorld() == NULL) {
        return;
    }

    cGraphics *graphics = GetWorld()->GetScreen()->GetManager()->GetApplication()->graphics;
    vector< cShape* > *shapes = GetShapeList();
    vector< cShape* >::iterator it;

    for (it = shapes->begin(); it != shapes->end(); it++) {
        cPolygonalShape *polyShape = static_cast< cPolygonalShape* >(*it);
        cWorld *world = GetWorld();
        sPolygon poly = world->ToScreen(polyShape->GetPolygon());
        sRect polyVirtualRect = poly.GetVirtualRect();

		graphics->DrawFilledPolygon(poly, sColor(128, 128, 128));
        graphics->PolyFillTexture(poly, graphics->textureManager->GetTexture("bricks.jpg"), true, sVector(polyVirtualRect.x, polyVirtualRect.y));
    }
	cout << "Leave Static Draw" << endl;
}

MainWindow::MainWindow()
{
    _blockdraw = false;
    _blockupdate = false;
    message = "Why Hello There!";
    _controlManager = new cControlManager(this);
    _world = NULL;
}

MainWindow::~MainWindow()
{
    delete _controlManager;
    delete _world;
}

bool MainWindow::Initialize()
{
    cout << "Mainwindow Initialize" << endl;
    _screenArea = _screenManager->GetApplication()->graphics->GetWindowArea();
    cTextureManager *textureManager = _screenManager->GetApplication()->graphics->textureManager;
    cFontManager *fontManager = _screenManager->GetApplication()->graphics->fontManager;

    if (textureManager->GetTexture("background.png") == NULL) {
        return false;
    }

    if (fontManager->GetFont("tahoma.ttf", 24) == NULL || fontManager->GetFont("arial.ttf", 16) == NULL) {
        return false;
    }

    sControlStyle controlStyle;
    controlStyle.textFont = fontManager->GetFont("tahoma.ttf", 12);
    cButton *dragBtn = new cButton("fps_button", sPosition(100, 300), "Uncap FPS", &MainWindow::OnButtonControlClick, controlStyle);
    cTextBox *txtBox = new cTextBox("textbox", sPosition (0, 0), "Type here", controlStyle);
    if (!_controlManager->AddControl(dragBtn) || !_controlManager->AddControl(txtBox)) {
        return false;
    }
    dragBtn->AllowDrag = true;
    txtBox->AllowDrag = true;

    cout << "Ended normal" << endl;

    sRect worldArea = sRect(0, 0, 200, 100);

    _world = new cWorld();
    _world->Initialize(this, worldArea, 80.0);

    GetManager()->GetApplication()->graphics->SetCamera(&sRect(0, 0,_world->ToScreen(worldArea.w), _world->ToScreen(worldArea.h)));

    cStatic *ground = new cStatic("ground");
    ground->SetPosition(sPosition(100, 0));
    cPolygonalShape *groundShape = new cPolygonalShape("static_main", sRect(0, 0, 200, 1));
    groundShape->SetDensity(0);
    groundShape->SetFriction(0.6);
    groundShape->SetRestitution(0.1);
    ground->AddShape(groundShape);

    cStatic *ramp = new cStatic("ramp");
    ramp->SetPosition(sPosition(50, 1));
    sPolygon rampPoly;
    rampPoly.vertices.push_back(sPosition(-10, 0));
    rampPoly.vertices.push_back(sPosition(10, 0));
    rampPoly.vertices.push_back(sPosition(5, 2));
    cPolygonalShape *rampShape = new cPolygonalShape("ramp_main", rampPoly);
    rampShape->SetDensity(0);
    rampShape->SetFriction(1.0);
    ramp->AddShape(rampShape);

    cStatic *walls = new cStatic("walls");
    walls->SetPosition(sPosition(100, 0));
    cPolygonalShape *wallShape1 = new cPolygonalShape("wall1", sRect(-30, 20, 5, 40));
    wallShape1->SetDensity(0);
    wallShape1->SetFriction(1.0);
    cPolygonalShape *wallShape2 = new cPolygonalShape("wall2", sRect(30, 20, 5, 40));
    wallShape2->SetDensity(0);
    wallShape2->SetFriction(1.0);
    cPolygonalShape *wallShape3 = new cPolygonalShape("wall3", sRect(-100, 50, 1, 100));
    wallShape3->SetDensity(0);
    wallShape3->SetFriction(1.0);
    cPolygonalShape *wallShape4 = new cPolygonalShape("wall4", sRect(100, 50, 1, 100));
    wallShape4->SetDensity(0);
    wallShape4->SetFriction(1.0);
    cPolygonalShape *wallShape5 = new cPolygonalShape("wall5", sRect(0, 100, 200, 1));
    wallShape5->SetDensity(0);
    wallShape5->SetFriction(1.0);
    walls->AddShape(wallShape1);
    walls->AddShape(wallShape2);
    walls->AddShape(wallShape3);
    walls->AddShape(wallShape4);
    walls->AddShape(wallShape5);

    cBall *body = new cBall("ball");
    body->SetPosition(sPosition(100 , 20));
    cCircularShape *shape = new cCircularShape("ball_circle", 0.11);
    shape->SetDensity(11);
    shape->SetFriction(1.0);
    shape->SetRestitution(0.3);
    body->AddShape(shape);
    body->SetLinearDamping(0);
    body->SetAngularDamping(0.5);
    body->SetIsBullet(true);

    cDyn *ball = new cDyn("other_ball");
    ball->SetPosition(sPosition(100, 40));
    cCircularShape *shape1 = new cCircularShape("ball_circle", 0.15);
    shape1->SetDensity(15);
    shape1->SetFriction(1.0);
    shape1->SetRestitution(0.3);
    ball->AddShape(shape1);
    ball->SetLinearDamping(0);
    ball->SetAngularDamping(0.5);


    _world->AddBody(ground);
    _world->AddBody(ramp);
    _world->AddBody(walls);
    _world->AddBody(body);
    _world->AddBody(ball);
    return true;
}

bool MainWindow::HandleEvent(cEvent *event)
{
    cout << "Mainwindow handle event" << endl;
	cKeyEvent *keyevent = static_cast< cKeyEvent* >(event);
    switch (event->GetType())
    {
        case EVENT_WRESTORED:
            message = "AH AH! You restored the Window!";
            break;
        default:
            break;
    }

    _controlManager->HandleEvent(event);
    _world->HandleEvent(event);

	cout << "Leave Mainwindow handle event" << endl;

    return true;
}

void MainWindow::Update()
{
    cout << "Mainwindow Update" << endl;
    _world->Update();
    if (_controlManager->GetFocusedControl() != NULL)
    cout << "Focused control: " << _controlManager->GetFocusedControl()->GetID() << endl;
}

void MainWindow::Draw()
{
    cout << "Mainwindow draw" << endl;
    cGraphics *graphics = _screenManager->GetApplication()->graphics;
    graphics->CenterCameraOnPosition(_world->ToScreen(_world->GetBody("ball")->GetPosition()));
    graphics->DrawFilledRectangle(GetScreenArea(), sColor(128, 128, 128), false);
    cTexture *bgTexture = graphics->textureManager->GetTexture("background.png");
    sRect scrollBGArea = _world->GetArea();
    //scrollBGArea.x = _world->ToScreen(scrollBGArea.x);
    //cout << "LOOOOOOL --- " << _world->ToScreen(scrollBGArea.y) << "-" << _world->ToScreen(scrollBGArea.h) << "-" << bgTexture->GetSize().h << endl;
    //scrollBGArea.y = (_world->ToScreen(scrollBGArea.y) + _world->ToScreen(scrollBGArea.h)) - bgTexture->GetSize().h;
    scrollBGArea.w = _world->ToScreen(scrollBGArea.w);
    scrollBGArea.h = _world->ToScreen(scrollBGArea.h);
    //cout << _screenArea.x << "-" << _screenArea.y << "-" << _screenArea.w << "-" << _screenArea.h << endl;*/
    //graphics->DrawFilledRectangle(_screenArea, sColor(221, 189, 174), false);
    graphics->RectFillTexture(scrollBGArea, "background.png", true);

    _world->DrawBodies();
    cFont *font = graphics->fontManager->GetFont("tahoma.ttf", 24);
    cFont *smallFont = graphics->fontManager->GetFont("tahoma.ttf", 14);
    sPosition ballWorldPosition = _world->GetBody("ball")->GetPosition();
    stringstream info;
    info.precision(2);
    info.setf(info.fixed);
    info << "X:" << ballWorldPosition.x << "m Y:" << ballWorldPosition.y << "m";
    message = info.str();

    cControl *button = _controlManager->GetControl("fps_button");

    stringstream fpsStream;
    stringstream btnStream;
    string fps;
    string buttonStr;
    fpsStream.precision(2);

    fpsStream << graphics->GetCurrentFPS() << " frames per second " << graphics->GetFPSCap();
    btnStream << "Button Dragging: " << (button->IsDragging() ? "true" : "false");
    fps = fpsStream.str();
    buttonStr = btnStream.str();

    sSize fpsSize = smallFont->CalculateTextSize(fps);
    sSize posSize = font->CalculateTextSize(message);
    sSize btnSize = smallFont->CalculateTextSize(buttonStr);

    if (button != NULL) {
        graphics->DrawText(sPosition(GetCenterPosition(btnSize, GetScreenArea()).x, 400), buttonStr, smallFont, sColor(255,255,255), false);
    }

    graphics->DrawText(sPosition(GetCenterPosition(fpsSize, GetScreenArea()).x, 10), fps, smallFont, sColor(255,255,255), false);
    graphics->DrawText(sPosition(GetCenterPosition(posSize, GetScreenArea()).x, 200), message, font, sColor(255,255,255), false);

    graphics->DrawRectangle(sRect(GetCenterPosition(fpsSize, GetScreenArea()).x, 10, fpsSize.w, fpsSize.h), sColor(255, 255, 255), false);
    graphics->DrawRectangle(sRect(GetCenterPosition(posSize, GetScreenArea()).x, 200, posSize.w, posSize.h), sColor(255, 255, 255), false);

    cTexture *background = graphics->textureManager->GetTexture("football_256.png");

    graphics->DrawTexturedRectangle(sRect(sPosition(50, 50), background->GetSize()), background, true);
    _controlManager->DrawControls();
}

void MainWindow::OnButtonControlClick(eMouseButton mouseBtn, const sPosition &mousePos, cButton *caller)
{
    if (caller != NULL) {
        MainWindow *screen = static_cast< MainWindow* >(caller->GetControlManager()->GetScreen());
        if (caller->GetID() == "fps_button") {
            cout << "FPS BUTTON CLICKED" << endl;
            cGraphics *graphics = screen->GetManager()->GetApplication()->graphics;
            if (graphics->GetFPSCap() != 0) {
                cout << "CAP != 0" << endl;
                graphics->CapFPS(0);
                caller->SetAllText("Cap FPS");
            } else {
                cout << "CAP == 0" << endl;
                graphics->CapFPS(60);
                caller->SetAllText("Uncap FPS");
            }
        }
    }
}

int main(int argc, char* args[])
{
    App MyApp;
    if (!MyApp.Init("Hello World", 800, 600, 32, false)) {
        return 1;
    }
    MyApp.Run();
    MyApp.Shutdown();
    return 0;
}

