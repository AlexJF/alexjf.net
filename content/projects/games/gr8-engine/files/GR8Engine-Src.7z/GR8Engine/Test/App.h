#ifndef APP_H_INCLUDED
#define APP_H_INCLUDED

#include <GR8Engine.h>

using namespace GR8;

class App : public cApp
{
    public:
        App();
        ~App();

        virtual bool Init(std::string windowTitle, int windowW, int windowH, int windowBPP, bool fullScreen);

        virtual void HandleEvent(cEvent *event);
        virtual void Run();
        virtual void Shutdown();

        bool exit;
};

class cBall : public cBody
{
    public:
        cBall(const std::string &ID);
        ~cBall();

        void Update();
        void HandleEvent(cEvent *event);
        void Draw();

    private:
        sColor color;
        float resultForce[2];
};

class cDyn : public cBody
{
    public:
        cDyn(const std::string &ID);
        ~cDyn();

        void Update();
        void HandleEvent(cEvent *event);
        void Draw();

    private:
        sColor color;
        float *resultForce;
};

class cStatic : public cBody
{
    public:
        cStatic(const std::string &ID);
        ~cStatic();

        void Update();
        void HandleEvent(cEvent *event);
        void Draw();

    private:
        sColor color;
};

class MainWindow : public cScreen
{
    public:
        MainWindow();
        ~MainWindow();

        virtual bool Initialize();

        virtual bool HandleEvent(cEvent *event);

        virtual void Update();
        virtual void Draw();

        std::string message;

        static void OnButtonControlClick(eMouseButton mouseBtn, const sPosition &mousePos, cButton *caller);

    private:
        cWorld *_world;
};



#endif // APP_H_INCLUDED
