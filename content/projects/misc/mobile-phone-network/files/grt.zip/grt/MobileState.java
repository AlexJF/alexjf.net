package grt;

import java.io.*;

import grt.exceptions.*;

/**
 * Classe abstracta que representa um estado de um telemóvel.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
abstract class MobileState implements Serializable {
	/** Telemóvel associado a esta instancia do estado */
    private Mobile _mobile;

	/**
	 * Cria uma nova instância de MobileState.
	 */
    MobileState(Mobile mobile) {
        _mobile = mobile;
    }

	/**
	 * Obtem o objecto Mobile associado a esta instância de estado.
	 *
	 * @return Objecto Mobile associado a esta instância de estado.
	 */
    Mobile getMobile() {
        return _mobile;
    }

	/**
	 * Liga o telemóvel e notifica chamadas perdidas.
	 */
    void turnOn() {
        _mobile.setState(new MobileStateOn(_mobile));
        _mobile.notifyOn();
    }

	/**
	 * Desliga o telemóvel.
	 */
    void turnOff() {
        _mobile.setState(new MobileStateOff(_mobile));
    }

	/**
	 * Silencia o telemóvel e notifica chamadas perdidas.
	 */
    void turnSilent() {
        _mobile.setState(new MobileStateSilent(_mobile));
        _mobile.notifySilent();
    }

	/**
	 * Verifica se um telemóvel está ligado.
	 *
	 * @return true se o telemóvel está ligado e false caso contrário.
	 */
    abstract boolean isOn();

    /**
     * Verifica se um telemóvel está em silêncio.
     *
     * @return true se o telemóvel está em silêncio.
     */
    abstract boolean isSilent();

    /**
     * Verifica se um telemóvel está desligado.
     *
     * @return true se o telemóvel está desligado e 
     *         false caso contrário.
     */ 
    boolean isOff() {
        return !isOn();
    }

	/**
     * Trata uma chamada recebida pelo telemóvel.
	 *
	 * @param call Chamada a ser tratada.
     *
     * @throws CallException Excepção na recepção da chamada.
	 */
    abstract void handleCall(Call call) throws CallException;

	/**
	 * Devolve uma string que descreve este estado do telemóvel.
     *
     * @return String com descrição deste estado.
	 */
    public abstract String toString();
}
