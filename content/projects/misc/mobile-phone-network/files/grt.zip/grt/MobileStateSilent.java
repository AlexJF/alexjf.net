package grt;

import java.io.*;

import grt.exceptions.*;
import grt.textui.mobile.Message;

/**
 * Classe abstracta que representa o estado silêncio de um 
 * telemóvel.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class MobileStateSilent extends MobileState {
	/**
	 * Cria uma nova instância de MobileStateSilent.
	 */
    MobileStateSilent(Mobile mobile) {
        super(mobile);
    }

	/**
	 * Silencia um telemóvel.
	 */
    void turnSilent() {
    }

	/**
	 * Verifica se um telemóvel está ligado.
	 *
	 * @return true se o telemóvel está ligado e false caso contrário.
	 */
    boolean isOn() {
        return true;
    }

	/**
     * Verifica se um telemóvel está em silêncio.
     *
     * @return true se o telemóvel está em silêncio.
     */
    boolean isSilent() {
        return true;
    }

	/**
	 * Trata uma chamada recebida pelo telemóvel.
     *
	 * @param call Chamada a ser tratada.
	 */
    void handleCall(Call call) throws CallException {
        if (call.canStartOnSilence()) {
            call.setEffective();
        } else {
            getMobile().getOwner().handleMissedCall(call);
            throw new CallDestinationSilentException();
        }
    }

	/**
	 * Devolve uma string que descreve este estado do telemóvel.
     *
     * @return String com descrição deste estado.
	 */
    public String toString() {
        return Message.mobileSilence();
    }
}
