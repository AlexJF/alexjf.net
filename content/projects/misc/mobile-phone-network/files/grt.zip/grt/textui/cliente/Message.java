/**
 * @version $Id: Message.java,v 1.0 $
 */
package grt.textui.cliente;

/**
 * Messages.
 */
public class Message {
	/**
	 * @return string prompting for a client identifier
	 */
	public static final String clientKeyReq() {
		return "Identificador do cliente: ";
	}

	/**
	 * @return string prompting for a client name
	 */
	public static final String clientNameReq() {
		return "Nome do cliente: ";
	}

	/**
	 * @return string prompting for an client NIF
	 */
	public static final String clientNifReq() {
		return "NIF do cliente: ";
	}

	/**
	 * @return string reporting client already had messages enabled
	 */
	public static final String alreadyMessageActive() {
		return "A recepção de mensagens já estava activa";
	}

	/**
	 * @return string reporting client already had messages disabled
	 */
	public static final String alreadyMessageInactive() {
		return "A recepção de mensagens já estava inactiva";
	}

	/**
	 * @param id
	 *            client id
	 * @return string reporting a duplicate client identifier
	 */
	public static final String duplicateClient(String id) {
		return "Cliente '" + id + "' já existe.";
	}

	/**
	 * @return string "NORMAL".
	 */
	public static final String clientNormal() {
		return "NORMAL";
	}

	/**
	 * @return string "OURO".
	 */
	public static final String clientGold() {
		return "OURO";
	}

	/**
	 * @return string "PLATINA".
	 */
	public static final String clientPlatine() {
		return "PLATINA";
	}

	/**
	 * @return string "ACTIVO".
	 */
	public static final String atendedorActivo() {
		return "ACTIVO";
	}

	/**
	 * @return string "INACTIVO".
	 */
	public static final String atendedorInactivo() {
		return "INACTIVO";
	}

	/**
	 * @return string "CLIENTE".
	 */
	public static final String client() {
		return "CLIENTE";
	}

}
