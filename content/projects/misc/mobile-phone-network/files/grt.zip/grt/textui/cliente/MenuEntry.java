/**
 * @version $Id: MenuEntry.java,v 1.0 $
 */
package grt.textui.cliente;

/**
 * Menu entries.
 */
public final class MenuEntry {
	/** Menu title. */
	public static final String TITLE = "Gestão de Clientes";

	/** Show all clients. */
	public static final String SHOW_ALL = "Visualizar";

	/** Register client. */
	public static final String REGISTER = "Registar";

	/** Enable message reception for one client. */
	public static final String ENABLE = "Activar";

	/** Disable message reception for one client. */
	public static final String DISABLE= "Desactivar";

	/** Show balance. */
	public static final String SHOW_BALANCE = "Calcular Saldo";

}