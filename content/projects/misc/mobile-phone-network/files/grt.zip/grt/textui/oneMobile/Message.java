/**
 * @version $Id: Message.java,v 1.0 $
 */
package grt.textui.oneMobile;

/**
 * Messages.
 */
public class Message {
	/**
	 * @return string prompting for a the deposit amount.
	 */
	public static final String paymentValue() {
		return "Qual o valor pretendido? (em cêntimos): ";
	}

	/**
	 * @return string prompting for the call type.
	 */
	public static final String typeReq() {
		return "Tipo de mensagem a efectuar (VOZ, SMS ou MMS): ";
	}

	/**
	 * @return string informing that the calling phone is off.
	 */
	public static final String thisMobileIsOff() {
		return "O telefone a partir do qual pretende ligar está desligado.";
	}

	/**
	 * @return string informing that the phone is off.
	 */
	public static final String mobileIsOff() {
		return "O telefone pretendido está desligado.";
	}

	/**
	 * @return string informing that the phone is silent.
	 */
	public static final String mobileIsSilent() {
		return "O telefone pretendido está no silêncio.";
	}

	/**
	 * @return string prompting for the call duration.
	 */
	public static final String timeReq() {
		return "Duração da chamada (em minutos): ";
	}

	/**
	 * @return string prompting for the number of SMS characters.
	 */
	public static final String charReq() {
		return "Número de caracteres da chamada: ";
	}

	/**
	 * @param cost
	 *            the cost of the communication
	 * @return string reporting the cost of the communication.
	 */
	public static final String costOfMessage(long cost) {
		return "O custo da chamada foi: " + cost/100 + "," + cost%100 + " euros.";
	}

	/**
	 * @return string reporting the mobile identifier does not exist.
	 */
	public static final String noMobile() {
		return "O Número de telemóvel indicado é desconhecido.";
	}

	/**
	 * @return string reporting a mobile is already on.
	 */
	public static final String alreadyOn() {
		return "O telemóvel já estava ligado.";
	}

	/**
	 * @return string reporting a mobile is already on the silent state.
	 */
	public static final String alreadySilent() {
		return "O telemóvel já estava no silêncio.";
	}

	/**
	 * @return string reporting a mobile is already off.
	 */
	public static final String alreadyOff() {
		return "O telemóvel já estava desligado.";
	}

	/**
	 * @param idMobile
	 *            the mobile number of the phone that has been turned on
	 * @param idCaller
	 *            the mobile number that tried to communicate before
	 * @return string with informative message.
	 */
	public static final String isAvailable(int idMobile, int idCaller) {
		return "O Telemóvel '" + idMobile + "' já está disponível para o telefone '" + idCaller + "'.";
	}

	/**
	 * @param idMobile
	 *            the mobile number of the phone that has been turned on
	 * @param idCaller
	 *            the mobile number that tried to communicate before
	 * @return string with informative message.
	 */
	public static final String isAvailableForSMS(int idMobile, int idCaller) {
		return "O Telemóvel '" + idMobile + "' já está disponível para receber SMSs do telefone '" + idCaller + "'.";
	}

	/**
	 * @return string representing a voice call.
	 */
	public static final String voiceMessage() {
		return "VOZ";
	}

	/**
	 * @return string representing a text call.
	 */
	public static final String textMessage() {
		return "SMS";
	}

	/**
	 * @return string representing a video call.
	 */
	public static final String videoMessage() {
		return "MMS";
	}

	/**
	 * @return string representing a call.
	 */
	public static final String call() {
		return "CHAMADA";
	}

}