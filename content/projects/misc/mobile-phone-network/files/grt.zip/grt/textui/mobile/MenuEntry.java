/**
 * @version $Id: MenuEntry.java,v 1.0 $
 */
package grt.textui.mobile;

/**
 * Menu entries.
 */
@SuppressWarnings("nls")
public final class MenuEntry {
	/** Menu title. */
	public static final String TITLE = "Gestão de Telemóveis";

	/** Show all mobiles. */
	public static final String SHOW_ALL = "Visualizar";

	/** Register one mobile. */
	public static final String REGISTER = "Registar";

	/** Manage one mobile. */
	public static final String MANAGE_ONE_MOBILE = "Gestão de UM Telemóvel";

}