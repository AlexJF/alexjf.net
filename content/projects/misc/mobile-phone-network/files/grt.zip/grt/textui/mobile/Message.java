/**
 * @version $Id: Message.java,v 1.0 $
 */
package grt.textui.mobile;

/**
 * Messages.
 */
public class Message {
	/**
	 * @return string prompting for mobile identifier
	 */
	public static final String numeroReq() {
		return "Número do telemóvel: ";
	}

	/**
	 * @return string prompting for mobile type
	 */
	public static final String typeReq() {
		return "Tipo do telemóvel (2G ou 3G): ";
	}

	/**
	 * @param id
	 *            int id
	 * @return string reporting a duplicate mobile identifier
	 */
	public static final String duplicateMobile(int id) {
		return "O número'" + id + "' já está atribuído.";
	}

	/**
	 * @return string representing a mobile on the on state.
	 */
	public static final String mobileOn() {
		return "LIGADO";
	}

	/**
	 * @return string representing a mobile on the silence state.
	 */
	public static final String mobileSilence() {
		return "SILENCIO";
	}

	/**
	 * @return string representing a mobile on the off state.
	 */
	public static final String mobileOff() {
		return "DESLIGADO";
	}

	/**
	 * @return string representing a 2G mobile.
	 */
	public static final String mobile2G() {
		return "2G";
	}

	/**
	 * @return string representing a 3G mobile.
	 */
	public static final String mobile3G() {
		return "3G";
	}

	/**
	 * @return string representing a telemovel.
	 */
	public static final String telemovel() {
		return "TELEMOVEL";
	}
}
