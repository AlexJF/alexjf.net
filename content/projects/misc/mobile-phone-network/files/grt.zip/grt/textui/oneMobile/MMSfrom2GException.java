/**
 * @version $Id: MMSto2GException.java, v 1.0 $
 */
package grt.textui.oneMobile;

import pt.utl.ist.po.ui.InvalidOperation;

/**
 * Exception for unknown client identifiers.
 */
@SuppressWarnings("nls")
public class MMSfrom2GException extends InvalidOperation {
	static final long serialVersionUID = 201010121102L;
	/**
	 * @param id
	 *            2G Mobile id to report.
	 */
	public MMSfrom2GException(int id) {
		super("O telefone '" + id + "'é 2G e não pode iniciar mensagens MMS.");
	}

}
