/**
 * @version $Id: MenuEntry.java,v 1.0 $
 */
package grt.textui.grt;

/**
 * Menu entries.
 */
public final class MenuEntry {
	/** Menu title. */
	public static final String TITLE = "Menu de Operação";

	/** Client management. */
	public static final String CLIENTS= "Gestão de Clientes";

	/** Mobiles management. */
	public static final String MOBILES= "Gestão de Telemóveis";

	/** Lookups. */
	public static final String LOOKUPS = "Consultas";

	/** Show Balance. */
	public static final String SHOW_BALANCE = "Ver Saldo";

}