/**
 * @version $Id: UnknownClientKeyException.java, v 1.0 $
 */
package grt.textui.cliente;

import pt.utl.ist.po.ui.InvalidOperation;

/**
 * Exception for unknown client identifiers.
 */
@SuppressWarnings("nls")
public class UnknownClientKeyException extends InvalidOperation {
	static final long serialVersionUID = 200910161102L;
	/**
	 * @param id
	 *            Unknown animal id to report.
	 */
	public UnknownClientKeyException(String id) {
		super("Não existe nenhum cliente identificado por '" + id + "'");
	}

}
