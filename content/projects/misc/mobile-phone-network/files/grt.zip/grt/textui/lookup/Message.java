/**
 * @version $Id: Message.java,v 1.0 $
 */
package grt.textui.lookup;

/**
 * Messages.
 */
public class Message {

	/**
	 * @return string representing a call that took place.
	 */
	public static final String done() {
		return "EFECTIVA";
	}

	/**
	 * @return string representing a text call.
	 */
	public static final String noMessage() {
		return "SEM-MENSAGEM";
	}

	/**
	 * @return string representing a video call.
	 */
	public static final String message() {
		return "COM-MENSAGEM";
	}

}