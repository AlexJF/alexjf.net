/**
 * @version $Id: Message.java,v 1.0 $
 */
package grt.textui.grt;

/**
 * Messages.
 */
public class Message {


}