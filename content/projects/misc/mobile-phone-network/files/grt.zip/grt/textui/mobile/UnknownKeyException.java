/**
 * @version $Id: UnknownKeyException.java,v 1.0 $
 */
package grt.textui.mobile;

import pt.utl.ist.po.ui.InvalidOperation;

/**
 * Exception for unknown mobile identifiers.
 */
@SuppressWarnings("nls")
public class UnknownKeyException extends InvalidOperation {
	static final long serialVersionUID = 200910161102L;


	/**
	 * @param id
	 *            Unknown mobile id to report.
	 */
	public UnknownKeyException(int id) {
		super("Não existe nenhum telemóvel identificado por '" + id + "'");
	}

}
