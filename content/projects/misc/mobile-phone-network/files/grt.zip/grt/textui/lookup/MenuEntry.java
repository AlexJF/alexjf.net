/**
 * @version $Id: MenuEntry.java,v 1.0 $
 */
package grt.textui.lookup;

/**
 * Menu entries.
 */
public final class MenuEntry {
	/** Menu title. */
	public static final String TITLE = "Consultas";

	/** List all calls. */
	public static final String ALL_CALLS = "Todas as Chamadas";

	/** List calls from one client. */
	public static final String CALLS_FROM_CLIENT = "Chamadas de um Cliente";

	/** List calls to a client. */
	public static final String CALLS_TO_CLIENT = "Chamadas para um Cliente";

	/** List clients with no debts. */
	public static final String CLIENTS_NO_DEBTS = "Clientes sem Dívidas";

	/** List clients with at least on mobile with debts. */
	public static final String CLIENTS_WITH_DEBTS = "Clientes com Dívidas";

	/** List mobiles with no activity. */
	public static final String MOBILE_NO_ACTIVITY = "Telemóveis sem Actividade";

	/** List mobiles with positive balance. */
	public static final String MOBILE_POSITIVE_BALANCE = "Telemóveis com Saldo Positivo";
}
