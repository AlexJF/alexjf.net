/**
 * @version $Id: MenuEntry.java,v 1.0 $
 */
package grt.textui.oneMobile;

/**
 * Menu entries.
 */
public final class MenuEntry {
	
	/** Menu title. */
	public static final String TITLE = "Gestão do Telemóvel ";

	/** Power on the mobile. */
	public static final String POWER_ON = "Ligar";

	/** Mute the mobile. */
	public static final String MUTE = "Colocar no Silêncio";

	/** Power off the mobile. */
	public static final String POWER_OFF = "Desligar";

	/** Register a new friend */
	public static final String NEW_FRIEND = "Adicionar Amigo";

	/** Remove an old friend. */
	public static final String OLD_FRIEND = "Retirar Amigo";

	/** Pay. */
	public static final String PAYMENT = "Pagamento";

	/** Show balance. */
	public static final String SHOW_BALANCE = "Consultar Saldo";

	/** Connect to another mobile. */
	public static final String CONNECT = "Estabelecer ligação";

}
