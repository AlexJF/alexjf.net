package grt;

/**
 * Esta classe representa uma chamada do tipo MMS.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class MMS extends Call {

	/**
	 * Cria uma nova instância de MMS.
	 *
     * @param network A rede à qual pertence este MMS.
	 * @param id Id da MMS.
	 * @param caller Telefone de onde provém a MMS.
	 * @param receiver Telefone para onde é enviada a MMS.
	 */
    MMS(Network network, int id, Mobile caller, Mobile receiver) {
        super(network, id, caller, receiver);
    }

	/**
	 * Devolve uma string com a informação da MMS.
	 *
	 * @return String com a informação da MMS.
	 */
    public String toString() {
		return super.toString(grt.textui.oneMobile.Message.videoMessage());
	}
}
