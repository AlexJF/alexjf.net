package grt;

/**
 * Esta classe representa uma chamada de voz.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class Voice extends Call {
	/**
	 * Cria uma nova instância de Voice.
	 *
     * @param network A rede à qual pertence esta chamada de voz.
	 * @param id Id da chamada de voz.
	 * @param caller Telefone de onde provém a chamada de voz.
	 * @param receiver Telefone para onde é enviada a chamada de voz.
	 */
    Voice(Network network, int id, Mobile caller, Mobile receiver) {
        super(network, id, caller, receiver);
    }

	/**
	 * Devolve uma string com a informação de chamada.
	 *
	 * @return String com a informação da chamada.
	 */
    public String toString() {
		return super.toString(grt.textui.oneMobile.Message.voiceMessage());
	}
}
