package grt;

import java.util.*;
import java.lang.*;
import java.io.Serializable;

import grt.textui.cliente.Message;

/**
 * Esta classe representa um cliente da rede.
 *
 * Um cliente contém:
 * - Id
 * - Nome
 * - Num. Identificação fiscal.
 * - Conjunto de telemóveis.
 * - Um comportamento referente à notificação de chamadas falhadas.
 * - Um estado/tipo.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public class Client implements Comparable, Serializable {
    /** Rede onde está registado o cliente. */
    private Network _network;
	/** Id do cliente */
	private String _id;
	/** Nome do cliente */
	private String _name;
	/** NIF do cliente */
	private int _nif;
	/** Lista do telemoveis do cliente */
	private Set<Mobile> _mobiles;
	/** Comportamento definido para chamadas perdidas */
    private MissedCallBehaviour _missedCallBehaviour;
    /** Tipo do cliente */
    private ClientState _state;

	/**
	 * Instancia um novo objecto do tipo Client.
     *
     * Este cliente será iniciado com o tipo especificado.
	 *
     * @param network Rede onde está registado o cliente.
	 * @param id Id do cliente
	 * @param name Nome do cliente
	 * @param nif NIF do cliente
	 * @param type Tipo do cliente
	 */
    Client(Network network, String id, String name, int nif, String type) {
        _network = network;
        _network.setDirty(true);
        _id = id;
        _name = name;
        _nif = nif;
        _mobiles = new TreeSet<Mobile>();
        _missedCallBehaviour = new MissedCallMessageAll();

        if (type.equals(Message.clientPlatine())) {
            setState(new ClientPlatinumState());
        }
        else if (type.equals(Message.clientGold())) {
            setState(new ClientGoldState());
        }
        else {
            setState(new ClientNormalState());
        }
    }

    /**
     * Devolve a rede associada a este cliente.
     *
     * @return Rede associada ao cliente.
     */
    public Network getNetwork() {
        return _network;
    }
	
	/**
	 * Retorna o id do cliente.
	 *
	 * @return Id do cliente.
	 */
	public String getId() {
		return _id;
	}
	
	/**
	 * Retorna o nome do cliente.
	 *
	 * @return Nome do cliente.
	 */
	public String getName() {
		return _name;
	}
	
	/**
	 * Retorna o nif do cliente.
	 *
	 * @return Nif do cliente.
	 */
	public int getNif() {
		return _nif;
	}

	/**
	 * Retorna a lista de telemóveis do cliente.
	 *
	 * @return Lista de telemóveis do cliente.
	 */ 
	public List<Mobile> getMobiles(){
		return new LinkedList<Mobile>(_mobiles);
	}
	
    /**
     * Devolve o somatório dos saldos de todos os telemóveis do cliente.
     *
     * @return Somatório dos saldos de todos os telemóveis do cliente.
     */
    public long getBalance() {
        long totalBalance = 0;
        for (Mobile m : _mobiles) {
            totalBalance += m.getBalance();
        }

        return totalBalance;
    }

    /**
     * Devolve o somatório dos saldos negativos dos telemóveis do 
     * cliente.
     *
     * @return Somatório dos saldos negativos dos telemóveis do cliente.
     */
    public long getDebt() {
        long totalDebt = 0;
        for (Mobile m : _mobiles) {
            long mBalance = m.getBalance();
            if (mBalance < 0) {
                totalDebt += -mBalance;
            }
        }

        return totalDebt;
    }

	/**
	 * Activa a recepção de notificações.
	 *
	 * @return false se as notifcações já estavam activas
	 * 		   e true caso contrário
	 */
    public boolean activateNotifications() {
        if (_missedCallBehaviour.notificationsActive()) {
            return false;
        }
        _network.setDirty(true);
        _missedCallBehaviour = new MissedCallMessageAll();
        return true;
    }

	/**
	 * Desactiva a recepção de notificações.
	 *
	 * @return false se as notificações ja estavam desactivadas
	 * 		   e true caso contrário
	 */
    public boolean disableNotifications() {
        if (!_missedCallBehaviour.notificationsActive()) {
            return false;
        }
        _network.setDirty(true);
        _missedCallBehaviour = new MissedCallMessageNone();
        return true;
    }

	/**
	 * Altera o tipo/estado do cliente.
     *
     * Esta função apenas deve ser chamada pelo construtor de cliente
     * ou por um dos vários tipos de ClientState para implementar a 
     * mudança transparente de estados.
	 *
	 * @param state Novo estado do cliente
	 */
    void setState(ClientState state) {
        _network.setDirty(true);
        _state = state;
        _state.setClient(this);
    }

	/**
	 * Adiciona um telemóvel ao cliente.
	 *
	 * @param m Telemóvel a adicionar.
	 */
    void addMobile(Mobile m) {
        _mobiles.add(m);
    }

	/**
	 * Notifica o cliente de que este efectuou a chamada passada como 
     * argumento.
     *
     * Isto permite ao vários estados saber quando devem mudar.
     *
     * @param call Chamada efectuada pelo cliente.
     *
     * @return Custo da chamada efectuada de acordo com o tarifário
     *         associado ao actual estado do cliente.
	 */
    long handleCall(Call call) {
        return _state.handleCall(call);
    }

    /**
     * Notifica o cliente de que um dos seus telemóveis recebeu uma
     * tentativa falhada de comunicação.
     *
     * O cliente redirecciona essa notificação para o seu missedCall
     * Behaviour que é quem sabe lidar com esses eventos.
     *
     * @param call Chamada falhada.
     */
    void handleMissedCall(Call call) {
        _missedCallBehaviour.handleCall(call);
    }

	/**
	 * Verifica se mediante um pagamanto o estado do cliente deve
	 * ou não ser alterado.
	 */
    void handlePayment() {
        _state.handlePayment();
    }
    
	/**
	 * Notifica o cliente de que este tentou efectuar uma chamada MMS 
     * para um telemóvel 2G.
     *
     * Isto permite aos vários estados saber quando devem mudar.
	 */
    void handleMMSTo2G() {
        _state.handleMMSTo2G();
    }

	/**
     * Obtem uma string que descreve uma instância de um cliente.
	 *
	 * @return String formatada com a informação do cliente
	 */
    public String toString() {
        return "CLIENTE|" + _id + "|" + _name + "|" + _nif + "|" +
               _state.toString() + "|" + 
               _missedCallBehaviour.toString() + "|" +
               _mobiles.size() + "|" + getBalance();
    }

	/**
	 * Compara esta instância de cliente com uma segunda instância.
     *
     * Um cliente é "maior" de que outro se o seu id for lexicograficamente
     * maior (sem contar com maiúsculas) do que o do segundo.
     *
     * @param client Cliente com o qual comparar o actual.
	 *
	 * @return  1 se cliente actual é maior, 0 se iguais e -1 se segundo
     *         cliente é maior.
	 */
    public int compareTo(Object client) {
        if (!(client instanceof Client)) {
            throw new ClassCastException("Esperava Cliente para a comparação.");
        }
        return this._id.compareToIgnoreCase(((Client) client).getId());
    }

    /**
     * Este Comparador compara 2 clientes tendo em conta as suas
     * dívidas e os seus ids.
     *
     * A ordem especificada por este comparador é a seguinte:
     * - Clientes ordenados por ordem decrescente de dívidas.
     * Caso 2 clientes tenham as mesmas dívidas, a ordem é
     * determinada pelos seus identificadores (crescente).
     */
    public static class ComparatorDebt implements Comparator<Client>, 
                                                  Serializable {
        /**
         * Compara dois clientes de acordo com o seu nível de dívidas.
         *
         * @param c1 Cliente 1.
         * @param c2 Cliente 2.
         *
         * @return 1 se c1 maior q c2, 0 se são iguais e -1 se 
         *         c2 maior q c1.
         */
        public int compare(Client c1, Client c2) {
            Long debtC1 = new Long(c1.getDebt());
            int compResult = debtC1.compareTo(c2.getDebt());
            if (compResult != 0) {
                return -1*compResult;
            }
            else {
                return c1.compareTo(c2);
            }
        }
    }

    /**
     * Este filtro permite seleccionar clientes com dívidas de entre
     * um conjunto de clientes.
     */
    public static class FilterWithDebt implements Filter<Client> {
        /**
         * Verifica se o cliente tem dívidas.
         *
         * @param c Cliente a analisar por dívidas.
         *
         * @return true - tem dívidas, false - não tem.
         */
        public boolean test(Client c) {
            return c.getDebt() > 0;
        }
    }
    
	/**
	 * Este filtro permite seleccionar clientes sem dívidas de entre
	 * um conjunto de clientes.
	 */
    public static class FilterWithNoDebt implements Filter<Client> {
        /**
         * Verifica se o cliente não tem dívidas.
         *
         * @param c Cliente a analisar por dívidas.
         *
         * @return true - não tem dívidas, false - tem.
         */
		public boolean test(Client c) {
			return c.getDebt() == 0;
		}
	}
}
