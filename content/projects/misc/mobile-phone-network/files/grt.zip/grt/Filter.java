package grt;

import java.io.*;

/**
 * Esta interface representa um filtro que permite ao utilizador 
 * descriminar elementos de um conjunto de entidades.
 *
 * @param <T> Tipo das entidades sobre o qual o filtro irá actuar.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public interface Filter<T> extends Serializable {

	/**
	 * Função a ser implementada por cada filtro.
	 *
	 * @param obj Entidade onde o filtro vai actuar.
     *
     * @return true - objecto corresponde ao tipo de objectos
     *         pretendidos, false caso contrário.
	 */
    public boolean test(T obj);
}
