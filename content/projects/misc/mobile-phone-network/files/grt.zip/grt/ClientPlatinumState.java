package grt;

/**
 * Implementa o estado de cliente Platinum.
 *
 * Este estado tem as seguintes transições:
 * - Platina p/ Ouro - Realização de 2 SMS consecutivos.
 * - Platina p/ Normal - Tentative de chamada MMS para 2G.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class ClientPlatinumState extends ClientState {
	/** Numero de SMS consecutivas realizadas */
    private int _numberSMSCalls;
    /** Booleano que determina se o estado acabou de tratar um SMS. */
    private boolean _handledSMS = false;

    /**
	 * Cria uma nova instância de ClientPlatinumState.
	 */
    ClientPlatinumState() {
        super(new PlatinumPlan());
    }

	/**
	 * Devolve uma string que descreve este estado de cliente.
     *
     * @return String com descrição deste estado.
	 */
    public String toString() {
        return grt.textui.cliente.Message.clientPlatine();
    }

    /**
     * Faz o reset do número de SMS consecutivos quando o tipo
     * de chamada efectuada não é SMS e calcula o preço da chamada.
     *
     * @param call Chamada efectuada.
     *
     * @return Long com preço da chamada.
     */
    long handleCall(Call call) {
        if (call == null) {
            return 0;
        }

        _handledSMS = false;

        long price = super.handleCall(call);

        if (!_handledSMS) {
            _numberSMSCalls = 0;
        }

        return price;
    }

	/**
	 * Verifica se deve mudar de estado apos a realizaçao de uma SMS.
     *
     * Caso tenha realizado 2 SMS consecutivas, o cliente deve passar
     * a Gold.
	 *
	 * @param call SMS realizada
	 */
    void handleSMS(SMS call) {
        if (call == null) {
            return;
        }

        _handledSMS = true;
        _numberSMSCalls++;

        if (_numberSMSCalls == 2) {
            getClient().setState(new ClientGoldState());
        }
    }

	/**
     * Muda de estado após ter efectuado uma chamada MMS para um 
     * telemóvel 2G.
     *
     * Caso tenha tentato efectuar uma chamada para um telemóvel 2G,
     * o cliente deve passar para o estado Normal.
	 */
    void handleMMSTo2G() {
        getClient().setState(new ClientNormalState());
    }

    /**
     * Tarifário associado a um cliente platina, onde são calculados os
     * preços de cada chamada.
     */
    static private class PlatinumPlan extends Plan {
        /**
         * Obtém o custo de uma chamada de voz.
         *
         * @param call Chamada da qual pretendemos saber o custo.
         *
         * @return Inteiro com o valor da chamada (cêntimos).
         */
        long getCostVoice(Voice call) {
            return checkFriend(call, 10*call.getDuration());
        }

        /**
         * Obtém o custo de uma chamada de MMS.
         *
         * @param call Chamada da qual pretendemos saber o custo.
         *
         * @return Inteiro com o valor da chamada (cêntimos).
         */
        long getCostMMS(MMS call) {
            return checkFriend(call, 10*call.getDuration());
        }

        /**
         * Obtém o custo de uma chamada de SMS.
         *
         * @param call Chamada da qual pretendemos saber o custo.
         *
         * @return Inteiro com o valor da chamada (cêntimos).
         */
        long getCostSMS(SMS call) {
            long smsLength = call.getDuration();

            if (smsLength < 50) {
                return 0;
            } 
            else {
                return 4;
            }
        }
    }
       
}
