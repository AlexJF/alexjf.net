package grt;

import java.io.*;

/**
 * Interface de comportamento referente à notificção de chamadas
 * perdidas.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
interface MissedCallBehaviour extends Serializable {

	/**
	 * Define o tratamento de uma chamada perdida.
	 *
	 * @param call Chamada perdida.
	 */
    abstract void handleCall(Call call);

    abstract boolean notificationsActive();

    /**
	 * Devolve uma string representante do comportamento.
	 *
	 * @return String representante do comportamento.
	 */
    abstract String toString();
}
