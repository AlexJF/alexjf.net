package grt;

/**
 * Implementa o estado de cliente Gold.
 *
 * Este estado tem as seguintes transições:
 * - Ouro p/ Normal - Saldo após chamada inferior a 0.
 * - Ouro p/ Platina - 5 chamadas consecutivas do tipo MMS.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class ClientGoldState extends ClientState {
	/** Número de MMS consecutivas realizadas */
    private int _numberMMSCalls;
    /** Booleano que determina se o estado acabou de tratar um MMS. */
    private boolean _handledMMS = false;

	/**
	 * Cria uma nova instância de ClientGoldState.
	 */
    ClientGoldState() {
        super(new GoldPlan());
    }

	/**
	 * Devolve uma string que descreve este estado de cliente.
     *
     * @return String com descrição deste estado.
	 */
    public String toString() {
        return grt.textui.cliente.Message.clientGold();
    }

	/**
	 * Verifica se após realização de uma chamada o cliente deve ou não
	 * mudar de estado.
     *
     * Caso o saldo total do cliente seja negativo após a concretização
     * da mensagem analisada, deve passar para o estado Normal.
	 *
	 * @param call Chamada realizada.
     *
     * @return Preço da chamada realizada.
	 */
    long handleCall(Call call) {
        if (call == null) {
            return 0;
        }

        _handledMMS = false;

        long price = super.handleCall(call);

        if (!_handledMMS) {
            _numberMMSCalls = 0;
        }

        if (getClient().getBalance() - price < 0) {
            getClient().setState(new ClientNormalState());
        }

        return price;
    }

	/**
     * Verifica se após a realização de uma chamada MMS o cliente deve
     * ou não mudar de estado.
     *
     * Caso o cliente tenha efectuado 5 MMS consecutivos deve mudar
     * para o estado Platinum.
	 *
	 * @param call MMS realizada.
	 */
    void handleMMS(MMS call) {
        _handledMMS = true;
        _numberMMSCalls++;
        if (_numberMMSCalls == 5) {
            getClient().setState(new ClientPlatinumState());
        }
    }

    /**
     * Tarifário associado a um cliente gold, onde são calculados os
     * preços de cada chamada.
     */
    static private class GoldPlan extends Plan {
        /**
         * Obtém o custo de uma chamada de voz.
         *
         * @param call Chamada da qual pretendemos saber o custo.
         *
         * @return Inteiro com o valor da chamada (cêntimos).
         */
        long getCostVoice(Voice call) {
            return checkFriend(call, 10*call.getDuration());
        }

        /**
         * Obtém o custo de uma chamada de MMS.
         *
         * @param call Chamada da qual pretendemos saber o custo.
         *
         * @return Inteiro com o valor da chamada (cêntimos).
         */
        long getCostMMS(MMS call) {
            return checkFriend(call, 20*call.getDuration());
        }

        /**
         * Obtém o custo de uma chamada de SMS.
         *
         * @param call Chamada da qual pretendemos saber o custo.
         *
         * @return Inteiro com o valor da chamada (cêntimos).
         */
        long getCostSMS(SMS call) {
            long smsLength = call.getDuration();

            if (smsLength < 100) {
                return 10;
            } else {
                return 2*smsLength;
            }
        }
    }
}
