package grt;

import java.io.Serializable;
import java.util.Comparator;

/**
 * Esta classe abstracta representa uma chamada entre 2 telemóveis.
 *
 * Instâncias de chamada devem ser criadas através de uma das classes
 * que a implementam (Voice, SMS ou MMS).
 *
 * Uma chamada contém:
 * - Id
 * - Telemóvel de origem
 * - Telemóvel de destino
 * - Duração
 * - Custo
 * - Estado
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */ 
abstract public class Call implements Serializable, Comparable {
    /** Rede à qual pertence a chamada. */
    private Network _network;
	/** Id da chamada */
	private int _id;
	/** Telemóvel que inicia a chamada */
	private Mobile _caller;
	/** Telemóvel que recebe a chamada */
	private Mobile _receiver;
	/** Duração da chamada */
	private long _duration;
	/** Custo da chamada */
	private long _cost;
	/** Estado da chamada */
    private CallState _state;
    /** 
     * Determina se a chamada pode ser efectuada
     * quando o telemóvel de destino está em silêncio ou não.
     */
    protected boolean _startOnSilence = false;

	/**
	 * Cria uma nova instância de Chamada.
     *
     * Todas as chamadas começam com estado correspondente
     * a não efectuada e sem mensagem de notificação.
	 *
     * @param network Rede à qual pertence a chamada.
	 * @param id Id da chamada
	 * @param caller Telemóvel que realizou a chamada
	 * @param receiver Telemóvel que recebe a chamada
	 */
    public Call(Network network, int id, Mobile caller, Mobile receiver) {
        _network = network;
        _network.setDirty(true);
        _id = id;
        _caller = caller;
        _receiver = receiver;
        _state = new CallStateNoMessage(this);
    }

    /**
     * Devolve a rede associada a esta chamada.
     *
     * @return Rede associada à chamada.
     */
    public Network getNetwork() {
        return _network;
    }

	/**
	 * Retorna o id da chamada.
	 *
	 * @return Id da chamada.
	 */
	public int getId() {
		return _id;
	}
	
	/**
	 * Retorna o telemovel que originou a chamada.
	 *
	 * @return Telemovel que originou a chamada.
	 */
	public Mobile getCaller() {
		return _caller;
	}
	
	/**
	 * Retorna o telemovel de destino da chamada.
	 *
	 * @return Telemovel de destino da chamada.
	 */
	public Mobile getReceiver(){
		return _receiver;
	}
	
	/**
	 * Retorna a duracao da chamada.
	 *
	 * @return Duracao da chamada.
	 */
	public long getDuration(){
		return _duration;
	}

	/**
	 * Retorna o custo da chamada.
	 *
	 * @return Custo da chamada.
	 */
	public long getCost() {
		return _cost;
	}

	/**
	* Retorna se é possivel iniciar uma chamada com o telemóvel de
	* destino em silêncio.
	*
	* @return true se se pode iniciar uma chamada com o telemóvel de
	* 			   destino em silêncio e false caso contrário .	
	*/
    public boolean canStartOnSilence() {
        return _startOnSilence;
    }

	/**
	 * Retorna se uma chamada foi efectiva.
	 *
	 * @return true se a chamada foi efectiva e false caso contrário.
	 */
    public boolean effective() {
        return _state.effective();
    }

	/**
	 * Retorna se a chamada deixou mensagem no telemóvel de destino.
	 *
	 * @return true se foi deixada mensagem no destino e false caso 
     *         contrário.
	 */
    public boolean leftMessage() {
        return _state.leftMessage();
    }

	/**
	 * Termina uma chamada efectiva.
     *
     * Esta função irá calcular o custo da chamada através do
     * tarifário, baseando-se na duração, no telemóvel de origem e no 
     * tipo de chamada.
	 *
	 * @param duration Duração da chamada.
	 */
    public void end(long duration) {
        _state.end(duration);
        _network.setDirty(true);
    }

	/**
	 * Atribui uma duração à chamada.
	 *
	 * @param duration Duração a atribuir à chamada
	 */
    void setDuration(long duration) {
        _duration = duration;
    }
	
	/**
	 * Atribui um custo à chamada.
	 *
	 * @param cost Custo a atribuir à chamada.
	 */
    void setCost(long cost) {
        _cost = cost;
    }

	/**
	 * Altera o estado da chamada.
     *
	 * Define que a chamada foi efectiva.
	 */
    void setEffective() {
        _state = new CallStateEffective(this);
    }

	/**
	 * Altera o estado da chamada.
     *
	 * Define que a chamada não foi efectiva e que foi deixada uma 
     * mensagem no telemóvel de destino.
	 */
    void setMessage() {
        _state = new CallStateMessage(this);
    }

	/**
	 * Altera o estado da chamada.
     *
	 * Define que a chamada não foi efectiva e que não foi deixada 
     * nenhuma mensagem no telemóvel de destino.
	 */
    void setNoMessage() {
        _state = new CallStateNoMessage(this);
    }

	/**
     * Obtem uma string que descreve a chamada.
     *
     * Esta função deve ser usada pelas classes que herdem de Call
     * para especificar a string que define o tipo da chamada.
     *
     * @param type Tipo da chamada.
	 * 
	 * @return String formatada com a informação da chamada.
	 */
    protected String toString(String type){
		return "CHAMADA|" + _id + "|" + _caller.getNumber() + "|" + 
               _receiver.getNumber() + "|" + type + "|" + 
               _duration + "|" + _cost + "|" + _state;
	}

    /**
     * Obtem uma string que descreve a chamada.
     *
     * Esta função deve ser definida pelas classes que herdem de Call
     * utilizando o método protected toString(type).
     *
     * @return String formatada com a informação da chamada.
     */
	abstract public String toString();

	/**
	 * Compara esta instância de chamada com uma segunda.
     *
     * Uma chamada é maior que outra se o seu id for maior do que o da
     * segunda.
     *
     * @param call Segunda instância de chamada com a qual comparar.
	 *
	 * @return Retorna 1 se actual maior que call, 0 se são iguais ou
     *         -1 se actual menor que call.
	 */
    public int compareTo(Object call) {
        if (!(call instanceof Call)) {
            throw new ClassCastException();
        }

        return (new Integer(_id)).compareTo(((Call) call).getId());
    }

    /**
     * Este comparador compara 2 chamadas tendo em conta quem foi
     * o realizador da chamada.
     */
    public static class ComparatorCaller implements Comparator<Call>, 
                                                   Serializable {
		/**
		 * Compara 2 chamadas especificando uma ordem determinada pelo
         * id dos callers de cada chamada.
         *
         * @param c1 Chamada 1.
         * @param c2 Chamada 2.
         *
         * @return 1 se c1 maior que c2, 0 se c1=c2, -1 se c1 menor
         *         que c2.
		 */ 
        public int compare(Call c1, Call c2) {
            return c1.getCaller().compareTo(c2.getCaller());
        }
    }

}

