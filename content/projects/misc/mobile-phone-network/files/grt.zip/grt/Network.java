package grt;

import java.util.*;
import java.io.*;

import static pt.utl.ist.po.ui.UserInteraction.IO;

import grt.exceptions.*;

/**
 * Esta classe representa uma rede de telemóveis.
 *
 * Esta é a classe central de todo o projecto, permitindo a interacção
 * com cada uma das entidades envolvidas na rede.
 *
 * Actua como factory de Clientes, Telemóveis e Chamadas.
 *
 * Contém:
 * - Mapa de clientes
 * - Mapa de telemóveis
 * - Mapa de chamadas
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */ 
public class Network implements Serializable {
	/** Mapa de todos os clientes da rede */
	private Map<String, Client> _clients;
	/** Mapa de todos os telemóveis da rede */
	private Map<Integer, Mobile> _mobiles;
	/** Mapa de todas as chamadas válidas da rede */
    private Map<Integer, Call> _calls;
    /** Gerador de ids de chamadas */
    private int _callIdGenerator = 1;
    /** Boolean que determina se a rede foi modificada */
    private boolean _dirty = false;

	/**
	 * Cria uma instância de uma rede (vazia).
	 */	 
    public Network() {
        _clients = new TreeMap<String, Client>(String.CASE_INSENSITIVE_ORDER);
        _mobiles = new TreeMap<Integer, Mobile>();
        _calls = new TreeMap<Integer, Call>();
    }
    
	/**
	 * Cria uma instância de uma rede (utilizando Import).
     *
     * Tenta interpretar o ficheiro passado como argumento para
     * inicializar a rede com algumas entidades pre-definidas.
	 *
	 * @param importFileName Nome do ficheiro a importar.
	 */ 
    public Network(String importFileName) {
        this();
        parseImportFile(importFileName);
    }

	/**
	 * Cria um novo cliente.
     *
	 * Esta função é para uso interno da rede. Existe devido à 
     * necessidade de iniciar clientes num estado específico
     * quando se faz o import de um ficheiro.
	 *
	 * @param id Id do cliente.
	 * @param name Nome do cliente.
	 * @param nif Nif do cliente.
	 * @param state Tipo do cliente (estado).
	 * 
	 * @return O novo cliente registado.
	 * 
	 * @throws ClientExistsException Ja existe um cliente com o id 
     *                               especificado.
	 */
    private Client registerClient(String id, String name, int nif, 
                                  String state)
                                        throws ClientExistsException {
        if (getClient(id) != null) {
            throw new ClientExistsException(id);
        }

        Client newClient = new Client(this, id, name, nif, state);

        _clients.put(id, newClient);

        return newClient;
    }

	/**
	 * Cria um novo cliente.
     *
     * O cliente criado por esta função encontra-se no estado
     * Normal.
	 *
	 * @param id Id do cliente.
	 * @param name Nome do cliente.
	 * @param nif Nome do cliente.
	 *
	 * @return Novo cliente registado.
	 *
	 * @throws ClientExistsExecption Já existe um cliente com o id 
     *                               especificado.
	 */
    public Client registerClient(String id, String name, int nif) 
                                        throws ClientExistsException {
        return registerClient(id, name, nif, "");
    }

	/**
	 * Cria um novo telemóvel.
     *
	 * Esta função é para uso interno da rede. Existe devido à 
     * necessidade de iniciar telemoveis num estado específico
     * e com um saldo específico quando se faz o import de um ficheiro.
	 *
	 * @param owner O dono do telemóvel.
	 * @param number O número do telemóvel (6 dígitos).
	 * @param type Tipo do telemóvel.
	 * @param state Estado do telemóvel.
	 * @param balance Saldo do telemóvel.
	 *
	 * @return Novo telemóvel registado ou null caso argumentos 
     *         inválidos.
	 *
	 * @throws MobileExistsException Já existe um telemóvel com o número 
     *                               especificado.
	 */
    private Mobile registerMobile(Client owner, int number, String type, 
                                  String state, int balance) 
                                        throws MobileExistsException {
        if (owner == null) {
            return null;
        }

        if (getMobile(number) != null) {
            throw new MobileExistsException(number);
        }

        Mobile newMobile;

        if (type.equals(grt.textui.mobile.Message.mobile2G())) {
            newMobile = new Mobile2G(this, owner, number, state, balance);
        } else {
            newMobile = new Mobile3G(this, owner, number, state, balance);
        }

        _mobiles.put(number, newMobile);

        return newMobile;
    }

	/**
	 * Cria um novo telemóvel.
     *
     * O telemóvel criado por esta função encontra-se Ligado e com
     * um saldo inicial de 0 cêntimos.
	 *
	 * @param owner O dono do telemóvel.
	 * @param number O número do telemóvel.
	 * @param type O tipo de telemóvel.
	 *
	 * @return Novo telemóvel registado ou null caso argumentos 
     *         inválidos.
	 *
	 * @throws MobileExistsException Já existe um telemóvel com este 
     *                               número
	 */
    public Mobile registerMobile(Client owner, int number, String type)
                                        throws MobileExistsException {
        return registerMobile(owner, number, type, 
                              grt.textui.mobile.Message.mobileOn(), 0);
    }

    /**
     * Cria (e inicia) uma nova chamada entre 2 telemóveis da rede.
     *
     * A partir do momento em que a chamada não é incompatível com o 
     * tipo de telemóveis em questão (2G/3G) e que o telemóvel de 
     * origem não está desligado, a chamada é criada e fica registada 
     * na rede.
     * Caso depois se venha a verificar que o telemóvel de destino está
     * desligado ou em silêncio, a chamada não é devolvida ao chamador
     * (pois é lançada uma excepção).
     *
     * @param caller Telemóvel que inicia a chamada.
     * @param receiver Telemóvel que irá receber a chamada.
     * @param type Tipo de chamada.
     *
     * @return Nova chamada criada e iniciada ou null caso argumentos 
     *         inválidos.
     *
     * @throws CallOrigin2GException Telemóvel de origem é 2G e tentou 
     *                                mandar MMS.
     * @throws CallDestination2GException Telemóvel de destino é 2G e  
     *                                recebeu MMS.
     * @throws CallException Excepção que representa algo de inesperado que
     *                       impediu a concretização da chamada (destino em
     *                       silêncio, desligado, etc.)
     */
    public Call registerCall(Mobile caller, Mobile receiver, String type) 
                             throws CallOrigin2GException,
                                    CallDestination2GException, 
                                    CallException {
        if (caller == null || receiver == null) {
            return null;
        }

        Call newCall = null;

        if (caller.isOff()) {
            throw new CallOriginOffException();
        }

        if (type.equals(grt.textui.oneMobile.Message.voiceMessage())) {
            newCall = new Voice(this, _callIdGenerator++, caller, receiver);
        }
        else if (type.equals(grt.textui.oneMobile.Message.videoMessage())) {
            if (caller instanceof Mobile2G) {
                throw new CallOrigin2GException();
            } 
            if (receiver instanceof Mobile2G) {
                caller.getOwner().handleMMSTo2G();
                throw new CallDestination2GException();
            }
            newCall = new MMS(this, _callIdGenerator++, caller, receiver);
        }
        else if (type.equals(grt.textui.oneMobile.Message.textMessage())) {
            newCall = new SMS(this, _callIdGenerator++, caller, receiver);
        }
        else {
            throw new CallInvalidType(type);
        }

        _calls.put(newCall.getId(), newCall);
        caller.startCall(newCall);
        receiver.receiveCall(newCall);

        return newCall;
    }

    
	/**
	 * Verifica se a rede foi modificada desde a última vez que foi
     * guardada.
	 *
	 * @return true se a rede se encontra dirty e false caso contrário.
	 */ 
    public boolean isDirty() {
        return _dirty;
    }
    
    /**
     * Assinala que a rede está ou não dirty (alterada).
     *
     * @param dirty Novo estado de dirty da rede.
     */ 
    void setDirty(boolean dirty) {
        _dirty = dirty;
    }

	/**
	 * Obtem o cliente com o identificador especificado.
	 *
	 * @param id Id do cliente pretendido.
	 *
	 * @return Cliente com o id expecificado ou null caso este
     *         não exista.
	 * */
    public Client getClient(String id) {
        return _clients.get(id);
    }

	/**
	 * Obtem a lista de todos os clientes da rede.
	 *
	 * @return Lista com todos os clientes da rede.
	 */ 
    public List<Client> getClients() {
        return getClients(null);
    }

	/**
	 * Obtem uma lista de clientes mediante um determinado filtro.
	 *
	 * @param filter O filtro a aplicar na lista de clientes.
	 *
	 * @return Uma lista de clientes filtrada mediante o filtro 
     *         especificado.
	 */
    public List<Client> getClients(Filter<Client> filter) {
        List<Client> filteredList;
        if (filter != null) {
            filteredList = new LinkedList<Client>();
            for (Client c : _clients.values()) {
                if (filter.test(c)) {
                    filteredList.add(c);
                }
            }
        } else {
            filteredList = new LinkedList<Client>(_clients.values());
        }
        return filteredList;
    }

	/**
	 * Devolve a chamada com o id indicado.
	 *
	 * @param number Id da chamada desejada.
	 *
	 * @return Chamada com o id indicado.
	 */
    public Call getCall(int id) {
        return _calls.get(id);
    }

	/**
	 * Devolve a lista de chamadas.
	 *
	 * @return A lista de chamadas.
	 */
     public List<Call> getCalls() {
        return getCalls(null);
    }

	/**
	 * Devolver uma lista de chamadas filtradas mediante o filtro indicado.
	 *
	 * @param filter Filtro a utilizar para filtra a lista de chamasdas.
	 *
	 * @return Lista de chamadas filtradas mediante o filtro indicado.
	 */
    public List<Call> getCalls(Filter<Call> filter){
        List<Call> filteredList;
        if (filter != null) {
            filteredList = new LinkedList<Call>();
            for (Call m : _calls.values()) {
                if (filter.test(m)) {
                    filteredList.add(m);
                }
            }

        } else {
            filteredList = new LinkedList<Call>(_calls.values());
        }
        return filteredList;
    }

	/**
	 * Obtem o telemóvel com o número dado.
	 *
	 * @param number Número do telemóvel desejado.
	 *
	 * @return O telemóvel que tem o número especificado.
	 */
    public Mobile getMobile(int number) {
        return _mobiles.get(number);
    }

	/**
	 * Obtem a lista de todos os telemóveis.
	 *
	 * @return Lista com todos os telemóveis.
	 */ 
    public List<Mobile> getMobiles() {
        return getMobiles(null);
    }

	/**
	 * Obtem uma lista de telemóveis mediante um determinado filtro.
	 *
	 * @param filter O filtro a aplicar na lista de telemóveis.
	 *
	 * @return Uma lista de telemóveis filtrada mediante o filtro 
     *         especificado.
	 */
    public List<Mobile> getMobiles(Filter<Mobile> filter){
        List<Mobile> filteredList;
        if (filter != null) {
            filteredList = new LinkedList<Mobile>();
            for (Mobile m : _mobiles.values()) {
                if (filter.test(m)) {
                    filteredList.add(m);
                }
            }

        } else {
            filteredList = new LinkedList<Mobile>(_mobiles.values());
        }
        return filteredList;
    }

	/**
	 * Obtem lista de telemóveis com saldo positivo.
	 *
	 * @return Lista com os teleméveis com saldo positivo.
	 */ 
    public List<Mobile> getMobilesPositiveBalance() {
		return this.getMobiles(new Mobile.FilterPositiveBalance());
	} 

	/**
	 * Obtem clientes com dividas.
	 *
	 * @return Lista com os clientes com dividas ordenada por ordem
     *         decrescente de dívidas e crescente de identificador.
	 */
    public List<Client> getClientsWithDebt() {
        List<Client> badClients = getClients(new Client.FilterWithDebt());
        Collections.sort(badClients, new Client.ComparatorDebt());
        return badClients;
    }

	/**
	 * Obtem clientes sem dividas.
	 *
	 * @return Lista com os clientes sem dividas ordenada por ordem
	 * 		   lixocográfica.
	 */
    public List<Client> getClientsWithNoDebt() {
		List<Client> goodClients = getClients(new Client.FilterWithNoDebt());
		return goodClients;
	}

	/**
	 * Obtem telemóveis sem actividade.
	 *
	 * @return Lista com os telemóveis sem actividade.
	 */
	public List<Mobile> getMobilesNoActivity() {
		List<Mobile> noActivityMobiles = getMobiles(new Mobile.FilterNoActivity());
		return noActivityMobiles;
	}

	/**
	 * Processa o ficheiro dado como argumento.
     *
     * No final desta função, e se o ficheiro era válido,
     * a rede terá uma série de novas entidades correspondentes
     * às entidades especificadas no ficheiro.
	 *
	 * @param importFileName Nome do ficheiro a processar
	 */
    private void parseImportFile(String importFileName) {
        if (importFileName == null || importFileName.isEmpty()) {
            return;
        }

        BufferedReader importReader;

        try {
            importReader = new BufferedReader(new FileReader(importFileName));

            String line = importReader.readLine();
            while (line != null) {
                parseImportLine(line);
                line = importReader.readLine();
            }

            importReader.close();
        } 
        catch (FileNotFoundException e1) {
            IO.message("Não foi encontrado o ficheiro de import especificado ("
                       + importFileName + ".");
        }
        catch (IOException e2) {
            IO.message("Erro ao processar ficheiro de import.");
        }
    }

	/**
	 * Processa uma linha do ficheiro de importação.
	 *
	 * @param line Linha a processar.
	 */
    private void parseImportLine(String line) {
        if (line.isEmpty()) {
            return;
        }

        String parts[] = line.split("\\|");

        if (parts.length == 0) {
            return;
        }

        if (parts[0].equals("CLIENTE")) {
            try {
                String id = parts[1];
                String name = parts[2];
                int nif = Integer.parseInt(parts[3]);
                String type = parts[4];
                registerClient(id, name, nif, type);
            } catch (ClientExistsException e) {
                String errorMsg = "Erro ao processar ficheiro de import: ";
                errorMsg += e.toString();
                IO.message(errorMsg);
            }
        }
        else if (parts[0].equals("TELEMOVEL")) {
            try {
                int number = Integer.parseInt(parts[1]);
                Client owner = getClient(parts[2]);
                if (owner == null) {
                    return;
                }
                String type = parts[3];
                String state = parts[4];
                int balance = Integer.parseInt(parts[5]);
                registerMobile(owner, number, type, state, balance);
            } catch (MobileExistsException e) {
                String errorMsg = "Erro ao processar ficheiro de import: ";
                errorMsg += e.toString();
                IO.message(errorMsg);
            }
        }
        else if (parts[0].equals("AMIGO")) {
            int number = Integer.parseInt(parts[1]);
            Mobile m = getMobile(number);
            if (m == null) {
                return;
            }
            String[] friendNumbers = parts[2].split(",");

            for (String friendNumberStr : friendNumbers) {
                int friendNumber = Integer.parseInt(friendNumberStr);
                Mobile friendMobile = getMobile(friendNumber);
                m.addFriend(friendMobile);
            }
        }
    }

}
