package grt;

import java.io.*;

import grt.textui.lookup.Message;

/**
 * Classe abstracta que representa o estado não efectivo de uma
 * chamada e sem mensagem registada no destino.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class CallStateNoMessage extends CallState {
	/**
	 * Cria uma nova instância de CallStateNoMessage.
	 */
    CallStateNoMessage(Call call) {
        super(call);
    }

	/**
     * Obtem se a chamada foi efectiva ou não.
     *
     * @return false pois a chamada não foi efectiva.
     */
    boolean effective() { return false; };

	/**
     * Obtem se foi deixada mensagem ou não.
     *
     * @return false pois não foi deixada mensagem no destino.
     */
    boolean leftMessage() { return false; };

	/**
     * Termina a execução de uma chamada.
     *
     * Como a chamada não é efectiva, não efectua qualquer operação.
     *
     * @param duration Duração da chamada a terminar.
     */
    void end(long duration) {
    }

	/**
	 * Devolve uma string que descreve este estado de chamada.
     *
     * @return String com descrição deste estado.
	 */
    public String toString() {
        return Message.noMessage();
    }
}
