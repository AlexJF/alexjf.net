package grt;

import java.io.*;

import grt.exceptions.*;
import grt.textui.mobile.Message;

/**
 * Classe abstracta que representa o estado ligado de um telemóvel.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class MobileStateOn extends MobileState {
	/**
	 * Cria uma nova instância de MobileStateOn.
	 */
    MobileStateOn(Mobile mobile) {
        super(mobile);
    }

	/**
	 * Liga um telemóvel.
	 */
    void turnOn() {
    }

	/**
	 * Verifica se um telemóvel está ligado.
	 *
	 * @return true se o telemóvel está ligado e false caso contrário.
	 */
    boolean isOn() {
        return true;
    }

	/**
     * Verifica se um telemóvel está em silêncio.
     *
     * @return true se o telemóvel está em silêncio.
     */
    boolean isSilent() {
        return false;
    }

	/**
     * Trata uma chamada recebida pelo telemóvel.
	 *
	 * @param call Chamada a ser tratada.
	 */
    void handleCall(Call call) throws CallException {
        call.setEffective();
    }

	/**
	 * Devolve uma string que descreve este estado do telemóvel.
     *
     * @return String com descrição deste estado.
	 */
    public String toString() {
        return Message.mobileOn();
    }
}
