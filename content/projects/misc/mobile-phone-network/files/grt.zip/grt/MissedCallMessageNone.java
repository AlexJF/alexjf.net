package grt;

import grt.textui.cliente.Message;

/**
 * Implementa o comportamento de um clinte onde este não notifica
 * nenhum dos telemóveis que tentaram estabelecer contacto com um dos
 * telemóveis do cliente e falharam.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class MissedCallMessageNone implements MissedCallBehaviour {

	/**
	 * Ignora uma chamada, nao realizando nenhuma notificação 
     * posterior.
	 *
	 * @param call Chamada recebida
	 */
    public void handleCall(Call call) {
        call.setNoMessage();
    }

    public boolean notificationsActive() {
        return false;
    }

	/**
	 * Devolve uma string que descreve o comportamento.
	 *
	 * @return Devolve uma string que descreve o comportamento.
	 */
    public String toString() {
        return Message.atendedorInactivo();
    }
}
