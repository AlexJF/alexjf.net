package grt;

import java.io.*;

import grt.textui.lookup.Message;

/**
 * Classe abstracta que representa o estado não efective de uma
 * chamada mas com mensagem registada no destino.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class CallStateMessage extends CallState {
	/**
	 * Cria uma nova instância de CallStateMessage.
	 */
    CallStateMessage(Call call) {
        super(call);
    }

	/**
     * Obtem se a chamada foi efectiva ou não.
     *
     * @return false pois chamada não foi efectiva.
     */
    boolean effective() { return false; };

	/**
     * Obtem se foi deixada mensagem ou não.
     *
     * @return true pois foi deixada mensagem.
     */
    boolean leftMessage() { return true; };

	/**
     * Termina a execução de uma chamada.
     *
     * Como a chamada não é efectiva, não efectua qualquer operação.
     *
     * @param duration Duração da chamada a terminar.
     */
    void end(long duration) {
    }

	/**
	 * Devolve uma string que descreve este estado de chamada.
     *
     * @return String com descrição deste estado.
	 */
    public String toString() {
        return Message.message();
    }
}
