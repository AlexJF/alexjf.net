package grt;

import java.io.Serializable;

/**
 * Esta classe abstracta representa um tarifário genérico
 * da qual os outros tarifários irão herdar. 
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
abstract class Plan implements Serializable {
    /**
     * Verifica se o telemóvel chamado é amigo do chamador.
     *
     * Em caso afirmativo, aplica um desconto de 50% no preço 
     * base já calculado.
     *
     * @param call Chamada tratada.
     * @param basePrice Preço já calculado para a chamada.
     *
     * @return Inteiro com valor da chamada (cêntimos).
     */
    long checkFriend(Call call, long basePrice) {
        Mobile caller = call.getCaller();
        Mobile receiver = call.getReceiver();

        if (caller.hasFriend(receiver)) {
            basePrice /= 2;
        }

        return basePrice;
    }

	/**
	 * Obtém o custo de uma chamada de voz.
	 *
	 * @param call Chamada da qual pretendemos saber o custo.
	 *
	 * @return Inteiro com o valor da chamada (cêntimos).
	 */
    abstract long getCostVoice(Voice call);

	/**
	 * Obtém o custo de uma chamada de MMS.
	 *
	 * @param call Chamada da qual pretendemos saber o custo.
	 *
	 * @return Inteiro com o valor da chamada (cêntimos).
	 */
    abstract long getCostMMS(MMS call);

	/**
	 * Obtém o custo de uma chamada de SMS.
	 *
	 * @param call Chamada da qual pretendemos saber o custo.
	 *
	 * @return Inteiro com o valor da chamada (cêntimos).
	 */
    abstract long getCostSMS(SMS call);
}
