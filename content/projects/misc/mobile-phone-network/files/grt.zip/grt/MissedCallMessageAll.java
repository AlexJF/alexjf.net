package grt;

import grt.textui.cliente.Message;

/**
 * Implementa o comportamento de um cliente onde este notifica todos
 * os telemóveis cujas comunicações com um telemóvel do cliente
 * falharam.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class MissedCallMessageAll implements MissedCallBehaviour {
	/**
	 * Marca uma chamada para notificação posterior.
	 *
	 * @param call Chamada recebida
	 */
    public void handleCall(Call call) {
        if (call == null) {
            return;
        }

        Mobile receiver = call.getReceiver();
        receiver.addCallToNotifyList(call);

        call.setMessage();
    }

    public boolean notificationsActive() {
        return true;
    }


	/**
	 * Devolve uma string que descreve o comportamento.
	 *
	 * @return Devolve uma string que descreve o comportamento.
	 */
    public String toString() {
        return Message.atendedorActivo();
    }

}
