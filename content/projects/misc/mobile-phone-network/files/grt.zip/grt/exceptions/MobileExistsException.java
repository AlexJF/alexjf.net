package grt.exceptions;

import java.lang.Exception;

import grt.textui.mobile.Message;

/**
 * Esta excepção é enviada quando já existe na rede um telemóvel com o
 * número especificado.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public class MobileExistsException extends Exception {
	/** Número do telemóvel que gerou a excepção */
    private int _mobileNumber;

	/**
	 * Cria uma nova instância de MobileExistsException.
	 *
	 * @param number Número de telefone que gerou a excepção
	 */
    public MobileExistsException(int number) {
        _mobileNumber = number;
    }

	/**
	 * Devolve uma string com a mensagem de erro.
     *
     * @return String com mensagem de erro.
	 */
    public String toString() {
        return Message.duplicateMobile(_mobileNumber);
    }
}
