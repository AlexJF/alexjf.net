package grt.exceptions;

import java.lang.Exception;

import grt.textui.oneMobile.Message;

/**
 * Esta excepção é enviada quando um telemóvel 2G tenta enviar uma
 * MMS.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public class CallOrigin2GException extends CallException {
}
