package grt.exceptions;

import java.lang.Exception;

/**
 * Esta classe abstracte representa uma excepção genérica relacionada
 * com uma chamada.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public abstract class CallException extends Exception {
}
