package grt.exceptions;

import java.lang.Exception;

import grt.textui.oneMobile.Message;

/**
 * Esta excepção é enviada quando um telemóvel tenta efectuar
 * uma chamada de tipo desconhecido.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public class CallInvalidType extends CallException {
    private String _type;

    public CallInvalidType(String type) {
        _type = type;
    }

    public String toString() {
        return "Chamada de tipo inválido: " + _type;
    }
}
