package grt.exceptions;

import java.lang.Exception;

import grt.textui.oneMobile.Message;

/**
 * Esta excepção é enviada quando um telemóvel tenta enviar uma MMS 
 * para um telemóvel 2G.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public class CallDestination2GException extends CallException {
}
