package grt.exceptions;

import java.lang.Exception;

import grt.textui.oneMobile.Message;

/**
 * Esta excepção é enviada quando um telemóvel tenta realizar uma
 * chamada para um telemóvel em silêncio.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public class CallDestinationSilentException extends CallException {

	/**
	 * Devolve uma string com a mensagem de erro.
     *
     * @return String com mensagem de erro.
	 */
    public String toString() {
        return Message.mobileIsSilent();
    }
}
