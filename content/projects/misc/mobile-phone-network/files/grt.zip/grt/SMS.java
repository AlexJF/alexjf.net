package grt;

/**
 * Esta class representa uma chamada do tipo SMS.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class SMS extends Call {
	/**
	 * Cria uma nova instância de SMS.
	 *
     * @param network A rede à qual pertence este SMS.
	 * @param id Id da SMS.
	 * @param caller Telefone de onde provém a SMS.
	 * @param receiver Telefone para onde é enviada a SMS.
	 */
    SMS(Network network, int id, Mobile caller, Mobile receiver) {
        super(network, id, caller, receiver);
        _startOnSilence = true;
    }

	/**
	 * Devolve uma string com a informação da SMS.
	 *
	 * @return String com a informação da SMS.
	 */
    public String toString() {
		return super.toString(grt.textui.oneMobile.Message.textMessage());
	}
}
