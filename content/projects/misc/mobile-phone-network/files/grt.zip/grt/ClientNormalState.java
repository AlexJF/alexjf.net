package grt;

/**
 * Implementa o estado de cliente Normal.
 *
 * Este estado tem as seguintes transições:
 * - Normal p/ Ouro - Saldo após carregamento de telemóvel é superior
 *                    a 500 cêntimos.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class ClientNormalState extends ClientState {

	/**
	 * Cria uma nova instância de ClientNormalState.
	 */
    ClientNormalState() {
        super(new NormalPlan());
    }

	/**
	 * Devolve uma string que descreve este estado de cliente.
     *
     * @return String com descrição deste estado.
	 */
    public String toString() {
        return grt.textui.cliente.Message.clientNormal();
    }

	/**
	 * Verifica se após a execução de um pagamento o cliente deve ou
	 * não manter o seu estado.
     *
     * Se o saldo do cliente depois do carregamento for superior a 500
     * cêntimos, devemos passar para o estado Gold.
	 */
    void handlePayment() {
        if (getClient().getBalance() > 500) {
            getClient().setState(new ClientGoldState());
        }
    }

    /**
     * Tarifário associado a um cliente normal, onde são calculados os
     * preços de cada chamada.
     */
    static private class NormalPlan extends Plan {
        /**
         * Obtém o custo de uma chamada de voz.
         *
         * @param call Chamada da qual pretendemos saber o custo.
         *
         * @return Inteiro com o valor da chamada (cêntimos).
         */
        long getCostVoice(Voice call) {
            return checkFriend(call, 20*call.getDuration());
        }

        /**
         * Obtém o custo de uma chamada de MMS.
         *
         * @param call Chamada da qual pretendemos saber o custo.
         *
         * @return Inteiro com o valor da chamada (cêntimos).
         */
        long getCostMMS(MMS call) {
            return checkFriend(call, 30*call.getDuration());
        }

        /**
         * Obtém o custo de uma chamada de SMS.
         *
         * @param call Chamada da qual pretendemos saber o custo.
         *
         * @return Inteiro com o valor da chamada (cêntimos).
         */
        long getCostSMS(SMS call) {
            long smsLength = call.getDuration();

            if (smsLength < 50) {
                return 10;
            } 
            else if (smsLength < 100) {
                return 16;
            }
            else {
                return 2*smsLength;
            }
        }
    }
}
