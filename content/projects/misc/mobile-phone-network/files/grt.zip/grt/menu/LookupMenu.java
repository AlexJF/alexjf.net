package grt.menu;

import java.util.*;

import static pt.utl.ist.po.ui.UserInteraction.IO;

import grt.Network;
import grt.Client;
import grt.Mobile;
import grt.Call;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Menu;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputInteger;
import pt.utl.ist.po.ui.InputString;

import grt.textui.lookup.MenuEntry;
import grt.textui.lookup.Message;
import grt.textui.cliente.UnknownClientKeyException;

/**
 * Esta classe implementa o menu de consultas.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */ 
public class LookupMenu extends Menu {

	/**
	 * Cria uma nova instância de LookupMenu.
	 *
	 * @param n Rede na qual se vão efectuar as consultas.
	 */
    public LookupMenu(Network n) {
        super(MenuEntry.TITLE, new Command<?>[] {
        
        new Command<Network> (false, MenuEntry.ALL_CALLS, n) {
            public final void execute() {
              List<Call> calls = entity().getCalls();
              for(Call call : calls)
				IO.message(call.toString());
			}
        },
        
        new Command<Network> (false, MenuEntry.CALLS_FROM_CLIENT, n) {
            public final void execute() throws UnknownClientKeyException {
				Form f = new Form(title());
				InputString clientId = new InputString(f, grt.textui.cliente.Message.clientKeyReq());
				f.parse();
			
				Client client = entity().getClient(clientId.value());
				if (client == null) 
                    throw new UnknownClientKeyException(clientId.value());
				else {
                    Set<Call> orderedCalls = new TreeSet<Call>();
					List<Mobile> mobiles = client.getMobiles();

					for (Mobile mobile : mobiles) {
						List<Call> calls = mobile.getOutgoingCalls();
						for(Call call : calls){
                            orderedCalls.add(call);
						}
					}

                    for (Call call : orderedCalls) {
                        IO.message(call.toString());
                    }
				}
            }
        },
        
        new Command<Network> (false, MenuEntry.CALLS_TO_CLIENT, n) {
            public final void execute() throws UnknownClientKeyException {
              Form f = new Form(title());
				InputString clientId = new InputString(f, grt.textui.cliente.Message.clientKeyReq());
				f.parse();
			
				Client client = entity().getClient(clientId.value());
				if (client == null) 
                    throw new UnknownClientKeyException(clientId.value());
				else {
                    Set<Call> orderedCalls = new TreeSet<Call>();
					List<Mobile> mobiles = client.getMobiles();

					for (Mobile mobile : mobiles) {
						List<Call> calls = mobile.getIncomingCalls();
						for (Call call : calls) {
                            orderedCalls.add(call);
						}
					}

                    for (Call call : orderedCalls) {
                        IO.message(call.toString());
                    }
				}
            }
        },
        
        new Command<Network> (false, MenuEntry.CLIENTS_NO_DEBTS, n) {
            public final void execute() {
				List<Client> goodClients = entity().getClientsWithNoDebt();

				for(Client c : goodClients)
					IO.message(c.toString());
            }
        },
        
        new Command<Network> (false, MenuEntry.CLIENTS_WITH_DEBTS, n) {
            public final void execute() {
                List<Client> badClients = entity().getClientsWithDebt();

                for (Client c : badClients) {
                    IO.message(c.toString());
                }
            }
        },
        		    
        new Command<Network> (false,MenuEntry.MOBILE_NO_ACTIVITY, n) {
            public final void execute() {
				List<Mobile> mobiles = entity().getMobilesNoActivity();
				for(Mobile mobile : mobiles){
						IO.message(mobile.toString());
				}
            }
        },
        
        new Command<Network> (false,MenuEntry.MOBILE_POSITIVE_BALANCE, n) {
            public final void execute() {
                List<Mobile> goodMobiles = entity().getMobilesPositiveBalance();
                for (Mobile m : goodMobiles) {
                    IO.message(m.toString());
                }
            }
        },
        });
    }
}
