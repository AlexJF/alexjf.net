package grt.menu;

import static pt.utl.ist.po.ui.UserInteraction.IO;

import grt.Mobile;
import grt.Call;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Menu;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputInteger;
import pt.utl.ist.po.ui.InputString;

import grt.textui.oneMobile.MenuEntry;
import grt.textui.oneMobile.Message;
import grt.textui.oneMobile.MMSfrom2GException;
import grt.textui.oneMobile.MMSto2GException;
import grt.textui.mobile.UnknownKeyException;

import grt.exceptions.*;

/**
 * Esta classe implementa o menu gestão um telemóvel.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */ 
public class OneMobileMenu extends Menu {

	/**
	 * Cria uma nova instância de OneMobileMenu.
	 *
	 * @param m Telemovel que se pretende gerir.
	 */
    public OneMobileMenu(Mobile m) {
        super(MenuEntry.TITLE + m.getNumber(), new Command<?>[] {
        
        new Command<Mobile> (false,MenuEntry.POWER_ON, m) {
            public final void execute() {
				if (entity().isOn() && !entity().isSilent())
					IO.message(Message.alreadyOn());
				else
					entity().turnOn();
			}
        },
        
        new Command<Mobile> (false,MenuEntry.MUTE, m) {
            public final void execute() {
				if (entity().isSilent())
                    IO.message(Message.alreadySilent());
                else 
                    entity().turnSilent();
            }
        },
        
        new Command<Mobile> (false,MenuEntry.POWER_OFF, m) {
            public final void execute() {
                if(entity().isOff())
					IO.message(Message.alreadyOff());
				else
					entity().turnOff();
            }
        },
        
        new Command<Mobile> (false,MenuEntry.NEW_FRIEND, m) {
            public final void execute() throws UnknownKeyException {
				Form f = new Form(title());
				InputInteger friend = new InputInteger(f, grt.textui.mobile.Message.numeroReq());
				f.parse();
				
				Mobile mobile = entity().getNetwork().getMobile(friend.value());
				if (mobile == null)
					throw new UnknownKeyException(friend.value());
				else
					entity().addFriend(mobile);
            }
        },
        
        new Command<Mobile> (false,MenuEntry.OLD_FRIEND, m) {
            public final void execute() throws UnknownKeyException {
                Form f = new Form(title());
				InputInteger friend = new InputInteger(f, grt.textui.mobile.Message.numeroReq());
				f.parse();

				Mobile mobile = entity().getNetwork().getMobile(friend.value());
				if (mobile == null)
					throw new UnknownKeyException(friend.value());
				else
					entity().removeFriend(mobile);
            }
        },
        
        new Command<Mobile> (false,MenuEntry.PAYMENT, m) {
            public final void execute() {
				Form f = new Form(title());
				InputInteger value = new InputInteger(f, Message.paymentValue());
				f.parse();
				entity().addBalance(value.value());
            }
        },
        
        new Command<Mobile> (false,MenuEntry.SHOW_BALANCE, m) {
            public final void execute() {
				IO.message(new Long(entity().getBalance()).toString());
            }
        },
        
        new Command<Mobile> (false,MenuEntry.CONNECT, m) {
            public final void execute() throws UnknownKeyException,
                                               MMSfrom2GException,
                                               MMSto2GException {
				if(entity().isOff()) {
					IO.message(Message.thisMobileIsOff());
					return;
				}
				
				Form f = new Form(title());
				InputInteger receiver = new InputInteger(f, grt.textui.mobile.Message.numeroReq());
				f.parse();

				Mobile mobile = entity().getNetwork().getMobile(receiver.value());
				if (mobile == null){
					IO.message(Message.noMobile());
					return;
				}

				Form h = new Form(title());
				InputString callType = new InputString(h, Message.typeReq());
				h.parse();

				while (!(callType.value().equals(Message.voiceMessage()) ||
					    callType.value().equals(Message.textMessage()) ||
					    callType.value().equals(Message.videoMessage())))
						h.parse();

				try {
					Call call = entity().getNetwork().registerCall(entity(), mobile, callType.value());
                    if (call == null) {
                        IO.message("Erro desconhecido.");
                        return;
                    }
                    Form j = new Form(title());
                    InputInteger duration;
                    if (callType.value().equals(Message.textMessage())) {
                        duration =  new InputInteger(j, Message.charReq());
                    } else {
                        duration = new InputInteger(j, Message.timeReq());
                    }
                    j.parse();
                    call.end(duration.value());
                    IO.message(grt.textui.oneMobile.Message.costOfMessage(call.getCost()));
				} catch (CallOrigin2GException e) {
					throw new MMSfrom2GException(entity().getNumber());
				} catch (CallDestination2GException e) {
					throw new MMSto2GException(receiver.value());
				} catch (CallException e) {
                    IO.message(e.toString());
				}
			}
		},
        });
    }
}
