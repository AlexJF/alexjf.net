package grt.menu;

import java.util.*;

import grt.Network;
import grt.Client;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Menu;

import grt.textui.grt.MenuEntry;
import grt.textui.grt.Message;

import static pt.utl.ist.po.ui.UserInteraction.IO;

/**
 * Esta classe implementa o menu de gestão de redes de telemóveis.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */ 
public class GrtMenu extends Menu {

	/**
	 * Cria uma nova instância de GrtMenu.
	 *
	 * @param n Rede que pretendemos gerir.
	 */
    public GrtMenu(Network n) {
        super(MenuEntry.TITLE, new Command<?>[] {
        
        new Command<Network> (false, MenuEntry.CLIENTS, n) {
            public final void execute() {
              Menu m = new grt.menu.ClientMenu(entity());
              m.open();
            }
        },
        
        new Command<Network> (false, MenuEntry.MOBILES, n) {
            public final void execute() {
              Menu m = new grt.menu.MobileMenu(entity());
              m.open();
            }
        },
        
        new Command<Network> (false, MenuEntry.LOOKUPS, n) {
            public final void execute() {
              Menu m = new grt.menu.LookupMenu(entity());
              m.open();
            }
        },
        
        new Command<Network> (false, MenuEntry.SHOW_BALANCE, n) {
            public final void execute() {
				List<Client> clients = entity().getClients();
				Long somSaldo = new Long(0);
				
				for(Client client : clients)
					somSaldo += client.getBalance();
				
				IO.message(somSaldo.toString());
            }
        },
        
        });
    }
}
