package grt.menu;

import java.io.*;

import grt.Grt;
import grt.Network;

import static pt.utl.ist.po.ui.UserInteraction.IO;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Menu;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputBoolean;
import pt.utl.ist.po.ui.InputString;

import grt.textui.main.MenuEntry;
import grt.textui.main.Message;


/**
 * Esta classe implementa o menu principal.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */ 
public class MainMenu extends Menu {

	/**
	 * Cria uma nova instância de MainMenu.
	 *
	 * @param g Grt utilizado para gerir redes.
	 */ 
    public MainMenu(Grt g) {
        super(MenuEntry.TITLE, new Command<?>[] {
        
        new Command<Grt> (false, MenuEntry.NEW, g) {
            public final void execute() {
                if (entity().getCurrentNetwork().isDirty()) {
                    Form f = new Form("Deseja guardar?");
                    InputBoolean bool = new InputBoolean(f, Message.saveBeforeExit());
                    f.parse();

                    if (bool.value()) {
                        String fileName = entity().getCurrentNetworkFile();

                        if (fileName == null) {
                            f = new Form("Onde guardar?");
                            InputString path = new InputString(f, Message.newSaveAs());
                            f.parse();
                            fileName = path.value();
                        }

                        try {
                            entity().saveNetworkToFile(fileName);
                        } catch (FileNotFoundException e) {
                            IO.message(Message.fileNotFound(fileName));
                        } catch (IOException e) {
                            IO.message("Erro ao guardar a rede: " + e);
                        }
                    }
                }

                entity().manageNewNetwork();
            }
        },

  		new Command<Grt> (false, MenuEntry.OPEN, g) {
  			public final void execute() {
                if (entity().getCurrentNetwork().isDirty()) {
                    Form f = new Form("Deseja guardar?");
                    InputBoolean bool = new InputBoolean(f, Message.saveBeforeExit());
                    f.parse();

                    if (bool.value()) {
                        String fileName = entity().getCurrentNetworkFile();

                        if (fileName == null) {
                            f = new Form("Onde guardar?");
                            InputString path = new InputString(f, Message.newSaveAs());
                            f.parse();
                            fileName = path.value();
                        }

                        try {
                            entity().saveNetworkToFile(fileName);
                        } catch (FileNotFoundException e) {
                            IO.message(Message.fileNotFound(fileName));
                        } catch (IOException e) {
                            IO.message("Erro ao guardar a rede: " + e);
                        }
                    }
                }

                Form f = new Form(title());
                InputString path = new InputString(f, Message.openFile());
                f.parse();

                try {
                    entity().openNetworkFromFile(path.value());
                } catch (FileNotFoundException e) {
                    IO.message(Message.fileNotFound(path.value()));
                } catch (IOException e) {
                    IO.message("Erro de leitura desconhecido: " + e);
                } catch (ClassNotFoundException e) {
                    IO.message("Ficheiro inválido: " + e);
                }
            }
        },
        
        new Command<Grt> (false, MenuEntry.SAVE, g) {
  			public final void execute() {
                if (!entity().getCurrentNetwork().isDirty()) {
                    return;
                }

                String fileName = entity().getCurrentNetworkFile();

                if (fileName == null) {
                    Form f = new Form("Onde guardar?");
                    InputString path = new InputString(f, Message.newSaveAs());
                    f.parse();
                    fileName = path.value();
                }

                try {
                    entity().saveNetworkToFile(fileName);
                } catch (FileNotFoundException e) {
                    IO.message(Message.fileNotFound(fileName));
                } catch (IOException e) {
                    IO.message("Erro ao guardar a rede: " + e);
                }
            }
        },
        
        new Command<Grt> (false, MenuEntry.SAVE_AS, g) {
  			public final void execute() {
                String fileName = null;

                Form f = new Form("Onde guardar?");
                InputString path = new InputString(f, Message.saveAs());
                f.parse();
                fileName = path.value();

                try {
                    entity().saveNetworkToFile(fileName);
                } catch (FileNotFoundException e) {
                    IO.message(Message.fileNotFound(fileName));
                } catch (IOException e) {
                    IO.message("Erro ao guardar a rede: " + e);
                }
            }
        },
        
        new Command<Grt> (false, MenuEntry.OPERATION, g) {
  			public final void execute() {
                Network currentNetwork = entity().getCurrentNetwork();
                Menu m = new grt.menu.GrtMenu(currentNetwork);
                m.open();
            }
        },
      });
    }
}
