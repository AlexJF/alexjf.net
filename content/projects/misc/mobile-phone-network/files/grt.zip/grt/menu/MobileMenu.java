package grt.menu;

import java.util.List;

import grt.Network;
import grt.Mobile;

import static pt.utl.ist.po.ui.UserInteraction.IO;

import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Menu;
import pt.utl.ist.po.ui.Form;
import pt.utl.ist.po.ui.InputInteger;
import pt.utl.ist.po.ui.InputString;

import grt.textui.mobile.MenuEntry;
import grt.textui.mobile.Message;
import grt.textui.mobile.UnknownKeyException;
import grt.textui.cliente.UnknownClientKeyException;

/**
 * Esta classe implementa o menu gestão de telemóveis da rede.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */ 
public class MobileMenu extends Menu {
	/**
	 * Cria uma nova instância de MobileMenu.
	 *
	 * @param n Rede à qual pertencem os telemóveis a gerir.
	 */ 
    public MobileMenu(Network n) {
        super(MenuEntry.TITLE, new Command<?>[] {
        
        new Command<Network> (false, MenuEntry.SHOW_ALL, n) {
            public final void execute() {
                List<Mobile> allMobiles = entity().getMobiles();

                for (Mobile mobile : allMobiles) {
                    IO.message(mobile.toString());
                }
            }
        },
        
        new Command<Network> (false, MenuEntry.REGISTER, n) {
            public final void execute() throws UnknownClientKeyException {
				Form f = new Form(title());

				InputInteger mobileNum = new InputInteger(f, Message.numeroReq());
				f.parse();

				while((String.valueOf(mobileNum.value())).length() != 6){
					f.parse();
				}

                if (entity().getMobile(mobileNum.value()) != null) {
                    IO.message(Message.duplicateMobile(mobileNum.value()));
                    return;
                }

				Form h = new Form(title());
				InputString mobileType = new InputString(h, Message.typeReq());
				h.parse();

				while(!mobileType.value().equals(Message.mobile2G()) &&
				      !mobileType.value().equals(Message.mobile3G())){
				      h.parse();
			    }

			    Form j = new Form(title());
				InputString clientId = new InputString(j, grt.textui.cliente.Message.clientKeyReq());
				j.parse();
				
				if(entity().getClient(clientId.value()) == null)
					throw new UnknownClientKeyException(clientId.value());
				else {
					try {
					entity().registerMobile(entity().getClient(clientId.value()),
                                            mobileNum.value(),
											mobileType.value());
					} catch (grt.exceptions.MobileExistsException e) {
						IO.message(Message.duplicateMobile(mobileNum.value()));
					}
				}	
			}
		},
        
        new Command<Network> (false, MenuEntry.MANAGE_ONE_MOBILE, n) {
            public final void execute() throws UnknownKeyException {
                Form f = new Form(title());
                InputInteger number = new InputInteger(f, Message.numeroReq());
                f.parse();
                Mobile mobile = entity().getMobile(number.value());

                if (mobile == null)
                    throw new UnknownKeyException(number.value());
                else {
                    Menu m = new OneMobileMenu(mobile);
                    m.open();
                }
            }
        },
        });
    }
}
