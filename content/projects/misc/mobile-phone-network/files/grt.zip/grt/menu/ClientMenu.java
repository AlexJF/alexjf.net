package grt.menu;

import java.util.List;

import static pt.utl.ist.po.ui.UserInteraction.IO;

import grt.Network;
import grt.Client;
import grt.Mobile;
import grt.exceptions.ClientExistsException;

import pt.utl.ist.po.ui.*;
import pt.utl.ist.po.ui.Command;
import pt.utl.ist.po.ui.Menu;
import pt.utl.ist.po.ui.Form;

import grt.textui.cliente.MenuEntry;
import grt.textui.cliente.Message;
import grt.textui.cliente.UnknownClientKeyException;

/**
 * Esta classe implementa o menu de gestão de clientes.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */ 
public class ClientMenu extends Menu {

	/**
	 * Cria uma nova instância de ClientMenu.
	 *
	 * @param n Rede à qual pertencem os clientes que queremos gerir.
	 */
    public ClientMenu(Network n) {
        super(MenuEntry.TITLE, new Command<?>[] {
        
        new Command<Network> (false, MenuEntry.SHOW_ALL, n)  {
            public final void execute() {
                List<Client> allClients = entity().getClients();
                
                for (Client client : allClients) {
                    IO.message(client.toString());
                }
            }
        },
        
        new Command<Network> (false, MenuEntry.REGISTER, n){
            public final void execute(){
				Form f = new Form(title());
				InputString clientId = new InputString(f, Message.clientKeyReq());
				f.parse();
				if (entity().getClient(clientId.value()) == null){
					Form h = new Form(title());
					InputString clientName = new InputString(h, Message.clientNameReq());
					InputInteger clientNif = new InputInteger(h, Message.clientNifReq());
					h.parse();
					try {
						entity().registerClient(clientId.value(), 
                                                clientName.value(), 
                                                clientNif.value()); 
					} catch(grt.exceptions.ClientExistsException e) {
						e.toString();
					}
				} else {
					IO.message(Message.duplicateClient(clientId.value()));
				}
            }
        },
        
        new Command<Network> (false,MenuEntry.ENABLE, n) {
            public final void execute() throws UnknownClientKeyException {

				Form f = new Form(title());
				InputString clientId = new InputString(f, Message.clientKeyReq());
				f.parse();
				if (entity().getClient(clientId.value()) == null)
					throw new UnknownClientKeyException(clientId.value());
				else
					if(!entity().getClient(clientId.value()).activateNotifications())
						IO.message(Message.alreadyMessageActive());
            }
        },
        
        new Command<Network> (false,MenuEntry.DISABLE, n) {
            public final void execute() throws UnknownClientKeyException{
				Form f = new Form(title());
				InputString clientId = new InputString(f, Message.clientKeyReq());
				f.parse();
				if (entity().getClient(clientId.value()) == null)
					throw new UnknownClientKeyException(clientId.value());
				else
					if (!entity().getClient(clientId.value()).disableNotifications())
						IO.message(Message.alreadyMessageInactive());
			}
        },
        
        new Command<Network> (false,MenuEntry.SHOW_BALANCE, n) {
            public final void execute() throws UnknownClientKeyException {
				Form f = new Form(title());
				InputString clientId = new InputString(f, Message.clientKeyReq());
				f.parse();
					
				Client cliente = entity().getClient(clientId.value());
				if (cliente == null) {
					throw new UnknownClientKeyException(clientId.value());
				}else{
					IO.message(new Long(cliente.getBalance()).toString());
				}
            }
        },
        });
    }
}
