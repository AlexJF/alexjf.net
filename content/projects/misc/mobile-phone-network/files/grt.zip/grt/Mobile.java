package grt;

import java.util.*;
import java.lang.*;
import java.io.Serializable;

import static pt.utl.ist.po.ui.UserInteraction.IO;

import grt.exceptions.*;
import grt.textui.mobile.Message;

/**
 * Esta classe representa um telemóvel.
 *
 * Um telemóvel contém:
 * - Número
 * - Saldo
 * - Dono
 * - Estado
 * - Telemóveis Amigos
 * - Lista de chamadas efectuadas/recebidas/falhadas.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public abstract class Mobile implements Comparable, Serializable {
    /** Rede onde está registado o telemóvel. */
    private Network _network;
	/** Numero do telemóvel */
	private int _number;
	/** Saldo do telemóvel */
	private long _balance;

	/** Dono do telemóvel */
	private Client _owner;
	/** Estado do telemóvel */
	private MobileState _state;

	/** Conjunto dos telemóveis amigos */
	private Set<Mobile> _mobileFriends;
	/** Conjunto das chamadas realizadas */
	private Set<Call> _outgoingCalls;
	/** Conjunto das chamadas recebidas */
	private Set<Call> _incomingCalls;
    /** 
     * Conjunto das chamadas que o telemóvel não atendeu por
     * estar indisponível.
     *
     * Os callers destas chamadas devem ser notificados na altura
     * apropriada.
     */
    private Set<Call> _mustNotifyCalls;

	/**
	 * Cria uma nova instância de Mobile.
	 *
     * @param network Rede a que pertence o telemóvel.
	 * @param owner Dono do telemóvel
	 * @param number Número do telemóvel
	 * @param state Estado do telemóvel
	 * @param balance Saldo do telemóvel
	 */
    Mobile(Network network, Client owner, int number, String state, long balance) {
        _network = network;
        _network.setDirty(true);
        _number = number;
        _balance = balance;
        _owner = owner;
        _mobileFriends = new TreeSet<Mobile>();
        _outgoingCalls = new TreeSet<Call>();
        _incomingCalls = new TreeSet<Call>();
        _mustNotifyCalls = new TreeSet<Call>(new Call.ComparatorCaller());
        owner.addMobile(this);

        if (state.equals(Message.mobileOff())) {
            _state = new MobileStateOff(this);
        } 
        else if (state.equals(Message.mobileSilence())) {
            _state = new MobileStateSilent(this);
        }
        else {
            _state = new MobileStateOn(this);
        }
    }

    /**
     * Devolve a rede associada ao Cliente.
     *
     * @return Rede associada ao Cliente.
     */
    public Network getNetwork() {
        return _network;
    }
	
	/**
	 * Retorna o número do telemóvel.
	 *
	 * @return Numero do telemóvel.
	 */
	public int getNumber(){
		return _number;
	}
	
	/**
	 * Retorna o saldo do telemóvel.
	 *
	 * @return Saldo do telemóvel.
	 */
	public long getBalance(){
		return _balance;
	}
	
	/**
	 * Retorna o dono do telemóvel.
	 *
	 * @return Dono do telemóvel.
	 */
	public Client getOwner(){
		return _owner;
	}

	/**
	 * Liga o telemóvel.
	 */
	public void turnOn() {
        _network.setDirty(true);
        _state.turnOn();
	}

	/**
	 * Desliga o telemóvel.
	 */
	public void turnOff() {
        _network.setDirty(true);
        _state.turnOff();
	}

	/**
	 * Silencia o telemóvel.
	 */
	public void turnSilent() {
        _network.setDirty(true);
        _state.turnSilent();
	}

   /**
	 * Devolve a lista de chamadas efectudas.
	 *
	 * @return Lista de chamadas efectuadas.
	 */
	public List<Call> getOutgoingCalls() {
		return new LinkedList<Call>(_outgoingCalls);
	}

	/**
	 * Devolve a lista de chamadas recebidas.
	 *
	 * @return Lista de chamadas recebidas.
	 */
	public List<Call> getIncomingCalls() {
		return new LinkedList<Call>(_incomingCalls);
	} 

	/**
	 * Verifica se o telemóvel está ligado.
	 *
	 * @return true se o telemóvel se encontra ligado e false
	 * 		   caso contrário
	 */
    public boolean isOn() {
        return _state.isOn();
    }

	/**
	 * Verifica se o telemóvel está desligado.
	 *
	 * @return true se o telemóvel se encontra desligado e false
	 * 		   caso contrário
	 */
    public boolean isOff() {
        return _state.isOff();
    }

	/**
	 * Verifica se o telemóvel está em silêncio.
	 *
	 * @return Devolve true se o telemóvel se encontra em silêncio e 
     *         false caso contrário.
	 */
    public boolean isSilent() {
        return _state.isSilent();
    }

	/**
	 * Carrega o telemóvel.
	 *
	 * @param value Valor com o qual carregar o telemóvel.
	 */
    public void addBalance(long value) {
        _network.setDirty(true);
		_balance += value;
        _owner.handlePayment();
	}

	/**
	 * Adiciona um telemóvel ao conjunto de amigos do telemóvel
     *
     * @param m Telemóvel a adicionar ao conjunto de amigos.
	 */
    public void addFriend(Mobile m) {
        if (m == null) {
            return;
        }
        _network.setDirty(true);
        _mobileFriends.add(m);
    }

	/**
	 * Verifica se um telemóvel é amigo ou não.
	 *
	 * @param m Telemóvel a verificar.
	 *
	 * @return true se o telemóvel indicado é amigo e false caso contrário.
	 */
    public boolean hasFriend(Mobile m) {
        if (m == null) {
            return false;
        }
        return _mobileFriends.contains(m);
    }

	/**
	 * Remove um telemóvel da lista de amigos.
	 *
	 * @param m Telemóvel a remover.
	 */
    public void removeFriend(Mobile m) {
		if(m == null) {
			return;
		}
        _network.setDirty(true);
		_mobileFriends.remove(m);
	}

	/**
	 * Altera o estado do telemóvel.
	 *
	 * @param state Novo estado do telemóvel.
	 */
    void setState(MobileState state) {
        _state = state;
    }

	/**
	 * Notifica todos os telemóveis que tentaram ligar enquanto o telemóvel
	 * estava desligado/silêncio impossibilitando assim a concretização da
     * chamada.
	 */
    void notifyOn() {
        Mobile lastCaller = null;
        Mobile currentCaller = null;

        for (Call call : _mustNotifyCalls) {
            currentCaller = call.getCaller();

            if (currentCaller == lastCaller) {
                continue;
            }

            IO.message(
                grt.textui.oneMobile.Message.isAvailable(
                    _number, 
                    currentCaller.getNumber()));

            lastCaller = currentCaller;
        }

        _mustNotifyCalls.clear();
    }

	/**
     * Notifica todos os telemóveis que tentaram ligar enquanto o telemóvel
     * estava desligado e cujo o tipo de chamada pode ser efectuada em
     * silêncio.
	 */
    void notifySilent() {
        Mobile lastCaller = null;
        Mobile currentCaller = null;
        Set<Call> newMustNotifyCalls = new TreeSet<Call>(new Call.ComparatorCaller());

        for (Call call : _mustNotifyCalls) {
            currentCaller = call.getCaller();

            if (currentCaller == lastCaller) {
                continue;
            }

            if (call.canStartOnSilence()) {
                IO.message(
                    grt.textui.oneMobile.Message.isAvailableForSMS(
                        _number, 
                        currentCaller.getNumber()));
            } else {
                newMustNotifyCalls.add(call);
                lastCaller = currentCaller;
            }
        }

        _mustNotifyCalls = newMustNotifyCalls;
    }

    /**
     * Regista uma chamada efectuada a partir deste telemóvel.
     *
     * @param call Chamada efectuada.
     */
    void startCall(Call call) {
        if (call != null) {
            _outgoingCalls.add(call);
        }
    }

	/**
	 * Recebe uma chamada.
	 *
	 * @param call Chamada recebida.
	 */
    void receiveCall(Call call) throws CallException {
        if (call != null) {
            _incomingCalls.add(call);
            _state.handleCall(call);
        }
    }

    /**
     * Permite adicionar uma chamada à lista de chamadas cujos
     * telemóveis de destino temos de notificar.
     *
     * @param call A chamada que pretendemos adicionar à lista.
     */
    void addCallToNotifyList(Call call) {
        if (call == null) {
            return;
        }
        _mustNotifyCalls.add(call);
    }


	/**
	 * Devolve uma string que descreve esta instância de Mobile.
     *
	 * Esta função é para ser usada pelas classes que herdam Mobile
     * e que conhecem o tipo de telemóvel em questão.
	 *
	 * @param type Tipo do telemóvel
     *
     * @return String que descreve esta instância de Mobile.
	 */
    protected String toString(String type) {
        boolean first = true;
        String descr = "TELEMOVEL|" + _number + "|" + _owner.getId()
                       + "|" + type + "|" + _state + "|" + _balance + "|";

        for (Mobile m : _mobileFriends) {
            if (!first) {
                descr += ",";
            }
            descr += Integer.toString(m.getNumber());
            first = false;
        }

        return descr;
    }


	/**
	 * Devolve uma string que descreve esta instância de Mobile.
     *
     * Classes que herdem de Mobile devem implementar esta função
     * utilizando a versão que aceita como argumento o tipo de 
     * telemóvel.
     *
     * @return String que descreve esta instância de Mobile.
	 */
    abstract public String toString();

	/**
	 * Compara a instância de mobile com um outro mobile.
     *
     * A ordem entre telemóveis é ditada pela ordenação
     * numérica dos seus números.
	 *
	 * @param mobile Mobile com o qual comparar.
	 *
	 * @return 1 se este mobile é maior que o segundo, 0 caso sejam
     *         iguais e -1 caso este seja menor que o segundo.
	 */
    public int compareTo(Object mobile) {
        if (!(mobile instanceof Mobile)) {
            throw new ClassCastException("A mobile object expected.");
        }

        Integer number = new Integer(_number);

        return number.compareTo(((Mobile) mobile).getNumber());
    }

    /**
     * Este filtro permite seleccionar telemóveis com saldo
     * positivo de entre um conjunto de telemóveis.
     */
    public static class FilterPositiveBalance implements Filter<Mobile> {
        /**
         * Testa um telemóvel verificando o seu saldo.
         *
         * @param m Telemóvel a testar.
         *
         * @return 1 se telemóvel tem saldo positivo, 0 caso
         *         contrário.
         */
        public boolean test(Mobile m) {
            return m.getBalance() > 0;
        }
    }


	/**
	 * Este filtro permite seleccionar telemóveis que não tiveram
	 * actividade de entre um conjunto de telemóveis.
	 */
    public static class FilterNoActivity implements Filter<Mobile> {
        /**
         * Testa se um telemóvel teve ou não actividade.
         *
         * @param m Telemóvel a testar.
         *
         * @return 1 se telemóvel não teve actividade, 0 caso
         *         contrário.
         */
		public boolean test(Mobile mobile){
			return (mobile.getIncomingCalls().size() == 0 && 
                    mobile.getOutgoingCalls().size() == 0);
		}
	}

}
