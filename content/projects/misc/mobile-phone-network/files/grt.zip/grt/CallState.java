package grt;

import java.io.*;

/**
 * Classe abstracta que representa um estado de uma chamada.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
abstract class CallState implements Serializable {
	/** Chamada associada a esta instancia do estado */
    private Call _call;

	/**
	 * Cria uma nova instância de CallState.
	 */
    CallState(Call call) {
        _call = call;
    }

	/**
	 * Obtem o objecto Call associado a esta instância de estado.
	 *
	 * @return Objecto Call associado a esta instância de estado.
	 */
    Call getCall() {
        return _call;
    }

    /**
     * Obtem se a chamada foi efectiva ou não.
     *
     * @return true se a chamada foi efectiva, false caso contrário.
     */
    abstract boolean effective();

    /**
     * Obtem se foi deixada mensagem ou não.
     *
     * @return true se foi deixada mensagem, false caso contrário.
     */
    abstract boolean leftMessage();

    /**
     * Termina a execução de uma chamada.
     *
     * @param duration Duração da chamada a terminar.
     */
    abstract void end(long duration);


	/**
	 * Devolve uma string que descreve este estado de chamada.
     *
     * @return String com descrição deste estado.
	 */
    public abstract String toString();
}
