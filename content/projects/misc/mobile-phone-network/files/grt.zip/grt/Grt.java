package grt;

import java.io.*;

import grt.menu.*;
import pt.utl.ist.po.ui.Menu;

/**
 * Esta classe implementa um gestor de redes de telemoveis.
 *
 * É por aqui que se deve iniciar a execução do programa.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public class Grt {
	/** Rede actualmente gerida por este gestor */
    private Network _currentNetwork;
    /** Ficheiro de onde foi lida a network aberta */
    private String _curNetFileName;

	
    /**
     * Função main.
     *
     * A execução do projecto irá principiar nesta função.
     *
     * @param args Argumentos passados ao programa.
     */
    static public void main(String[] args) {
        Grt grt = new Grt();

        Menu mainMenu = new MainMenu(grt);
        mainMenu.open();
    }

	/**
	 * Cria uma instância de um objecto Grt.
     *
	 * Cria uma nova rede para gerir, tentando interpretar um
     * ficheiro de import se tal existir.
	 */
    public Grt() {
        _currentNetwork = new Network(System.getProperty("Import"));
        _curNetFileName = null;
    }

    /**
     * Faz com que o grt gira uma nova rede vazia.
     */
    public void manageNewNetwork() {
        _currentNetwork = new Network();
        _curNetFileName = null;
    }

	/**
	 * Devolve a rede que está actualmente a ser gerida pelo Grt.
     *
     * @return Rede actualmente gerida pelo Grt.
     */
    public Network getCurrentNetwork() {
        return _currentNetwork;
    }

	/**
	 * Devolve o nome do ficheiro onde estava a rede actualmente 
     * gerida pelo Grt.
	 *
	 * @return Nome do ficherio onde estava a rede actualmente gerida 
     *         pelo Grt. 
	 */
    public String getCurrentNetworkFile() {
        return _curNetFileName;
    }

	/**
	 * Dado o nome de um ficheiro abre a rede nele contida.
     *
     * Essa rede passará a ser a nova rede actual.
	 *
	 * @param fileName Nome do ficheiro de origem
     *
     * @throws FileNotFoundException O ficheiro não foi encontrado.
     * @throws IOException Erro ao ler o ficheiro.
     * @throws ClassNotFoundException Classe lida não pertence ao 
     *                                projecto.
	 */
    public void openNetworkFromFile(String fileName)
                                throws FileNotFoundException,
                                       IOException,
                                       ClassNotFoundException {
        if (fileName == null) {
            throw new FileNotFoundException();
        }
        FileInputStream inputStream = null;
        ObjectInputStream objInputStream = null;
        try {
            inputStream = new FileInputStream(fileName);
            objInputStream = new ObjectInputStream(inputStream);
            _currentNetwork = (Network) objInputStream.readObject();
            _currentNetwork.setDirty(false);
            _curNetFileName = fileName;
        } finally {
            if (objInputStream != null) {
                objInputStream.close();
            }
            else if (inputStream != null) {
                inputStream.close();
            }
        }
    }

	/**
	 * Guarda a rede actual num ficheiro.
     *
     * Tal permite que mais tarde esta possa ser carregada
     * chamando a função openNetworkFromFile.
	 *
	 * @param fileName Nome do ficheiro de destino
     *
     * @throws FileNotFoundException Erro ao abrir ficheiro para 
     *                               escrita.
     * @throws IOException Erro ao escrever no ficheiro.
	 */
    public void saveNetworkToFile(String fileName)
                                throws FileNotFoundException,
                                       IOException {
        if (fileName == null) {
            throw new FileNotFoundException();
        }
        FileOutputStream outputStream = null;
        ObjectOutputStream objOutputStream = null;
        try {
            outputStream = new FileOutputStream(fileName);
            objOutputStream = new ObjectOutputStream(outputStream);
            objOutputStream.writeObject(_currentNetwork);
            _curNetFileName = fileName;
            _currentNetwork.setDirty(false);
        } finally {
            if (objOutputStream != null) {
                objOutputStream.close();
            }
            else if (outputStream != null) {
                outputStream.close();
            }
        }
    }

}
