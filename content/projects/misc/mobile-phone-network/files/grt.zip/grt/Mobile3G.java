package grt;

/**
 * Esta classe implementa um telemóvel 3G.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class Mobile3G extends Mobile {

	/**
	 * Construtor da classe
	 *
     * @param network A rede à qual pertence este mobile3G.
	 * @param owner Dono do telemóvel
	 * @param number Numero do telemóvel
	 * @param state Estado do telemóvel
	 * @param balance Saldo do telemóvel
	 */
    Mobile3G(Network network, Client owner, int number, String state, int balance) {
        super(network, owner, number, state, balance);
    }

	/**
	 * Devolve uma string que descreve esta instância de Mobile3G.
     *
     * @return String que descreve esta instância de Mobile3G.
	 */
    public String toString() {
        return super.toString(grt.textui.mobile.Message.mobile3G());
    }
}
