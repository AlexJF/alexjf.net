package grt;

import java.io.*;

import grt.textui.lookup.Message;

/**
 * Classe abstracta que representa o estado efectivo de uma chamada.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
class CallStateEffective extends CallState {
	/**
	 * Cria uma nova instância de CallStateEffective.
	 */
    CallStateEffective(Call call) {
        super(call);
    }

	/**
     * Obtem se a chamada foi efectiva ou não.
     *
     * @return true pois a chamada foi efectiva.
     */
    boolean effective() { return true; };

    /**
     * Obtem se foi deixada mensagem ou não.
     *
     * @return false pois não foi deixada mensagem no destino.
     */
    boolean leftMessage() { return false; };

	/**
     * Termina a execução de uma chamada.
     *
     * @param duration Duração da chamada a terminar.
     */
    void end(long duration) {
        Call call = getCall();
        call.setDuration(duration);
        call.setCost(call.getCaller().getOwner().handleCall(call));
        call.getCaller().addBalance(-call.getCost());
    }

	/**
	 * Devolve uma string que descreve este estado de chamada.
     *
     * @return String com descrição deste estado.
	 */
    public String toString() {
        return Message.done();
    }
}
