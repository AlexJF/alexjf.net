package grt;

import java.io.*;

/**
 * Classe abstracte que representa um estado de um cliente.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
abstract class ClientState implements Serializable {
	/** Cliente associado a esta instancia do estado */
    private Client _client;
	/** Plano associado a esta instancia do estado*/
    private Plan _plan;

	/**
	 * Cria uma nova instância de ClientState.
	 *
	 * @param plan Plano associado ao estado.
	 */
    ClientState(Plan plan) {
        _client = null;
        _plan = plan;
    }

	/**
	 * Obtem o objecto Plan associado a este tipo de cliente.
	 *
	 * @return Objecto Plan associado a este tipo de cliente.
	 */
    Plan getPlan() {
        return _plan;
    }

	/**
	 * Obtem o objecto Client associado a esta instância de estado.
	 *
	 * @return Objecto Client associado a esta instância de estado.
	 */
    Client getClient() {
        return _client;
    }

	/**
	 * Altera o cliente que está associado a esta instância de estado.
	 *
	 * @param client Client ao qual associar este estado.
	 */
    void setClient(Client client) {
        _client = client;
    }

	/**
	 * Verifica se mediante um pagamento o estado do cliente deve ou
	 * não ser alterado.
     *
     *  Por omissão não efectua qualquer acção.
	 */
    void handlePayment() {
    }

	/**
	 * Verifica se mediante uma chamada o estado do cliente deve ou
	 * não ser alterado.
     *
     * @param call Chamada efectuada pelo cliente.
     *
     * @return Custo da chamada de acordo com tarifário do cliente.
	 */
    long handleCall(Call call) {
        if (_plan == null || call == null) {
            return 0;
        }

        long price = 0;
        if (call instanceof Voice) {
            Voice voiceCall = (Voice) call;
            handleVoice(voiceCall);
            price = _plan.getCostVoice(voiceCall);
        } 
        else if (call instanceof SMS) {
            SMS smsCall = (SMS) call;
            handleSMS(smsCall);
            price = _plan.getCostSMS(smsCall);
        }
        else if (call instanceof MMS) {
            MMS mmsCall = (MMS) call;
            handleMMS(mmsCall);
            price = _plan.getCostMMS(mmsCall);
        }
        return price;
    }

	/**
	 * Verifica se mediante uma chamada de voz o estado do cliente deve
	 *  ou não ser alterado.
     *
     *  Por omissão não efectua qualquer acção.
     *
     *  @param call Chamada efectuada pelo cliente.
	 */
    void handleVoice(Voice call) {
    }

	/**
	 * Verifica se mediante uma MMS o estado do cliente deve ou
	 * não ser alterado.
     *
     * Por omissão não efectua qualquer acção.
     *
     * @param call Chamada efectuada pelo cliente.
	 */
    void handleMMS(MMS call) {
    }

	/**
	 * Verifica se mediante uma SMS o estado do cliente deve ou
	 * não ser alterado.
     *
     * Por omissão não efectua qualquer acção.
     *
     * @param call Chamada efectuada pelo cliente.
	 */
    void handleSMS(SMS call) {
    }

	/**
	 * Verifica se mediante o envio de uma MMS para o telemovel 2G o
	 * estado do cliente deve ou não ser alterado.
     *
     * Por omissão não efectua qualquer acção.
	 */
    void handleMMSTo2G() {
    }

	/**
	 * Devolve uma string que descreve este estado de cliente.
     *
     * @return String com descrição deste estado.
	 */
    public abstract String toString();
}
