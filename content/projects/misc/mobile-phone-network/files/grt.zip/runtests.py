#! /usr/bin/env python2
# -*- coding: utf-8 -*-

## @file runtests.py
#  @version 1.0
#  @date 2010
#  @author Revolt
#  Executa todos os testes encontrados na pasta onde o script é corrido

import os, sys, glob, subprocess, time

path = os.path

curDir = os.getcwd()
testDir = curDir + "/testes-final/";

dirContents = os.listdir(testDir)
dirContents.sort()

for obj in dirContents:
    objRoot = path.join(testDir, obj)

    if path.isfile(objRoot):
        fileName, fileExt = path.splitext(obj)
        fileRootNoExt = path.join(testDir, fileName)
        importFile = ""
        if path.isfile(fileRootNoExt + ".import"):
            importFile = fileRootNoExt + ".import"
        if fileExt == ".in":
            if path.isfile(fileRootNoExt + ".out"):
                startTime = time.time();
                testProcess = subprocess.Popen('java -DImport="' + importFile + '" -Din="' + fileRootNoExt + '.in" -Dout=out.dat grt.Grt' , shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdoutdata, stderrdata = testProcess.communicate()
                #if stderrdata != "":
                    #print "Error while executing test: " + stderrdata
                    #continue;
                duration = time.time() - startTime;
                compProcess = subprocess.Popen('diff -b out.dat "' + fileRootNoExt + '.out"', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE);
                stdoutdata, stderrdata = compProcess.communicate()

                text = "Test '" + fileName + "' "

                if stdoutdata == "" and stderrdata == "":
                    print text + "Successful"
                elif stderrdata == "":
                    print text + "Failed:\n" + stdoutdata + "\n"
                else:
                    print text + "Failed:\n" + stderrdata + "\n"

                print " (%.6f)" % duration


outFile = path.join(curDir, "out.dat")
if path.isfile(outFile):
    os.unlink(outFile)



