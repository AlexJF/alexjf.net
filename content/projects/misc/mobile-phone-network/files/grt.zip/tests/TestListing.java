package tests;

import junit.framework.TestCase;
import junit.textui.TestRunner;
import java.util.*;
import grt.*;
import grt.textui.mobile.Message;
import grt.exceptions.MobileExistsException;
import grt.exceptions.ClientExistsException;

/**
 * Esta classe tem como objectivo efectuar uma bateria de testes
 * relacionados com as várias consultas que podem ser efectuadas sobre
 * os elementos de uma rede.
 *
 * @author Alexandre Fonseca - 68114
 * @author Pedro Luz - 68178
 */
public class TestListing extends TestCase {

    /** Grt utilizado durante os testes. */
	private Grt _grt;

	/**
	 * Cria uma nova instância de TestListing.
     *
     * @param name Nome do TestCase
     */
	public TestListing(String name) {
        super(name);
    }

	/**
     * Dá início ao teste utilizando um método da classe
     * TestRunner.
     * 
     * @param args Array de argumentos passados ao programa.
     */
    public static void main(String args[]) {
        junit.textui.TestRunner.run(TestListing.class);
	}

	/** 
     * Cria uma instância da classe Grt e preenche-se a rede actual
     * com algumas entidades.
     *
     * Esta instância será aquela que será submetida aos
     * testes.
     */
    protected void setUp() {
        _grt = new Grt();
        Network net = _grt.getCurrentNetwork();
        
        try {
			Client cliente1 = net.registerClient("Alefon", 
                                                 "Alexandre Fonseca", 
                                                 1950683);
			Client cliente2 = net.registerClient("pedroLuz", 
                                                 "Pedro Luz",
                                                 1953532);
			Client cliente3 = net.registerClient("alefondue",
                                                 "Alexandre Fondue",
                                                 123456789);
			Client cliente4 = net.registerClient("miguel",
                                                 "Miguel Torres",
                                                 934578562);
			Client cliente5 = net.registerClient("jose",
                                                 "José Bacano",
                                                 30971234);
			Client cliente6 = net.registerClient("XaNiTa",
                                                 "Joana Alexandra",
                                                 320478912);
			Client cliente7 = net.registerClient("piRiquito",
                                                 "João Periquito",
                                                 32974211);
			Client cliente8 = net.registerClient("Aaaaaaaa",
                                                 "Francisco",
                                                 210723123);
			Client cliente9 = net.registerClient("Joaquim",
                                                 "Joaquim Fernandes",
                                                 213454123);
            cliente9.disableNotifications();
			Client cliente10 = net.registerClient("Filipina",
                                                 "Filipa Paulina",
                                                 245023423);

			Mobile mobile1 = net.registerMobile(cliente1,
                                                 124433,
                                                 Message.mobile3G());
			mobile1.addBalance(5);

			Mobile mobile2 = net.registerMobile(cliente2,
                                                 124436,
                                                 Message.mobile2G());
			mobile2.addBalance(4);

			Mobile mobile3 = net.registerMobile(cliente3,
                                                 124434,
                                                 Message.mobile2G());
			mobile3.addBalance(3);

			Mobile mobile4 = net.registerMobile(cliente3,
                                                 124437,
                                                 Message.mobile3G());
			mobile4.addBalance(-1);

			Mobile mobile5 = net.registerMobile(cliente4,
                                                 124438,
                                                 Message.mobile2G());
			mobile5.addBalance(-3);

			Mobile mobile6 = net.registerMobile(cliente4,
                                                 124435,
                                                 Message.mobile3G());
			mobile6.addBalance(6);

			Mobile mobile7 = net.registerMobile(cliente5,
                                                 124439,
                                                 Message.mobile2G());
			mobile7.addBalance(-2);

			Mobile mobile8 = net.registerMobile(cliente6,
                                                 124430,
                                                 Message.mobile3G());
			mobile8.addBalance(2);

			Mobile mobile9 = net.registerMobile(cliente6,
                                                 124431,
                                                 Message.mobile3G());
			mobile9.addBalance(-4);

			Mobile mobile10 = net.registerMobile(cliente7,
                                                 124312,
                                                 Message.mobile2G());
			mobile10.addBalance(-5);

			Mobile mobile11 = net.registerMobile(cliente8,
                                                 124316,
                                                 Message.mobile3G());
			mobile11.addBalance(-5);

			Mobile mobile12 = net.registerMobile(cliente8,
                                                 203316,
                                                 Message.mobile3G());
			mobile12.addBalance(50);

			Mobile mobile13 = net.registerMobile(cliente9,
                                                 232983,
                                                 Message.mobile3G());
			mobile13.addBalance(-4);

			Mobile mobile14 = net.registerMobile(cliente9,
                                                 233873,
                                                 Message.mobile3G());
			mobile14.addBalance(-16);

			Mobile mobile15 = net.registerMobile(cliente9,
                                                 329873,
                                                 Message.mobile3G());
			mobile15.addBalance(80);

			Mobile mobile16 = net.registerMobile(cliente10,
                                                 383923,
                                                 Message.mobile3G());
			mobile16.addBalance(30);
			
		} catch(MobileExistsException e) {
			fail("Erro na criação de um mobile: " + e);
		} catch(ClientExistsException e) {
			fail("Erro na criação de um cliente: " + e);
		}
		
    }

    /**
     * Este método procura testar a listagem de clientes com dívidas.
     *
     * Para tal, constrói uma string a partir da lista de clientes
     * devolvida pelo Grt e compara com a string construída à priori e
     * que se sabe estar correcta.
     */
    public void testClientDebtListing() {
        Network net = _grt.getCurrentNetwork();
        String result = "";

        String activeNotif = grt.textui.cliente.Message.atendedorActivo();
        String inactiveNotif = grt.textui.cliente.Message.atendedorInactivo();
        String normalClient = grt.textui.cliente.Message.clientNormal();
        
		String str =   "CLIENTE|Joaquim|Joaquim Fernandes|213454123|" + 
                       normalClient + "|" + inactiveNotif + "|3|60" +
                       "CLIENTE|Aaaaaaaa|Francisco|210723123|" + 
                       normalClient + "|" + activeNotif + "|2|45" +
					   "CLIENTE|piRiquito|João Periquito|32974211|" + 
                       normalClient + "|" + activeNotif + "|1|-5" +
					   "CLIENTE|XaNiTa|Joana Alexandra|320478912|" + 
                       normalClient + "|" + activeNotif + "|2|-2" +
					   "CLIENTE|miguel|Miguel Torres|934578562|" + 
                       normalClient + "|" + activeNotif + "|2|3" + 
					   "CLIENTE|jose|José Bacano|30971234|" + 
                       normalClient + "|" + activeNotif + "|1|-2" +
					   "CLIENTE|alefondue|Alexandre Fondue|123456789|" +
                       normalClient + "|" + activeNotif + "|2|2";

		List<Client> badClients = net.getClientsWithDebt();

		for (Client cli : badClients){
			result += cli.toString();
		}
		
		assertEquals("Erro na listagem de clientes com dívidas.", str,
                     result);
	}
}
