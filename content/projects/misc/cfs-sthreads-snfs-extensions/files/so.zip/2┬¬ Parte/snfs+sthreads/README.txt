
 I) O c�digo disponibilizado nesta fase funciona, por omiss�o, com a implementa��o das tarefas nativas - pthreads.
 
II) Para o lan�amento da aplica��o servidor:
   1) Executa do comando "make" na directoria snfs+sthreads
   2) muda para a directoria snfs_server
   3) lan�ar na linha comandos ./server ( A mensagem "Server is running ...." indica que a aplica��o j� foi iniciada)     
   
II) Para a os programas que cont�m os testes:  
   1) Abre um novo terminal
   2) Muda para a directoria onde se encontram os testes
   3) executa o "make"
   4) lan�a os testes com o servidor j� iniciado noutro terminal.   



   