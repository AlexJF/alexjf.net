
  Os testes devem ser descompactados na directoria snfs+sthreads e uma vez compilados (comando make) 
devem  ser executados num terminal depois de que o servidor já estiver a executar noutro terminal.
 Para cada teste é preciso executar de novo o servidor no respectivo terminal.

