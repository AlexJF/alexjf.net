#include "ipmap.h"
#include "stdlib.h"
#include "string.h"

struct ipmap {
    ipmap_entry_t* entries;
    int num_inodes;
};

struct ipmap_entry {
    char path[MAX_PATH_NAME_SIZE];
};

ipmap_t* ipmap_create(int num_inodes) {
	if (num_inodes < 1)
		return NULL;
		
	ipmap_t *new_ipmap = (ipmap_t*) malloc(sizeof(ipmap_t));

	if (new_ipmap == NULL)
		return NULL;

    new_ipmap->entries = (ipmap_entry_t*) malloc(sizeof(ipmap_entry_t)*num_inodes);

    if (new_ipmap->entries == NULL) {
        free(new_ipmap);
        return NULL;
    }

    ipmap_clear(new_ipmap);
	
    new_ipmap->num_inodes = num_inodes;

	return new_ipmap;
}

void ipmap_add(ipmap_t* ipmap, inodeid_t inodeid, inodeid_t parentid, char* name){
	if (inodeid < 0 || parentid < 0 || inodeid >= ipmap->num_inodes 
        || parentid >= ipmap->num_inodes) {
		return;
    }

    char* new_entry_path = ipmap->entries[inodeid].path;

	if (parentid == 0) {
		strcpy(new_entry_path, name);
    }
    else if (parentid == 1) {
        strcpy(new_entry_path, ipmap->entries[parentid].path);
        strcat(new_entry_path, name);
	} 
    else {
        strcpy(new_entry_path, ipmap->entries[parentid].path);
        strcat(new_entry_path, "/");
        strcat(new_entry_path, name);
    }
}

void ipmap_remove(ipmap_t* ipmap, inodeid_t inodeid){
	if (inodeid < 0 || inodeid >= ipmap->num_inodes) {
		return;
    }

    memset(ipmap->entries[inodeid].path, 0, MAX_PATH_NAME_SIZE*sizeof(char));
}

int ipmap_get(ipmap_t* ipmap, inodeid_t inodeid, char* path){
    if (path == NULL || inodeid < 0 || inodeid >= ipmap->num_inodes) {
        return 0;
    }

	strcpy(path, ipmap->entries[inodeid].path);
	return 1;
}

void ipmap_clear(ipmap_t* ipmap) {
    memset(ipmap->entries, 0, sizeof(ipmap_entry_t)*ipmap->num_inodes);
}

