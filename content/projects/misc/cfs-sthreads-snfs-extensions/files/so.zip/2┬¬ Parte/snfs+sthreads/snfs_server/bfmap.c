#include "bfmap.h"

/***************************************************
 * Internal: BFMap entry structures and functions. *
 ***************************************************/

struct bfmap_entry {
    /* The block this entry represents. */
    unsigned int block_number;
    /* The list of all inodeids using this block. */
    rbt_t* inodeid_rbt;
};

static rbt_key_t inodeid_key(void* item) {
    inodeid_t* inodeid = (inodeid_t*) item;

    return *inodeid;
}

bfmap_entry_t* bfmap_entry_create(unsigned int block_number) {
    bfmap_entry_t* new_entry = (bfmap_entry_t*) malloc(sizeof(bfmap_entry_t));

    new_entry->block_number = block_number;
    new_entry->inodeid_rbt = rbt_create(inodeid_key, NULL);

    return new_entry;
}

static void bfmap_entry_add_inodeid(bfmap_entry_t* entry, inodeid_t inodeid) {
    inodeid_t* new_inodeid = (inodeid_t*) malloc(sizeof(inodeid_t));
    *new_inodeid = inodeid;
    rbt_insert(entry->inodeid_rbt, new_inodeid);
}

static void bfmap_entry_remove_inodeid(bfmap_entry_t* entry, inodeid_t inodeid) {
    rbt_remove(entry->inodeid_rbt, inodeid, 1);
}

int bfmap_entry_block_number(bfmap_entry_t* entry) {
    if (entry == NULL) {
        return -1;
    }
    return entry->block_number;
}

int bfmap_entry_number_inodeids(bfmap_entry_t* entry) {
    if (entry == NULL) {
        return 0;
    }
    return rbt_getNumItems(entry->inodeid_rbt);
}

void bfmap_entry_reset_iterator(bfmap_entry_t* entry) {
    if (entry == NULL) {
        return;
    }
    rbt_resetIterator(entry->inodeid_rbt);
}

int bfmap_entry_iterate_inodeids(bfmap_entry_t* entry, inodeid_t* inodeid) {
    if (entry == NULL) {
        return 0;
    }
    inodeid_t* id = (inodeid_t*) rbt_iterate(entry->inodeid_rbt);

    if (id == NULL) {
        return 0;
    } else {
        *inodeid = *id;
        return 1;
    }
}

void bfmap_entry_free(bfmap_entry_t* entry) {
    if (entry == NULL) {
        return;
    }
    rbt_delete(entry->inodeid_rbt, 1);
}

static rbt_key_t key_bfmap_entry(void* entry) {
    return bfmap_entry_block_number((bfmap_entry_t*) entry);
}

static void free_bfmap_entry(void* entry) {
    bfmap_entry_free((bfmap_entry_t*) entry);
}

bfmap_t* bfmap_create() {
    return rbt_create(key_bfmap_entry, free_bfmap_entry);
}

void bfmap_add(bfmap_t* bfmap, unsigned int block_number, inodeid_t inodeid) {
    bfmap_entry_t* entry;

    entry = bfmap_get(bfmap, block_number);
    printf("Adding bfmap entry block %d inodeid %d\n", block_number, inodeid);

    /* If no entry was found we need to create a new one... */
    if (entry == NULL) {
        printf("No entry found.\n");
        entry = bfmap_entry_create(block_number);
        bfmap_entry_add_inodeid(entry, inodeid);
        rbt_insert(bfmap, (void*) entry);
    /* If there already was an entry then add the inodeid to it... */
    } else {
        printf("Entry found.\n");
        bfmap_entry_add_inodeid(entry, inodeid);
    }
}

void bfmap_remove(bfmap_t* bfmap, unsigned int block_number, inodeid_t inodeid) {
    bfmap_entry_t* entry;

    entry = bfmap_get(bfmap, block_number);

    if (entry == NULL) {
        return;
    }

    bfmap_entry_remove_inodeid(entry, inodeid);

    if (rbt_getNumItems(entry->inodeid_rbt) == 0) {
        rbt_remove(bfmap, block_number, 1);
    }
}

void bfmap_swap(bfmap_t* bfmap, unsigned int old_block_num, unsigned int block_num, inodeid_t inodeid) {
    bfmap_remove(bfmap, old_block_num, inodeid);
    bfmap_add(bfmap, block_num, inodeid);
}

void bfmap_swap_entries(bfmap_t* bfmap, unsigned int block1, unsigned int block2) {
    if (block1 == block2) return;
    bfmap_entry_t* entry1 = bfmap_get(bfmap, block1);
    bfmap_entry_t* entry2 = bfmap_get(bfmap, block2);

    printf("[bfmap_swap_entries] swapping %d and %d\n", block1, block2);

    if (entry1 != NULL) {
        printf("[bfmap_swap_entries] changing block of entry1 to %d\n", block2);
        rbt_remove(bfmap, block1, 0);
        entry1->block_number = block2;
    }

    if (entry2 != NULL) {
        printf("[bfmap_swap_entries] changing block of entry2 to %d\n", block1);
        rbt_remove(bfmap, block2, 0);
        entry2->block_number = block1;
    }

    if (entry1 != NULL) {
        rbt_insert(bfmap, entry1);
    }

    if (entry2 !=  NULL) {
        rbt_insert(bfmap, entry2);
    }
}

void bfmap_clear(bfmap_t* bfmap) {
    rbt_clear(bfmap, 1);
}

bfmap_entry_t* bfmap_get(bfmap_t* bfmap, unsigned int block_number) {
    return (bfmap_entry_t*) rbt_get(bfmap, block_number);
}

int bfmap_number_of_blocks(bfmap_t* bfmap) {
    return rbt_getNumItems(bfmap);
}

void bfmap_reset_iterator(bfmap_t* bfmap) {
    rbt_resetIterator(bfmap);
}

bfmap_entry_t* bfmap_iterate(bfmap_t* bfmap) {
    return (bfmap_entry_t*) rbt_iterate(bfmap);
}


void bfmap_print(bfmap_t* bfmap) {
    bfmap_entry_t* bfmap_entry = NULL;
    inodeid_t inodeid;
    bfmap_reset_iterator(bfmap);
    
    printf("====================\n");
    while ((bfmap_entry = bfmap_iterate(bfmap)) != NULL) {
        bfmap_entry_reset_iterator(bfmap_entry);

        printf("BFMap entry associated with block number %d:\n", bfmap_entry_block_number(bfmap_entry));

        while (bfmap_entry_iterate_inodeids(bfmap_entry, &inodeid)) {
            printf(" %d\n", inodeid);
        }
    }
    printf("====================\n");
}


