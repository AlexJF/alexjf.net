#if !defined BFMAP_H_INCLUDE
#define BFMAP_H_INCLUDE

#include <stdlib.h>
#include <fs.h>
#include <rbt.h>

/****************************************************************
 * A BFMap is a special structure whose aim is to aid the       *
 * filesystem server in the management of file<->block          *
 * relationships.                                               *
 *                                                              *
 * This allows efficient dumping and defrag operations by       *
 * avoiding the reparsing of the entire inode tree for each     *
 * operation that needs to find the inodeid of each file        *
 * that uses a certain block.                                   *
 *                                                              *
 * Internally it is implemented as a rbt tree whose node keys   *
 * are the block_numbers.                                       *
 *                                                              *
 * Each node contains a list of all the inodeids using that     *
 * block (multiple files can use the same block with            *
 * Copy-on-Write).                                              *
 *                                                              *
 * Note that only used blocks are stored in the structure since *
 * it would be pointless to store empty blocks with no data.    *
 ****************************************************************/

/* The bfmap type. */
typedef struct rbt bfmap_t;
/* The type of each entry of the bfmap. */
typedef struct bfmap_entry bfmap_entry_t;

/*
 * Returns the block number associated with the entry.
 *
 * @param entry The entry whose block number we want.
 *
 * @return Block number (-1 if entry is null).
 */
int bfmap_entry_block_number(bfmap_entry_t* entry);

/*
 * Resets the iterator of the internal bfmap entry inodeid list.
 *
 * @param entry The entry in which we wish to reset the iterator.
 */
void bfmap_entry_reset_iterator(bfmap_entry_t* entry);

/*
 * Returns the total number of inode ids in this entry.
 *
 * @param entry The specified entry.
 *
 * @return Number of inode ids in this entry.
 */
int bfmap_entry_number_inodeids(bfmap_entry_t* entry);

/*
 * Iterates through the inode ids of a bfmap entry.
 *
 * @param entry The entry whose inodeids we wish to iterate through.
 * @param[out] inodeid The id of the inode.
 *
 * @return 0 - Reached end of inodeids rbt.
 *         1 - Read one inodeid.
 */
int bfmap_entry_iterate_inodeids(bfmap_entry_t* entry, inodeid_t* inodeid);

/* 
 * Initializes a new bfmap.
 *
 * @return New bfmap.
 */
bfmap_t* bfmap_create();

/*
 * Given a block number and a inodeid, associates the file represented
 * by its inode's id with the block number.
 *
 * @param bfmap The block-file map where we wish to perform this action.
 * @param block_number The block whose file association we wish to set.
 * @param inodeid The id of the inode associated with the file.
 */
void bfmap_add(bfmap_t* bfmap, unsigned int block_number, inodeid_t inodeid);

/*
 * Removes the association between a block and a file.
 *
 * @param bfmap The block-file map where we wish to perform this action.
 * @param block_number The block whose file association we wish to remove.
 * @param inodeid The id of the inode of the file.
 */
void bfmap_remove(bfmap_t* bfmap, unsigned int block_number, inodeid_t inodeid);

/*
 * Swaps an inode from one entry associated with the old block to the new
 * entry associated with the new block number.
 *
 * @param bfmap The block-file map where we wish to perform this action.
 * @param old_block_num The block whose file association we wish to remove.
 * @param block_number The block whose file association we wish to add.
 * @param inodeid The id of the inode we wish to swap.
 */
void bfmap_swap(bfmap_t* bfmap, unsigned int old_block_num, unsigned int block_num, inodeid_t inodeid);

void bfmap_swap_entries(bfmap_t* bfmap, unsigned int block1, unsigned int block2);

/*
 * Clears all block<->file associations
 *
 * @param bfmap The bfmap to clear.
 */
void bfmap_clear(bfmap_t* bfmap);

/*
 * Gets the entry referring to the specified block.
 *
 * @param bfmap The block-file map that contains the required entry.
 * @param block_number The block the entry refers to.
 *
 * @return The bfmap_entry or NULL if none exists.
 */
bfmap_entry_t* bfmap_get(bfmap_t* bfmap, unsigned int block_number);

/*
 * Gets the number of blocks managed by the provided bfmap.
 *
 * @param bfmap The bfmap to examine.
 *
 * @return Number of blocks managed by the bfmap.
 */
int bfmap_number_of_blocks(bfmap_t* bfmap);

/**
 * Clears the bfmap iterator pointing it to the lowest entry.
 *
 * @param bfmap The bfmap in which to perform this action.
 */
void bfmap_reset_iterator(bfmap_t* bfmap);

/**
 * Iterates through the bfmap in an orderly fashion (one entry 
 * at a time).
 *
 * @param bfmap The bfmap in which to iterate.
 *
 * @return The entry we iterated through (or NULL if we reached 
 * the end of the bfmap).
 */
bfmap_entry_t* bfmap_iterate(bfmap_t* bfmap);

void bfmap_print(bfmap_t* bfmap);


#endif
