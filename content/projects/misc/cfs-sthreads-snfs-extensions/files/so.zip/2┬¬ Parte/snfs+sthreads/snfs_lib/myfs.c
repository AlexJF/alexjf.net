/*
 * File System Interface
 *
 * myfs.c
 *
 * Implementation of the SNFS programming interface simulating the
 * standard Unix I/O interface. This interface uses the SNFS API to
 * invoke the SNFS services in a remote server.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <myfs.h>
#include <snfs_api.h>
#include <snfs_proto.h>
#include <unistd.h>
#include "queue.h"


#ifndef SERVER_SOCK
#define SERVER_SOCK "/tmp/server.socket"
#endif

#define MAX_OPEN_FILES 10		// how many files can be open at the same time


static queue_t *Open_files_list;		// Open files list
static int Lib_initted = 0;           // Flag to test if library was initted
static int Open_files = 0;		// How many files are currently open


int mkstemp(char *template);

int myparse(char *pathname);

int my_init_lib() {
    char CLIENT_SOCK[] = "/tmp/clientXXXXXX";
    if(mkstemp(CLIENT_SOCK) < 0) {
        printf("[my_init_lib] Unable to create client socket.\n");
        return -1;
    }

    if(snfs_init(CLIENT_SOCK, SERVER_SOCK) < 0) {
        printf("[my_init_lib] Unable to initialize SNFS API.\n");
        return -1;
    }
    Open_files_list = queue_create();
    Lib_initted = 1;

    return 0;
}

int my_split_path(char *path, char *dirpath, char *filename) {
    char line[MAX_PATH_NAME_SIZE];
    char *token;
    char *search = "/";
    int i=0;

    strcpy(line, path);

    if(strlen(line) >= MAX_PATH_NAME_SIZE || (strlen(line) < 1) ) {
        printf("[my_split_path] Wrong path size.\n");
        return -1;
    }

    if (strchr(line, ' ') != NULL || strstr((const char *) line, "//") != NULL || line[0] != '/' ) {
        printf("[my_split_path] Malformed path.\n");
        return -1;
    }

    if ((i=strlen(line)) && line[i]=='/') {
        printf("[my_split_path] Malformed path.\n");
        return -1;
    }

    i=0;

    if (filename != NULL) {
        memset(filename, 0, MAX_FILE_NAME_SIZE);
    }
    if (dirpath != NULL) {
        memset(dirpath, 0, MAX_PATH_NAME_SIZE);
    }

    token = strtok(line, search);

    while(token != NULL) {
        if (strlen(token) > MAX_FILE_NAME_SIZE -1) {
            printf("[my_split_path] File/Directory name size exceeded limits.:%s \n", token);
            return -1;
        }
        if (filename != NULL) {
            strcpy(filename, token);
        }
        i++;
        token = strtok(NULL, search);
    }

    if (i > 1 && dirpath != NULL) {
        strncpy(dirpath, path, strlen(path) - (strlen(filename)+1));
    } 
    else if (i <= 1) {
        if (filename != NULL)
            strncpy(filename, &path[1], (strlen(path)-1));
        if (dirpath != NULL)
            strncpy(dirpath, path, 1);
    }
    
    return 0;
}

int my_open(char* name, int flags) {
    if (!Lib_initted) {
        printf("[my_open] Library is not initialized.\n");
        return -1;
    }

    if(Open_files >= MAX_OPEN_FILES) {
        printf("[my_open] All slots filled.\n");
        return -1;
    }

    snfs_fhandle_t dir, file_fh;
    unsigned fsize = 0;
    char dirpath[MAX_PATH_NAME_SIZE];
    char filename[MAX_FILE_NAME_SIZE];

    if (my_split_path(name, dirpath, filename) != 0) {
        printf("[my_open] malformed paths.\n");
        return -1;
    }

    snfs_call_status_t status = snfs_lookup(name, &file_fh, &fsize);

    if (status != STAT_OK) {
        snfs_lookup(dirpath, &dir, &fsize);
    }

    if(flags == O_CREATE && status != STAT_OK) {
        if (snfs_create(dir, filename, &file_fh) != STAT_OK) {
            printf("[my_open] Error creating a file in server.\n");
            return -1;
        }
    } else	if (status != STAT_OK) {
        printf("[my_open] Error opening up file.\n");
        return -1;
    }

    fd_t fdesc = (fd_t) malloc(sizeof(struct _file_desc));
    fdesc->fileId = file_fh;
    fdesc->size = fsize;
    fdesc->write_offset = 0;
    fdesc->read_offset = 0;

    queue_enqueue(Open_files_list, fdesc);
    Open_files++;

    return file_fh;
}

int my_read(int fileId, char* buffer, unsigned numBytes) {

    if (!Lib_initted) {
        printf("[my_read] Library is not initialized.\n");
        return -1;
    }

    fd_t fdesc = queue_node_get(Open_files_list, fileId);
    if(fdesc == NULL) {
        printf("[my_read] File isn't in use. Open it first.\n");
        return -1;
    }

    // EoF ?
    if(fdesc->read_offset == fdesc->size)
        return 0;

    int nread;
    unsigned rBytes;
    int counter = 0;

    // If bytes to be read are greater than file size
    if(fdesc->size < ((unsigned)fdesc->read_offset) + numBytes)
        numBytes = fdesc->size - (unsigned)(fdesc->read_offset);

    //if data must be read using blocks
    if(numBytes > MAX_READ_DATA)
        rBytes = MAX_READ_DATA;
    else
        rBytes = numBytes;

    while(numBytes) {
        if(rBytes > numBytes)
            rBytes = numBytes;

        if (snfs_read(fileId,(unsigned)fdesc->read_offset,rBytes,&buffer[counter],&nread) != STAT_OK) {
            printf("[my_read] Error reading from file.\n");
            return -1;
        }
        fdesc->read_offset += nread;
        numBytes -= (unsigned)nread;
        counter += nread;
    }

    return counter;
}

int my_write(int fileId, char* buffer, unsigned numBytes) {
    if (!Lib_initted) {
        printf("[my_write] Library is not initialized.\n");
        return -1;
    }

    fd_t fdesc = queue_node_get(Open_files_list, fileId);
    if(fdesc == NULL) {
        printf("[my_write] File isn't in use. Open it first.\n");
        return -1;
    }

    unsigned fsize;
    unsigned wBytes;
    int counter = 0;

    if(numBytes > MAX_WRITE_DATA)
        wBytes = MAX_WRITE_DATA;
    else
        wBytes = numBytes;

    while(numBytes) {
        if(wBytes > numBytes)
            wBytes = numBytes;

        if (snfs_write(fileId,(unsigned)fdesc->write_offset,wBytes,&buffer[counter],&fsize) != STAT_OK) {
            printf("[my_write] Error writing to file.\n");
            return -1;
        }
        fdesc->size = fsize;
        fdesc->write_offset += (int)wBytes;
        numBytes -= (unsigned)wBytes;
        counter += (int)wBytes;
    }

    return counter;
}

int my_close(int fileId) {
    if (!Lib_initted) {
        printf("[my_close] Library is not initialized.\n");
        return -1;
    }

    fd_t temp = queue_node_remove(Open_files_list, fileId);
    if(temp == NULL) {
        printf("[my_close] File isn't in use. Open it first.\n");
        return -1;
    }

    free(temp);
    Open_files--;

    return 0;
}


int my_listdir(char* path, char **filenames, int* numFiles) {
    if (!Lib_initted) {
        printf("[my_listdir] Library is not initialized.\n");
        return -1;
    }

    snfs_fhandle_t dir;
    unsigned fsize;

    if ( myparse(path) != 0 ) {
        printf("[my_listdir] Error looking for folder in server.\n");
        return -1;
    }

    if ((strlen(path)==1) && (path[0]== '/') ) dir = ( snfs_fhandle_t)  1;
    else if(snfs_lookup(path, &dir, &fsize) != STAT_OK) {
        printf("[my_listdir] Error looking for folder in server.\n");
        return -1;
    }


    snfs_dir_entry_t list[MAX_READDIR_ENTRIES];
    unsigned nFiles;
    char* fnames;

    if (snfs_readdir(dir, MAX_READDIR_ENTRIES, list, &nFiles) != STAT_OK) {
        printf("[my_listdir] Error reading directory in server.\n");
        return -1;
    }

    *numFiles = (int)nFiles;

    *filenames = fnames = (char*) malloc(sizeof(char)*((MAX_FILE_NAME_SIZE+1)*(*numFiles)));
    for (int i = 0; i < *numFiles; i++) {
        strcpy(fnames, list[i].name);
        fnames += strlen(fnames)+1;
    }

    return 0;
}

int my_mkdir(char* dirname) {
    if (!Lib_initted) {
        printf("[my_mkdir] Library is not initialized.\n");
        return -1;
    }

    snfs_fhandle_t dir, newdir;
    char newdirname[MAX_FILE_NAME_SIZE];
    char dirpath[MAX_PATH_NAME_SIZE];
    unsigned fsize = 0;

    if (my_split_path(dirname, dirpath, newdirname) != 0) {
        printf("[my_mkdir] malformed paths.\n");
        return -1;
    }

    if (snfs_lookup(dirname, &dir, &fsize) == STAT_OK) {
        printf("[my_mkdir] Error creating a  subdirectory that already exists.\n");
        return -1;
    }

    if (dirpath == NULL || strlen(dirpath) == 0) {
        printf("[my_mkdir] Error looking for directory in server.\n");
        return -1;
    }


    if(snfs_lookup(dirpath, &dir, &fsize) != STAT_OK) {
        printf("[my_mkdir] Error creating a  subdirectory which has a wrong pathname.\n");
        return -1;
    }

    if(snfs_mkdir(dir, newdirname, &newdir) != STAT_OK) {
        printf("[my_mkdir] Error creating new directory in server.\n");
        return -1;
    }

    return 0;
}

int myparse(char* pathname) {

    char line[MAX_PATH_NAME_SIZE];
    char *token;
    char *search = "/";
    int i=0;

    strcpy(line,pathname);

    if(strlen(line) >= MAX_PATH_NAME_SIZE || (strlen(line) < 1) ) {
        printf("[myparse] Wrong pathname size.\n");
        return -1;
    }

    if (strchr(line, ' ') != NULL || strstr( (const char *) line, "//") != NULL || line[0] != '/' ) {
        printf("[myparse] Malformed pathname.\n");
        return -1;
    }


    if ((i=strlen(pathname)) && line[i]=='/') {
        printf("[myparse] Malformed pathname.\n");
        return -1;
    }

    i=0;
    token = strtok(line, search);

    while(token != NULL) {
        if ( strlen(token) > MAX_FILE_NAME_SIZE -1) {
            printf("[myparse] File/Directory name size exceeded limits.:%s \n", token);
            return -1;
        }
        i++;

        token = strtok(NULL, search);
    }

    return 0;
}

int my_remove(char *name) {
    if (!Lib_initted) {
        printf("[my_remove] Library is not initialized.\n");
        return 0;
    }

    char filename[MAX_FILE_NAME_SIZE];
    char dirpath[MAX_PATH_NAME_SIZE];

    snfs_fhandle_t dir, removed_file;
    unsigned int fsize;

    if (my_split_path(name, dirpath, filename) != 0) {
        printf("[my_remove] Malformed pathnames.\n");
        return 0;
    }

    if (snfs_lookup(dirpath, &dir, &fsize) != STAT_OK) {
        printf("[my_remove] Couldn't find specified directory: %s.\n", dirpath);
        return 0;
    }

    printf("[my_remove] Removing file %s from %s\n", filename, dirpath);
    if (snfs_remove(dir, filename, &removed_file) == STAT_OK) {
        return 1;
    } else {
        return 0;
    }

    queue_node_remove(Open_files_list, removed_file);
}


int my_copy(char *name1, char *name2) {
    if (!Lib_initted) {
        printf("[my_copy] Library is not initialized.\n");
        return 0;
    }

    char src_filename[MAX_FILE_NAME_SIZE];
    char src_dirpath[MAX_PATH_NAME_SIZE];
    char dst_filename[MAX_FILE_NAME_SIZE];
    char dst_dirpath[MAX_PATH_NAME_SIZE];
    unsigned int fsize;

    snfs_fhandle_t src_dir, dst_dir;
    snfs_fhandle_t copied_file;

    if (my_split_path(name1, src_dirpath, src_filename) != 0 || my_split_path(name2, dst_dirpath, dst_filename) != 0) {
        printf("[my_copy] Malformed pathnames.\n");
        return 0;
    }

    if (snfs_lookup(src_dirpath, &src_dir, &fsize) != STAT_OK || snfs_lookup(dst_dirpath, &dst_dir, &fsize) != STAT_OK) {
        printf("[my_copy] Couldn't find file directories.\n");
        return 0;
    }

    if (snfs_copy(src_dir, src_filename, dst_dir, dst_filename, &copied_file) == STAT_OK) {
        return 1;
    } else {
        return 0;
    }
}

int my_append(char* pathname1, char* pathname2) {
	if (!Lib_initted) {
		printf("[my_copy] library is not initialized.\n");
        return 0;
	}
	
    char src_filename[MAX_FILE_NAME_SIZE];
    char src_dirpath[MAX_PATH_NAME_SIZE];
    char dst_filename[MAX_FILE_NAME_SIZE];
    char dst_dirpath[MAX_PATH_NAME_SIZE];
    unsigned int fsize;

    snfs_fhandle_t src_dir, dst_dir;

    if (my_split_path(pathname1, src_dirpath, src_filename) != 0 || my_split_path(pathname2, dst_dirpath, dst_filename) != 0) {
        printf("[my_append] Malformed pathnames.\n");
        return 0;
    }

    if (snfs_lookup(src_dirpath, &src_dir, &fsize) != STAT_OK || snfs_lookup(dst_dirpath, &dst_dir, &fsize) != STAT_OK) {
        printf("[my_append] Couldn't find file directories.\n");
        return 0;
    }

	if (snfs_append(src_dir, src_filename, dst_dir, dst_filename, &fsize) == STAT_OK) {
        return 1;
    } else {
        return 0;
    }
}	


int my_defrag() {
	if (!Lib_initted) {
		printf("[my_defrag] library is not initialized.\n");
        return 0;
	}

    if (snfs_defrag() == STAT_OK) {
        return 1;
    } else {
        return 0;
    }
}

int my_diskusage(){
	if (!Lib_initted) {
		printf("[my_diskusage] library is not initialized.\n");
        return 0;
	}

    if (snfs_diskusage() == STAT_OK) {
        return 1;
    } else {
        return 0;
    }
}

int my_dumpcache(){
	if (!Lib_initted) {
		printf("[my_dumpchace] library is not initialized.\n");
        return 0;
	}

    if (snfs_dumpcache() == STAT_OK) {
        return 1;
    } else {
        return 0;
    }
}



