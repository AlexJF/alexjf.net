#if !defined RBT_H_INCLUDE
#define RBT_H_INCLUDE

#include <stdlib.h>
#include <stdio.h>

/**
 * @internal
 * @defgroup rbt Red and Black Tree
 * @{
 */
/** An enumaration of node colors. */
enum colors {RED, BLACK};

typedef long long rbt_key_t;

/** A structure representing each node. */
typedef struct rbt_node {
    /** A pointer to the right son */
    struct rbt_node* right;
    /** A pointer to the left son */
    struct rbt_node* left;
    /** 
     * A pointer to the parent of this node. 
     *
     * If this node is the root then it points to himself
     */
    struct rbt_node* parent;


    /** The item contained in this node */
    void* item;

    /** The color of this node */
    enum colors nodeColor;

} rbt_node_t;

/** A structure representig a red-black tree. */
typedef struct rbt {
    /** A pointer to the root of a tree **/
    rbt_node_t* root;

    /** A pointer to the element with the lowest run time node */
    rbt_node_t* lowestNode;

    /** A pointer that allows iteration over the rbt. */
    rbt_node_t* iterator;

    /** Number of nodes in a tree **/
    int numNodes;

    /**
     * The function that given an item returns its key.
     *
     * This key should uniquely id that item although that isn't
     * strictly necessary.
     *
     * This function is used to order the rbt and to retrieve/remove
     * a certain item (if the key is shared by more than one item 
     * then the first one encountered is the one affected).
     *
     * @return Key of the item.
     */
    rbt_key_t (*keyFunction)(void*);

    /** 
     * The function to call when freeing an item.
     * If NULL, free() will be called instead.
     */
    void (*freeFunction)(void*);
} rbt_t;

/**
 * Create a new tree.
 *
 * @return A pointer to a tree
 */
rbt_t* rbt_create(rbt_key_t (*keyFunction)(void*), void (*freeFunction)(void*));

/**
 * Insert a new item in the tree.
 *
 * @param tree The tree in which to insert the item.
 * @param item The item to insert in the tree.
 */
void rbt_insert(rbt_t* tree, void* item);

/**
 * Remove an item from the tree.
 *
 * @param tree The tree in which to insert the item.
 * @param key The key of the item to remove.
 * @param freeItem Whether or not to free the items.
 */
void rbt_remove(rbt_t* tree, rbt_key_t key, int freeItems);

/**
 * Get number of items in the tree.
 *
 * @param tree The tree in which to count the items.
 *
 * @return The number of items in the tree.
 */
int rbt_getNumItems(rbt_t* tree);

/**
 * Gets an item from the tree.
 *
 * @param tree The tree from where to get the item.
 * @param key The key of the item to get.
 *
 * @return The item or NULL if it doesn't exist.
 */
void* rbt_get(rbt_t* tree, rbt_key_t key);

/**
 * Delete the node with the lowest value.
 *
 * @param tree The tree from which to remove the node.
 * 
 * @note It doesn't free the node's item.
 */
void* rbt_pop(rbt_t* tree);

/**
 * Delete the entire tree
 *
 * @param tree The tree that we wish to delete.
 * @param freeItem Whether or not to free the items.
 */
void rbt_delete(rbt_t* tree, int freeItem);

/**
 * Erase all nodes of a tree
 *
 * @param tree The tree whose nodes we wish to delete
 * @param freeItems Whether or not to free the items.
 */
void rbt_clear(rbt_t* tree, int freeItems);

/**
 * Get the lowest item on the list
 *
 * @param tree The tree where we will search
 *
 * @return The item with the lowest value on the tree
 */
void* rbt_getLowestItem(rbt_t* tree);

/**
 * Clears the tree iterator pointing it to the lowest node.
 *
 * @param tree The tree in which to perform this action.
 */
void rbt_resetIterator(rbt_t* tree);

/**
 * Iterates through the tree in an orderly fashion (one node
 * at a time).
 *
 * @param tree The tree in which to iterate.
 *
 * @return The item of the node we iterated through (or NULL
 * if we reached the end of the tree).
 */
void* rbt_iterate(rbt_t* tree);

/** @} */

#endif
