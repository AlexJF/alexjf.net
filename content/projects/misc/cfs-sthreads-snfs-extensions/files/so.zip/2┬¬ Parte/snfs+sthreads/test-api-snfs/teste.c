/* 
 * SNFS API Layer
 * 
 * test-copy
 *
 * Tests the SNFS services:
 * - create: creates a file
 * - write: writes data to a file 
 * - copy: makes a file copy
 * 
 * Atention: in current release, only the root directory exists
 * which corresponds to the file handler 1.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <myfs.h>

// the SNFS API interface



#ifndef CLIENT_SOCK
#define CLIENT_SOCK "/tmp/client.socket"
#endif

#ifndef SERVER_SOCK
#define SERVER_SOCK "/tmp/server.socket"
#endif

#define ROOT_FHANDLE 1

#define DATA_SIZE 1024
#define MAX_PATH_NAME_SIZE 200

int main(int argc, char **argv) {
	char menu[] = "1 - Criar Ficheiro\n2 - Apagar Ficheiro\n3 - Append\n4 - Ler um Ficheiro\n5 - Escrever num Ficheiro\n6 - Copiar Ficheiro\n7 - Dump disk usage\n8 - Dump cache\n9 - Defrag\n10 - Criar Directório\n11 - Listar Directório\n";
	

	my_init_lib();
	
	while(1){
		printf("%s\n", menu);
		int op;
		scanf("%d", &op);
        char pathname1[MAX_PATH_NAME_SIZE];
        char pathname2[MAX_PATH_NAME_SIZE];
        int fileid;
        char buffer[DATA_SIZE];
        int i, j;
        int numBytesRead;
        int totalBytesRead;
        int numfiles;
        char *filenames;


		switch(op){
			case 1:
				printf("Criar um ficheiro\n");
			    printf("Path: "); scanf("%s", pathname1);
				printf("File id: %d\n", (fileid = my_open(pathname1, O_CREATE)));
                my_close(fileid);
				break;
			case 2:
				printf("Apagar um ficheiro\n");
				printf("Path: "); scanf("%s", pathname1);
				if (!my_remove(pathname1)) {
                    printf("Error removing file.\n");
                }
				break;
			case 3:
				printf("Append\n");
				printf("Destino: "); scanf("%s", pathname1);
				printf("Origem: "); scanf("%s", pathname2);
				if (!my_append(pathname1, pathname2)) {
                    printf("Error appending file.\n");
                }
				break;
			case 4:
				printf("Ler um ficheiro\n");
				printf("Path: "); scanf("%s", pathname1);
                if ((fileid = my_open(pathname1, 0)) == -1) {
                    printf("Error opening file.\n");
                    break;
                }
                totalBytesRead = 0;
				while ((numBytesRead = my_read(fileid, buffer, DATA_SIZE)) && numBytesRead != -1) {
                    for (i = 0; i < numBytesRead; i++) {
                        printf("%c", buffer[i]);
                    }
                    totalBytesRead += numBytesRead;
                }
                printf("\nTotal Bytes Read: %d bytes\n", totalBytesRead);
                my_close(fileid);
				break;
			case 5:
				printf("Escrever num ficheiro\n");
				printf("Path: "); scanf("%s", pathname1);
                if ((fileid = my_open(pathname1, 0)) == -1) {
                    break;
                }
                char c;
                while ((c = getchar()) == '\n');
                ungetc(c, stdin);
				while (fgets(buffer, DATA_SIZE, stdin) != NULL) {
                    if (my_write(fileid, buffer, strlen(buffer)) == -1) {
                        break;
                    }
                }
                my_close(fileid);
				break;
			case 6:
				printf("Copiar um ficheiro\n");
				printf("Origem: "); scanf("%s", pathname1);
				printf("Destino: "); scanf("%s", pathname2);
				if (!my_copy(pathname1, pathname2)) {
                    printf("Error copying file.\n");
                }
				break;
			case 7:
				printf("Dump diskusage\n");
				my_diskusage();
				break;
			case 8:
				printf("Dump cache\n");
				my_dumpcache();
				break;
            case 9:
                printf("Defrag\n");
                my_defrag();
                break;
            case 10:
                printf("Criar directório\n");
			    printf("Path: "); scanf("%s", pathname1);
				my_mkdir(pathname1);
                break;
            case 11:
                filenames = NULL;
                printf("Listar directório\n");
			    printf("Path: "); scanf("%s", pathname1);
                if (my_listdir(pathname1, &filenames, &numfiles) == -1) {
                    printf("Erro ao ler directório\n");
                    break;
                }

                for (j = 0, i = 0; j < numfiles; i++) {
                    if (filenames[i] == '\0') {
                        printf("\n");
                        j++;
                        continue;
                    }

                    printf("%c", filenames[i]);
                }

                printf("\n");

                free(filenames);
                break;

			default: printf("Opção escolhida não existente!\n");
					break;
		}
	}
}
