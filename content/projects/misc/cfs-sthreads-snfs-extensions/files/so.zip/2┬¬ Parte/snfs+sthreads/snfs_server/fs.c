/*
 * File System Layer
 *
 * fs.c
 *
 * Implementation of the file system layer. Manages the internal
 * organization of files and directories in a 'virtual memory disk'.
 * Implements the interface functions specified in fs.h.
 *
 */


#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sthread.h>
#include "fs.h"
#include "bfmap.h"
#include "ipmap.h"

/*
 * Other internal file system macros and functions
 */
#define MIN(a,b) ((a)<=(b)?(a):(b))
#define MAX(a,b) ((a)>=(b)?(a):(b))
#define OFFSET_TO_BLOCKS(pos) ((pos)/BLOCK_SIZE+(((pos)%BLOCK_SIZE>0)?1:0))
#define dprintf if(1) printf

#define BLOCK_SIZE 512

/*
 * Inode
 * - inode size = 64 bytes
 * - num of direct block refs = 10 blocks
 */

#define INODE_NUM_BLKS 10

#define EXT_INODE_NUM_BLKS (BLOCK_SIZE / sizeof(unsigned int))

typedef struct fs_inode {
    fs_itype_t type;
    unsigned int size;
    /* As the number of blocks is much less than 4.294.967.296 we can
     * use one of the unused bits in each entry to represent the copy
     * on write (we chose the most significant bit).
     * e.g.: X_______ ________ __XXXXXX XXXXXXXX (for 16384 blocks) */
    unsigned int blocks[INODE_NUM_BLKS];
    unsigned int reserved[4]; // reserved[0] -> extending table block number
} fs_inode_t;

typedef unsigned int fs_inode_ext_t;


/*
 * Directory entry
 * - directory entry size = 16 bytes
 * - filename max size - 14 bytes (13 chars + '\0') defined in fs.h
 */

#define DIR_PAGE_ENTRIES (BLOCK_SIZE / sizeof(fs_dentry_t))

typedef struct dentry {
    char name[FS_MAX_FNAME_SZ];
    inodeid_t inodeid;
} fs_dentry_t;

/*****************************
 * Cache related structures. *
 *****************************/
/* Total number of entries in the block cache. */
#define BLKCACHE_NUM_ENTRIES 8
/* Frequency with which the analysys of the block cache is made
 * with the purpose of resetting R bits and saving M blocks to
 * disk. (in seconds) */
#define BLKCACHE_ANALYSYS_FREQ 4
/* The minimum time before a modified block in cache is flushed
 * to the disk. */
#define BLKCACHE_MINIMUM_FLUSH 10

/* Entrada da cache de blocos. */
typedef struct blkcache_entry {
    /* This bit repsents if the cache entry is valid or not. */
    short V;
    /* This bit represents if the entry was referenced since the
     * last time the analysys process ran. */
    short R;
    /* This bit represents if the modified block is (1) or not (0)
     * different from the in-disk block. */
    short M;
    /* Index of the in-disk block associated with this cache entry. */
    unsigned int block;
    /* Block content on cache (it might differ from the content
     * on disk). */
    char block_data[BLOCK_SIZE];
    /* Age of the block (number of BLKCACHE_ANALYSYS_FREQ seconds
     * since we last wrote this block to disk). */
    unsigned int age;
} fs_blkcache_entry_t;

/* Block Cache */
typedef struct blkcache {
    /* Cache entries. */
    fs_blkcache_entry_t entries[BLKCACHE_NUM_ENTRIES];
    /* Id of the analyzer thread. */
    sthread_t analyzert;
    /* Mutex for cache operations. */
    sthread_mutex_t mutex;
} fs_blkcache_t;

/*********************************************************************
 * Filesystem structure.                                             *
 * - inode table size = 64 entries (8 blocks)                        *
 *                                                                   *
 * Internal organization                                             *
 *   -block 0        - free block bitmap                             *
 *   -block 1        - free inode bitmap                             *
 *   -block 2-9      - inode table (8 blocks)                        *
 *   -block 10-(N-1) - data blocks, where N is the number of blocks  *
 *********************************************************************/
#define ITAB_NUM_BLKS 8
#define ITAB_SIZE (ITAB_NUM_BLKS*BLOCK_SIZE / sizeof(fs_inode_t))

struct fs_ {
    blocks_t* blocks;
    char inode_bmap [BLOCK_SIZE];
    char blk_bmap [BLOCK_SIZE];
    fs_inode_t inode_tab [ITAB_SIZE];
    fs_blkcache_t cache;
    bfmap_t* bfmap;
	ipmap_t* ipmap;
};

/***************************
 * Cache related functions *
 ***************************/
static void* fsi_blkcache_analyser(void* data);
static int fsi_blkcache_init(fs_t* fs);
static void fsi_blkcache_clear(fs_t* fs);
static void fsi_blkcache_entry_reset(fs_blkcache_entry_t* entry);
static int fsi_blkcache_block_get(fs_t* fs, unsigned int block, char* data);
static void fsi_blkcache_block_add(fs_t* fs, unsigned int block, char* data);
static int fsi_blkcache_block_swap(fs_t* fs, fs_blkcache_entry_t* cache_entry);

/*
 * Thread responsible for analyzing the block cache every BLKCACHE_ANALYSYS_FREQ
 * seconds.
 *
 * @param data The filesystem that contains this cache (cast to void*).
 */
static void* fsi_blkcache_analyser(void* data) {
    if (data == NULL) {
		sthread_exit((void *) -1);
    }

    fs_t* fs = (fs_t*) data;
    fs_blkcache_entry_t* current_entry;
    int i;

    while (1) {
        sthread_sleep(BLKCACHE_ANALYSYS_FREQ * 1000000);
        printf("[fsi_blkcache_analyser] woke up.\n");

        sthread_mutex_lock(fs->cache.mutex);
        for (i = 0; i < BLKCACHE_NUM_ENTRIES; i++) {
            current_entry = &fs->cache.entries[i];

            if (current_entry->M) {
                current_entry->age++;
            }

            if (current_entry->age * BLKCACHE_ANALYSYS_FREQ > BLKCACHE_MINIMUM_FLUSH) {
                fsi_blkcache_block_swap(fs, current_entry);
            }

            current_entry->R = 0;
        }
        sthread_mutex_unlock(fs->cache.mutex);
    }

    return 0;
}


/*
 * Initializes a new block cache.
 *
 * @param fs The filesystem in which to initialize a new cache.
 *
 * @return 0 - Error
 *         1 - Success
 */
static int fsi_blkcache_init(fs_t* fs) {
    fsi_blkcache_clear(fs); 

    if ((fs->cache.analyzert = sthread_create(fsi_blkcache_analyser, (void*) fs, 0)) == NULL) {
        dprintf("[fsi_blkcache_init] Error while initializing cache analyser.\n");
        return 0;
    }

    fs->cache.mutex = sthread_mutex_init();

    return 1;
}

/* 
 * Resets all entries of the cache.
 *
 * @param fs The filesystem where the cache resides.
 */
static void fsi_blkcache_clear(fs_t* fs) {
    int i;

    for (i = 0; i < BLKCACHE_NUM_ENTRIES; i++) {
        fsi_blkcache_block_swap(fs, &fs->cache.entries[i]);
        fsi_blkcache_entry_reset(&fs->cache.entries[i]);
    }
}

/*
 * Resets all status bits of the provided blkcache_entry.
 *
 * @param entry The entry in which to perform the reset.
 */
static void fsi_blkcache_entry_reset(fs_blkcache_entry_t* entry) {
    entry->V = entry->R = entry->M = entry->age = 0;
}

/*
 * Attempts to read the specified block's data from cache.
 *
 * @param fs The filesystem where the block (and cache) reside.
 * @param block The index of the block whose data we require.
 * @param[out] data The data contained in the cached block.
 *
 * @return 0 - Block isn't cached so no data read.
 *         1 - Block cached and data read.
 */
static int fsi_blkcache_block_get(fs_t* fs, unsigned int block, char* data) {
    fs_blkcache_t* cache = &fs->cache;
    fs_blkcache_entry_t* cache_entry;
    int i;

    for (i = 0; i < BLKCACHE_NUM_ENTRIES; i++) {
        cache_entry = &cache->entries[i];

        if (!cache_entry->V) continue;

        if (cache_entry->block == block) {
            memcpy(data, cache_entry->block_data, BLOCK_SIZE);
            cache_entry->R = 1;
            dprintf("[fsi_blkcache_block_get] returning block %d from cache.\n", block);
            return 1;
        }
    }

    return 0;
}

/* Given a cache block entry, assures that the in-disk block matches the cached block.
 *
 * @param fs The filesystem where the block (and cache) reside.
 * @param cache_entry The entry whose block we wish to swap.
 *
 * @return 0 - Error while writing block to disk. Block not swapped.
 *         1 - Swapping successful.
 */
static int fsi_blkcache_block_swap(fs_t* fs, fs_blkcache_entry_t* cache_entry) {
    if (cache_entry->V && cache_entry->M) {
        if (block_write(fs->blocks, cache_entry->block, cache_entry->block_data) == -1) {
            dprintf("[fsi_swap_cached_block] error while writing cached block to disk.\n");
            return 0;
        }
        dprintf("[fsi_blkcache_block_swap] saved block %d to disk.\n", cache_entry->block);
    }

    cache_entry->M = 0;

    return 1;
}

/*
 * Adds a new block to the cache or modifies an existing one.
 *
 * @param fs The filesystem where the block (and cache) reside.
 * @param block The index of the block.
 * @param data The current data of the block.
 */
static void fsi_blkcache_block_add(fs_t* fs, unsigned int block, char* data) {
    int i;
    fs_blkcache_t* cache = &fs->cache;
    fs_blkcache_entry_t* current_cache_entry = NULL;

    /* First check if block doesn't already exist */
    for (i = 0; i < BLKCACHE_NUM_ENTRIES; i++) {
        current_cache_entry = &cache->entries[i];
        
        if (!current_cache_entry->V) continue;

        if (current_cache_entry->block == block) {
            dprintf("[fsi_blkcache_block_add] found block %d already in cache.\n", block);
            memcpy(current_cache_entry->block_data, data, BLOCK_SIZE);
            current_cache_entry->M = 1;
            current_cache_entry->R = 1;
            current_cache_entry->age = 0;
            return;
        }
    }

    /* If block didn't already exist then add a new one. */
    /* Randomize the starting position so we don't replace only the
     * initial entries. */
    int j = (rand() % BLKCACHE_NUM_ENTRIES);
    fs_blkcache_entry_t* minimum_cache_entry = &cache->entries[j];
    int minimum_entry_sum = minimum_cache_entry->M + minimum_cache_entry->R;
    int entry_sum = 0;

    for (i = 0; i < BLKCACHE_NUM_ENTRIES; i++, (j = (j + 1) % BLKCACHE_NUM_ENTRIES)) {
        current_cache_entry = &cache->entries[j];

        /* If entry isn't valid then we don't need to look any further. It's a free spot. */
        if (!current_cache_entry->V) {
            minimum_cache_entry = current_cache_entry;
            break;
        }

        entry_sum = current_cache_entry->M + current_cache_entry->R;

        if (entry_sum < minimum_entry_sum) {
            minimum_cache_entry = current_cache_entry;
        }
    }

    if (minimum_cache_entry->V) 
        dprintf("[fsi_blkcache_block_add] selected block %d for substitution.\n", minimum_cache_entry->block);

    if (!fsi_blkcache_block_swap(fs, minimum_cache_entry)) {
        dprintf("[fsi_add_cached_block] couldn't ensure dirty block consistency on disk.\n");
        return;
    }

    minimum_cache_entry->block = block;
    minimum_cache_entry->V = 1;
    minimum_cache_entry->M = 1;
    minimum_cache_entry->R = 1;
    minimum_cache_entry->age = 0;
    memcpy(minimum_cache_entry->block_data, data, BLOCK_SIZE);

    dprintf("[fsi_blkcache_block_add] added block %d to cache.\n", block);
}

/*
 * Wrapper functions around block reading/writing.
 */
int fsi_block_write(fs_t* fs, unsigned block, char* data) {
    sthread_mutex_lock(fs->cache.mutex);
    fsi_blkcache_block_add(fs, block, data);
    sthread_mutex_unlock(fs->cache.mutex);
    return 0;
}

int fsi_block_read(fs_t* fs, unsigned block, char* data) {
    sthread_mutex_lock(fs->cache.mutex);
    if (!fsi_blkcache_block_get(fs, block, data)) {
        if (block_read(fs->blocks, block, data) == -1) {
            dprintf("[fsi_block_read] error reading block %d from disk.\n", block);
            sthread_mutex_unlock(fs->cache.mutex);
            return -1;
        }
        fsi_blkcache_block_add(fs, block, data);
    }
    sthread_mutex_unlock(fs->cache.mutex);

    return 0;
}

/********************************************************************
 * Functions for loading/storing file system metadata do the blocks *
 ********************************************************************/
#define NOT_FS_INITIALIZER  1

static void fsi_load_fsdata(fs_t* fs) {
    blocks_t* bks = fs->blocks;

    // load free block bitmap from block 0
    block_read(bks, 0, fs->blk_bmap);

    // load free inode bitmap from block 1
    block_read(bks, 1, fs->inode_bmap);

    // load inode table from blocks 2-9
    for (int i = 0; i < ITAB_NUM_BLKS; i++) {
        block_read(bks, i+2, &((char*)fs->inode_tab)[i*BLOCK_SIZE]);
    }
#define NOT_FS_INITIALIZER  1  //file system is already initialized, subsequent block acess will be delayed using a sleep function.
}


static void fsi_store_fsdata(fs_t* fs) {
    blocks_t* bks = fs->blocks;

    // store free block bitmap to block 0
    block_write(bks, 0, fs->blk_bmap);

    // store free inode bitmap to block 1
    block_write(bks, 1, fs->inode_bmap);

    // store inode table to blocks 2-9
    for (int i = 0; i < ITAB_NUM_BLKS; i++) {
        block_write(bks, i+2, &((char*)fs->inode_tab)[i*BLOCK_SIZE]);
    }
}

/*
 * Bitmap management macros
 */
#define BMAP_SET(bmap,num) ((bmap)[(num)/8]|=(0x1<<((num)%8)))
#define BMAP_CLR(bmap,num) ((bmap)[(num)/8]&=~((0x1<<((num)%8))))
#define BMAP_ISSET(bmap,num) ((bmap)[(num)/8]&(0x1<<((num)%8)))

/*
 * Copy on write macros
 */
#define COW_SET(inode,blockindex) ((inode)->blocks[(blockindex)]|=(0x1<<(31)))
#define COW_CLR(inode,blockindex) ((inode)->blocks[(blockindex)]&=~(0x1<<(31)))
#define COW_ISSET(inode,blockindex) ((inode)->blocks[(blockindex)]&(0x1<<(31)))
#define BLOCK(inode, blockindex) (((inode)->blocks[(blockindex)])&~(0x1<<(31)))

/*
 * Bitmap management functions
 */
static int fsi_bmap_find_free(char* bmap, int size, unsigned* free) {
    for (int i = 0; i < size; i++) {
        if (!BMAP_ISSET(bmap,i)) {
            *free = i;
            return 1;
        }
    }
    return 0;
}

static void fsi_dump_bmap(char* bmap, int size) {
    int i = 0;
    for (; i < size; i++) {
        printf("%x.", (unsigned char)bmap[i]);
        if (i > 0 && i % 32 == 0) {
            printf("\n");
        }
    }
}



static void fsi_inode_init(fs_inode_t* inode, fs_itype_t type) {
    int i;

    inode->type = type;
    inode->size = 0;
    for (i = 0; i < INODE_NUM_BLKS; i++) {
        inode->blocks[i] = 0;
    }

    for (i = 0; i < 4; i++) {
        inode->reserved[i] = 0;
    }
}

static int fsi_dir_search(fs_t* fs, inodeid_t dir, char* file,
                          inodeid_t* fileid) {
    fs_dentry_t page[DIR_PAGE_ENTRIES];
    fs_inode_t* idir = &fs->inode_tab[dir];
    int num = idir->size / sizeof(fs_dentry_t);
    int iblock = 0;

    while (num > 0) {
        fsi_block_read(fs, BLOCK(idir, iblock), (char*)page);
        iblock++;
        for (int i = 0; i < DIR_PAGE_ENTRIES && num > 0; i++, num--) {
            if (strcmp(page[i].name, file) == 0) {
                *fileid = page[i].inodeid;
                return 0;
            }
        }
    }
    return -1;
}

int fsi_split_path(char *path, char *dirpath, char *filename) {
    char line[MAX_PATH_NAME_SIZE];
    char *token;
    char *search = "/";
    int i;

    strcpy(line, path);

    if(strlen(line) >= MAX_PATH_NAME_SIZE || (strlen(line) < 1) ) {
        printf("[my_split_path] Wrong path size.\n");
        return -1;
    }

    if (strchr(line, ' ') != NULL || strstr( (const char *) line, "//") != NULL || line[0] != '/' ) {
        printf("[my_split_path] Malformed path.\n");
        return -1;
    }

    if ((i=strlen(line)) && line[i]=='/') {
        printf("[my_split_path] Malformed path.\n");
        return -1;
    }

    i = 0;

    if (filename != NULL) {
        memset(filename, 0, FS_MAX_FNAME_SZ);
    }

    if (dirpath != NULL) {
        memset(dirpath, 0, MAX_PATH_NAME_SIZE);
    }

    token = strtok(line, search);

    while(token != NULL) {
        if (strlen(token) > FS_MAX_FNAME_SZ -1) {
            printf("[my_split_path] File/Directory name size exceeded limits.:%s \n", token);
            return -1;
        }
        if (filename != NULL) {
            strcpy(filename, token);
        }
        i++;
        token = strtok(NULL, search);
    }

    if (i > 1 && dirpath != NULL) {
        strncpy(dirpath, path, strlen(path) - (strlen(filename)+1));
    } 
    else if (i <= 1) {
        if (filename != NULL)
            strncpy(filename, &path[1], (strlen(path)-1));
        if (dirpath != NULL)
            strncpy(dirpath, path, 1);
    }

    return 0;
}

/*
 * Copy-On-Write management functions.
 */
static int fsi_cow_search(fs_t* fs, unsigned int block) {
    /*fs_inode_t* inode;
    unsigned inode_blockj;
    int i, j;*/

    /*for (i = 0; i < ITAB_SIZE; i++) {
        inode = &fs->inode_tab[i];
        for (j = 0; j < OFFSET_TO_BLOCKS(inode->size); j++) {
            inode_blockj = BLOCK(inode, j);

            if (inode_blockj == block) {
                return 1;
            }
        }
    }*/

    bfmap_entry_t* entry = bfmap_get(fs->bfmap, block);

    return bfmap_entry_number_inodeids(entry) > 1;
}

static int fsi_cow_replace(fs_t* fs, inodeid_t inodeid, int pos) {
    fs_inode_t* inode = &fs->inode_tab[inodeid];
    unsigned old_block = BLOCK(inode, pos);
    unsigned *block = &inode->blocks[pos];

    if (fsi_cow_search(fs, old_block)) {
        if (!fsi_bmap_find_free(fs->blk_bmap, block_num_blocks(fs->blocks), block)) {
            dprintf("[fsi_cow_replace] No free blocks to write to :(\n");
            return 0;
        }

        dprintf("[fsi_cow_replace] Found other inodes with same block.\n  \
                Replaced inode block at index %d [%d->%d]\n", pos, old_block, *block);

        bfmap_swap(fs->bfmap, old_block, *block, inodeid);
        BMAP_SET(fs->blk_bmap, *block);
    } else {
        dprintf("[fsi_cow_replace] No other inodes use this block so we can keep it.\n");
        COW_CLR(inode, pos);
    }

    return 1;
}


/*
 * File system interface functions
 */
void io_delay_on(int disk_delay);

fs_t* fs_new(unsigned num_blocks, int disk_delay) {
    fs_t* fs = (fs_t*) malloc(sizeof(fs_t));
    fs->blocks = block_new(num_blocks,BLOCK_SIZE);
    fsi_blkcache_init(fs);
    fs->bfmap = bfmap_create();
    fs->ipmap = ipmap_create(ITAB_SIZE);
    fsi_load_fsdata(fs);
    io_delay_on(disk_delay);
    return fs;
}


int fs_format(fs_t* fs) {

    if (fs == NULL) {
        printf("[fs] argument is null.\n");
        return -1;
    }

    // erase all blocks
    char null_block[BLOCK_SIZE];
    memset(null_block,0,sizeof(null_block));
    for (int i = 0; i < block_num_blocks(fs->blocks); i++) {
        block_write(fs->blocks, i, null_block);
    }

    // reserve file system meta data blocks
    BMAP_SET(fs->blk_bmap, 0);
    BMAP_SET(fs->blk_bmap, 1);
    for (int i = 0; i < ITAB_NUM_BLKS; i++) {
        BMAP_SET(fs->blk_bmap, i+2);
    }

    // reserve inodes 0 (will never be used) and 1 (the root)
    BMAP_SET(fs->inode_bmap, 0);
    BMAP_SET(fs->inode_bmap, 1);
    fsi_inode_init(&fs->inode_tab[1], FS_DIR);

    ipmap_clear(fs->ipmap);
    bfmap_clear(fs->bfmap);
    ipmap_add(fs->ipmap, 1, 0, "/");

    // save the file system metadata
    fsi_store_fsdata(fs);
    fsi_blkcache_clear(fs);
    return 0;
}


int fs_get_attrs(fs_t* fs, inodeid_t file, fs_file_attrs_t* attrs) {
    if (fs == NULL || file >= ITAB_SIZE || attrs == NULL) {
        dprintf("[fs_get_attrs] malformed arguments.\n");
        return -1;
    }

    if (!BMAP_ISSET(fs->inode_bmap,file)) {
        dprintf("[fs_get_attrs] inode is not being used.\n");
        return -1;
    }

    fs_inode_t* inode = &fs->inode_tab[file];
    attrs->inodeid = file;
    attrs->type = inode->type;
    attrs->size = inode->size;
    switch (inode->type) {

    case FS_DIR:
        attrs->num_entries = inode->size / sizeof(fs_dentry_t);
        break;
    case FS_FILE:
        attrs->num_entries = -1;
        break;
    default:
        dprintf("[fs_get_attrs] fatal error - invalid inode.\n");
        exit(-1);
    }
    return 0;
}


int fs_lookup(fs_t* fs, char* file, inodeid_t* fileid) {
    char *token;
    char line[MAX_PATH_NAME_SIZE];
    char *search = "/";
    int i=0;
    int dir=0;

    if (fs==NULL || file==NULL ) {
        dprintf("[fs_lookup] malformed arguments.\n");
        return -1;
    }


    if(file[0] != '/') {
        dprintf("[fs_lookup] malformed pathname.\n");
        return -1;
    }

    strcpy(line,file);
    token = strtok(line, search);

    while(token != NULL) {
        i++;
        if(i==1) dir=1;  //Root directory

        if (!BMAP_ISSET(fs->inode_bmap,dir)) {
            dprintf("[fs_lookup] inode is not being used.\n");
            return -1;
        }
        fs_inode_t* idir = &fs->inode_tab[dir];
        if (idir->type != FS_DIR) {
            dprintf("[fs_lookup] inode is not a directory.\n");
            return -1;
        }
        inodeid_t fid;
        if (fsi_dir_search(fs, dir, token, &fid) < 0) {
            dprintf("[fs_lookup] file does not exist.\n \
                     token: %s || dir: %d\n", token, dir);
            return 0;
        }
        *fileid = fid;
        dir=fid;
        token = strtok(NULL, search);
    }

    if (i == 0) *fileid = 1;

    return 1;
}


int fs_read(fs_t* fs, inodeid_t file, unsigned offset, unsigned count,
            char* buffer, int* nread) {
    if (fs==NULL || file >= ITAB_SIZE || buffer==NULL || nread==NULL) {
        dprintf("[fs_read] malformed arguments.\n");
        return -1;
    }

    if (!BMAP_ISSET(fs->inode_bmap,file)) {
        dprintf("[fs_read] inode is not being used.\n");
        return -1;
    }

    fs_inode_t* ifile = &fs->inode_tab[file];
    if (ifile->type != FS_FILE) {
        dprintf("[fs_read] inode is not a file.\n");
        return -1;
    }

    if (offset >= ifile->size) {
        *nread = 0;
        return 0;
    }

    dprintf("[fs_read] count=%d, offset=%d, fsize=%d\n",
            count,offset, ifile->size);

    // read the specified range
    int pos = 0;
    int iblock = offset/BLOCK_SIZE;
    int blks_used = OFFSET_TO_BLOCKS(ifile->size);
    int max = MIN(count, ifile->size - offset);
    char block[BLOCK_SIZE];

    while (pos < max && iblock < blks_used) {
        fsi_block_read(fs, BLOCK(ifile, iblock), block);

        int start = ((pos == 0) ? (offset % BLOCK_SIZE) : 0);
        int num = MIN(BLOCK_SIZE - start, max - pos);
        memcpy(&buffer[pos], &block[start], num);

        pos += num;
        iblock++;
    }
    *nread = pos;
    dprintf("[fs_read] read %d bytes, file size %d.\n", pos, ifile->size);
    return 0;
}


int fs_write(fs_t* fs, inodeid_t file, unsigned offset, unsigned count,
             char* buffer) {
    if (fs == NULL || file >= ITAB_SIZE || buffer == NULL) {
        dprintf("[fs_write] malformed arguments.\n");
        return -1;
    }

    if (!BMAP_ISSET(fs->inode_bmap,file)) {
        dprintf("[fs_write] inode is not being used.\n");
        return -1;
    }

    fs_inode_t* ifile = &fs->inode_tab[file];
    if (ifile->type != FS_FILE) {
        dprintf("[fs_write] inode is not a file.\n");
        return -1;
    }

    if (offset > ifile->size) {
        offset = ifile->size;
    }

    unsigned *blk;

    int blks_used = OFFSET_TO_BLOCKS(ifile->size);
    int blks_req = MAX(OFFSET_TO_BLOCKS(offset+count), blks_used) - blks_used;

    dprintf("[fs_write] count=%d, offset=%d, fsize=%d, bused=%d, breq=%d\n",
            count,offset,ifile->size,blks_used,blks_req);

    if (blks_req > 0) {
        if(blks_req > INODE_NUM_BLKS-blks_used) {
            dprintf("[fs_write] no free block entries in inode.\n");
            return -1;
        }

        dprintf("[fs_write] required %d blocks, used %d\n", blks_req, blks_used);

        // check and reserve if there are free blocks
        for (int i = blks_used; i < blks_used + blks_req; i++) {
            if (i < INODE_NUM_BLKS)
                blk = &ifile->blocks[i];

            if (!fsi_bmap_find_free(fs->blk_bmap,block_num_blocks(fs->blocks),blk)) { // ITAB_SIZE
                dprintf("[fs_write] there are no free blocks.\n");
                return -1;
            }
            BMAP_SET(fs->blk_bmap, *blk);
            bfmap_add(fs->bfmap, *blk, file);
            dprintf("[fs_write] block %d allocated.\n", *blk);
        }
    }

    char block[BLOCK_SIZE];
    int num = 0, pos;
    int iblock = offset/BLOCK_SIZE;

    // write within the existent blocks
    while (num < count && iblock < blks_used) {
        if(iblock < INODE_NUM_BLKS) {
            blk = ifile->blocks;
            pos = iblock;
        }

        fsi_block_read(fs, BLOCK(ifile, pos), block);

        int start = ((num == 0) ? (offset % BLOCK_SIZE) : 0);
        for (int i = start; i < BLOCK_SIZE && num < count; i++, num++) {
            block[i] = buffer[num];
        }

        if (COW_ISSET(ifile, pos)) {
            if (!fsi_cow_replace(fs, file, pos)) {
                dprintf("[fs_write] error while writing cow block.\n");
                return -1;
            }
        }

        fsi_block_write(fs, blk[pos], block);
        iblock++;
    }

    dprintf("[fs_write] written %d bytes within.\n", num);

    // write within the allocated blocks
    while (num < count && iblock < blks_used + blks_req) {
        if(iblock < INODE_NUM_BLKS) {
            blk = ifile->blocks;
            pos = iblock;
        }

        for (int i = 0; i < BLOCK_SIZE && num < count; i++, num++) {
            block[i] = buffer[num];
        }

        fsi_block_write(fs, blk[pos], block);
        iblock++;
    }

    if (num != count) {
        printf("[fs_write] severe error: num=%d != count=%d!\n", num, count);
        exit(-1);
    }

    ifile->size = MAX(offset + count, ifile->size);

    // update the inode in disk
    fsi_store_fsdata(fs);

    dprintf("[fs_write] written %d bytes, file size %d.\n", count, ifile->size);
    return 0;
}


int fs_create(fs_t* fs, inodeid_t dir, char* file, inodeid_t* fileid) {
    if (fs == NULL || dir >= ITAB_SIZE || file == NULL || fileid == NULL) {
        printf("[fs_create] malformed arguments.\n");
        return -1;
    }

    if (strlen(file) == 0 || strlen(file)+1 > FS_MAX_FNAME_SZ) {
        dprintf("[fs_create] file name size error.\n");
        return -1;
    }

    if (!BMAP_ISSET(fs->inode_bmap, dir)) {
        dprintf("[fs_create] inode is not being used.\n");
        return -1;
    }

    fs_inode_t* idir = &fs->inode_tab[dir];
    if (idir->type != FS_DIR) {
        dprintf("[fs_create] inode is not a directory.\n");
        return -1;
    }

    if (fsi_dir_search(fs,dir,file,fileid) == 0) {
        dprintf("[fs_create] file already exists.\n");
        return -1;
    }

    int pos = idir->size/BLOCK_SIZE;
    // check if there are free inodes
    unsigned finode;
    if (!fsi_bmap_find_free(fs->inode_bmap, ITAB_SIZE, &finode)) {
        dprintf("[fs_create] there are no free inodes.\n");
        return -1;
    }

    // add a new block to the directory if necessary
    if (idir->size % BLOCK_SIZE == 0) {
        unsigned fblock;
        if (!fsi_bmap_find_free(fs->blk_bmap, block_num_blocks(fs->blocks), &fblock)) {
            dprintf("[fs_create] no free blocks to augment directory.\n");
            return -1;
        }
        BMAP_SET(fs->blk_bmap,fblock);
        idir->blocks[pos] = fblock;
        bfmap_add(fs->bfmap, idir->blocks[pos], dir);
    }

    // add the entry to the directory
    fs_dentry_t page[DIR_PAGE_ENTRIES];
    fsi_block_read(fs, BLOCK(idir, pos), (char*) page);
    fs_dentry_t* entry = &page[idir->size % BLOCK_SIZE / sizeof(fs_dentry_t)];
    strcpy(entry->name, file);
    entry->inodeid = finode;
    if (COW_ISSET(idir, pos)) {
        if (!fsi_cow_replace(fs, dir, pos)) {
            dprintf("[fs_write] error while writing cow block.\n");
            return -1;
        }
    }
    fsi_block_write(fs, idir->blocks[pos], (char*) page);
    idir->size += sizeof(fs_dentry_t);

    // reserve and init the new file inode
    BMAP_SET(fs->inode_bmap,finode);
    fsi_inode_init(&fs->inode_tab[finode],FS_FILE);

	ipmap_add(fs->ipmap, finode, dir, file);

    // save the file system metadata
    fsi_store_fsdata(fs);

    *fileid = finode;
    return 0;

}


int fs_mkdir(fs_t* fs, inodeid_t dir, char* newdir, inodeid_t* newdirid) {
    if (fs==NULL || dir>=ITAB_SIZE || newdir==NULL || newdirid==NULL) {
        printf("[fs_mkdir] malformed arguments.\n");
        return -1;
    }

    if (strlen(newdir) == 0 || strlen(newdir)+1 > FS_MAX_FNAME_SZ) {
        dprintf("[fs_mkdir] directory size error.\n");
        return -1;
    }

    if (!BMAP_ISSET(fs->inode_bmap,dir)) {
        dprintf("[fs_mkdir] inode is not being used.\n");
        return -1;
    }

    fs_inode_t* idir = &fs->inode_tab[dir];
    if (idir->type != FS_DIR) {
        dprintf("[fs_mkdir] inode is not a directory.\n");
        return -1;
    }

    if (fsi_dir_search(fs,dir,newdir,newdirid) == 0) {
        dprintf("[fs_mkdir] directory already exists.\n");
        return -1;
    }

    unsigned pos = idir->size / BLOCK_SIZE;
    // check if there are free inodes
    unsigned finode;
    if (!fsi_bmap_find_free(fs->inode_bmap, ITAB_SIZE, &finode)) {
        dprintf("[fs_mkdir] there are no free inodes.\n");
        return -1;
    }

    // add a new block to the directory if necessary
    if (idir->size % BLOCK_SIZE == 0) {
        unsigned fblock;
        if (!fsi_bmap_find_free(fs->blk_bmap, block_num_blocks(fs->blocks), &fblock)) {
            dprintf("[fs_mkdir] no free blocks to augment directory.\n");
            return -1;
        }
        BMAP_SET(fs->blk_bmap, fblock);
        idir->blocks[pos] = fblock;
        bfmap_add(fs->bfmap, idir->blocks[pos], dir);
    }

    // add the entry to the directory
    fs_dentry_t page[DIR_PAGE_ENTRIES];
    fsi_block_read(fs, BLOCK(idir, pos), (char*) page);
    fs_dentry_t* entry = &page[idir->size % BLOCK_SIZE / sizeof(fs_dentry_t)];
    strcpy(entry->name, newdir);
    entry->inodeid = finode;
    if (COW_ISSET(idir, pos)) {
        if (!fsi_cow_replace(fs, dir, pos)) {
            dprintf("[fs_write] error while writing cow block.\n");
            return -1;
        }
    }
    fsi_block_write(fs, idir->blocks[pos], (char*) page);
    idir->size += sizeof(fs_dentry_t);

    // reserve and init the new file inode
    BMAP_SET(fs->inode_bmap,finode);
    fsi_inode_init(&fs->inode_tab[finode], FS_DIR);

	ipmap_add(fs->ipmap, finode, dir, newdir);

    // save the file system metadata
    fsi_store_fsdata(fs);

    *newdirid = finode;
    return 0;
}


int fs_readdir(fs_t* fs, inodeid_t dir, fs_file_name_t* entries, int maxentries,
               int* numentries) {
    if (fs == NULL || dir >= ITAB_SIZE || entries == NULL ||
            numentries == NULL || maxentries < 0) {
        dprintf("[fs_readdir] malformed arguments.\n");
        return -1;
    }

    if (!BMAP_ISSET(fs->inode_bmap, dir)) {
        dprintf("[fs_readdir] inode is not being used.\n");
        return -1;
    }

    fs_inode_t* idir = &fs->inode_tab[dir];
    if (idir->type != FS_DIR) {
        dprintf("[fs_readdir] inode is not a directory.\n");
        return -1;
    }

    // fill in the entries with the directory content
    fs_dentry_t page[DIR_PAGE_ENTRIES];
    int num = MIN(idir->size / sizeof(fs_dentry_t), maxentries);
    int iblock = 0, ientry = 0;

    while (num > 0) {
        fsi_block_read(fs, BLOCK(idir, iblock++), (char*) page);
        for (int i = 0; i < DIR_PAGE_ENTRIES && num > 0; i++, num--) {
            strcpy(entries[ientry].name, page[i].name);
            entries[ientry].type = fs->inode_tab[page[i].inodeid].type;
            ientry++;
        }
    }
    *numentries = ientry;
    return 0;
}


void fs_dump(fs_t* fs) {
    printf("Free block bitmap:\n");
    fsi_dump_bmap(fs->blk_bmap, BLOCK_SIZE);
    printf("\n");

    printf("Free inode table bitmap:\n");
    fsi_dump_bmap(fs->inode_bmap, BLOCK_SIZE);
    printf("\n");
}

struct file_t{
	char name[FS_MAX_FNAME_SZ];
	char pathname[MAX_PATH_NAME_SIZE];
} file_t;

int fs_dumpcache(fs_t* fs){
	printf("===== Dump: Cache of Blocks Entries =======================\n");
	int i, j;
	// Para cada entrada da cache
    for (i = 0; i < BLKCACHE_NUM_ENTRIES; i++) {
		printf("Entry_N: %d\n", i);
		printf("V: %d\n",fs->cache.entries[i].V);
		printf("R: %d M: %d\n",fs->cache.entries[i].R, fs->cache.entries[i].M); 
		
		printf("Blk_Cnt:\n");
        for (j = 0; j < BLOCK_SIZE; j++) {
			printf("%x", fs->cache.entries[i].block_data[j]);
		}
		
		printf("\n");
		printf("=============[dump_cache]============\nLeitura bloco: \n");
        for (j = 0; j < BLOCK_SIZE; j++) {
			printf("%c", fs->cache.entries[i].block_data[j]);
		}
		printf("\n=====================================\n");
	}
	printf("************************************************************\n");
    return 0;
}


int fs_diskusage(fs_t* fs){
	bfmap_entry_t* entry; 
	char path[MAX_PATH_NAME_SIZE];
    char name[FS_MAX_FNAME_SZ];
    inodeid_t inodeid;

	printf("===== Dump: FileSystem Blocks =======================\n");

	bfmap_reset_iterator(fs->bfmap);
	// For each used block in the filesystem...
	while ((entry = bfmap_iterate(fs->bfmap)) != NULL) {
		printf("\nblk_id: %d\n", bfmap_entry_block_number(entry));

        // And for each inode using the block...
		bfmap_entry_reset_iterator(entry);
		while (bfmap_entry_iterate_inodeids(entry, &inodeid)){
			if (!ipmap_get(fs->ipmap, inodeid, path)) {
                dprintf("[fs_disk_usage] error getting path of inode %d\n", inodeid);
                return -1;
            }

            if (fsi_split_path(path, NULL, name) == -1) {
                dprintf("[fsi_get_filename] error parsing file path %s\n", path);
            }

            if (strlen(name) == 0) {
                printf("%s\n", path);
            } else {
                printf("%s : %s\n", name, path);
            }
		}
	}
	printf("\n*******************************************************\n");
    return 0;
}

int fs_remove(fs_t* fs, inodeid_t dir, char* file, inodeid_t* fileid) {
    if (fs == NULL || dir >= ITAB_SIZE || file == NULL || fileid == NULL) {
        printf("[fs_remove] malformed arguments.\n");
        return -1;
    }

    if (!BMAP_ISSET(fs->inode_bmap, dir)) {
        dprintf("[fs_remove] inode is not being used.\n");
        return -1;
    }
    
    fs_inode_t* idir = &fs->inode_tab[dir];

    if (idir->type != FS_DIR) {
        dprintf("[fs_remove] specified dir isn't a directory.\n");
        return -1;
    }

    inodeid_t file_id;

    fs_dentry_t page[DIR_PAGE_ENTRIES];
    int initial_dir_size = idir->size;
    int num = idir->size / sizeof(fs_dentry_t);
    int iblock = 0;
    int found = 0;
    int i;

    while (num > 0) {
        fsi_block_read(fs, BLOCK(idir, iblock), (char*)page);
        for (i = 0; i < DIR_PAGE_ENTRIES && num > 0; i++, num--) {
            if (strcmp(page[i].name, file) == 0) {
                /* Found file */
                file_id = page[i].inodeid;
                found = 1;
                break;
            }
        }

        if (found) break;
        iblock++;
    }

    if (!found) {
        dprintf("[fs_remove] specified file doesn't exist.\n");
        return -1;
    }

    printf("Found file to remove at position %d of block %d of dir %d\n", i, BLOCK(idir, iblock), dir);

    *fileid = file_id;
    fs_inode_t* ifile = &fs->inode_tab[file_id];

    /* Ter em atenção na remoção que se o bloco tiver Copy-On-Write a 1 e
     * existir outro ficheiro a utilizar o mesmo bloco (usar fsi_cow_search)
     * então não se pode libertar o bloco declarando-o como livre. */
    if (ifile->type == FS_DIR) { 
        if (ifile->size > 0) {
            dprintf("[fs_remove] specified directory isn't empty so we can't remove it.\n");
            return -1;
        }
    } 

    int blks_used = OFFSET_TO_BLOCKS(ifile->size);
    int j;
    int current_block;

    /* Set all blocks used by this file as free. */
    for (j = 0; j < blks_used; j++) {
        current_block = BLOCK(ifile, j);
        printf("[fs_remove] setting block %d used by removed file as free.\n", current_block);
        /* Unless they are Copy-on-Write and there are other inodes
         * referencing it. */
        if (COW_ISSET(ifile, j)) {
            if (fsi_cow_search(fs, current_block)) {
                printf("[fs_remove] block is used by other files so we won't set it as free.\n");
                bfmap_remove(fs->bfmap, current_block, file_id);
                continue;
            }
        }
        bfmap_remove(fs->bfmap, current_block, file_id);
        BMAP_CLR(fs->blk_bmap, current_block);
    } 

    fs_dentry_t new_page[DIR_PAGE_ENTRIES];
    
    /* Remove the entry from the directory and push all other entries up
     * to fill the empty space */
    while (num > 0) {
        for (; i < DIR_PAGE_ENTRIES - 1 && num > 0; i++, num--) {
            printf("[fs_remove] putting dentry %d in dentry %d\n", i+1, i);
            page[i].inodeid = page[i+1].inodeid;
            strcpy(page[i].name, page[i+1].name);
        }

        if (num > 0) {
            printf("[fs_remove] get next block %d\n", iblock + 1);
            fsi_block_read(fs, BLOCK(idir, iblock + 1), (char*) new_page);
            page[i].inodeid = new_page[0].inodeid;
            strcpy(page[i].name, new_page[0].name);
        }

        if (COW_ISSET(idir, iblock)) {
            if (!fsi_cow_replace(fs, dir, iblock)) {
                dprintf("[fs_remove] error while writing cow block.\n");
                return -1;
            }
        }

        fsi_block_write(fs, BLOCK(idir, iblock), (char*) page);

        memcpy(page, new_page, DIR_PAGE_ENTRIES);

        iblock++;
        i = 0;
    }

    idir->size -= sizeof(fs_dentry_t);

    /* Set inode used by the file as free. */
    BMAP_CLR(fs->inode_bmap, file_id);

    ipmap_remove(fs->ipmap, file_id);

    int initial_number_blocks = OFFSET_TO_BLOCKS(initial_dir_size);
    int final_number_blocks = OFFSET_TO_BLOCKS(idir->size);

    /* If the initial number of blocks is different from the final number of blocks
     * then that meands that the directory inode now uses one block less.
     * Therefore, if no other inodes use that block, we set it as free. */
    if (initial_number_blocks != final_number_blocks) {
        int last_block = BLOCK(idir, final_number_blocks);
        if (COW_ISSET(idir, final_number_blocks)) {
            if (fsi_cow_search(fs, last_block)) {
                return 0;
            }
        }
        BMAP_CLR(fs->blk_bmap, idir->blocks[final_number_blocks]);
        printf("I'm calling bfmap_remove on block %d\n", BLOCK(idir, final_number_blocks));
        bfmap_remove(fs->bfmap, BLOCK(idir, final_number_blocks), dir);
    }

    return 0;
}


int fs_append(fs_t* fs, inodeid_t dir1, char* name_file1, inodeid_t dir2, char* name_file2, int* filesize){
	if (fs == NULL || dir1 >= ITAB_SIZE || dir2 >= ITAB_SIZE || name_file1 == NULL || name_file2 == NULL || filesize == NULL) {
		printf("[fs_append] malformed arguments.\n");
        return -1;
	}
	
	inodeid_t fileid1;
	inodeid_t fileid2;
	
	if (fsi_dir_search(fs, dir1, name_file1, &fileid1) == -1 || fsi_dir_search(fs, dir2, name_file2, &fileid2) == -1) {
		printf("[fs_append] no such files in specified directories.\n");
		return -1;
	}

	fs_inode_t* ifile1 = &fs->inode_tab[fileid1];
	fs_inode_t* ifile2 = &fs->inode_tab[fileid2];

    char buffer[ifile2->size];
    int num_bytes_read;
    
    if (fs_read(fs, fileid2, 0, ifile2->size, buffer, &num_bytes_read) == -1)
		return -1;
	else {
		if (fs_write(fs, fileid1, ifile1->size, num_bytes_read, buffer) == -1) {
            dprintf("[fs_append] concatenation error.\n");
            return -1;
        }
		*filesize = ifile1->size;
        return 0;
	}
}

int fs_copy(fs_t* fs, inodeid_t src_dir, char* src_name, inodeid_t dst_dir, char* dst_name, inodeid_t *fileid) {
    if (fs == NULL || src_dir > ITAB_SIZE || src_name == NULL || dst_dir > ITAB_SIZE || dst_name == NULL || fileid == NULL) {
        dprintf("[fs_copy] malformed arguments.\n");
        return -1;
    }

    if (!BMAP_ISSET(fs->inode_bmap, src_dir)) {
        dprintf("[fs_copy] inode of source dir is not being used.\n");
        return -1;
    }

    if (!BMAP_ISSET(fs->inode_bmap, dst_dir)) {
        dprintf("[fs_copy] inode of destination dir is not being used.\n");
        return -1;
    }

    fs_inode_t* src_idir = &fs->inode_tab[src_dir];
    fs_inode_t* dst_idir = &fs->inode_tab[dst_dir];

    if (src_idir->type != FS_DIR) {
        dprintf("[fs_copy] source directory is not a directory.\n");
        return -1;
    }

    if (dst_idir->type != FS_DIR) {
        dprintf("[fs_copy] destination directory is not a directory.\n");
        return -1;
    }

    inodeid_t src_inodeid;
    inodeid_t dst_inodeid;

    if (fsi_dir_search(fs, src_dir, src_name, &src_inodeid) == -1) {
        dprintf("[fs_copy] source file doesn't exist.\n");
        return -1;
    }

    if (fsi_dir_search(fs, dst_dir, dst_name, &dst_inodeid) == 0) {
        dprintf("[fs_copy] destination file already exists.\n");
        return -1;
    }

    fs_inode_t *src_inode = &fs->inode_tab[src_inodeid];

    /* If source is a file, link all blocks of the new file to the blocks
     * of the old file with COW */
    if (src_inode->type == FS_FILE) {
        if (fs_create(fs, dst_dir, dst_name, &dst_inodeid) == -1) {
            dprintf("[fs_copy] failed to create a new file in the destination directory.\n");
            return -1;
        }

        fs_inode_t *dst_inode = &fs->inode_tab[dst_inodeid];

        int blks_used = OFFSET_TO_BLOCKS(src_inode->size);
        int i;

        for (i = 0; i < blks_used; i++) {
            dst_inode->blocks[i] = BLOCK(src_inode, i);
            printf("[fs_copy] copied block %d from source to destination\n", dst_inode->blocks[i]);
            bfmap_add(fs->bfmap, BLOCK(src_inode, i), dst_inodeid);
            COW_SET(src_inode, i);
            COW_SET(dst_inode, i);
        }

        dst_inode->size = src_inode->size;
    /* If it is a directory, create a new directory and copy each one of its files/folders. */
    } else {
        if (fs_mkdir(fs, dst_dir, dst_name, &dst_inodeid) == -1) {
            dprintf("[fs_copy] failed to create a new directory in the destination directory.\n");
            return -1;
        }

        fs_file_name_t children[DIR_PAGE_ENTRIES];
        int num_children;
        int i;
        inodeid_t fileid;

        if (fs_readdir(fs, src_inodeid, children, DIR_PAGE_ENTRIES, &num_children) == -1) {
            dprintf("[fs_copy] failed to read source directory.\n");
            return -1;
        }

        for (i = 0; i < num_children; i++) {
            if (fs_copy(fs, src_inodeid, children[i].name, dst_inodeid, children[i].name, &fileid) == -1) {
                dprintf("[fs_copy] error copying directory entries.\n");
                return -1;
            }
        }
    }

    return 0;
}

void fsi_defrag_block_inodes_update(fs_t* fs, bfmap_entry_t* entry1, unsigned int block1, \
                                    bfmap_entry_t* entry2, unsigned int block2) {
    inodeid_t inodeid;
    fs_inode_t *inode;
    int i, j, num_blocks;
    unsigned int current_block, old_block_cow;
    int num_inodes_entry1 = bfmap_entry_number_inodeids(entry1);
    inodeid_t* inodes_entry1 = (inodeid_t*) malloc(sizeof(inodeid_t)*num_inodes_entry1);

    j = 0;

    bfmap_entry_reset_iterator(entry1);
    while (bfmap_entry_iterate_inodeids(entry1, &inodeid))  {
        inode = &fs->inode_tab[inodeid];
        num_blocks = OFFSET_TO_BLOCKS(inode->size);

        for (i = 0; i < num_blocks; i++) {
            current_block = BLOCK(inode, i);
            old_block_cow = COW_ISSET(inode, i);

            if (current_block == block1) {
                inode->blocks[i] = block2;
                dprintf("[fsi_defrag_block_inodes_update] updated inode %d at pos %d. %d -> %d\n", inodeid, i, block1, block2);
            }
            else if (current_block == block2) {
                inode->blocks[i] = block1;
                dprintf("[fsi_defrag_block_inodes_update] updated inode %d at pos %d. %d -> %d\n", inodeid, i, block2, block1);
            }

            if (old_block_cow) {
                COW_SET(inode, i);
            }
        }

        inodes_entry1[j++] = inodeid;
    }

    int skip;

    bfmap_entry_reset_iterator(entry2);
    while (bfmap_entry_iterate_inodeids(entry2, &inodeid))  {
        skip = 0;

        for (j = 0; j < num_inodes_entry1; j++) {
            if (inodes_entry1[j] == inodeid) {
                skip = 1;
                break;
            }
        }

        if (skip) continue;

        inode = &fs->inode_tab[inodeid];
        num_blocks = OFFSET_TO_BLOCKS(inode->size);

        for (i = 0; i < num_blocks; i++) {
            current_block = BLOCK(inode, i);
            old_block_cow = COW_ISSET(inode, i);

            if (current_block == block1) {
                inode->blocks[i] = block2;
                dprintf("[fsi_defrag_block_inodes_update] updated inode %d at pos %d. %d -> %d\n", inodeid, i, block1, block2);
            }
            else if (current_block == block2) {
                inode->blocks[i] = block1;
                dprintf("[fsi_defrag_block_inodes_update] updated inode %d at pos %d. %d -> %d\n", inodeid, i, block2, block1);
            }

            if (old_block_cow) {
                COW_SET(inode, i);
            }
        }
    }
}

int fsi_defrag_block_swap(fs_t* fs, unsigned int block1, unsigned int block2) {
    if (block1 == block2) {
        return 0;
    }

    bfmap_entry_t* entry1 = bfmap_get(fs->bfmap, block1);
    bfmap_entry_t* entry2 = bfmap_get(fs->bfmap, block2);

    char block1_data[BLOCK_SIZE];
    char block2_data[BLOCK_SIZE];

    /* Read all data of occupied blocks to memory. */
    if (entry1 != NULL) {
        if (block_read(fs->blocks, block1, block1_data) == -1) {
            dprintf("[fsi_block_swap] error reading block 1 data.\n");
            return -1; 
        }
    } 

    if (entry2 !=  NULL) {
        if (block_read(fs->blocks, block2, block2_data) == -1) {
            dprintf("[fsi_defrag_block_swap] error reading block 2 data.\n");
            return -1; 
        }
    }

    /* Write all backed up data to the opposed blocks and update inode
     * references where needed. */
    if (entry1 != NULL) {
        if (block_write(fs->blocks, block2, block1_data) == -1) {
            dprintf("[fsi_defrag_block_swap] error writing block 1 data in block2.\n");
            return -1;
        }
        BMAP_SET(fs->blk_bmap, block2);

    } else {
        BMAP_CLR(fs->blk_bmap, block2);
    }

    if (entry2 != NULL) {
        if (block_write(fs->blocks, block1, block2_data) == -1) {
            dprintf("[fsi_defrag_block_swap] error writing block 2 data in block1.\n");
            return -1;
        }
        BMAP_SET(fs->blk_bmap, block1);
    } else {
        BMAP_CLR(fs->blk_bmap, block1);
    }
    
    fsi_defrag_block_inodes_update(fs, entry1, block1, entry2, block2);
    bfmap_swap_entries(fs->bfmap, block1, block2);

    return 0;
}

int fs_defrag(fs_t* fs) {
    if (fs == NULL) {
        dprintf("[fs_defrag] malformed paramenters.\n");
        return -1;
    }

    unsigned int current_block = ITAB_NUM_BLKS + 2;
    unsigned int target_block = 0;
    int i, j, number_blocks_inode;
    int total_used_blocks = bfmap_number_of_blocks(fs->bfmap);
    bfmap_entry_t* current_block_bfmap_entry;

    inodeid_t inodeid;
    fs_inode_t* inode;

    /* Clear the cache and make sure all modified blocks are written to disk.*/
    fsi_blkcache_clear(fs);

    /* While we've got used blocks left to position. */
    for (i = 0; i < total_used_blocks; i++) {
        target_block = 0;

        /* Iterate through all the empty blocks until we find a used one. */
        while ((current_block_bfmap_entry = bfmap_get(fs->bfmap, current_block)) == NULL) {
            /* If this was the first empty block we found, then it is our target
             * for the next block swap because we want blocks to be contiguous. */
            if (!target_block) {
                target_block = current_block;
            }
            current_block++;
        }

        /* If we didn't set a target block then we didn't even enter the while
         * which means that the first block we found had data. This block will
         * be the target then. */
        if (!target_block) {
            target_block = current_block;
        }


        bfmap_entry_reset_iterator(current_block_bfmap_entry);
        bfmap_entry_iterate_inodeids(current_block_bfmap_entry, &inodeid);
        inode = &fs->inode_tab[inodeid];
        number_blocks_inode = OFFSET_TO_BLOCKS(inode->size);

        dprintf("[fs_defrag] current_block: %d\ttarget_block: %d\n", current_block, target_block);

        for (j = 0; j < number_blocks_inode; j++) {
            current_block = BLOCK(inode, j);

            /* The only way this can happen is if this block is shared with COW with another file that was
             * already defragged. In that case we don't need to do anything. */
            if (current_block < target_block) {
                dprintf("[fs_defrag] block %d has already been swapped during this defrag (COW).\n", current_block);
                continue;
            }

            dprintf("[fs_defrag] swapping block %d with block %d.\n", current_block, target_block);

            /* Swap the block data on disk. */
            if (fsi_defrag_block_swap(fs, current_block, target_block) == -1) {
                printf("[fs_defrag] fatal error while swapping blocks %d -> %d\n", \
                        current_block, target_block);
                exit(-1);
            }

            /* The new target block is the block adjacent to the previous target block. */
            target_block++;
            /* We handled one used block so increment the i counter. */
            i++;
        }

        /* Start examining the disk from the block adjacent to the old target_block */
        current_block = target_block;
    }

    dprintf("[fs_defrag] complete\n");
    return 0;
}


