/* 
 * SNFS API Layer
 * 
 * test-copy
 *
 * Tests the SNFS services:
 * - create: creates a file
 * - write: writes data to a file 
 * - copy: makes a file copy
 * 
 * Atention: in current release, only the root directory exists
 * which corresponds to the file handler 1.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// the SNFS API interface
#include <snfs_api.h>


#ifndef CLIENT_SOCK
#define CLIENT_SOCK "/tmp/client.socket"
#endif

#ifndef SERVER_SOCK
#define SERVER_SOCK "/tmp/server.socket"
#endif

#define ROOT_FHANDLE 1

#define DATA_SIZE 1024


int main(int argc, char **argv)
{
   // initialize the SNFS API layer
   if (snfs_init(CLIENT_SOCK,SERVER_SOCK) < 0) {
      printf("[test] unable to initialize SNFS API.\n");
      return -1;
   } else {
      printf("[test] SNFS API initialized.\n");
   }

   // invoke the 'create' service to create file 'f1' in root dir
   snfs_fhandle_t file_fh;
   if (snfs_create(ROOT_FHANDLE,"f1",&file_fh) != STAT_OK) {
      printf("[test] error creating a file in server.\n");
      return -1;
   }
   printf("[test] file created with file handle %d.\n",file_fh);

   /*
    * do the 'write'
    */
   
   // build a string of 'A' chars
   char data[DATA_SIZE];
   for (int i = 0; i < DATA_SIZE-1; data[i] = 'A', i++);
   data[DATA_SIZE-1] = '\0';
   
   // invoke the 'write' service to write to file 'f1'
   unsigned fsize;
   if (snfs_write(file_fh,0,DATA_SIZE,data,&fsize) != STAT_OK) {
      printf("[test] error writing to file.\n");
      return -1;
   }

   // test if all data was written
   if (fsize != DATA_SIZE) {
      printf("[test] error: f1 sizes differ %d!=%d.\n",fsize,DATA_SIZE);
      return -1;
   }

   //copying "f1" to "f2"
   if (snfs_copy(ROOT_FHANDLE,"f1",ROOT_FHANDLE,"f2",&file_fh) != STAT_OK) {
      printf("[test] error copying a file.\n");
      return -1;
   }

   if (snfs_lookup("/f2", &file_fh, &fsize) != STAT_OK) {
       printf("[test] error: can't locate copied file\n");
       return -1;
   }

   if (fsize != DATA_SIZE) {
       printf("[test] error: f2 sizes differ %d!=%d.\n", fsize, DATA_SIZE);
       return -1;
   }

   char f2data[fsize];
   int numRead = 0;

   if (snfs_read(file_fh, 0, fsize, f2data, &numRead) != STAT_OK) {
       printf("[test] error: couldn't read f2.\n");
       return -1;
   }

   if (numRead != fsize) {
       printf("[test] error: read less than the file size: %d\n", numRead);
   }

   //printf("F1:\n%s\n\n", data);
   //printf("F2:\n%s\n", f2data);

   for (int i = 0; i < fsize; i++) {
       if (f2data[i] != data[i]) {
           printf("[test] error: files don't match.\n");
           return -1;
       }
   }
  
   printf("[test] copy successful to a file with file handle %d.\n",file_fh);

   char data2[DATA_SIZE/2];
   for (int i = 0; i < DATA_SIZE/2-1; data2[i] = 'B', i++);
   data2[DATA_SIZE/2-1] = '\0';

   if (snfs_write(file_fh, DATA_SIZE/2, DATA_SIZE/2, data2, &fsize) != STAT_OK) {
       printf("[test] error: error writing new data.\n");
       return -1;
   }

   if  (snfs_read(file_fh, 0, DATA_SIZE, f2data, &numRead) != STAT_OK) {
       printf("[test] error: error reading written data.\n");
       return -1;
   }

   printf("%s\n", f2data);

   for (int i = 0; i < DATA_SIZE/2; i++) {
       if (f2data[i] != 'A') {
        printf("[test] error: content mismatch A.\n");
        return -1;
       }
   }

   for (int i = DATA_SIZE/2; i < DATA_SIZE-1; i++) {
       if (f2data[i] != 'B') {
        printf("[test] error: content mismatch B.\n");
        return -1;
       }
   }

   if (snfs_append(ROOT_FHANDLE, "f2", ROOT_FHANDLE, "f1", &fsize) != STAT_OK) {
       printf("[test] error: concatenating files.\n");
       return -1;
   }

   char data3[fsize];
   printf("[test] concatenated file size %d versus %d\n", fsize, DATA_SIZE*2);

   int i = 0;
   
   while (i < fsize) {
       if (snfs_read(file_fh, i, 1024, &data3[i], &numRead) != STAT_OK) {
           printf("[test] error: reading concatenated file.\n");
           return -1;
       }

       i += numRead;
   }

   if (i != fsize) {
       printf("[test] error: concatenated file content size mismatch.\n");
       return -1;
   }

   for (i = 0; i < fsize; i++) {
       printf("%c", data3[i]);
   }

   printf("\n");

   //sleep(20);

   if (snfs_create(ROOT_FHANDLE,"f3",&file_fh) != STAT_OK) {
      printf("[test] error creating a file in server.\n");
      return -1;
   }
   printf("[test] file created with file handle %d.\n",file_fh);

   char data4[DATA_SIZE];
   for (int i = 0; i < DATA_SIZE-1; data4[i] = 'C', i++);
   data4[DATA_SIZE-1] = '\0';
   
   if (snfs_write(file_fh,0,DATA_SIZE,data4,&fsize) != STAT_OK) {
      printf("[test] error writing to file.\n");
      return -1;
   }

   int tempfileid;
   int temp_file_fh;
   if (snfs_remove(ROOT_FHANDLE, "f1", &tempfileid) != STAT_OK) {
       printf("[test] error removing f1.\n");
       return -1;
   }

   if (snfs_lookup("/f1", &temp_file_fh, &tempfileid) == STAT_OK) {
       printf("[test] removed file still exists.\n");
       return -1;
   }

   if (snfs_append(ROOT_FHANDLE, "f3", ROOT_FHANDLE, "f2", &fsize) != STAT_OK) {
       printf("[test] error appending files.\n");
       return -1;
   }

   
   i = 0;
   char data5[fsize];

   while (i < fsize) {
       if (snfs_read(file_fh, i, 1024, &data5[i], &numRead) != STAT_OK) {
           printf("[test] error: reading concatenated file.\n");
           return -1;
       }

       i += numRead;
   }

   for (i = 0; i < fsize; i++) {
       printf("%c", data5[i]);
   }

   printf("\n");
   sleep(5);

   if (snfs_defrag() != STAT_OK) {
       printf("[test] error defragging.\n");
       return -1;
   }

   printf("[test] PASSED.\n");
   
   return 0;
}
