#if !defined IPMAP_H_INCLUDE
#define IPMAP_H_INCLUDE

#include "fs.h"

typedef struct ipmap ipmap_t;

typedef struct ipmap_entry ipmap_entry_t;

ipmap_t* ipmap_create(int num_inodes);
void ipmap_add(ipmap_t* ipmap, inodeid_t inodeid, inodeid_t parentid, char* name);
void ipmap_remove(ipmap_t* ipmap, inodeid_t inodeid);
int ipmap_get(ipmap_t *ipmap, inodeid_t inodeid, char* path);
void ipmap_clear(ipmap_t* ipmap);


#endif
