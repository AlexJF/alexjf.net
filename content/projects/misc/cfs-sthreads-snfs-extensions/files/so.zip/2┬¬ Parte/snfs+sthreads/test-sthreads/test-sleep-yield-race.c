/* 
 * escalonamneto-08.c
 *
 * sthread_sleep test
 * 
 */


#include <stdio.h>
#include <stdlib.h>
#include <sthread.h>
#include <time.h>


void *thread0(void *);
void *thread1(void *);

int passed0;
int passed1;



int main(int argc, char **argv)
{
  int t;
  sthread_t t1;
  sthread_t t2;

  sthread_init();
    
  if ((t1 = sthread_create(thread0, (void*)1, 2)) == NULL) {
    printf("sthread_create failed\n");
    exit(-1);
  }
  if ((t2 = sthread_create(thread1, (void*)1, 5)) == NULL) {
    printf("sthread_create failed\n");
    exit(-1);
  }
    
  sthread_join(t1, &t);
  sthread_join(t2, &t);

  return 0;
}


void *thread0(void *arg)
{
  int i;

  for(i = 1; i < 10; i++){
    sthread_sleep(4000000);
    printf("%i sec\n", i*4);
  }

  passed0 = 1;

  return 0;
}

void *thread1(void *arg)
{
  int i;

  while(1) {
      sthread_yield();
  }

  passed1= 1;

  return 0;
}

