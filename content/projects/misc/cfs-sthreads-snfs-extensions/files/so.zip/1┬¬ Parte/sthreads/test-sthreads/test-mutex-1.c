/*
 * thread.c - counter thread
 */

#include <stdio.h>
#include <sthread.h>
#include <stdlib.h>

sthread_mutex_t Mutex;

int Counter = 0;

void* thr_inc_odd(void *ptr)
{
	while (1){
		sthread_mutex_lock(Mutex);
		if (Counter >= 20){
			sthread_mutex_unlock(Mutex);
			break;
		} else if (Counter % 2 != 0){
			Counter++;
			printf("[O] Counter= %d\n", Counter);
		}
		sthread_mutex_unlock(Mutex);
	}
	return NULL;
}


void* thr_inc_even(void* ptr)
{
	while (1){
		/*printf("\n\n\n\n\nIN THREVEN");
		sthread_dump();*/
		sthread_mutex_lock(Mutex);
		if (Counter >= 20){
            break;
		} else if (Counter % 2 == 0){
			Counter++;
			printf("[E] Counter= %d\n", Counter);
		}
		sthread_mutex_unlock(Mutex);

	}
	return NULL;
}

int main()
{
	sthread_init();
	Mutex = sthread_mutex_init();
	void* ret;
	
	sthread_t tid1, tid2;
	if ((tid1 = sthread_create(thr_inc_even, NULL, 1)) == NULL) {
		printf("Error creating thread 1.\n");
		return -1;
	}
	//printf("\n\n\n\n\nCRIADO THR2");
	//sthread_dump();
	if ((tid2 = sthread_create(thr_inc_odd, NULL, 1)) == NULL) {
		printf("Error creating thread 2.\n");
		return -1;
	}
	//printf("\n\n\n\n\nCRIADO THR3");
	//sthread_dump();
	
	printf("joining 1");
	if(sthread_join(tid1, &ret) != 0) {
		printf("Error joining thred 1.\n");
		return -1;
	}
	printf("joining 2");
	if(sthread_join(tid2, &ret) != 0) {
		printf("Error joining thred 2.\n");
		return -1;
	}


	printf("Finished: Counter=%d\n",Counter);
	return 0;
}
