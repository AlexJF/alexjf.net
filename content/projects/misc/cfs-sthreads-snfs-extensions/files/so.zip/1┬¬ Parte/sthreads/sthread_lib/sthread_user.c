/**
 * Implements the sthread API using user-level threads.
 *
 * @file sthread_user.c
 * @ingroup sthread_user
 */

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#include <sthread.h>
#include <sthread_user.h>
#include <sthread_ctx.h>
#include <sthread_time_slice.h>
#include <sthread_user.h>
#include "rbt.h"
#include "list.h"

typedef unsigned long long time;


/** Internal thread structure */
struct _sthread {
    /** The context of the thread. */
    sthread_ctx_t *saved_ctx;
    /** Arguments to pass to the starting routine. */
    void* args;
    /** The routine where the thread will start execution. */
    sthread_start_func_t start_routine_ptr;

    /** The total time the thread has ran */
    time runtime;
    /** 
     * The value used by the scheduler to choose the next
     * running thread. It is similar to runtime but takes
     * into account the thread's niceness and priority.
     */
    time vruntime;
    /** Total time the thread has been waiting for execution. */
    time waittime;
    /** Total time the thread has been waiting to join another one. */
    time jointime;
    /** Total time the thread has been blocked. */
    time blocktime;
    /** Total sleeping time of the thread. */
    time sleeptime;

    /** The thread's priority (0 - 10). */
    int priority;
    /** The thread's niceness (0 - 10). */
    int nice;

    /** The id of the thread this user is waiting to join. */
    int join_id;
    /** 
     * The value with which the thread exited to be passed to the
     * thread waiting to join with this one 
     */
    void* join_ret;

    /** The thread id */
    int id;

    /** Start time of execute */
    time start_time_run;
    /** Start time of entry into the red-black tree */
    time start_time_wait;
    /** Start time of waiting to join another thread. */
    time start_time_join;
    /** Start time of thread block */
    time start_time_block;
    /** Time when thread started sleeping */
    time start_time_sleep;
    /** Time when the thread should wake */
    time end_time_sleep;

    /** The mutex this thread currently owns. */
    sthread_mutex_t ownedMutex;
};

/**
 * The internal structure of a monitor
 */
struct _sthread_mon {
    /** The id of this monitor */
    int id;
    /** The mutex used internally by the monitor */
    sthread_mutex_t mutex;
    /** The list of threads blocked in this monitor */
    list_t* list;
};

/**
 * The internal structure of a mutex.
 */
struct _sthread_mutex {
    /** This variable represents the id of the mutex. */
    int id;
    /** This variable represents if the mutex is locked (1) or not (0). */
    lock_t l;
    /** This variable points to the thread that has locked the mutex (if any) */
    struct _sthread *thr;
    /** This variable points to a list of threads waiting for the mutex to unlock */
    list_t* list;
};

/** 
 * Executable threads list .
 * @todo Replace with a red and black tree.
 */
static rbt_t* exe_thr_rbt;
/** Dead threads list. */
static list_t* dead_thr_list;
/** Sleeping threads list. */
static rbt_t* sleep_thr_rbt;
/** Waiting for join threads list. */
static list_t* join_thr_list;
/** Zombie threads list. */
static list_t* zombie_thr_list;

/** A list of all live mutexes. */
static list_t* mutex_list;
/** A list of all live monitors. */
static list_t* monitor_list;

/** Currently active thread */
static struct _sthread* active_thr;
/** Thread ID generator (incremented on every thread creation) */
static int tid_gen;
/** Mutex ID generator (incremented on every mutex creation) */
static int mutid_gen;
/** Monitor ID generator (incremented on every mutex creation) */
static int monid_gen;

/** 
 * The dumb thread that prevents the application from closing when
 * there are no more executable threads but there are sleeping ones.
 */
static struct _sthread* dumb_thr;


/** Set the clock period to 0.01 seconds. */
#define CLOCK_TICK 10000
/** Set minimum ticks before preemption can occur. */
#define MINIMUM_TICKS_RUNNING 5

/**
 * Number of Clock ticks since the initialization of the thread
 * system.
 */
static time Clock;


/*********************************************************************/
/* Part 1: Creating and Scheduling Threads                           */
/*********************************************************************/


static struct _sthread* sthread_user_createDumbThread();
static void sthread_user_free(struct _sthread *thread);
static void sthread_user_freeThreadInList(void* item);
static void sthread_user_mutex_freeMutexInList(void* item);
static void sthread_user_monitor_freeMonitorInList(void* item);
static void tick_handler();
static void sthread_user_dispatcher(void);

/**
 * Function used by the RBT to compare vruntimes of 2 threads
 *
 * @param item1 A thread casted to void*
 * @param item2 A second thread casted to void*
 * 
 * @return 0 if item1->vruntime == item2->vruntime
 * @return 1 it item1->vruntime > item2->vruntime
 * @return -1 if item1->vruntime < item2->vruntime
 */
static int sthread_user_compareVRuntimes(void* item1, void* item2) {
    struct _sthread* thread1 = (struct _sthread*) item1;
    struct _sthread* thread2 = (struct _sthread*) item2;

    if (thread1 == NULL || thread2 == NULL) {
        return 0;
    }

    if (thread1->vruntime == thread2->vruntime) {
        return 0;
    }
    else if (thread1->vruntime > thread2->vruntime) {
        return 1;
    } 
    else {
        return -1;
    }
}

static int sthread_user_compareSleepTimeLeft(void* item1, void* item2) {
    struct _sthread* thread1 = (struct _sthread*) item1;
    struct _sthread* thread2 = (struct _sthread*) item2;

    if (thread1 == NULL || thread2 == NULL) {
        return 0;
    }

    if (thread1->end_time_sleep == thread2->end_time_sleep) {
        return 0;
    }
    else if (thread1->end_time_sleep > thread2->end_time_sleep) {
        return 1;
    } 
    else {
        return -1;
    }
}

/**
 * Exits the program but first clears all lists.
 *
 * Should be called when there are no more threads to
 * execute.
 */
static void sthread_user_terminateNicely() {
    printf("Cleaning lists...\n");
    rbt_delete(exe_thr_rbt, 1);
    rbt_delete(sleep_thr_rbt, 1);
    list_delete(dead_thr_list, 1);
    list_delete(join_thr_list, 1);
    list_delete(zombie_thr_list, 1);
    list_delete(mutex_list, 1);
    list_delete(monitor_list, 1);
    if (dumb_thr != NULL) {
        sthread_user_free(dumb_thr);
    }
    printf("Done! Exiting...\n");
    exit(0);
}

/**
 * This function puts one of the waiting threads as the
 * active one, without caring about the where the previous
 * active thread goes.
 *
 * NOTE: This function must be called between a splx(HIGH)
 * splx(LOW) pair.
 */
static void sthread_user_setNewActiveThread() {
    struct _sthread *old_thr = active_thr;
    old_thr->runtime += Clock - old_thr->start_time_run;
    old_thr->start_time_run = 0;
    active_thr = (struct _sthread*) rbt_pop(exe_thr_rbt);
    /* This happens when there are no more threads in the executable list.
     * The only way the program can expect to recover from this is if one
     * of the sleeping threads wakes. 
     * If there are indeed sleeping threads, create a dumb thread to keep
     * the program running while we wait for the sleeping threads to wake. */
    if (active_thr == NULL) {
        printf("Exec queue is empty!\n");
        if (rbt_getNumItems(sleep_thr_rbt) == 0) {
            printf("No sleeping threads...\n");
            sthread_user_terminateNicely();
        } else {
            printf("There are sleeping threads so lets start the dumb one.\n");
            active_thr = sthread_user_createDumbThread();
        }
    }
    active_thr->waittime += Clock - active_thr->start_time_wait;
    active_thr->start_time_wait = 0;
    active_thr->start_time_run = Clock;
    sthread_switch(old_thr->saved_ctx, active_thr->saved_ctx);
}

/**
 * A wrapper around the actual thread's start routine.
 *
 * This allows the passing of the parameters specified on thread
 * creation and automatic thread exiting.
 */
void sthread_aux_start(void) {
    splx(LOW);
    active_thr->start_routine_ptr(active_thr->args);
    sthread_user_exit((void*) 0);
}

/**
 * The dumb thread main routine.
 *
 * This allows the application to wait for a sleeping thread to wake when no
 * other threads are in execution/executable.
 */
void sthread_aux_startDumb(void) {
    splx(LOW);
    for(;;);
    sthread_user_exit((void*) 0);
}

void sthread_user_init(void) {
    exe_thr_rbt = rbt_create(sthread_user_compareVRuntimes, sthread_user_freeThreadInList);
    dead_thr_list = list_create(sthread_user_freeThreadInList);
    sleep_thr_rbt = rbt_create(sthread_user_compareSleepTimeLeft, sthread_user_freeThreadInList);
    join_thr_list = list_create(sthread_user_freeThreadInList);
    zombie_thr_list = list_create(sthread_user_freeThreadInList);

    mutex_list = list_create(sthread_user_mutex_freeMutexInList);
    monitor_list = list_create(sthread_user_monitor_freeMonitorInList);

    tid_gen = 1;
    mutid_gen = 1;
    monid_gen = 1;

    struct _sthread *main_thread = malloc(sizeof(struct _sthread));
    main_thread->start_routine_ptr = NULL;
    main_thread->args = NULL;
    main_thread->saved_ctx = sthread_new_blank_ctx();
    main_thread->runtime = 0;
    main_thread->vruntime = 0;
    main_thread->waittime = 0;
    main_thread->jointime = 0;
    main_thread->blocktime = 0;
    main_thread->sleeptime = 0;
    main_thread->priority = 1;
    main_thread->nice = 0;
    main_thread->start_time_run = 1;
    main_thread->start_time_wait = 0;
    main_thread->start_time_join = 0;
    main_thread->start_time_block = 0;
    main_thread->start_time_sleep = 0;
    main_thread->end_time_sleep = 0;
    main_thread->join_id = 0;
    main_thread->join_ret = NULL;
    main_thread->id = tid_gen++;
    main_thread->ownedMutex = NULL;

    active_thr = main_thread;
    dumb_thr = NULL;

    Clock = 1;
    sthread_time_slices_init(tick_handler, CLOCK_TICK);
}


sthread_t sthread_user_create(sthread_start_func_t start_routine, void *arg, int priority) {
    struct _sthread *lowestThread = NULL;
    struct _sthread *new_thread = (struct _sthread*)malloc(sizeof(struct _sthread));
    sthread_ctx_start_func_t func = sthread_aux_start;
    new_thread->args = arg;
    new_thread->start_routine_ptr = start_routine;
    new_thread->runtime = 0;
    lowestThread = (struct _sthread*) rbt_getLowestItem(exe_thr_rbt);
    if (lowestThread == NULL) {
        new_thread->vruntime = active_thr->vruntime;
    } else {
        new_thread->vruntime = lowestThread->vruntime;
    }
    new_thread->waittime = 0;
    new_thread->sleeptime = 0;
    new_thread->jointime = 0;
    new_thread->blocktime = 0;
    new_thread->priority = priority;
    new_thread->nice = 0;
    new_thread->join_id = 0;
    new_thread->join_ret = NULL;
    new_thread->saved_ctx = sthread_new_ctx(func);
    new_thread->start_time_run = 0;
    new_thread->start_time_wait = 1;
    new_thread->start_time_join = 0;
    new_thread->start_time_block = 0;
    new_thread->start_time_sleep = 0;
    new_thread->end_time_sleep = 0;
    new_thread->ownedMutex = NULL;

    splx(HIGH);
    new_thread->id = tid_gen++;
    rbt_insert(exe_thr_rbt, new_thread);
    splx(LOW);
    return new_thread;
}

/**
 * This function creates (or returns a previously created)
 * dumb thread that keeps the program running if there are no
 * more executable threads but there are sleeping ones.
 *
 * @return The dumb thread (new or previously created).
 */
static sthread_t sthread_user_createDumbThread() {
    if (dumb_thr != NULL) {
        return dumb_thr;
    }

    dumb_thr = (struct _sthread*)malloc(sizeof(struct _sthread));
    sthread_ctx_start_func_t func = sthread_aux_startDumb;
    dumb_thr->args = NULL;
    dumb_thr->start_routine_ptr = NULL;
    dumb_thr->runtime = 0;
    dumb_thr->vruntime = 0;
    dumb_thr->waittime = 0;
    dumb_thr->sleeptime = 0;
    dumb_thr->jointime = 0;
    dumb_thr->blocktime = 0;
    dumb_thr->priority = 10;
    dumb_thr->nice = 0;
    dumb_thr->join_id = 0;
    dumb_thr->join_ret = NULL;
    dumb_thr->saved_ctx = sthread_new_ctx(func);
    dumb_thr->start_time_run = 0;
    dumb_thr->start_time_wait = 0;
    dumb_thr->start_time_join = 0;
    dumb_thr->start_time_block = 0;
    dumb_thr->start_time_sleep = 0;
    dumb_thr->end_time_sleep = 0;
    dumb_thr->ownedMutex = NULL;

    dumb_thr->id = 0;
    return dumb_thr;
}


void sthread_user_exit(void *ret) {
    splx(HIGH);

    int is_zombie = 1;
    struct _sthread *thread = NULL;

    /* Search for threads waiting to join on the active one.
     * If one is found, make it executable */
    list_resetIterator(join_thr_list);
    while ((thread = (struct _sthread*) list_iterate(join_thr_list)) != NULL) {
        if (thread->join_id == active_thr->id) {
            /* Save the return of the active thread in the
             * waiting one */
            thread->join_ret = ret;
            thread->jointime += Clock - thread->start_time_join;
            thread->start_time_join = 0;
            thread->start_time_wait = Clock;
            list_removeIteratedItem(join_thr_list, 0);
            rbt_insert(exe_thr_rbt, thread);
            /* If we woke all threads waiting to join on this one,
             * it will not become a zombie. */
            is_zombie = 0;
        }
    }

    if (is_zombie) {
        /* If this thread is to become a zombie, insert it in the zombie
         * list (in the last position) */
        list_insertLast(zombie_thr_list, active_thr);
    } else {
        /* Else insert it in the dead list. */
        list_insertLast(dead_thr_list, active_thr);
    }

    /* If this thread was inside a mutex then unlock the mutex. */
    if (active_thr->ownedMutex != NULL) {
        sthread_user_mutex_unlock(active_thr->ownedMutex);
    }


    /* Try setting a new active thread. If it isn't possible
     * the function will automatically call terminateNicely. */
    sthread_user_setNewActiveThread();

    splx(LOW);
}


static void tick_handler() {
    struct _sthread* sleep_thr = NULL;    
    splx(HIGH);

    Clock++;

    /* As we update vruntime every tick, the tick delta is always 1 */
    active_thr->vruntime += (active_thr->priority + active_thr->nice);

    rbt_resetIterator(sleep_thr_rbt);
    while ((sleep_thr = (struct _sthread*) rbt_getLowestItem(sleep_thr_rbt)) != NULL) {
        /* Since sleep rbt is ordered by end_time_sleep, if the first doesnt verify
         * end_time_sleep == Clock no other does. */
        if (sleep_thr->end_time_sleep > Clock) {
            break;
        }
        else if (sleep_thr->end_time_sleep == Clock) {
            sleep_thr->sleeptime += Clock - sleep_thr->start_time_sleep;
            sleep_thr->start_time_sleep = 0;
            sleep_thr->end_time_sleep = 0;
            sleep_thr->start_time_wait = Clock;
            rbt_pop(sleep_thr_rbt);
            rbt_insert(exe_thr_rbt, sleep_thr);
        }
    }

    sthread_user_dispatcher();
    splx(LOW);
}

/**
 * Checks if we need to preemptively switch threads and manages
 * sleeping threads.
 *
 * @ingroup sthread_user
 */
static void sthread_user_dispatcher() {
    struct _sthread* next_thr = NULL;
    time time_running = 0;

    /* Get the waiting thread with the lowest vruntime */
    next_thr = rbt_getLowestItem(exe_thr_rbt);

    /* If no such thread exists, the active one is the only
     * thread running */
    if (next_thr == NULL) {
        return;
    }

    time_running = Clock - active_thr->start_time_run;

    /* Else check if we can (and should) preempt the running thread */
    if (time_running > MINIMUM_TICKS_RUNNING && active_thr->vruntime > next_thr->vruntime) {
        /* If the active thread isn't the dumb thread, yield */
        if (active_thr->id != 0) {
            sthread_user_yield();
        /* If it is the dumb thread we don't want to put the dumb
         * thread in the executable rbt so we just set a new active
         * thread without yielding */
        } else {
            int previous = splx(HIGH);
            sthread_user_setNewActiveThread();
            splx(previous);
        }
    }
}
   
void sthread_user_yield() {
    splx(HIGH);
    active_thr->start_time_wait = Clock; 	
    rbt_insert(exe_thr_rbt, active_thr);
    sthread_user_setNewActiveThread();
    splx(LOW);
}



/**
 * Frees the specified thread and all its resources.
 *
 * @param thread The thread to free.
 * @ingroup sthread_user
 */
static void sthread_user_free(struct _sthread *thread) {
    sthread_free_ctx(thread->saved_ctx);
    free(thread);
}

void sthread_user_freeThreadInList(void* item) {
    struct _sthread* thread = (struct _sthread*) item;
    sthread_user_free(thread);
}


/*********************************************************************/
/* Part 2: Join and Sleep Primitives                                 */
/*********************************************************************/

int sthread_user_join(sthread_t thread, void **value_ptr) {
    /* suspends execution of the calling thread until the target thread
       terminates, unless the target thread has already terminated.
       On return from a successful pthread_join() call with a non-NULL
       value_ptr argument, the value passed to pthread_exit() by the
       terminating thread is made available in the location referenced
       by value_ptr. When a pthread_join() returns successfully, the
       target thread has been terminated. The results of multiple
       simultaneous calls to pthread_join() specifying the same target
       thread are undefined. If the thread calling pthread_join() is
       canceled, then the target thread will not be detached.

       If successful, the pthread_join() function returns zero.
       Otherwise, an error number is returned to indicate the error. */


    splx(HIGH);
    int found = 0;
    struct _sthread* zthread = NULL;
    struct _sthread* ethread = NULL;
    struct _sthread* sthread = NULL;
    struct _sthread* jthread = NULL;

    list_resetIterator(zombie_thr_list);

    /* Checks if the thread to wait for is already zombie */
    while ((zthread = (struct _sthread*) list_iterate(zombie_thr_list)) != NULL) {
        /* If it is, put the zombie thread in the dead list and exit */
        if (thread->id == zthread->id) {
            *value_ptr = zthread->join_ret;
            list_removeIteratedItem(zombie_thr_list, 0);
            list_insertLast(dead_thr_list, zthread);
            splx(LOW);
            return 0;
        }
    }

    /* If thread to join with is the active thread */
    if (active_thr->id == thread->id) {
        found = 1;
    }

    if (!found) {
        /* Search waiting threads */
        rbt_resetIterator(exe_thr_rbt);
        while ((ethread = rbt_iterate(exe_thr_rbt)) != NULL) {
            if (ethread->id == thread->id) {
                found = 1;
                break;
            }
        }
    }

    if (!found) {
        /* Search sleeping threads */
        rbt_resetIterator(sleep_thr_rbt);
        while ((sthread = (struct _sthread*) rbt_iterate(sleep_thr_rbt)) != NULL) {
            if (sthread->id == thread->id) {
                found = 1;
                break;
            }
        }
    }

    if (!found) {
        /* Search joining threads */
        list_resetIterator(join_thr_list);
        while ((jthread = (struct _sthread*) list_iterate(join_thr_list)) != NULL) {
            if (jthread->id == thread->id) {
                found = 1;
                break;
            }
        }
    }

    if (!found) {
        sthread_mutex_t mutex = NULL;
        /* Search threads in mutexes */
        list_resetIterator(mutex_list);
        while ((mutex = (sthread_mutex_t) list_iterate(mutex_list)) != NULL) {
            struct _sthread* mutthread = NULL;
            list_resetIterator(mutex->list);
            while ((mutthread = (struct _sthread*) list_iterate(mutex->list)) != NULL) {
                if (mutthread->id == thread->id) {
                    found = 1;
                    break;
                }
            }
        }
    }

    if (!found) {
        sthread_mon_t mon = NULL;
        /* Search threads in monitors */
        list_resetIterator(mutex_list);
        while ((mon = (sthread_mon_t) list_iterate(monitor_list)) != NULL) {
            struct _sthread* monthread = NULL;
            list_resetIterator(mon->list);
            while ((monthread = (struct _sthread*) list_iterate(mon->list)) != NULL) {
                if (monthread->id == thread->id) {
                    found = 1;
                    break;
                }
            }

            list_resetIterator(mon->mutex->list);
            while ((monthread = (struct _sthread*) list_iterate(mon->mutex->list)) != NULL) {
                if (monthread->id == thread->id) {
                    found = 1;
                    break;
                }
            }
        }
    }

    /* If we haven't found the thread... */
    if (!found) {
        splx(LOW);
        return -1;
    /* If we found it, block until it dies */
    } else {
        active_thr->join_id = thread->id;
        active_thr->start_time_join = Clock;
        list_insertLast(join_thr_list, active_thr);

        sthread_user_setNewActiveThread();
        *value_ptr = thread->join_ret;
    }

    splx(LOW);
    return 0;
}




/* minimum sleep time of 1 clocktick.
  1 clock tick, value 10 000 = 10 ms */
int sthread_user_sleep(int sleeptime) {
    splx(HIGH);

    time num_ticks = sleeptime / CLOCK_TICK;

    /* If we are sleeping for 0 ticks, there's no point in sleeping */
    if (num_ticks == 0) {
        splx(LOW);
        return 0;
    }

    active_thr->start_time_sleep = Clock;
    active_thr->end_time_sleep = Clock + num_ticks;

    rbt_insert(sleep_thr_rbt, active_thr);
    sthread_user_setNewActiveThread();

    splx(LOW);
    return 0;
}

/* ------------------------------------------------------------
 * Nice setting
 * ------------------------------------------------------------ */
int sthread_user_nice(int nice) {
    if (nice >= 0 && nice <= 10) {
        active_thr->nice = nice;
    }
    return active_thr->priority + active_thr->nice;
}

/**
 * Prints all relevant thread info to the terminal.
 *
 * @param thread The thread with the info we want to print.
 */
static void sthread_user_printThreadInfo(struct _sthread* thread) {
    time updatedBlockTime = thread->blocktime;
    if (thread->start_time_block != 0) {
        updatedBlockTime += Clock - thread->start_time_block;
    }

    time updatedJoinTime = thread->jointime;
    if (thread->start_time_join != 0) {
        updatedJoinTime += Clock - thread->start_time_join;
    }

    time updatedSleepTime = thread->sleeptime;
    if (thread->start_time_sleep != 0) {
        updatedSleepTime += Clock - thread->start_time_sleep;
    }

    time updatedRunTime = thread->runtime;
    if (thread->start_time_run != 0) {
        updatedRunTime += Clock - thread->start_time_run;
    }

    time updatedWaitTime = thread->waittime;
    if (thread->start_time_wait != 0) {
        updatedWaitTime += Clock - thread->start_time_wait;
    }
    
    printf("id: %d\n", thread->id);
    printf("priority: %d\n", thread->priority);
    printf("vruntime: %lld\n", thread->vruntime);
    printf("runtime: %lld\n", updatedRunTime);
    printf("sleeptime: %lld\n", updatedBlockTime + updatedJoinTime + updatedSleepTime);
    printf("waittime: %lld\n\n", updatedWaitTime);
}

/**
 * Iterates through all the threads in a thread list and
 * prints their info.
 *
 * @param threadList The list of threads whose info we want to print.
 */
static void sthread_user_printThreadList(list_t* threadList) {
    struct _sthread* thread = NULL;
    list_resetIterator(threadList);

    while ((thread = (struct _sthread*) list_iterate(threadList)) != NULL) {
        sthread_user_printThreadInfo(thread);
    }
}

/**
 * Iterates through all the threads in a thread rbt and
 * prints their info.
 *
 * @param threadRBT The rbt of threads whose info we want to print.
 */
static void sthread_user_printThreadRBT(rbt_t* threadRBT) {
    struct _sthread* thread = NULL;
    rbt_resetIterator(threadRBT);

    while ((thread = (struct _sthread*) rbt_iterate(threadRBT)) != NULL) {
        sthread_user_printThreadInfo(thread);
    }
}

void sthread_user_dump() {
    splx(HIGH);
    printf("\n\n\n=== dump start ===\n");
    printf("active thread\n");
	sthread_user_printThreadInfo(active_thr);

    printf(">>>> RB-Tree <<<<\n");
    sthread_user_printThreadRBT(exe_thr_rbt);

    printf(">>>>SleepList<<<<\n");  
    sthread_user_printThreadRBT(sleep_thr_rbt);

    printf(">>>>BlockedList<<<<\n");

    sthread_mutex_t mutex = NULL;
    list_resetIterator(mutex_list);

    while ((mutex = (sthread_mutex_t) list_iterate(mutex_list)) != NULL) {
        printf("Mutex (ID: %d)\n------\n", mutex->id);
        sthread_user_printThreadList(mutex->list);
    }

    sthread_mon_t monitor = NULL;
    list_resetIterator(monitor_list);

    while ((monitor = (sthread_mon_t) list_iterate(monitor_list)) != NULL) {
        printf("Monitor (ID: %d)\n------\n", monitor->id);
        sthread_user_printThreadList(monitor->list);
        printf("Monitor (ID: %d) Mutex:\n-----\n", monitor->id);
        sthread_user_printThreadList(monitor->mutex->list);
    }

    printf("=== Dump End ===\n\n\n");
    splx(LOW);
}

/* --------------------------------------------------------------------------*
 * Synchronization Primitives                                                *
 * ------------------------------------------------------------------------- */

/*
 * Mutex implementation
 */

/**
 * This function creates as new mutex.
 *
 * It should be used internally only. It doesn't care where
 * the mutex will be put (in a list or in a monitor).
 * 
 * @return The created mutex.
 */
static sthread_mutex_t sthread_user_mutex_create() {
    sthread_mutex_t lock;

    if(!(lock = malloc(sizeof(struct _sthread_mutex)))) {
        printf("Error in creating mutex\n");
        return NULL;
    }

    /* mutex initialization */
    splx(HIGH);
    lock->id = mutid_gen++;
    splx(LOW);
    lock->l= 0;
    lock->thr = NULL;
    lock->list = list_create(sthread_user_freeThreadInList);

    return lock;
}

sthread_mutex_t sthread_user_mutex_init() {
    sthread_mutex_t lock;

    lock = sthread_user_mutex_create();

    if (lock == NULL) {
        return NULL;
    }

    /* Put mutex in mutex list */
    list_insertLast(mutex_list, lock);

    return lock;
}

/**
 * This function effectively destroys and frees the provided mutex.
 *
 * It should be used internally only to free a mutex independently
 * of its location (in the mutex list or in a monitor).
 *
 * @param lock The mutex to destroy.
 */
static void sthread_user_mutex_destroy(sthread_mutex_t lock) {
    if (lock == NULL) {
        return;
    }

    list_delete(lock->list, 1);
    free(lock);
}

/**
 * This function should be passed to a mutex list
 * as its free function.
 *
 * It is a wrapper around #sthread_user_mutex_destroy necessary
 * because lists use void*.
 *
 * @param item A pointer to a mutex on the list (cast to void*)
 */
static void sthread_user_mutex_freeMutexInList(void* item) {
    sthread_user_mutex_destroy((sthread_mutex_t) item);
}

/* Since every user-created mutex will be added to the list, this
 * function simply finds the mutex in the list and removes it.
 * The list already knows how to deal with the freeing of a mutex
 * (see function above).
 */
void sthread_user_mutex_free(sthread_mutex_t lock) {
    sthread_mutex_t mutex;

    int previous = splx(HIGH);
    list_resetIterator(mutex_list);
    while ((mutex = (sthread_mutex_t) list_iterate(mutex_list)) != NULL) {
        if (mutex->id == lock->id) {
            /* Since free = 1, the list will automatically perform
             * the freeing. */
            list_removeIteratedItem(mutex_list, 1);
            break;
        }
    }
    splx(previous);
}

void sthread_user_mutex_lock(sthread_mutex_t lock) {
    /* Try to gain ownership of the mutex object 
     * (Not the critical section) */
    while (atomic_test_and_set(&(lock->l))) {}

    /* If we got here, and lock->thr is NULL then we are clear
     * to enter the critical section and lock the mutex. */
    if(lock->thr == NULL) {
        lock->thr = active_thr;
        active_thr->ownedMutex = lock;

        atomic_clear(&(lock->l));
    /* If there's a thread running inside the mutex then we'll
     * have to wait until it unlocks the mutex */
    } else {
        active_thr->start_time_block = Clock;
        list_insertLast(lock->list, active_thr);

        atomic_clear(&(lock->l));

        int previous = splx(HIGH);
        sthread_user_setNewActiveThread();
        splx(previous);
    }
}

void sthread_user_mutex_unlock(sthread_mutex_t lock) {
    /* If the thread inside the lock isn't the same one
     * as the active thread, then the active thread is trying
     * to unlock a lock it hadn't locked itself. */
    if (lock->thr != active_thr) {
        printf("unlock without lock!\n");
        return;
    }

    /* Try to gain ownership of the mutex object 
     * (Not the critical section) */
    while(atomic_test_and_set(&(lock->l))) {}

    /* If there are no threads waiting for the mutex unlock 
     * leave the mutex withouth any running thread. */
    if (list_getNumItems(lock->list) == 0) {
        lock->thr = NULL;
    /* If there are threads waiting for the mutex unlock, put one
     * of them in the mutex. */
    } else {
        lock->thr = list_pop(lock->list);
        lock->thr->ownedMutex = lock;
        lock->thr->blocktime += Clock - lock->thr->start_time_block;
        lock->thr->start_time_block = 0;
        lock->thr->start_time_wait = Clock;
        rbt_insert(exe_thr_rbt, lock->thr);
    }

    active_thr->ownedMutex = NULL;

    atomic_clear(&(lock->l));
    sthread_user_dispatcher();
}

/*
 * Monitor implementation
 */


sthread_mon_t sthread_user_monitor_init() {
    sthread_mon_t mon;
    if(!(mon = malloc(sizeof(struct _sthread_mon)))) {
        printf("Error creating monitor\n");
        return 0;
    }

    splx(HIGH);
    mon->id = monid_gen++;
    splx(LOW);
    /* Create a new mutex but don't use #sthread_user_mutex_init
     * because we dont' want to add it to the global mutex list. */
    mon->mutex = sthread_user_mutex_create();
    mon->list = list_create(sthread_user_freeThreadInList);

    list_insertLast(monitor_list, mon);

    return mon;
}

void sthread_user_monitor_freeMonitorInList(void* item) {
    sthread_mon_t mon = (sthread_mon_t) item;
    /* Use #sthread_user_mutex_destroy instead of #sthread_user_mutex_free
     * because the mutex wasn't added to the global list. */
    sthread_user_mutex_destroy(mon->mutex);
    list_delete(mon->list, 1);
    free(mon);
}

void sthread_user_monitor_free(sthread_mon_t mon) {
    sthread_mon_t monitor;

    int previous = splx(HIGH);
    list_resetIterator(monitor_list);
    
    while ((monitor = (sthread_mon_t) list_iterate(monitor_list)) != NULL) {
        if (mon->id == monitor->id) {
            /* Since free = 1, the list will automatically perform
             * the freeing. */
            list_removeIteratedItem(monitor_list, 1);
            break;
        }
    }
    splx(previous);
}

void sthread_user_monitor_enter(sthread_mon_t mon) {
    sthread_user_mutex_lock(mon->mutex);
}

void sthread_user_monitor_exit(sthread_mon_t mon) {
    sthread_user_mutex_unlock(mon->mutex);
}

void sthread_user_monitor_wait(sthread_mon_t mon) {
    /* If the thread currently inside the monitor critical
     * section wasn't the one that called wait, then some
     * other thread tried to call wait on a monitor it 
     * doesn't control */
    if (mon->mutex->thr != active_thr) {
        printf("monitor wait called outside monitor\n");
        return;
    }

    splx(HIGH);
    active_thr->start_time_block = Clock;
    /* inserts thread in list of blocked threads */
    list_insertLast(mon->list, active_thr);

    /* exits mutual exclusion region */
    sthread_user_mutex_unlock(mon->mutex);

    sthread_user_setNewActiveThread();
    splx(LOW);
}

void sthread_user_monitor_signal(sthread_mon_t mon) {
    struct _sthread *temp;

    if (mon->mutex->thr != active_thr) {
        printf("monitor signal called outside monitor\n");
        return;
    }

    /* Try to obtain ownership of the monitor's mutex object 
     * (not the critical section) */
    while (atomic_test_and_set(&(mon->mutex->l))) {}

    /* If there are threads queued in the monitor... */
    if (list_getNumItems(mon->list) > 0) {
        /* Wake one from the monitor and have it 
         * queue at the mutex */
        temp = list_pop(mon->list);
        list_insertLast(mon->mutex->list, temp);
    }
    atomic_clear(&(mon->mutex->l));
}

void sthread_user_monitor_signalall(sthread_mon_t mon) {
    struct _sthread *temp;

    if (mon->mutex->thr != active_thr) {
        printf("monitor signalall called outside monitor\n");
        return;
    }

    /* Try to obtain ownership of the monitor's mutex object 
     * (not the critical section) */
    while(atomic_test_and_set(&(mon->mutex->l))) {}

    while(list_getNumItems(mon->list) != 0) {
        /* changes blocking queue for thread */
        temp = list_pop(mon->list);
        list_insertLast(mon->mutex->list, temp);
    }
    atomic_clear(&(mon->mutex->l));
}


/* The following functions are dummies to
 * highlight the fact that pthreads do not
 * include monitors.
 */

sthread_mon_t sthread_dummy_monitor_init() {
    printf("WARNING: pthreads do not include monitors!\n");
    return NULL;
}


void sthread_dummy_monitor_free(sthread_mon_t mon) {
    printf("WARNING: pthreads do not include monitors!\n");
}


void sthread_dummy_monitor_enter(sthread_mon_t mon) {
    printf("WARNING: pthreads do not include monitors!\n");
}


void sthread_dummy_monitor_exit(sthread_mon_t mon) {
    printf("WARNING: pthreads do not include monitors!\n");
}


void sthread_dummy_monitor_wait(sthread_mon_t mon) {
    printf("WARNING: pthreads do not include monitors!\n");
}


void sthread_dummy_monitor_signal(sthread_mon_t mon) {
    printf("WARNING: pthreads do not include monitors!\n");
}

void sthread_dummy_monitor_signalall(sthread_mon_t mon) {
    printf("WARNING: pthreads do not include monitors!\n");
}

