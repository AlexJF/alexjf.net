/**
 * Interface for the #strhead_ctx_t Abstract Data Type.
 *
 * This is only used internally by sthread, not by the applications
 * directly.
 *
 * @file sthread_ctx.h
 * @ingroup sthread_ctx
 */

#ifndef STHREAD_CTX_H
#define STHREAD_CTX_H 1

#include <sthread.h>

/**
 * @internal
 * @defgroup sthread_ctx Thread Context
 *
 * This group is for internal sthread use only.
 * It is responsible for providing an interface around
 * the #sthrhead_ctx_t data type.
 *
 * @{
 */
/** Struct responsible for the thread context (stack). */
typedef struct _sthread_ctx {
    /** Pointer to the base of the stack */
    char *stackbase; 
    /**
     * Pointer to current stack position. 
     *
     * Initialized to stackbase+STACK_SIZE.
     */
    char *sp;       
} sthread_ctx_t;

typedef void (*sthread_ctx_start_func_t)(void);

/**
 * Create a new thread context and initialize it according to func
 *
 * @param func The function that is initially loaded into the
 *        thread context. This function is responsible for 
 *        calling the actual thread start function and for 
 *        exiting the thread when the said function returns.
 * @return The new thread context.
 */
sthread_ctx_t *sthread_new_ctx(sthread_ctx_start_func_t func);

/**
 * Create a new blank thread context.
 *
 * This new #streadh_ctx_t is suitable for use as 'old' in a call
 * to #sthread_switch, since it is defined to overwrite 'old'.
 * It should not be used as 'new' until it has been initialized.
 *
 * @return The new blank thread context.
 */
sthread_ctx_t *sthread_new_blank_ctx();

/**
 * Free the resources used by the given thread context.
 *
 * The passed context should not be the currently active context.
 */
void sthread_free_ctx(sthread_ctx_t *ctx);

/**
 * Switches the active context, saving it in #old and loading
 * the one in #new to the active context.
 *
 * #old can be uninitialized but new must be a valid initialized
 * and/or saved context.
 *
 * @param old The destination of the currently active context.
 * @param new The new context to load in the active context.
 */
void sthread_switch(sthread_ctx_t *old, sthread_ctx_t *new);
/** @} */

#endif /* STHREAD_CTX_H */
