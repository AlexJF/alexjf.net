/*
 * test-sleep.c
 *
 * Simple test of thread create
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <sthread.h>


int main(int argc, char **argv) {
    sthread_t thr;
    void *ret;
    int i;

    sthread_init();

    printf("Testing if program dies when there are no executable threads but there is a sleeping one (in this case, the main).\n");

    sthread_sleep(1000000);

    printf("Program didn't die! Yey!\n");

    printf("Let's try it again just for fun :D\n");
    sthread_sleep(1000000);

    printf("Program didn't die! Yey!\n");

    return 0;
}
