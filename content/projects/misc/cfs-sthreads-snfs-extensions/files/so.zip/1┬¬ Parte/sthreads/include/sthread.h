/**
 * The public interface to simplethreads, used by applications.
 * @file sthread.h
 * @ingroup sthread
 * @see sthread_user.h
 * @see sthread_pthread.h
 */


#ifndef STHREAD_H
#define STHREAD_H 1

/**
 * @defgroup sthread Threads
 * @{
 */
/**
 * Defines the sthread_t type.
 *
 * This is to separate implementation from the public API.
 */
typedef struct _sthread *sthread_t;

/** Defines the type of routines where a thread will begin its life. */
typedef void *(*sthread_start_func_t)(void *);

/**
 * Possible thread implementations.
 *
 * There are two different types of thread implementation. Using pthreads
 * (kernel) or user-defined threads (pseudothreads). What impl. to use
 * is a compile-time setting.
 */
typedef enum { STHREAD_PTHREAD_IMPL, STHREAD_USER_IMPL } sthread_impl_t;

/**
 * Returns the selected implementation at compile time.
 *
 * @return One of the possible values in the #sthread_impl_t enumeration,
 * corresponding to the implementation the library was compiled with.
 */
sthread_impl_t sthread_get_impl(void);

/**
 * Perform any initialization needed by the underlying thread
 * implementation.
 *
 * This function should be called exactly once, before any other
 * sthread functions (except #sthread_get_impl).
 */
void sthread_init();

/**
 * Create a new thread which will be started at the given routine.
 *
 * This thread won't necessarily execute immediatly (it doesn't force
 * a switch).
 *
 * @param start_routine The routine where the thread will start
 *        execution.
 * @param arg Arguments to pass to #start_routine.
 * @param priority The initial priority of the thread.
 *
 * @return A pointer to the created thread.
 */
sthread_t sthread_create(sthread_start_func_t start_routine, void *arg, int priority);

/**
 * Exits the calling thread, setting the specified return value.
 *
 * @param ret Pointer to the return value.
 *
 * @note In this version of sthreads, there is no way to retrieve the
 * return value.
 */
void      sthread_exit(void *ret);

/**
 * Voluntarily yield the CPU to another waiting thread (force switch)
 */
void      sthread_yield(void);


/**
 * Suspends calling thread for the time specified.
 *
 * @param time The time to keep the thread suspended (in miliseconds).
 *
 * @return 0 on success.
 */
int sthread_sleep(int time);


/**
 * Blocks the calling thread until the specified thread exits.
 *
 * Unless the specified thread already exited.
 * Multiple calls with the same #thread argument result in undefined
 * behaviour.
 *
 * @param thread The thread to join with (wait for).
 * @param value_ptr A pointer to a variable where the exit status of
 *        #thread will be written to.
 *
 * @return 0 on success
 */
int sthread_join(sthread_t thread, void **value_ptr);

/**
 * This function changes the nice value of the thread.
 *
 * This value determines the thread's willingness to 
 * let other threads take priority over itself.
 *
 * It acts as a user-level priority as opposed to the
 * real kernel-level priority.
 *
 * @param nice The nice value to set.
 *
 * @return The new total priority of the thread. This 
 * priority is equal to the thread's real priority+nice.
 */
int sthread_nice(int nice);

/**
 * This function dumps the entire thread statistics.
 *
 * It prints info about the running thread, the executable
 * threads, the sleeping threads and the blocked threads.
 */
void sthread_dump();
/** @} */


/**********************************************************************/
/* Synchronization Primitives: Mutexs and Condition Variables         */
/**********************************************************************/

/****************************************************/

/**
 * @defgroup sthread_mutex Mutexes
 * @{
 */
/** Defines the sthread_mutex_t. */
typedef struct _sthread_mutex *sthread_mutex_t;

/**
 * Initializes a new, unlocked mutex.
 *
 * @return The new mutex.
 */
sthread_mutex_t sthread_mutex_init();

/**
 * Frees a no-longer needed mutex.
 *
 * This assumes the mutex has no waiters.
 *
 * @param lock The mutex to free.
 */
void sthread_mutex_free(sthread_mutex_t lock);

/**
 * Tries to lock the mutex.
 *
 * If the mutex was already locked, the calling thread is blocked
 * until the mutex in unlocked. Otherwise, calling thread continues
 * execution.
 *
 * @param lock The mutex to lock.
 */
void sthread_mutex_lock(sthread_mutex_t lock);

/**
 * Unlocks a previously locked mutex.
 *
 * This function assumes the calling thread owns the mutex.
 *
 * @param lock The mutex to unlock.
 */
void sthread_mutex_unlock(sthread_mutex_t lock);
/** @} */

/****************************************************/

/**
 * @defgroup sthread_mon Monitors
 * @{
 */
/** Defines sthread_mon_t. **/
typedef struct _sthread_mon *sthread_mon_t;

/**
 * Initializes a new, unlocked monitor.
 *
 * @return The new monitor.
 */
sthread_mon_t sthread_monitor_init();

/**
 * Free a no-longer needed monitor.
 *
 * This function assumes the monitor has no waiters.
 *
 * @param mon The monitor to free.
 */
void sthread_monitor_free(sthread_mon_t mon);

/**
 * Tries to enter the monitor critical section.
 *
 * If another thread is already in the critical section, the calling
 * thread blocks. Otherwise, the calling thread continues execution.
 *
 * @param mon The monitor whose critical section we're trying to enter.
 */
void sthread_monitor_enter(sthread_mon_t mon);

/**
 * Leaves a monitor's critical section.
 *
 * This function assumes the calling thread is inside the monitor's
 * critical section.
 *
 * @param mon The monitor whose critical section we're leaving.
 */
void sthread_monitor_exit(sthread_mon_t mon);

/**
 * Waits on the monitor's critical section (blocking) until another
 * thread signals the monitor waiters.
 *
 * This effectively allows threads to relinquish critical section
 * execution rights withouth actually leaving the critical section.
 *
 * @param mon The monitor where we would like to wait.
 */
void sthread_monitor_wait(sthread_mon_t mon);

/**
 * Signals a single monitor waiter (at the front of the queue).
 *
 * @param mon The monitor on which to signal the waiter.
 */
void sthread_monitor_signal(sthread_mon_t mon);

/**
 * Signals all monitor waiters.
 *
 * @param mon The monitor on which to signal the waiters.
 */
void sthread_monitor_signalall(sthread_mon_t mon);
/** @} */

#endif /* STHREAD_H */

