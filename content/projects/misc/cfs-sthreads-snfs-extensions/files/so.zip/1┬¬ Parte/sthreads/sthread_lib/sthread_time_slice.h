#include <sthread_ctx.h>


#define HIGH 1
#define LOW  0

typedef int lock_t;


/* start time slices - func will be called every period microseconds */
void sthread_time_slices_init(sthread_ctx_start_func_t func, int period);

/**
 * Turns interrupts ON or OFF
 *
 * @param splval LOW - Interrupts On
 *               HIGH - Interrupts Off
 *
 * @return Previous interrupts state.
 */
int splx(int splval);

/**
 * @defgroup atomic Atomic Operations
 * 
 * These operations are executed in one step and,
 * therefore, can't be interrupted.
 *
 * @{
 */
/**
 * Perform an atomic test and set using native Intel x86 operation.
 *
 * Example usage:
 * @code
 * lock_t lock;
 * // Outside critical section.
 * while(atomic_test_and_set(&lock)) {} // Wait until set
 * // Inside critical section.
 * atomic_clear(&lock);
 * // Outside critical section.
 * @endcode
 *
 * @param l Variable to test and set (lock to test and lock).
 *
 * @return Set successful (1) or not (0).
 */
int atomic_test_and_set(lock_t *l);

/**
 * Perform an atomic unset using native Intel x86 operation.
 *
 * @param l Variable to unset (lock to unlock).
 */
void atomic_clear(lock_t *l);
/** @} */


/*
 * sthread_print_stats - prints out the number of drupped interrupts
 *   and "successful" interrupts
 */
void sthread_print_stats();
