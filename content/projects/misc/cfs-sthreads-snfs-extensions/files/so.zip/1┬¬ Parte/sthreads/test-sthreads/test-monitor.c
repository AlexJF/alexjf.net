#include <sthread.h>
#include <stdio.h>
#include <stdlib.h>

sthread_mon_t Monitor = NULL;
int numReaders = 0;
int writing = 0;
int consecutiveWrites = 0;
int totalWrites = 0;
int readersWaiting = 0;

void* thread_reader(void* arg) {
    readersWaiting = 1;
    sthread_monitor_enter(Monitor);
    readersWaiting = 0;
    numReaders++;
    sthread_monitor_exit(Monitor);
    printf("Reader in.\n");
    sthread_sleep(3000000);
    printf("Finished reading...\n");
    sthread_monitor_enter(Monitor);
    numReaders--;
    if (numReaders == 0) {
        sthread_monitor_signal(Monitor);
    }
    sthread_monitor_exit(Monitor);
    printf("Reader out.\n");
    return 0;
}

void* thread_reader_special(void* arg) {
    while (writing != 1) {
    }
    while (consecutiveWrites < 3) {
    }
    readersWaiting = 1;
    sthread_monitor_enter(Monitor);
    readersWaiting = 0;
    numReaders++;
    sthread_monitor_exit(Monitor);
    printf("Reader special in.\n");
    sthread_sleep(3000000);
    printf("Finished reading...\n");
    sthread_monitor_enter(Monitor);
    numReaders--;
    if (numReaders == 0) {
        sthread_monitor_signal(Monitor);
        consecutiveWrites = 0;
    }
    sthread_monitor_exit(Monitor);
    printf("Reader out.\n");
    return 0;
}

void* thread_writer(void* arg) {
    sthread_monitor_enter(Monitor);
    printf("Writer in.\n");
    while (numReaders > 0 || (consecutiveWrites >= 2 && readersWaiting)) {
        if (numReaders == 0) {
            printf("Damn... There are readers waiting (and we already wrote too much). Let's wait then...\n");
        } else {
            printf("Damn... There are readers. Let's wait then...\n");
        }
        sthread_monitor_wait(Monitor);
        printf("WOOOOW!!! CAN IT BE?!\n");
    }
    writing = 1;
    consecutiveWrites++;
    totalWrites++;
    printf("YESS! LETS WRITE!!!\n");
    sthread_sleep(1000000);
    writing = 0;
    printf("Finished writing.\n");
    printf("Consecutive Writes: %d\n", consecutiveWrites);
    sthread_monitor_signal(Monitor);
    sthread_monitor_exit(Monitor);
    printf("Writer out.\n");
    return 0;
}

void* thread_dump(void* arg) {
    sthread_sleep(5000000);
    sthread_dump();
    return 0;
}

int main(int argc, char *argv[]) {
    int i;
    sthread_init();

    if ((Monitor = sthread_monitor_init()) == NULL) {
        printf("Monitor initialization failed.\n");
        exit(-1);
    }

    for (i = 0; i < 10; i++) {
        if (sthread_create(thread_reader, NULL, 1) == NULL) {
            printf("sthread_create failed\n");
            exit(-1);
        }
    }

    if (sthread_create(thread_dump, NULL, 1) == NULL) {
        printf("sthread_create failed\n");
        exit(-1);
    }

    for (i = 0; i < 10; i++) {
        if (sthread_create(thread_writer, NULL, 1) == NULL) {
            printf("sthread_create failed\n");
            exit(-1);
        }
    }

    for (i = 0; i < 10; i++) {
        if (sthread_create(thread_reader, NULL, 1) == NULL) {
            printf("sthread_create failed\n");
            exit(-1);
        }
    }

    for (i = 0; i < 10; i++) {
        if (sthread_create(thread_reader_special, NULL, 1) == NULL) {
            printf("sthread_create failed\n");
            exit(-1);
        }
    }

    while(totalWrites < 10 || writing) {
    }

    return 0;
}
