/*
 * test-mutex.c
 *
 * Simple test of mutexes. Checks that they do, in fact, provide
 * mutual exclusion.
 *
 * Mutexes are implemented as semaphores initialized with 1 unit.
 */


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sthread.h>

static int counter = 0;
static int ran_thread = 0;
static sthread_mutex_t mutex;


void *thread_start(void *);


int main(int argc, char **argv) {
    int checks;

    printf("Testing sthread_mutex_*, impl: %s\n",
           (sthread_get_impl() == STHREAD_PTHREAD_IMPL) ? "pthread" : "user");

    sthread_init();

    mutex = sthread_mutex_init();

    if (sthread_create(thread_start, (void*)1, 1) == NULL) {
        printf("sthread_create failed\n");
        exit(1);
    }

    if (sthread_create(thread_start, (void*)2, 1) == NULL) {
        printf("sthread_create failed\n");
        exit(1);
    }

    sthread_sleep(5000000);

    sthread_mutex_free(mutex);
    return 0;
}


void *thread_start(void *arg) {
    sthread_mutex_lock(mutex);
    printf("Thread %d got the mutex.\n", ((int) arg));
    int i;
    for (i = 0; i < 300000000; i++);
    printf("Thread %d will exit inside the mutex.\n", ((int) arg));
    sthread_exit(0);
    sthread_mutex_unlock(mutex);
    return 0;
}
