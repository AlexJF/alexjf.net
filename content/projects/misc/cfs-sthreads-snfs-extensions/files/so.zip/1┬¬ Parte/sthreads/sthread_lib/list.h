#if !defined LIST_H_INCLUDE
#define LIST_H_INCLUDE

#include <stdlib.h>

/**
 * @defgroup list Generic List
 * Generic Double-Linked Iteratable List
 * @{
 */

/**
 * An element of the list.
 *
 * Each element contains an item and a reference to the next
 * and previous elements.
 */
typedef struct list_element {
    /** A pointer to the next element in the list. */
    struct list_element* next;
    /** A pointer to the previous element in the list. */
    struct list_element* previous;
    /** A pointer to the item of this element. */
    void* item;
} list_element_t;

/** A double-linked list. */
typedef struct list {
    /** The first element in the list. */
    list_element_t* first;
    /** The last element in the list. */
    list_element_t* last;
    /** 
     * A pointer that allows controlled iteration over
     * the list.
     */
    list_element_t* iterator;

    /** The number of elements in the list. */
    int numElements;

    /** 
     * The function to call when freeing an item.
     * If NULL, free() will be called instead.
     */
    void (*freeFunction)(void*);
} list_t;

/** 
 * Creates a new list.
 *
 * @return A new empty list.
 */
list_t* list_create(void (*freeFunction)(void*));

/**
 * Deletes a list and all its items, optionally
 * freeing them.
 *
 * @param list The list to delete.
 * @param freeItems A boolean indicating wether or not
 * we should delete the list's items.
 */
void list_delete(list_t* list, int freeItems);

/**
 * Inserts a new item in the list at the specified position.
 *
 * @param list The list where we want to insert the item.
 * @param item The item to insert.
 * @param position The position in which to insert the item.
 */
void list_insert(list_t* list, void* item, int position);

/**
 * Inserts a new item in the begginning of the list. 
 *
 * @param list The list where we want to insert the item.
 * @param item The item to insert.
 */
void list_insertFirst(list_t* list, void* item);

/**
 * Inserts a new item in the last position of the list.
 *
 * @param list The list where we want to insert the item.
 * @param item The item to insert.
 */
void list_insertLast(list_t* list, void* item);

/**
 * Removes an item from the list at the specified position.
 *
 * @param list The list from which to remove the item.
 * @param position The position of the item to remove.
 * @param free Wheter or not to free the item.
 */
void list_remove(list_t* list, int position, int free);

/**
 * Gets the item at the specified position.
 *
 * @param list The list from which to get the item.
 * @param position The position of the item.
 * 
 * @return A pointer to the item or NULL if there's no such item.
 */
void* list_getItem(list_t* list, int position);

/**
 * Gets the item at the first position of the list,
 * removing it from the list at the same time (without freeing).
 *
 * @param list The list to get the item from.
 *
 * @return A pointer to the item that was in the first position
 * of the list.
 */
void* list_pop(list_t* list);

/**
 * Gets the number of elements in the list.
 *
 * @param list The list whose elements to count.
 *
 * @return Integer with number of elements.
 */
int list_getNumItems(list_t* list);

/**
 * Removes all items from the list, optionally freeing them.
 *
 * @param list The list from where to remove the items.
 * @param free Wheter or not to free the removed items.
 */
void list_removeAllItems(list_t* list, int free);

/**
 * Puts the iterator pointing to the first item of the list.
 *
 * This function should be called before iterating over the list
 * to ensure that iterator will work as expected.
 *
 * All functions that manipulate lists that are not related to 
 * the iterator perform an iterator reset.
 *
 * @param list The list whose iterator we are going to reset.
 */
void list_resetIterator(list_t* list);

/**
 * Allows the user to iterate over the elements of the list.
 *
 * Each subsequent call returns the next item in the list until
 * no more items exist, at what point, it starts returning NULL.
 *
 * @param list The list to iterate
 *
 * @return Pointer to the item of the list element currently pointed 
 * by the list's iterator. If there are no more items, return NULL.
 */
void* list_iterate(list_t* list);

/**
 * Removes the element whose item was last returned by #list_iterate.
 *
 * If #list_iterate was never called it doesn't remove anything.
 *
 * @param list The list where to perform the action.
 * @param free Whether or not to free the item.
 */
void list_removeIteratedItem(list_t* list, int free);
/** @} */

#endif
