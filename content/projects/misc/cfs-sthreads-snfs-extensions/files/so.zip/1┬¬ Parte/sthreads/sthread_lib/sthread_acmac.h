/* Straight out of GNU Pth */

/* sig{set,long}jmp macros */
@pth_sigjmpbuf@
@pth_sigsetjmp@
@pth_siglongjmp@
