#include "list.h"

/**
 * Creates a new list element with all attributes initalized to NULL.
 *
 * @return The newly created element.
 */
static list_element_t* createElement() {
    list_element_t* newElement = (list_element_t*) malloc(sizeof(list_element_t));

    if (newElement == NULL) {
        return NULL;
    }

    newElement->next = NULL;
    newElement->previous = NULL;
    newElement->item = NULL;

    return newElement;
}

/**
 * Given a list and a position, returns the corrersponding element, if any (otherwise NULL).
 *
 * @return Element at list's specified position or NULL if it doesn't exist.
 */
static list_element_t* getElement(list_t* list, int position) {
    if (list == NULL) {
        return NULL;
    }

    if (position < 0 || position >= list->numElements) {
        return NULL;
    }

    list_element_t* currentElement = NULL;

    currentElement = list->first;

    while (position > 0) {
        currentElement = currentElement->next;
        position--;
    }

    return currentElement;
}

static void removeElement(list_t* list, list_element_t* element, int freeItem) {
    list_element_t* previousElement;
    list_element_t* nextElement;
    previousElement = element->previous;
    nextElement = element->next;

    /* If there is an element next to the one we are removing, make its
     * previous point to the previous of the one we are removing. */
    if (nextElement != NULL) {
        nextElement->previous = previousElement;
    }
    /* Else we are removing the last one so update list->last */
    else {
        list->last = previousElement;
    }

    /* If there is an element previous to the one we are removing, make its
     * next point to the next of the one we are removing. */
    if (previousElement != NULL) {
        previousElement->next = nextElement;
    }
    /* Else we are removing the first so updated list->first */
    else {
        list->first = nextElement;
    }

    if (freeItem) {
        if (list->freeFunction == NULL) {
            free(element->item);
        } else {
            list->freeFunction(element->item);
        }
    }

    free(element);
    list->numElements--;
}


/****************************************************/

list_t* list_create(void (*freeFunction)(void*)) {
    list_t* newList = (list_t*) malloc(sizeof(list_t));

    if (newList == NULL) {
        return NULL;
    }

    newList->first = NULL;
    newList->last = NULL;
    newList->iterator = NULL;
    newList->numElements = 0;
    newList->freeFunction = freeFunction;

    return newList;
}

void list_delete(list_t* list, int freeItems) {
    if (list == NULL) {
        return;
    }

    list_removeAllItems(list, freeItems);
    free(list);
}

void list_insert(list_t* list, void* item, int position) {
    list_element_t* elementAtPosition = NULL;
    list_element_t* newElement = NULL;

    if (list == NULL) {
        return;
    }

    if (position <= 0) {
        list_insertFirst(list, item);
    }
    else if (position >= list->numElements) {
        list_insertLast(list, item);
    }

    elementAtPosition = getElement(list, position);

    if (elementAtPosition == NULL) {
        return;
    }

    newElement = createElement();

    if (newElement == NULL) {
        return;
    }

    newElement->item = item;
    newElement->next = elementAtPosition;
    newElement->previous = elementAtPosition->previous;
    elementAtPosition->previous->next = newElement;
    elementAtPosition->previous = newElement;

    list->numElements++;

    /* Reset iterator because we can't guarantee that it is correct */
    list->iterator = list->first;
}

void list_insertFirst(list_t* list, void* item) {
    list_element_t* newElement = NULL;

    if (list == NULL) {
        return;
    }

    newElement = createElement();

    if (newElement == NULL) {
        return;
    }

    newElement->item = item;

    /* If there was already an element in the list */
    if (list->first != NULL) {
        newElement->next = list->first;
        newElement->next->previous = newElement;
        list->first = newElement;
    } else {
        list->first = list->last = newElement;
    }

    list->numElements++;

    /* Reset iterator because we can't guarantee that it is correct */
    list->iterator = list->first;
}
    
void list_insertLast(list_t* list, void* item) {
    list_element_t* newElement = NULL;

    if (list == NULL) {
        return;
    }

    newElement = createElement();

    if (newElement == NULL) {
        return;
    }

    newElement->item = item;

    /* If there was already an element in the list */
    if (list->last != NULL) {
        list->last->next = newElement;
    } else {
        list->first = newElement;
    }

    newElement->previous = list->last;
    list->last = newElement;
    list->numElements++;

    /* Reset iterator because we can't guarantee that it is correct */
    list->iterator = list->first;
}

void list_remove(list_t* list, int position, int free) {
    list_element_t* element;

    element = getElement(list, position);

    if (element == NULL) {
        return;
    }

    removeElement(list, element, free);

    /* Reset iterator because we can't guarantee that it is correct */
    list->iterator = list->first;
}

void* list_getItem(list_t* list, int position) {
    list_element_t* element;

    element = getElement(list, position);

    if (element == NULL) {
        return NULL;
    } else {
        return element->item;
    }
}

void* list_pop(list_t* list) {
    list_element_t* element = NULL;
    void* item = NULL;

    element = list->first;

    if (element == NULL) {
        return NULL;
    } else {
        item = element->item;
        removeElement(list, element, 0);
        return item;
    }
}

int list_getNumItems(list_t* list) {
    if (list == NULL) {
        return 0;
    } else {
        return list->numElements;
    }
}

void list_removeAllItems(list_t* list, int freeItems) {
    list_element_t* currentElement = NULL;
    list_element_t* tempElement = NULL;

    if (list == NULL) {
        return;
    }

    for (currentElement = list->last; currentElement != NULL; currentElement = tempElement) {
        tempElement = currentElement->previous;
        if (freeItems) {
            if (list->freeFunction == NULL) {
                free(currentElement->item);
            } else {
                list->freeFunction(currentElement->item);
            }
        }
        free(currentElement);
    }

    list->iterator = list->last = list->first = NULL;
    list->numElements = 0;
}

void list_resetIterator(list_t* list) {
    if (list == NULL) {
        return;
    }

    list->iterator = list->first;
}

void* list_iterate(list_t* list) {
    if (list->iterator == NULL) {
        return NULL;
    } 

    void* item = NULL;
    item = list->iterator->item;
    list->iterator = list->iterator->next;
    return item;
}

void list_removeIteratedItem(list_t* list, int free) {
    if (list == NULL || list->numElements == 0) {
        return;
    }

    /* This only happens when the last element returned was the last one on the list. */
    if (list->iterator == NULL) {
        removeElement(list, list->last, free);
    } 
    /* Otherwise we returned some other element */
    else {
        removeElement(list, list->iterator->previous, free);
    }
}



