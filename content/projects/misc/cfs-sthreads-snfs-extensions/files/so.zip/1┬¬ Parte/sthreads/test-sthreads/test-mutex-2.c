/*
 * thread.c - counter thread
 */

#include <stdio.h>
#include <sthread.h>
#include <stdlib.h>
#include <semaphore.h>
#include <unistd.h>

#define		MAX	20

sthread_mutex_t Mutex;

typedef struct {
	int mod;	/* módulo referente à thread */
	int id;		/* id da thread */
	int max;	/* valor máximo até onde a thread deve contar */
} intVal;

int Counter = 0;


void *thr_inc_module(void *valores)
{
	intVal* val = (intVal*)valores;
	while (1){
		sthread_mutex_lock(Mutex);
		if (Counter >= (val->max)){
			sthread_mutex_unlock(Mutex);
			break;
		}
		if (Counter % 3 == (val->mod)){
			Counter++;
			printf("[%d] Counter= %d\n", (val->id), Counter);
		}
		sthread_mutex_unlock(Mutex);
	}

	return NULL;
}



int main()
{
	sthread_t tid1, tid2, tid3;
	intVal *valores1, *valores2, *valores3;


	sthread_init();
	Mutex = sthread_mutex_init();
	void* ret;

	valores1 = (intVal *) malloc(sizeof(intVal));
	valores2 = (intVal *) malloc(sizeof(intVal));
	valores3 = (intVal *) malloc(sizeof(intVal));


	valores1->mod = 0;
	valores1->id = 0;
	valores1->max = MAX;

	valores2->mod = 1;
	valores2->id = 1;
	valores2->max = MAX;

	valores3->mod = 2;
	valores3->id = 2;
	valores3->max = MAX;


	/* criar threads */
	if ((tid1 = sthread_create(thr_inc_module, (void*)valores1, 1)) == NULL) {
		printf("Error creating thread 1.\n");
		return -1;
	}

	if ((tid2 = sthread_create(thr_inc_module, (void*)valores2, 1)) == NULL) {
		printf("Error creating thread 2.\n");
		return -1;
	}

	if ((tid3 = sthread_create(thr_inc_module, (void*)valores3, 1)) == NULL) {
		printf("Error creating thread 3.\n");
		return -1;
	}


	/* esperar pelas threads */
	if(sthread_join(tid1, &ret) != 0) {
		printf("Error joining thred 1.\n");
		return -1;
	}

	if(sthread_join(tid2, &ret) != 0) {
		printf("Error joining thred 2.\n");
		return -1;
	}

	if(sthread_join(tid3, &ret) != 0) {
		printf("Error joining thred 3.\n");
		return -1;
	}

	printf("Finished: Counter=%d\n",Counter);
	return 0;
}

