#include <stdlib.h>
#include <stdio.h>
#include "rbt.h"
#include <sthread.h>
#include "sthread_user.h"

void rbt_fixDelete1(rbt_t* tree, rbt_node_t* node); 
void rbt_fixDelete2(rbt_t* tree, rbt_node_t* node); 
void rbt_fixDelete3(rbt_t* tree, rbt_node_t* node); 
void rbt_fixDelete4(rbt_t* tree, rbt_node_t* node); 
void rbt_fixDelete5(rbt_t* tree, rbt_node_t* node);
void rbt_fixDelete6(rbt_t* tree, rbt_node_t* node); 

void rbt_replaceNode(rbt_t* tree, rbt_node_t* oldn, rbt_node_t* newn);

void rbt_fixInsert1(rbt_t* tree, rbt_node_t* node);
void rbt_fixInsert2(rbt_t* tree, rbt_node_t* node);
void rbt_fixInsert3(rbt_t* tree, rbt_node_t* node);
void rbt_fixInsert4(rbt_t* tree, rbt_node_t* node);
void rbt_fixInsert5(rbt_t* tree, rbt_node_t* node);

rbt_node_t* rbt_findLowestNode(rbt_node_t* node);

/*** Implementaçoes (Metodos privados)***/

rbt_node_t* rbt_getGrandParent(rbt_node_t* node){
	/* Node is defined, node is not the root and node is not the root's child */
	if(node != NULL && node->parent != NULL && node->parent->parent != NULL)
		return node->parent->parent;
	else
		return NULL;
}

rbt_node_t* rbt_getSibling(rbt_node_t* node){
	/* Node is difined and node is not the root */
	if(node != NULL && node->parent != NULL){
		if(node == node->parent->left)
			return node->parent->right;
		else
			return node->parent->left;
	}
	else
		return NULL;
}

rbt_node_t* rbt_getUncle(rbt_node_t* node){
	/* Root or is child have no uncle */
	if(node != NULL && node->parent != NULL && node->parent->parent != NULL)
		return rbt_getSibling(node->parent);
	else
		return NULL;
}

rbt_node_t* rbt_findLowestNode(rbt_node_t* node){
	if (node == NULL)
		return NULL;
	
	while(node->left != NULL)
		node = node->left;
	
	return node;
}

void rbt_rotateLeft(rbt_t* tree, rbt_node_t* node) {
    rbt_node_t* node2 = node->right;
    rbt_replaceNode(tree, node, node2);
    node->right = node2->left;
    if (node2->left != NULL) {
        node2->left->parent = node;
    }
    node2->left = node;
    node->parent = node2;
}

void rbt_rotateRight(rbt_t* tree, rbt_node_t* node) {
    rbt_node_t* node2 = node->left;
    rbt_replaceNode(tree, node, node2);
    node->left = node2->right;
    if (node2->right != NULL) {
        node2->right->parent = node;
    }
    node2->right = node;
    node->parent = node2;
}

void rbt_replaceNode(rbt_t* tree, rbt_node_t* oldn, rbt_node_t* newn) {
    /* If there is no node then we will chande the root */
    if (oldn->parent == NULL) {
        tree->root = newn;
    } else {
        if (oldn == oldn->parent->left)
            oldn->parent->left = newn;
        else
            oldn->parent->right = newn;
    }
    if (newn != NULL) {
        newn->parent = oldn->parent;
    }
}


void rbt_fixInsert1(rbt_t* tree, rbt_node_t* node) {
    /* node is the root */
    if (node->parent == NULL)
        node->nodeColor = BLACK;
    else
        rbt_fixInsert2(tree, node);
}

void rbt_fixInsert2(rbt_t* tree, rbt_node_t* node) {
    if (node->parent->nodeColor == BLACK)
        return; /* Tree is still valid */
    else
        rbt_fixInsert3(tree, node);
}

void rbt_fixInsert3(rbt_t* tree, rbt_node_t* node) {
    rbt_node_t* uncle = rbt_getUncle(node);
  	
    if (uncle != NULL && uncle->nodeColor== RED) {
        node->parent->nodeColor = BLACK;
        uncle->nodeColor = BLACK;
        uncle->parent->nodeColor = RED;
        rbt_fixInsert1(tree, uncle->parent);
    } else {
        rbt_fixInsert4(tree, node);
    }
}

void rbt_fixInsert4(rbt_t* tree, rbt_node_t* node) {
	rbt_node_t* grandParent = rbt_getGrandParent(node);

    if (node == node->parent->right && node->parent == grandParent->left) {
        rbt_rotateLeft(tree, node->parent);
        node = node->left;
    } else if (node == node->parent->left && node->parent == grandParent->right) {
       rbt_rotateRight(tree, node->parent);
        node = node->right;
    }
    rbt_fixInsert5(tree, node);
}

void rbt_fixInsert5(rbt_t* tree, rbt_node_t* node) {
    rbt_node_t* grandParent = rbt_getGrandParent(node);
    
    node->parent->nodeColor = BLACK;
    grandParent->nodeColor = RED;
    if (node == node->parent->left && node->parent == grandParent->left) {
        rbt_rotateRight(tree, grandParent);
    } else if (node == node->parent->right && node->parent == grandParent->right){
        rbt_rotateLeft(tree, grandParent);
    }
}


void rbt_fixDelete1(rbt_t* tree, rbt_node_t* node) {
    if (node->parent == NULL)
        return;
    else
        rbt_fixDelete2(tree, node);
}

void rbt_fixDelete2(rbt_t* tree, rbt_node_t* node) {
    rbt_node_t* sibling = rbt_getSibling(node);
    
    if (sibling != NULL && sibling->nodeColor == RED) {
        node->parent->nodeColor = RED;
        sibling->nodeColor = BLACK;
        if (node == node->parent->left)
            rbt_rotateLeft(tree, node->parent);
        else
            rbt_rotateRight(tree, node->parent);
    }
    rbt_fixDelete3(tree, node);
}

void rbt_fixDelete3(rbt_t* tree, rbt_node_t* node) {
	rbt_node_t* sibling = rbt_getSibling(node);

    if(sibling != NULL && node->parent->nodeColor == BLACK){
    	if( (sibling->left == NULL || sibling->left->nodeColor == BLACK) &&
    	    (sibling->right == NULL || sibling->right->nodeColor == BLACK)){
				sibling->nodeColor = RED;
				rbt_fixDelete1(tree, node->parent);
    	}
    	else
    		 rbt_fixDelete4(tree, node);
    }
    else
        rbt_fixDelete4(tree, node);
}

void rbt_fixDelete4(rbt_t* tree, rbt_node_t* node) {
     rbt_node_t* sibling = rbt_getSibling(node);
    
  if(sibling != NULL && node->parent->nodeColor == RED){
    	if( (sibling->left == NULL || sibling->left->nodeColor == BLACK) &&
    	    (sibling->right == NULL || sibling->right->nodeColor == BLACK)){
				sibling->nodeColor = RED;
        		node->parent->nodeColor = BLACK;
    	}
    	else
    		 rbt_fixDelete5(tree, node);
    }
    else
        rbt_fixDelete5(tree, node);
}

void rbt_fixDelete5(rbt_t* tree, rbt_node_t* node) {
    rbt_node_t* sibling = rbt_getSibling(node); 
    
   	if(sibling != NULL){
   		if(node == node->parent->left &&
   		  (sibling->left != NULL && sibling->left->nodeColor == RED) &&
    	  (sibling->right == NULL || sibling->right->nodeColor == BLACK)){
    	   sibling->nodeColor = RED;
           sibling->left->nodeColor = BLACK;
           rbt_rotateRight(tree, sibling);
    	 }
    	 else if(node == node->parent->right &&
    	 		(sibling->right != NULL || sibling->right->nodeColor == RED) &&
    	        (sibling->left == NULL || sibling->left->nodeColor == BLACK)){
    	        sibling->nodeColor = RED;
          		sibling->right->nodeColor = BLACK;
           		rbt_rotateLeft(tree, sibling);
    	 }
   	}
    rbt_fixDelete6(tree, node);
}

void rbt_fixDelete6(rbt_t* tree, rbt_node_t* node) {
    rbt_node_t* sibling = rbt_getSibling(node);
    
    if(sibling != NULL)
    	sibling->nodeColor = node->parent->nodeColor;
    else
    	sibling->nodeColor = BLACK;
    
    node->parent->nodeColor = BLACK;
    
    if (node == node->parent->left) {
      if(sibling->right != NULL && sibling->right->nodeColor == RED){
         sibling->right->nodeColor = BLACK;
         rbt_rotateLeft(tree, node->parent);
      }
    }
    else{
		if(sibling->left != NULL && sibling->left->nodeColor == RED){
			sibling->left->nodeColor = BLACK;
			rbt_rotateRight(tree, node->parent);
		}
	}
}

/*** Implementaçoes (Metodos publicos)***/

rbt_t* rbt_create(int (*compareFunction)(void*, void*), void (*freeFunction)(void*)) {
    if (compareFunction == NULL) {
        return NULL;
    }

  	rbt_t* tree = (rbt_t*) malloc(sizeof(rbt_t));

    if (tree == NULL) {
        return NULL;
    }
	
	/*Initialize a new tree */
	tree->numNodes = 0;
	tree->root = NULL;
    tree->iterator = NULL;
	tree->lowestNode = NULL;
    tree->freeFunction = freeFunction;
    tree->compareFunction = compareFunction;
	
	return tree;
}

void* rbt_getLowestItem(rbt_t* tree){
    if (tree != NULL && tree->lowestNode != NULL) {
        return tree->lowestNode->item;
    } else {
        return NULL;
    }
}

void rbt_insert(rbt_t* tree, void* item) {
	rbt_node_t* newNode = (rbt_node_t*) malloc(sizeof(rbt_node_t));
	
	newNode->parent = NULL;
	newNode->left = NULL;
	newNode->right = NULL;
	newNode->item = item;
	newNode->nodeColor = RED;
    rbt_node_t* node = tree->root;
    
    if (tree->root == NULL) {
        tree->root = newNode;
    } else {
        node = tree->root;
        while (1) {
            /* If node is greater than newNode... */
            if (tree->compareFunction(node->item, newNode->item) == 1) {
                if (node->left == NULL) {
                    node->left = newNode;
                    break;
                } else {
                    node = node->left;
                }
            } else {
                if (node->right == NULL) {
                    node->right = newNode;
                    break;
                } else {
                    node = node->right;
                }
            }
        }
        newNode->parent = node;
    }

    rbt_fixInsert1(tree, newNode);
    
 	tree->lowestNode = tree->iterator = rbt_findLowestNode(tree->root);
 	tree->numNodes++;
}

int rbt_getNumItems(rbt_t* tree) {
    if (tree == NULL) {
        return 0;
    }

    return tree->numNodes;
}

void* rbt_pop(rbt_t* tree) {
    rbt_node_t* child;
    rbt_node_t* node;
    
    if (tree == NULL) 
    	return NULL;  
    
    node = tree->lowestNode;
    
    if(node == NULL)
    	return NULL;
    
    child = node->right == NULL ? node->left  : node->right;
    if (node->nodeColor == BLACK) {
    	if(child != NULL)
        	node->nodeColor = child->nodeColor;
        rbt_fixDelete1(tree, node);
    }
    rbt_replaceNode(tree, node, child);
    if (node->parent == NULL && child != NULL)
        child->nodeColor = BLACK;
    void* item = node->item;
    free(node);
	tree->numNodes--;
    tree->lowestNode = tree->iterator = rbt_findLowestNode(tree->root);
    return item;
}

void rbt_clearTree(rbt_t* tree, int freeItems) {
    void* item;
	while (tree->lowestNode != NULL) {
		item =rbt_pop(tree);
        if (freeItems) {
            if (tree->freeFunction == NULL) {
                free(item);
            } else {
                tree->freeFunction(item);
            }
        }
    }
}

void rbt_delete(rbt_t* tree, int freeItems) {
	rbt_clearTree(tree, freeItems);
	free(tree);
}

void rbt_resetIterator(rbt_t* tree) {
    if (tree == NULL) {
        return;
    }
    tree->iterator = tree->lowestNode;
}

void* rbt_iterate(rbt_t* tree) {
    void* item = NULL;

    if (tree == NULL || tree->iterator == NULL) {
        return NULL;
    }

    item = tree->iterator->item;

    if (tree->iterator->right != NULL) {
        tree->iterator = rbt_findLowestNode(tree->iterator->right);
    } else {
        rbt_node_t* x = NULL;
        rbt_node_t* y = NULL;
        x = tree->iterator;

        for (y = x->parent; y != NULL && x == y->right; y = y->parent) {
            x = y;
        }

        tree->iterator = y;
    }

    return item;
}




