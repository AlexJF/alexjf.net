import os, subprocess, sys

def generate(path, compilerName, virtual):
    if not os.path.isdir(path):
        return

    files = os.listdir(path)
    files.sort()

    try: 
        fForward = open("generated_forward_decls.hpp", "w")
        fHeader = open("generated.hpp", "w")
        fSource = open("generated.cpp", "w")

        for f in files:
            (name, ext) = os.path.splitext(f)

            if ext == ".cpp" and name.startswith("Node"):
                fForward.write("class " + name + ";\n")
                if (virtual): 
                    fHeader.write("virtual void node" + name[4:] + "(" + name + " &n) = 0;\n")
                else:
                    fHeader.write("void node" + name[4:] + "(" + name + " &n);\n")
                    if (compilerName == ""):
                        fSource.write("void node" + name[4:] + "(" + name + " &n) {\n}\n\n")
                    else:
                        fSource.write("void " + compilerName + "::node" + name[4:] + "(" + name + " &n) {\n}\n\n")

    except Exception as e:
        print(str(e))
    finally:
        fForward.close()
        fHeader.close()
        fSource.close()


scriptDir = os.path.dirname(sys.argv[0])

if scriptDir:
    os.chdir(scriptDir)

compilerPath = os.path.join(os.getcwd(), 'src')

generate('src', sys.argv[1], bool(len(sys.argv) > 2))
