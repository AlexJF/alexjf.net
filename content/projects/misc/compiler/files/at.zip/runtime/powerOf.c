int powerOf(int x, int y) {
	if(y == 0){
		return 1;
	}
	else if(y < 0){
		return 1 / (powerOf(x, -y));
	}
	else if(y % 2 != 0){
		int z = (powerOf(x,(y-1)/2));
		return x*z*z;
	}
	else{
		int z = (powerOf(x, y/2));
		return z*z;
	}
}
