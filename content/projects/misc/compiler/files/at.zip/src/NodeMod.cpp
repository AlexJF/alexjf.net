#include "NodeMod.hpp"

NodeMod::NodeMod(Node* arg1, Node* arg2, int lineno, int columnno) :
	NodeBinary(arg1, arg2, lineno, columnno) {}

void NodeMod::accept(Visitor& c) { 
    c.nodeMod(*this); 
}

void NodeMod::print(std::ostream &out) {
	out << "NodeMod: ";
	NodeBinary::print(out);
}
