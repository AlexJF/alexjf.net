#include "NodeGe.hpp"

NodeGe::NodeGe(Node* arg1, Node* arg2, int lineno, int columnno) : 
	NodeBinary(arg1, arg2, lineno, columnno) {
}

void NodeGe::accept(Visitor& c) { 
    c.nodeGe(*this); 
}

void NodeGe::print(std::ostream &out) {
	out << "NodeGe: ";
	NodeBinary::print(out);
}
