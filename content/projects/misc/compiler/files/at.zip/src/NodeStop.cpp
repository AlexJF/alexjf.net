#include "NodeStop.hpp"

NodeStop::NodeStop(int lineno, int columnno) : 
    Node(lineno, columnno) {
}

void NodeStop::accept(Visitor& c) { 
    c.nodeStop(*this); 
}

void NodeStop::print(std::ostream &out) {
	out << "NodeStop" << std::endl;
}
