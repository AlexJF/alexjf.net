#include <iostream>
#include <cstring>

#include "Compiler.hpp"
#include "At.hpp"

int main(int argc, char *argv[]) {
    Compiler *compiler;
    bool printTree = false;
    bool debugLex = false;
    bool debugYacc = false;
    std::string inputFile;
    std::string outputFile;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--debug") == 0) {
            debugLex = debugYacc = true;
        }
        else if (strcmp(argv[i], "--debuglex") == 0) {
            debugLex = true;
        }
        else if (strcmp(argv[i], "--debugyacc") == 0) {
            debugYacc = true;
        }
        else if (strcmp(argv[i], "--print-tree") == 0) {
            printTree = true;
        }
        else if (strcmp(argv[i], "--help") == 0) {
            std::cout << "AT Compiler" << std::endl;
            std::cout << "Usage: at [commands] (inputfile outputfile?)?" << std::endl;
            std::cout << "-----------" << std::endl;
            std::cout << "Available commands:" << std::endl;
            std::cout << "--debug        - Activate debug for lex and yacc" << std::endl;
            std::cout << "--debuglex     - Activate debug for lex" << std::endl;
            std::cout << "--debugyacc    - Activate debug for yacc" << std::endl;
            std::cout << "--print-tree   - Prints the generated parse tree" << std::endl;
            std::cout << "--help         - This text" << std::endl;
            return 0;
        }
        else if (inputFile.length() == 0) {
            inputFile.assign(argv[i]);
        }
        else {
            outputFile.assign(argv[i]);
        }
    }

    compiler = new At(inputFile, outputFile, debugLex, debugYacc, printTree);

    bool error = !compiler->parse();
    error = !compiler->generate();

    delete compiler;
    return error;
}
