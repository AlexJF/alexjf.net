#include "Symbol.hpp"
#include "NodeVarDeclare.hpp"

SymbolVar::SymbolVar(Type *t, int displacement, NodeValue *initialValue) :
    _t(t), _displacement(displacement),
    _initialValue(initialValue) {
}

SymbolVar::~SymbolVar() {
    delete _t;
}

Type* SymbolVar::getType() const {
    return _t;
}

int SymbolVar::getDisplacement() const {
    return _displacement;
}

NodeValue* SymbolVar::getInitialValue() const {
    return _initialValue;
}

SymbolFunc::SymbolFunc(Type *t, NodeVarDeclare **args, unsigned int nargs) :
    _t(t), _args(args), _nargs(nargs) {
}

SymbolFunc::~SymbolFunc() {
    if (_args == NULL) {
        return;
    }

    for (unsigned int i = 0; i < _nargs; i++) {
        delete _args[i];
    }
    delete[] _args;
    delete _t;
}

Type* SymbolFunc::getType() const {
    return _t;
}

NodeVarDeclare* SymbolFunc::getArg(unsigned int pos) const {
    if (pos < _nargs) {
        return _args[pos];
    } else {
        return NULL;
    }
}

unsigned int SymbolFunc::getNumArgs() const {
    return _nargs;
}
