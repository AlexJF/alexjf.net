#include "NodeIndex.hpp"
#include "NodeList.hpp"
#include "NodeIdentifier.hpp"

NodeIndex::NodeIndex(Node* id, Node* indexList, int lineno, int column) :
    NodeExpression(NULL, lineno, columnno),
    _shouldLoad(true) {
    _id = (NodeIdentifier*) id;
    _indexList = (NodeList*) indexList;
}

NodeIndex::~NodeIndex() {
    delete _id;
    delete _indexList;
}

NodeIdentifier* NodeIndex::getIdentifier() {
	return _id;
}

NodeList* NodeIndex::getIndexList() {
	return _indexList;
}

void NodeIndex::accept(Visitor& c) { 
    c.nodeIndex(*this); 
}

bool NodeIndex::shouldLoad() {
	return _shouldLoad;
}

void NodeIndex::setLoad(bool load) {
	_shouldLoad = load;
}

void NodeIndex::print(std::ostream &out) {
	out << "NodeIndex: {" << std::endl;
	_id->print(out);
    out << "Indexes:";
	_indexList->print(out);
    out << "}" << std::endl;;
}
