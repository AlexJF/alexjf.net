#include "NodeExclusiveSection.hpp"
#include "NodeExpression.hpp"

NodeExclusiveSection::NodeExclusiveSection(Node* condition, Node *block, int lineno, int columnno) :
    NodeSection(block, lineno, columnno) {
    _condition = (NodeExpression*) condition;
}

NodeExclusiveSection::~NodeExclusiveSection() {
    delete _condition;
}

NodeExpression* NodeExclusiveSection::getCondition() {
    return _condition;
}

void NodeExclusiveSection::accept(Visitor &c) {
    c.nodeExclusiveSection(*this);
}

void NodeExclusiveSection::print(std::ostream &out) {
    out << "NodeExclusiveSection: {";
    _condition->print(out);
    NodeSection::print(out);
    out << "}" << std::endl;
}
