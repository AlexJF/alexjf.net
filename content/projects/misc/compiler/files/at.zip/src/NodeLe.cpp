#include "NodeLe.hpp"

NodeLe::NodeLe(Node* arg1, Node* arg2, int lineno, int columnno) :
	NodeBinary(arg1, arg2, lineno, columnno) {
}

void NodeLe::accept(Visitor& c) { 
    c.nodeLe(*this); 
}

void NodeLe::print(std::ostream &out) {
	out << "NodeLe: ";
	NodeBinary::print(out);
}
