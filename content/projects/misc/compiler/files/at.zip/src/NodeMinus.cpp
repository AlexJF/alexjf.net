#include "NodeMinus.hpp"

NodeMinus::NodeMinus(Node* arg, int lineno, int columnno) : 
	NodeUnary(arg, lineno,  columnno) {
}

void NodeMinus::accept(Visitor& c) { 
    c.nodeMinus(*this); 
}

void NodeMinus::print(std::ostream &out) {
	out << "NodeMinus: " << std::endl;
	NodeUnary::print(out);
}
