#include "NodeAddress.hpp"

NodeAddress::NodeAddress(Node* arg, int lineno, int columnno) : 
	NodeUnary(arg, lineno,  columnno) {
}

void NodeAddress::accept(Visitor& c) { 
    c.nodeAddress(*this); 
}

void NodeAddress::print(std::ostream &out) {
	out << "NodeAddress: ";
	NodeUnary::print(out);
}
