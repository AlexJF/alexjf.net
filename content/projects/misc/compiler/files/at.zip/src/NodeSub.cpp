#include "NodeSub.hpp"

NodeSub::NodeSub(Node* arg1, Node* arg2, int lineno, int columnno) :
	NodeBinary (arg1, arg2, lineno, columnno) {}
				 
void NodeSub::accept(Visitor& c) { 
    c.nodeSub(*this); 
}

void NodeSub::print(std::ostream &out) {
	out << "NodeSub: ";
	NodeBinary::print(out);
}

