#include "NodeCondList.hpp"
#include "NodeList.hpp"

NodeCondList::NodeCondList(Node *listCond, Node *nodeElse, int lineno, int columnno) :
    Node(lineno, columnno) {
    _condList = (NodeList*) listCond;
    _else = nodeElse;
}

NodeCondList::~NodeCondList() {
    delete _condList;
    delete _else;
}

void NodeCondList::accept(Visitor &c) {
    c.nodeCondList(*this);
}

NodeList* NodeCondList::getListCond() {
	return _condList;
}

Node* NodeCondList::getElse() {
	return _else;
}

void NodeCondList::print(std::ostream &out) {
    out << "NodeCondList: {" << std::endl;
    _condList->print(out);
    out << "Else: ";
    _else->print(out);
    out << "}" << std::endl;
}

