#include "NodeRealValue.hpp"
#include "Type.hpp"

NodeRealValue::NodeRealValue(double value, int lineno, int columnno) :
	NodeValue(new Type(T_REAL, 0, true), lineno, columnno), 
    _value(value) {
}

double NodeRealValue::getValue() {
    return _value;
}

void NodeRealValue::makeNegative(){
     _value *= -1;
}

void NodeRealValue::accept(Visitor& c) { 
    c.nodeRealValue(*this); 
}

void NodeRealValue::print(std::ostream &out) {
	out << "NodeRealValue: " << _value << std::endl;
}
