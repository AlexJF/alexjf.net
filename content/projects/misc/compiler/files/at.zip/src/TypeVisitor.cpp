#include "TypeVisitor.hpp"

TypeVisitor::TypeVisitor(Tabid &tabid) :
    _type(NULL),
    _downwards(true),
    _first(true),
    _tabid(tabid) {
}

TypeVisitor::~TypeVisitor() {
    delete _type;
}

void TypeVisitor::reset() {
    _type = NULL;
    _downwards = true;
    _first = true;
}

Type* TypeVisitor::getType() const {
    return _type;
}

void TypeVisitor::guessOperatorType(NodeOperator &n) {
    // Should we change search direction after calling first and
    // second accepts? This should only be true on the first call.
    bool resetDirection = false;

    /* If this is the first call to guessOperatorType then we first try
     * to guess its type be checking its children (search downwards). If
     * that fails, check the parent operators (search upwards).
     *
     * On subsequent calls to guessOperatorType, we only want to check in the
     * set direction otherwise we get infinite loops */
    if (_first) {
        _downwards = true;
        resetDirection = true;
        _first = false;
    }

    if (_downwards) {
        n.first()->accept(*this);

        // If we were unable to determine the type of the operation based on
        // the first argument, try the second.
        if (_type == NULL &&  n.second() != NULL) {
            n.second()->accept(*this);
        }
    }

    /* If we can change search directions, change it to upward */
    if (resetDirection) {
        _downwards = false;
    }

    // If type is still null and we have a parent operator, try to guess this
    // operator type through the parent's type.
    if (_type == NULL && !_downwards && n.getParent() != NULL)
        n.getParent()->accept(*this);
}

void TypeVisitor::nodeAdd(NodeAdd &n) {
    guessOperatorType(n);
}

void TypeVisitor::nodeAddress(NodeAddress &n) {
}

void TypeVisitor::nodeAlloc(NodeAlloc &n) {
}

void TypeVisitor::nodeAnd(NodeAnd &n) {
    delete _type;
    _type = (new Type(T_INT));
}

void TypeVisitor::nodeAssign(NodeAssign &n) {
	n.first()->accept(*this);

    /* We don't try to determine it through the second argument because it is the first
     * argument (the identifier) that is the major argument */
}

void TypeVisitor::nodeBlock(NodeBlock &n) {
}

void TypeVisitor::nodeCond(NodeCond &n) {
}

void TypeVisitor::nodeCondList(NodeCondList &n) {
}

void TypeVisitor::nodeDiv(NodeDiv &n) {
    guessOperatorType(n);
}

void TypeVisitor::nodeEqual(NodeEqual &n) {
    delete _type;
    _type = (new Type(T_INT));
}

void TypeVisitor::nodeExclusiveSection(NodeExclusiveSection &n) {
}

void TypeVisitor::nodeFinalSection(NodeFinalSection &n) {
}

void TypeVisitor::nodeFuncBody(NodeFuncBody &n) {
}

void TypeVisitor::nodeFuncCall(NodeFuncCall &n) {
    SymbolFunc *s = _tabid.getFuncSymbol(n.getName());

    if (s == NULL) {
        _type = NULL;
    } else {
        _type = s->getType()->copy();
    }
}

void TypeVisitor::nodeFuncDeclare(NodeFuncDeclare &n) {
}

void TypeVisitor::nodeGe(NodeGe &n) {
    delete _type;
    _type = (new Type(T_INT));
}

void TypeVisitor::nodeGt(NodeGt &n) {
    delete _type;
    _type = (new Type(T_INT));
}

void TypeVisitor::nodeIdentifier(NodeIdentifier &n) {
    SymbolVar *s = _tabid.getVarSymbol(n.getName());

    if (s == NULL) {
        _type == NULL;
    } else {
        _type = s->getType()->copy();
    }
}

void TypeVisitor::nodeInclusiveSection(NodeInclusiveSection &n) {
}

void TypeVisitor::nodeIndex(NodeIndex &n) {
    SymbolVar *s = _tabid.getVarSymbol(n.getIdentifier()->getName());

    _type = s->getType();

    for (unsigned int i = 0; i < n.getIndexList()->size(); i++) {
        _type = _type->dereference();

        if (_type == NULL) {
            break;
        }
    }

    _type = _type->copy(true);
}

void TypeVisitor::nodeInitialSection(NodeInitialSection &n) {
}

void TypeVisitor::nodeInstr(NodeInstr &n) {
}

void TypeVisitor::nodeIntegerValue(NodeIntegerValue &n) {
    _type = new Type(T_INT, 0, true);
}

void TypeVisitor::nodeIter(NodeIter &n) {
}

void TypeVisitor::nodeLe(NodeLe &n) {
    delete _type;
    _type = new Type(T_INT);
}

void TypeVisitor::nodeList(NodeList &n) {
}

void TypeVisitor::nodeLt(NodeLt &n) {
    delete _type;
    _type = new Type(T_INT);
}

void TypeVisitor::nodeMinus(NodeMinus &n) {
    guessOperatorType(n);
}

void TypeVisitor::nodeMod(NodeMod &n) {
    guessOperatorType(n);
}

void TypeVisitor::nodeMult(NodeMult &n) {
    guessOperatorType(n);
}

void TypeVisitor::nodeNe(NodeNe &n) {
    delete _type;
    _type = new Type(T_INT);
}

void TypeVisitor::nodeNeg(NodeNeg &n) {
    guessOperatorType(n);
}

void TypeVisitor::nodeNext(NodeNext &n) {
}

void TypeVisitor::nodeOr(NodeOr &n) {
    delete _type;
    _type = new Type(T_INT);
}

void TypeVisitor::nodePlus(NodePlus &n) {
    guessOperatorType(n);
}

void TypeVisitor::nodePow(NodePow &n) {
    delete _type;
    _type = new Type(T_INT);
}

void TypeVisitor::nodePrint(NodePrint &n) {
}

void TypeVisitor::nodeRead(NodeRead &n) {
}

void TypeVisitor::nodeRealValue(NodeRealValue &n) {
    _type = new Type(T_REAL, 0, true);
}

void TypeVisitor::nodeReturn(NodeReturn &n) {
}

void TypeVisitor::nodeSection(NodeSection &n) {
}

void TypeVisitor::nodeStop(NodeStop &n) {
}

void TypeVisitor::nodeStringValue(NodeStringValue &n) {
    _type = new Type(T_STRING, 0, true);
}

void TypeVisitor::nodeSub(NodeSub &n) {
    guessOperatorType(n);
}

void TypeVisitor::nodeVarDeclare(NodeVarDeclare &n) {
}

void TypeVisitor::nodeWhen(NodeWhen &n) {
}
