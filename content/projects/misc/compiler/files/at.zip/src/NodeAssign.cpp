#include "NodeAssign.hpp"

NodeAssign::NodeAssign(Node *arg1, Node *arg2, int lineno, int columnno) : 
    NodeBinary(arg1, arg2, lineno, columnno) {
}
				   
void NodeAssign::accept(Visitor& c) { 
    c.nodeAssign(*this); 
}

void NodeAssign::print(std::ostream &out) {
	out << "NodeAssign: ";
    NodeBinary::print(out);
}
