#include "NodeMult.hpp"

NodeMult::NodeMult(Node* arg1, Node* arg2, int lineno, int columnno) :
    NodeBinary(arg1, arg2, lineno, columnno) {}

void NodeMult::accept(Visitor& c) { 
    c.nodeMult(*this); 
}

void NodeMult::print(std::ostream &out) {
	out << "NodeMult: ";
	NodeBinary::print(out);
}
