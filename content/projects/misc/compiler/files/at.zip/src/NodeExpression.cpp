#include "NodeExpression.hpp"
#include "Type.hpp"

NodeExpression::NodeExpression(Type *t, int lineno, int columnno) :
    _t(t),
    _parent(NULL),
    Node(lineno, columnno) {
}

NodeExpression::~NodeExpression() {
    delete _t;
}

void NodeExpression::setParent(NodeOperator *parent) {
    _parent = parent;
}

NodeOperator* NodeExpression::getParent() {
    return _parent;
}

Type* NodeExpression::getType() {
    return _t;
}

void NodeExpression::setType(Type *t) {
    delete _t;
    _t = t;
}
