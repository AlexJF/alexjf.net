#include "NodeFinalSection.hpp"

#include "NodeFinalSection.hpp"

NodeFinalSection::NodeFinalSection(Node *block, int lineno, int columnno) :
    NodeSection(block, lineno, columnno) {
}

NodeFinalSection::~NodeFinalSection() {
}

void NodeFinalSection::accept(Visitor &c) {
    c.nodeFinalSection(*this);
}

void NodeFinalSection::print(std::ostream &out) {
    out << "NodeFinalSection: ";
    NodeSection::print(out);
}
