#include "NodeFuncDeclare.hpp"
#include "NodeFuncBody.hpp"
#include "NodeIdentifier.hpp"
#include "NodeList.hpp"

NodeFuncDeclare::NodeFuncDeclare(Type *type, Node *identifier, Node *argList, Node *body, 
                                 int lineno, int columnno) : 
    Node(lineno, columnno), 
    _type(type) {

    _identifier = (NodeIdentifier*) identifier;

    if (argList != NULL) {
        _argList = (NodeList*) argList;
    } else {
        _argList = NULL;
    }

    if (body != NULL) {
        _body = (NodeFuncBody*) body;
        _body->setFunctionDeclaration(this);
    } else {
        _body = NULL;
    }
}

NodeFuncDeclare::~NodeFuncDeclare() {
    delete _identifier;
    delete _argList;
    delete _body;
    delete _type;
}

const std::string& NodeFuncDeclare::getName() {
    return _identifier->getName();
}

Type* NodeFuncDeclare::getType() {
    return _type;
}

NodeList* NodeFuncDeclare::getArgList() {
    return _argList;
}

NodeFuncBody* NodeFuncDeclare::getBody() {
    return _body;
}

eQualifier NodeFuncDeclare::getQualifier() {
    return _qualifier;
}

void NodeFuncDeclare::accept(Visitor &c) {
    c.nodeFuncDeclare(*this);
}

void NodeFuncDeclare::print(std::ostream &out) {
	out << "NodeFuncDeclare: {" << std::endl;
    out << "Type: " << _type->getName() << std::endl;
    out << "Identifier: ";
    _identifier->print(out);
    if (_argList != NULL) {
        out << "Arglist: ";
        _argList->print(out);
    }
    if (_body != NULL) {
        out << "Body: ";
        _body->print(out);
    }
    out << "}" << std::endl;
}
