#include "NodeInstr.hpp"
#include "NodeExpression.hpp"

NodeInstr::NodeInstr(Node* expr, int lineno, int columnno) :
    Node(lineno, columnno) {
    _expr = (NodeExpression*) expr;
}

NodeInstr::~NodeInstr() {
    delete _expr;
}

NodeExpression& NodeInstr::getExpression() {
    return *_expr;
}

void NodeInstr::accept(Visitor &c) {
    c.nodeInstr(*this);
}

void NodeInstr::print(std::ostream &out) {
    out << "NodeInstr: {" << std::endl;
	_expr->print(out);
    out << "}" << std::endl;
}
