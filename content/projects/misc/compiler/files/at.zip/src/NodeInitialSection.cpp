#include "NodeInitialSection.hpp"

NodeInitialSection::NodeInitialSection(Node *block, int lineno, int columnno) :
    NodeSection(block, lineno, columnno) {
}

NodeInitialSection::~NodeInitialSection() {
}

void NodeInitialSection::accept(Visitor &c) {
    c.nodeInitialSection(*this);
}

void NodeInitialSection::print(std::ostream &out) {
    out << "NodeInitialSection: ";
    NodeSection::print(out);
}
