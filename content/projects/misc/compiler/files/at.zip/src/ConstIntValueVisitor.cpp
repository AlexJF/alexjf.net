#include "ConstIntValueVisitor.hpp"

ConstIntValueVisitor::ConstIntValueVisitor(Tabid &tabid) :
    _tabid(tabid),
    _foundValue(false),
    _value(0) {
}

ConstIntValueVisitor::~ConstIntValueVisitor() {
}

void ConstIntValueVisitor::reset() {
    _foundValue = false;
    _value = 0;
}

int ConstIntValueVisitor::getValue() const {
    return _value;
}

bool ConstIntValueVisitor::foundValue() const {
    return _foundValue;
}

void ConstIntValueVisitor::nodeAdd(NodeAdd &n) {
}

void ConstIntValueVisitor::nodeAddress(NodeAddress &n) {
}

void ConstIntValueVisitor::nodeAlloc(NodeAlloc &n) {
}

void ConstIntValueVisitor::nodeAnd(NodeAnd &n) {
}

void ConstIntValueVisitor::nodeAssign(NodeAssign &n) {
}

void ConstIntValueVisitor::nodeBlock(NodeBlock &n) {
}

void ConstIntValueVisitor::nodeCond(NodeCond &n) {
}

void ConstIntValueVisitor::nodeCondList(NodeCondList &n) {
}

void ConstIntValueVisitor::nodeDiv(NodeDiv &n) {
}

void ConstIntValueVisitor::nodeEqual(NodeEqual &n) {
}

void ConstIntValueVisitor::nodeExclusiveSection(NodeExclusiveSection &n) {
}

void ConstIntValueVisitor::nodeFinalSection(NodeFinalSection &n) {
}

void ConstIntValueVisitor::nodeFuncBody(NodeFuncBody &n) {
}

void ConstIntValueVisitor::nodeFuncCall(NodeFuncCall &n) {
}

void ConstIntValueVisitor::nodeFuncDeclare(NodeFuncDeclare &n) {
}

void ConstIntValueVisitor::nodeGe(NodeGe &n) {
}

void ConstIntValueVisitor::nodeGt(NodeGt &n) {
}

void ConstIntValueVisitor::nodeIdentifier(NodeIdentifier &n) {
    SymbolVar *s = _tabid.getVarSymbol(n.getName());

    if (s != NULL) {
        Type *t = s->getType();
        if (t->getId() == T_INT && t->isConstant()) {
            _foundValue = true;
            _value = ((NodeIntegerValue*) s->getInitialValue())->getValue();
        }
    }
}

void ConstIntValueVisitor::nodeInclusiveSection(NodeInclusiveSection &n) {
}

void ConstIntValueVisitor::nodeIndex(NodeIndex &n) {
}

void ConstIntValueVisitor::nodeInitialSection(NodeInitialSection &n) {
}

void ConstIntValueVisitor::nodeInstr(NodeInstr &n) {
}

void ConstIntValueVisitor::nodeIntegerValue(NodeIntegerValue &n) {
    _foundValue = true;
    _value = n.getValue();
}

void ConstIntValueVisitor::nodeIter(NodeIter &n) {
}

void ConstIntValueVisitor::nodeLe(NodeLe &n) {
}

void ConstIntValueVisitor::nodeList(NodeList &n) {
}

void ConstIntValueVisitor::nodeLt(NodeLt &n) {
}

void ConstIntValueVisitor::nodeMinus(NodeMinus &n) {
}

void ConstIntValueVisitor::nodeMod(NodeMod &n) {
}

void ConstIntValueVisitor::nodeMult(NodeMult &n) {
}

void ConstIntValueVisitor::nodeNe(NodeNe &n) {
}

void ConstIntValueVisitor::nodeNeg(NodeNeg &n) {
}

void ConstIntValueVisitor::nodeNext(NodeNext &n) {
}

void ConstIntValueVisitor::nodeOr(NodeOr &n) {
}

void ConstIntValueVisitor::nodePlus(NodePlus &n) {
}

void ConstIntValueVisitor::nodePow(NodePow &n) {
}

void ConstIntValueVisitor::nodePrint(NodePrint &n) {
}

void ConstIntValueVisitor::nodeRead(NodeRead &n) {
}

void ConstIntValueVisitor::nodeRealValue(NodeRealValue &n) {
}

void ConstIntValueVisitor::nodeReturn(NodeReturn &n) {
}

void ConstIntValueVisitor::nodeSection(NodeSection &n) {
}

void ConstIntValueVisitor::nodeStop(NodeStop &n) {
}

void ConstIntValueVisitor::nodeStringValue(NodeStringValue &n) {
}

void ConstIntValueVisitor::nodeSub(NodeSub &n) {
}

void ConstIntValueVisitor::nodeVarDeclare(NodeVarDeclare &n) {
}

void ConstIntValueVisitor::nodeWhen(NodeWhen &n) {
}
