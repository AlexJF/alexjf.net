#include "NodeRead.hpp"

NodeRead::NodeRead(int lineno, int columnno) : 
    NodeExpression(NULL, lineno, columnno) {
}

void NodeRead::accept(Visitor& c) { 
    c.nodeRead(*this); 
}

void NodeRead::print(std::ostream &out) {
	out << "NodeRead" << std::endl;
}
