#include "NodeAlloc.hpp"

NodeAlloc::NodeAlloc(Node* arg, int lineno, int columnno) :
	NodeUnary (arg, lineno, columnno) {
}
				 
void NodeAlloc::accept(Visitor& c) { 
    c.nodeAlloc(*this); 
}

void NodeAlloc::print(std::ostream &out) {
	out << "NodeAlloc: ";
	NodeUnary::print(out);
}
