#include "NodeInclusiveSection.hpp"
#include "NodeExpression.hpp"

NodeInclusiveSection::NodeInclusiveSection(Node* condition, Node *block, int lineno, int columnno) :
    NodeSection(block, lineno, columnno) {
    _condition = (NodeExpression*) condition;
}

NodeInclusiveSection::~NodeInclusiveSection() {
    delete _condition;
}

NodeExpression* NodeInclusiveSection::getCondition() {
    return _condition;
}

void NodeInclusiveSection::accept(Visitor &c) {
    c.nodeInclusiveSection(*this);
}

void NodeInclusiveSection::print(std::ostream &out) {
    out << "NodeInclusiveSection: {" << std::endl;
    out << "Condition: " << std::endl;
    _condition->print(out);
    NodeSection::print(out);
    out << "}" << std::endl;
}
