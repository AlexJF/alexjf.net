#include "NodePlus.hpp"

NodePlus::NodePlus(Node* arg, int lineno, int columnno) : 
	NodeUnary(arg, lineno,  columnno) {
}

void NodePlus::accept(Visitor& c) { 
    c.nodePlus(*this); 
}

void NodePlus::print(std::ostream &out) {
	out << "NodePlus: ";
	NodeUnary::print(out);
}
