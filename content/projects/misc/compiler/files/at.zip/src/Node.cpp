#include "Node.hpp"

Node::Node(const int line, const int column) {
	if (line <= 0) {
		_line = lineno;
	} else {
		_line = line;
	}
	
	if (column <= 0) {
		_column = columnno;
	} else {
		_column = column;
	}
}

Node::~Node() { 
}

int Node::getLine() const {
    return _line;
}

int Node::getColumn() const {
    return _column;
}
