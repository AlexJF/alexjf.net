#include "NodeCond.hpp"
#include "NodeExpression.hpp"

NodeCond::NodeCond(Node *cond, Node *instr, int lineno, int columnno) :
    Node(lineno, columnno) {
    _cond = (NodeExpression*) cond;
    _instr = instr;
}

NodeCond::~NodeCond() {
    delete _cond;
    delete _instr;
}

NodeExpression* NodeCond::getCondition() {
	return _cond;
}
Node* NodeCond::getInstr() {
	return _instr;
}

void NodeCond::accept(Visitor &c) {
    c.nodeCond(*this);
}

void NodeCond::print(std::ostream &out) {
    out << "NodeCond: {" << std::endl;
    _cond->print(out);
    _instr->print(out);
    out << "}" << std::endl;
}
