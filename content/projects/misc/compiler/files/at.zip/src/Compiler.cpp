#include "Compiler.hpp"
#include "Node.hpp"

std::string Compiler::extension(const std::string &filename, const std::string &ext) {
    int pos = filename.find_last_of('.');
    if (pos == std::string::npos) return filename + "." + ext;
    else return filename.substr(0, pos) + ext;
}

Compiler::~Compiler() {
    delete _tree;
}

void Compiler::printTree() {
    if (_tree != NULL) {
        _tree->print();
    }
}

Node* Compiler::getTree() {
    return _tree;
}

void Compiler::setTree(Node* tree) {
    _tree = tree;
}
