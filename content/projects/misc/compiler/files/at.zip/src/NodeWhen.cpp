#include "NodeWhen.hpp"
#include "NodeExpression.hpp"

NodeWhen::NodeWhen(Node *expr, Node *cond, int lineno, int columnno) :
    Node(lineno, columnno) {
    _expr = (NodeExpression*) expr;
    _cond = (NodeExpression*) cond;
}

NodeWhen::~NodeWhen() {
    delete _cond;
    delete _expr;
}

NodeExpression* NodeWhen::getCondition() {
	return _cond;
}

NodeExpression* NodeWhen::getExpression() {
	return _expr;
}

void NodeWhen::accept(Visitor &c) {
    c.nodeWhen(*this);
}

void NodeWhen::print(std::ostream &out) {
    out << "NodeWhen: {" << std::endl;
    out << "Condition: ";
    _cond->print(out);
    out << "Action: ";
    _expr->print(out);
    out << "}" << std::endl;
}
