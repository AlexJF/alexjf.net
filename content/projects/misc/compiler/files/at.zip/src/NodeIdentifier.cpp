#include "NodeIdentifier.hpp"

NodeIdentifier::NodeIdentifier(const std::string &name, int lineno, int columnno) : 
	NodeValue(NULL, lineno, columnno),
    _load(true),
    _name(name),
    _value(NULL) {
}

const std::string& NodeIdentifier::getName() const {
    return _name;
}

void NodeIdentifier::setLoad(bool load) {
    _load = load;
}

bool NodeIdentifier::shouldLoad() const {
    return _load;
}

void NodeIdentifier::accept(Visitor& c) { 
    c.nodeIdentifier(*this); 
}
void NodeIdentifier::print(std::ostream &out) {
	out << "NodeIdentifier: \" " << _name <<" \"\n";
}
