#include "NodeOperator.hpp"

NodeOperator::NodeOperator(Node *arg1, Node *arg2, int lineno, int columnno) : 
	NodeExpression(NULL, lineno, columnno) {

    if (arg1 != NULL) {
        _arg1 = (NodeExpression*) arg1;
        _arg1->setParent(this);
    } else {
        _arg1 = NULL;
    }

    if (arg2 != NULL) {
        _arg2 = (NodeExpression*) arg2;
        _arg2->setParent(this);
    } else {
        _arg2 = NULL;
    }
}

NodeOperator::~NodeOperator() { 
    delete _arg1; 
    delete _arg2;
}

NodeExpression* NodeOperator::first() {
    return _arg1;
}

NodeExpression* NodeOperator::second() {
    return _arg2;
}
