#include "NodeList.hpp"
#include <stdarg.h>

NodeList::NodeList(int lineno, int columnno) : Node(lineno, columnno) {
}

NodeList::~NodeList() {
    for (int i = 0; i < _list.size(); i++)
        delete _list[i];
    _list.clear();
}

int NodeList::size() {
    return _list.size();
}

std::vector<Node*>& NodeList::nodes() { 
    return _list; 
}

Node& NodeList::elementAt(int i) { 
    return *_list[i]; 
}

void NodeList::prepend(Node* n) { 
    if (n == NULL) return;
    _list.insert(_list.begin(), n); 
}

void NodeList::append(Node* n) { 
    if (n == NULL) return;
    _list.push_back(n); 
}

void NodeList::accept(Visitor &c) {
    c.nodeList(*this);
}

void NodeList::print(std::ostream &out) {
	out << "NodeList: " << _list.size() << " {\n";
	for (int i = 0; i < _list.size(); i++) {
		_list[i]->print(out);
    }
    out << "}" << std::endl;
}
