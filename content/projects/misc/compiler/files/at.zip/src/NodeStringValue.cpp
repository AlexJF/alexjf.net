#include "NodeStringValue.hpp"
#include "NodeIntegerValue.hpp"
#include "NodeList.hpp"
#include "Type.hpp"

NodeStringValue::NodeStringValue(const std::string &value, int lineno, int columnno) :
	NodeValue(new Type(T_STRING, 0, true), lineno, columnno), 
    _value(value) {
}

NodeStringValue::NodeStringValue(Node *list, int lineno, int columnno) :
    NodeValue(new Type(T_STRING, 0, true), lineno, columnno) {
    _value.assign("");

    NodeListIterator it;
    std::vector< Node* > nodes = ((NodeList*) list)->nodes();

    for (it = nodes.begin(); it != nodes.end(); it++) {
        _value.append(1, ((NodeIntegerValue*)(*it))->getValue());
    }
}

const std::string& NodeStringValue::getValue() {
    return _value;
}

void NodeStringValue::accept(Visitor& c) { 
    c.nodeStringValue(*this); 
}

void NodeStringValue::print(std::ostream &out) {
	out << "NodeStringValue: \"" << _value << "\"" << std::endl;
}
