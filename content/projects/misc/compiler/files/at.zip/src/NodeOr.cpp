#include "NodeOr.hpp"

NodeOr::NodeOr(Node *arg1, Node *arg2, int lineno, int columnno) : 
    NodeBinary(arg1, arg2, lineno, columnno) {
}

void NodeOr::accept(Visitor& c) { 
    c.nodeOr(*this); 
}

void NodeOr::print(std::ostream &out) {
	out << "NodeOr: ";
    NodeBinary::print(out);
}
