#include "NodeIntegerValue.hpp"
#include "Type.hpp"

NodeIntegerValue::NodeIntegerValue(int value, int lineno, int columnno) :
	NodeValue(new Type(T_INT, 0, true), lineno, columnno), 
    _value(value) {
}

int NodeIntegerValue::getValue() {
    return _value;
}

void NodeIntegerValue::makeNegative(){
    _value *= -1;
}

void NodeIntegerValue::accept(Visitor& c) { 
    c.nodeIntegerValue(*this); 
}

void NodeIntegerValue::print(std::ostream &out) {
	out << "NodeIntegerValue: " << _value << std::endl;
}
