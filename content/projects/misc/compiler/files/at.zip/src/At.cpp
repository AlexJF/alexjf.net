#include "At.hpp"
#include "Parser.hpp"
#include "PFi386.hpp"
#include "Nodes.hpp"
#include "Type.hpp"
#include "MaxBytesVisitor.hpp"
#include "TypeVisitor.hpp"
#include "ConstIntValueVisitor.hpp"
#include <sstream>

At::At(const std::string &in, const std::string &out, 
       bool debugLex, bool debugYacc, bool printTree) :
    _activeFuncBody(NULL), 
    _returnExecuted(false),
    _stopExecuted(false),
    _nextExecuted(false),
    _currentArgType(NULL),
    _printTree(printTree) {
    _parser = new Parser(in, debugLex, debugYacc);
    if (out != "") {
        _pf = new PFi386(out);
    } 
    else if (in != "") {
        _pf = new PFi386(extension(in, ".asm"));
    } 
    else {
        _pf = new PFi386();
    }
}

At::~At() {
    delete _pf;
    delete _parser;
}

bool At::parse() {
	if (_parser->parse() == 0)
		setTree(_parser->getTree());
	return _parser->getNumErrors() == 0;
}

bool At::generate() {
	if (_parser->getNumErrors() > 0) {
        /* Remove .asm file created on _pf creation */
        _pf->deleteFile();
        return false;
    }
    if (_printTree) printTree();
	getTree()->accept(*this);
	// import library functions
	_pf->EXTRN("readi");
    _pf->EXTRN("readd");
	_pf->EXTRN("printi");
	_pf->EXTRN("prints");
	_pf->EXTRN("printd");
	_pf->EXTRN("println");
	_pf->EXTRN("powerOf");
	_pf->flush();
	if (_parser->getNumErrors() == 0) {
        return true;
    } else {
        _pf->deleteFile();
        return false;
    }
}

void At::STR2CHR(const std::string &str) {
    for (unsigned i = 0; i < str.size(); i++) {
        _pf->CHAR(str[i]);
    }
    _pf->CHAR(0);
}

void At::nodeAdd(NodeAdd &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();
	TypeVisitor v1(_tabid);
	TypeVisitor v2(_tabid);
	Type* t1 = NULL;
	Type* t2 = NULL;
	
	first->accept(v1);
	t1 = v1.getType();
	second->accept(v2);
	t2 = v2.getType();

	NodeExpression* pnt = NULL;
	NodeExpression* value = NULL;
	Type* pntType = NULL;
	_pf->TEXT();
	
	if (t1 != NULL && t2 != NULL) {
		if (t1->getPointerDepth() > 0 && t2->getPointerDepth() > 0) {
			generror("Can't add two pointers", n);
            return;
		}
		else if(t1->getId() == T_INT && t2->getPointerDepth() > 0){
			pnt = second;
			pntType = t2;
			value = first;
		}
		else if (t2->getId() == T_INT && t1->getPointerDepth() > 0){
			pnt = first;
			pntType = t1;
			value = second;
		}
		
		if( pnt != NULL && value != NULL){
			value->accept(*this);
			
			_pf->INT(pntType->dereference()->getSize());
				
			_pf->MUL();
			pnt->accept(*this);
			_pf->ADD();
			n.setType(pnt->getType()->copy());
            return;
		}
	} 

    first->accept(*this);
    second->accept(*this);
    
    Type *firstType = first->getType();
    Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }

    if (!firstType->isCompatible(secondType)) {
        generror("Incompatible types (" + firstType->getName() + 
                 " vs " + secondType->getName() + ")", n);
        return;
    }
    
    switch (firstType->getId()) {
        case T_INT:
            _pf->ADD();
            break;
        case T_STRING:
            generror("Operation not valid on strings", n);
            break;
        case T_REAL:
            _pf->DADD();
            break;
    }
    n.setType(firstType->copy());
}

void At::nodeAddress(NodeAddress &n) {
	NodeExpression* first = n.first();
	
	first->accept(*this);
    if (first->getType() != NULL) {
        n.setType(first->getType()->reference());
    }
}

void At::nodeAlloc(NodeAlloc &n) {
    NodeOperator *parent = n.getParent();
	NodeExpression* first = n.first();
    TypeVisitor v(_tabid);
    Type *type = NULL;

	first->accept(*this);

    if (first->getType() == NULL || first->getType()->getId() != T_INT) {
        generror("Alloc argument must be an integer", n);
    }

    /* If we got this far, the generated tree respects the grammar so
     * we are sure that an alloc can only occur in the right side of
     * an assignment. Due to this, we can be sure it has a parent and
     * that it is of type NodeAssign. Guess its type using the TypeVisitor. */
    parent->accept(v);
    type = v.getType();

    if (type == NULL) {
        generror("Unable to determine what type to alloc" , n);
        return;
    }

    if (type->getPointerDepth() == 0) {
        generror("Can't alloc data to non-pointer type.", n);
        return;
    }

	_pf->TEXT();
	_pf->INT(type->dereference()->getSize());
	_pf->MUL();
	_pf->ALLOC();
	_pf->SP();
	n.setType(type->copy());
}

void At::nodeAnd(NodeAnd &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_REAL:
		case T_INT:
			_pf->AND();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(firstType->copy());
}

void At::nodeAssign(NodeAssign &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();
    TypeVisitor v1(_tabid);
    TypeVisitor v2(_tabid);
    Type *firstType;
    Type *secondType;

    first->accept(v1);
    second->accept(v2);

    firstType = v1.getType();
    secondType = v2.getType();

    /* Check special cases (pointer with int 0 and string with int) */
    if (firstType != NULL && secondType != NULL) {
        /* If we have a <type> = int check if int is = 0 and in case it is, continue */
        if (firstType->getPointerDepth() != 0 && secondType->getId() == T_INT
            && secondType->isConstant()) {
            ConstIntValueVisitor v(_tabid);
            second->accept(v);
            if (!v.foundValue() || v.getValue() != 0) {
                generror("Integer to pointer assignment is only valid when integer is a 0 literal/constant", n);
                return;
            } 
        }
        /* If we have a string = int, convert the second argument to a NodeStringValue */
        else if (firstType->getPointerDepth() == 0 && firstType->getId() == T_STRING &&
                 secondType->getId() == T_INT && secondType->getPointerDepth() == 0 &&
                 secondType->isConstant()) {
            ConstIntValueVisitor v(_tabid);
            second->accept(v);
            if (!v.foundValue()) {
                generror("Unable to determine type of constant integer in string assignment.", n);
                return;
            }
            second = new NodeStringValue(std::string(1, (char)v.getValue()));
        }
    }

	second->accept(*this);
	secondType = second->getType();

    if (secondType == NULL) {
        generror("Type of second argument unknown.", n);
        return;
    } else {
        if (secondType->getSize() == 4 || secondType->getPointerDepth()) 
            _pf->DUP();
        else if (secondType->getSize() == 8)
            _pf->DUP2();
    }

	first->accept(*this);

	firstType = first->getType();
    
    if (firstType == NULL) {
        generror("Type of first argument unknown.", n);
        return;
    }

    if (firstType->isConstant()) {
        generror("Can't assign values to constants", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType)) {
        generror("Incompatible types (" + firstType->getName() + 
                 " vs " + secondType->getName() + ")", n);
        return;
	}

	_pf->TEXT();
    _pf->ALIGN();
    if (firstType->getPointerDepth()) {
		_pf->STORE();
	} else {
		switch (firstType->getId()) {
			case T_INT:
            case T_STRING:
				_pf->STORE();
				break;
			/*case T_STRING:
				generror("Operation not valid on strings", n);
				break;*/
			case T_REAL:
				_pf->STORE2();   
				break;
		}
	}
	n.setType(firstType->copy());
}

void At::nodeBlock(NodeBlock &n) {
    NodeList* var_decls = n.getVarDecls();
    NodeList* instrs = n.getInstrs();

    if (n.createNewNameSpace()) {
        _tabid.pushNameSpace();
    }

    if (var_decls != NULL)
        var_decls->accept(*this);

    if (instrs != NULL) {
        _returnExecuted = false;
        _nextExecuted = false;
        _stopExecuted = false;

        NodeListIterator it;
        std::vector< Node* > &vec = instrs->nodes();

        for (it = vec.begin(); it != vec.end(); it++) {
            if (_returnExecuted) {
                generror("A return instruction must be the last one on its block.", **it);
                _returnExecuted = false;
            }
            else if (_nextExecuted) {
                generror("A next instruction must be the last one on its block.", **it);
                _nextExecuted = false;
            }
            else if (_stopExecuted) {
                generror("A stop instruction must be the last one on its block.", **it);
                _stopExecuted = false;
            }
            (*it)->accept(*this);
        }
    }

    if (n.createNewNameSpace()) {
        _tabid.popNameSpace();
    }
}

void At::nodeCond(NodeCond &n) {
	NodeExpression* condition = n.getCondition();
	Node* instr = n.getInstr();
	_pf->TEXT();
	std::string label = _pf->label();
	condition->accept(*this);
	
	_pf->JZ(label);
	instr->accept(*this);
    /* A return instruction in a if block doesn't mean there can be no more
     * instructions following the if so set the return flag to false */
    _returnExecuted = false;
    _nextExecuted = false;
    _stopExecuted = false;
	_pf->LABEL(label);
}

void At::nodeCondList(NodeCondList &n) {
	NodeList* first = (NodeList *) n.getListCond();
	std::string fim = _pf->label();
	_pf->TEXT();

	for (int i = 0; i < first->size(); i++){
		NodeCond* expr = (NodeCond *)&first->elementAt(i);
		
		if (expr != NULL) {
			NodeExpression* condition = expr->getCondition();
			Node* instr = expr->getInstr();
			std::string label = _pf->label();
			_pf->TEXT();
		
			condition->accept(*this);
			
			_pf->JZ(label);
			instr->accept(*this);
			_pf->JMP(fim);
			_pf->LABEL(label);

			/* A return instruction in a if block doesn't mean there can be no more
			 * instructions following the if so set the return flag to false */
			_returnExecuted = false;
            _nextExecuted = false;
            _stopExecuted = false;
		}
	}

	NodeExpression* condElse = (NodeExpression* )n.getElse();

    if (condElse != NULL) {
        condElse->accept(*this);
        /* A return instruction in an else block doesn't mean there can be no more
         * instructions following the else so set the return flag to false */
        _returnExecuted = false;
        _nextExecuted = false;
        _stopExecuted = false;
    }

	_pf->LABEL(fim);
}

void At::nodeDiv(NodeDiv &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->DIV();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
		case T_REAL:
			_pf->DDIV();
			break;
	}
	
	n.setType(firstType->copy());
	
}

void At::nodeEqual(NodeEqual &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->EQ();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
		case T_REAL:
			_pf->DCMP();
			_pf->INT(0);
			_pf->EQ();
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodeExclusiveSection(NodeExclusiveSection &n) {
	NodeExpression* condition = n.getCondition();
	NodeBlock &block = n.getBlock();
	_pf->TEXT();
	std::string label = _pf->label();

    /* An empty condition is seen as true so we only need to setup a JZ
     * instruction if there is indeed a condition. */
    if (condition != NULL) {
        condition->accept(*this);
        _pf->JZ(label);
    }

	block.accept(*this);

    /* After executing this section, jump to the final section */
    _pf->JMP(_activeFuncBody->getFinalLabel());
	_pf->LABEL(label);
}

void At::nodeFinalSection(NodeFinalSection &n) {
    /* Generate a new final label for the active function. This way, all returns inside
     * a final section will jump to the end of the final section and not the beggining. */
    _activeFuncBody->setFinalLabel(_pf->label());
    n.getBlock().accept(*this);
    _pf->LABEL(_activeFuncBody->getFinalLabel());
}

void At::nodeFuncBody(NodeFuncBody &n) {
    NodeExpression *initialValue = n.getInitialValue();
    NodeInitialSection *initialSection = n.getInitialSection();
    NodeList &sections = n.getSections();
    NodeFinalSection *finalSection = n.getFinalSection();
    NodeFuncDeclare *funcDeclare = n.getFunctionDeclaration();
    NodeList *argList = funcDeclare->getArgList();
    Type *fdt = funcDeclare->getType();
    int returnValueDisplacement = 0;

    _tabid.pushNameSpace();

    _activeFuncBody = &n;

    _pf->TEXT();
    _pf->ALIGN();

    if (argList != NULL) {
        unsigned int displacement = 8;
        unsigned int nargs = argList->size();
        bool optional_args = false;
        NodeVarDeclare *vardecl;

        for (unsigned int i = 0; i < nargs; i++) {
            vardecl = (NodeVarDeclare*)&argList->elementAt(i);
            _tabid.addVarName(vardecl->getName(), new SymbolVar(vardecl->getType()->copy(), displacement));
            displacement += vardecl->getType()->getSize();

            /* Check if this is an optional argument. If it isn't and we have already encountered 
             * atleast one optional argument then this is an error because all arguments after the
             * first optional argument must be optional aswell. */
            if (vardecl->getInitialValue() == NULL) {
                if (optional_args) {
                    generror("All arguments after the first optional one must be optional aswell.", n);
                } 
            /* Else, if it is indeed an optional argument, just set the optional_args flag. */
            } else {
                Type *t1 = vardecl->getInitialValue()->getType();
                Type *t2 = vardecl->getType();
                optional_args = true;
                /* Check if initial value is compatible with the argument type */
                if (!t1->isCompatible(t2)) {
                    /* If we have a string = int, we can convert the int to a character so it
                     * isn't invalid. */
                    if (!(t2->getId() == T_STRING && !t2->getPointerDepth() && t1->getId() == T_INT
                          && t1->isConstant() && !t1->getPointerDepth())) {
                        generror("Formal argument '" + vardecl->getName() + "' and default value have incompatible types: " + t1->getName() + " vs " + t2->getName(), n);
                    }
                }
            }
        }
    }

    if (fdt->getId() != T_VOID) {
        // Calculate the position of the return variable considering the type size
        returnValueDisplacement -= fdt->getSize();
        // Add the return value variable to the tabid if the function type isn't void
        _tabid.addVarName("@", new SymbolVar(fdt->copy(), returnValueDisplacement));
    }

    /* Load the default return value */
    if (initialValue != NULL) {
        /* Check types */
        Type *ivt = initialValue->getType();
        if (!ivt->isCompatible(fdt)) {
            /* Check if we have <ptr> = 0 */
            if (fdt->getPointerDepth() != 0 && ivt->getId() == T_INT) {
                NodeIntegerValue *intValue = (NodeIntegerValue*) initialValue;
                if (intValue->getValue() != 0) {
                    generror("Pointers can only be instantiated by a 0 integer", n);
                }
            } 
            /* If we have a string initialized with a single int, convert the int to a string
             * value */
            else if (fdt->getId() == T_STRING && !fdt->getPointerDepth() &&
                     ivt->getId() == T_INT && !ivt->getPointerDepth()) {
                ConstIntValueVisitor v(_tabid);
                initialValue->accept(v);
                if (!v.foundValue()) {
                    generror("Unable to determine type of constant integer in initial value.", n);
                    return;
                }
                initialValue = new NodeStringValue(std::string(1, (char)v.getValue()));
            }
            else {
                generror("Incompatible types (" + fdt->getName() + " vs " + ivt->getName() + ")", n);
            }
        }

        // Load the default return value to the stack
        initialValue->accept(*this);    
        // Load the address where the local variable containing the return value is stored.
        _pf->LOCAL(returnValueDisplacement);
        // And then store in that address the previously calculated value.
        switch(ivt->getSize()) {
            case 4:
                _pf->STORE();
                break;
            case 8:
                _pf->STORE2();
                break;
        }
    }

    /* Generate label where to jump on function exit either through return or
     * exclusive seciton */
    n.setFinalLabel(_pf->label());

    if (initialSection != NULL) {
        initialSection->accept(*this);
    }

    sections.accept(*this);

    /* Set the label where to jump on function exit either through return or
     * exclusive section */
    _pf->LABEL(n.getFinalLabel());

    if (finalSection != NULL) {
        finalSection->accept(*this);
    }

    /* If function isn't void we have to put the return value in the accumulator */
    if (fdt->getId() != T_VOID) {
        _pf->LOCAL(returnValueDisplacement);
        switch (fdt->getSize()) {
            case 4:
                _pf->LOAD();
                _pf->POP();
                break;
            case 8:
                _pf->LOAD2();
                _pf->DPOP();
                break;
            default:
                generror("Invalid type size", n);
        }
    }

    _tabid.popNameSpace();
    _activeFuncBody = NULL;
}

void At::nodeFuncCall(NodeFuncCall &n) {
    std::string name = n.getName();
    NodeList *argList = n.getArgList();

    /* If we used @ to call the same function we are in right now, the
     * real name of the function to call is the active one */
    if (name == "@") {
        name = _activeFuncBody->getFunctionDeclaration()->getName();
    }

    SymbolFunc *s = _tabid.getFuncSymbol(name);
    
    /* If we didn't find a function symbol for this name, no function with that
     * name was declared */
    if (s == NULL) {
        /* If there is a variable with the same name... */
        if (_tabid.getVarSymbol(name) != NULL) {
            generror("Identifier '" + name + "' is not a function.", n);
        /* Else no such identifier was declared... */
        } else {
            generror("No function named '" + name + "' found in this namespace", n);
        }
        return;
    }

    _pf->TEXT();
    _pf->ALIGN();

    /* Get the total number of arguments this function takes */
    unsigned int numberFormalArgs = s->getNumArgs();
    unsigned int numberActualArgs = (argList == NULL) ? 0 : argList->size();

    if (numberActualArgs > numberFormalArgs) {
        std::stringstream ss;
        ss << "Function '" << name << "' expects a maximum of " << numberFormalArgs;
        ss << " arguments. " << numberActualArgs << " passed.";
        generror(ss.str(), n);
    }

    NodeVarDeclare *formalArg = NULL;
    NodeExpression *actualArg = NULL;
    Type *formalArgType = NULL;
    Type *actualArgType = NULL;
    bool specialCase = false;

    unsigned int bytesToTrash = 0;

    /* Put them in the stack in reverse order (so that the last argument is the
     * one furthest away from the frame pointer) */
    for (int i = numberFormalArgs - 1; i >= 0; i--) {
        specialCase = false;
        formalArg = s->getArg(i);
        formalArgType = formalArg->getType();

        /* If we reached the user provided arguments, put their value in the
         * stack and not the default value of the arguments */
        if (i < numberActualArgs) {
            actualArg = (NodeExpression*) &argList->elementAt(i);

            /* First check special cases */
            if (!formalArgType->getPointerDepth() && formalArgType->getId() == T_STRING) {
                TypeVisitor tv(_tabid);
                actualArg->accept(tv);

                /* If we have a string formal argument and we provided an integer, make the
                 * conversion */
                if (tv.getType() != NULL && tv.getType()->getId() == T_INT &&
                    tv.getType()->isConstant() && !tv.getType()->getPointerDepth()) {
                    ConstIntValueVisitor vv(_tabid);
                    actualArg->accept(vv);
                    if (vv.foundValue()) {
                        actualArg = new NodeStringValue(std::string(1, (char)vv.getValue()));
                        specialCase = true;
                    }
                }
            }
            else if (formalArgType->getPointerDepth()) {
                TypeVisitor tv(_tabid);
                actualArg->accept(tv);

                /* If we have a pointer formal argument and we provided a null integer, let it
                 * continue. Otherwise, it's an error */
                if (tv.getType() != NULL && tv.getType()->getId() == T_INT &&
                    tv.getType()->isConstant() && !tv.getType()->getPointerDepth()) {
                    ConstIntValueVisitor vv(_tabid);
                    actualArg->accept(vv);
                    if (!vv.foundValue() || vv.getValue() != 0) {
                        std::stringstream ss;
                        ss << "Tried to give a non-null integer as actual argument for formal pointer argument at position " << i << " in the argument list.";
                        generror(ss.str(), n);
                        continue;
                    } else {
                        specialCase = true;
                    }
                }
            }

            actualArg->accept(*this);
            actualArgType = actualArg->getType();
            _currentArgType = actualArgType;

            if (actualArgType == NULL) {
                std::stringstream ss;
                ss << "Unknown type of actual argument at position " << i << " in the argument list.";
                generror(ss.str(), n);
                continue;
            }
            else if (!actualArgType->isCompatible(formalArgType) && !specialCase) {
                std::stringstream ss;
                ss << "Incompatible types for actual argument at position " << i << " in the argument list:";
                ss << " expected '" << formalArgType->getName() << "', received '" << actualArgType->getName() << "'";
                generror(ss.str(), n);
                continue;
            } 
            else {
                bytesToTrash += actualArgType->getSize();
            }
        /* Else we are still handling default arguments */
        } else {
            NodeExpression* initialValue = formalArg->getInitialValue();

            /* If one of the supposed default arguments doesn't have a default value
             * this means that the user didn't provide enough arguments to the function */
            if (initialValue == NULL) {
                std::stringstream ss;
                ss << "Insufficient arguments for call to '" << name << "': expected ";
                ss << (i + 1) << " to " << numberFormalArgs << ", provided: " << numberActualArgs;
                generror(ss.str(), n);
                break;
            } else {
                /* First check special string case */
                if (formalArgType->getId() == T_STRING && !formalArgType->getPointerDepth()) {
                    TypeVisitor tv(_tabid);
                    initialValue->accept(tv);

                    /* If we have a string formal argument and we provided an integer, make the
                     * conversion */
                    if (tv.getType() != NULL && tv.getType()->getId() == T_INT &&
                        tv.getType()->isConstant() && !tv.getType()->getPointerDepth()) {
                        ConstIntValueVisitor vv(_tabid);
                        initialValue->accept(vv);
                        if (vv.foundValue()) {
                            initialValue = new NodeStringValue(std::string(1, (char)vv.getValue()));
                        }
                    }
                }

                initialValue->accept(*this);
                bytesToTrash += initialValue->getType()->getSize();
            }
        }
    }

    _currentArgType = NULL;

    _pf->CALL(name);
    _pf->TRASH(bytesToTrash);

    if (s->getType()->getSize() == 4) {
        _pf->PUSH();
    } 
    else if (s->getType()->getSize() == 8) {
        _pf->DPUSH();
    }

    n.setType(s->getType()->copy());
}

void At::nodeFuncDeclare(NodeFuncDeclare &n) {
    const std::string &name = n.getName();
    Type *type = n.getType();
    NodeFuncBody *body = n.getBody();
    NodeList *argList = n.getArgList();
    eQualifier qualifier = type->getQualifier();

    if (_tabid.nameConflict(name)) {
        generror("Identifier '" + name + "' is already in use.", n);
    } 

    NodeVarDeclare **args = NULL;
    unsigned int nargs = 0;

    if (argList != NULL) {
        nargs = argList->size();
        args = new NodeVarDeclare*[nargs];

        for (unsigned int i = 0; i < nargs; i++) {
            args[i] = (NodeVarDeclare*) &argList->elementAt(i);
        }
    }

    SymbolFunc *s = new SymbolFunc(n.getType()->copy(true), args, nargs);
    _tabid.addFuncName(name, s);

    if (body != NULL) {
        MaxBytesVisitor visitor;

        body->accept(visitor);
        
        _pf->TEXT();
        _pf->ALIGN();

        if (qualifier == Q_PUBLIC) {
            _pf->GLOBLfunc(name);
            _pf->LABEL(name);
        }
        else if (qualifier == Q_USE) {
            generror("Function with body can't have use qualifier", n);
            return;
        }
        else {
            _pf->LABEL(name);
        }

        /* Enter function and allocate enough space to hold the return value */
        _pf->ENTER(visitor.getMaxBytesAllocated());
        body->accept(*this);
        _pf->LEAVE();
        _pf->RET();
    } 
    else if (qualifier == Q_USE) {
        _pf->EXTRN(name);
    }
}

void At::nodeGe(NodeGe &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }

	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->GE();
			break;
		case T_REAL:
			_pf->DCMP();
			_pf->INT(0);
			_pf->GE();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodeGt(NodeGt &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->GT();
			break;
		case T_REAL:
			_pf->DCMP();
			_pf->INT(0);
			_pf->GT();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(new Type(T_INT));
	
}

void At::nodeIdentifier(NodeIdentifier &n) {
	const std::string name = n.getName();
	SymbolVar* symbol = _tabid.getVarSymbol(name);
	
	if (symbol == NULL) {
		/* generate error*/
        generror("Identifier '" + name + "' does not exist", n);
    } else {
        Type *type = symbol->getType();
        /* if we should load the identifier addr/value to the stack... */
        if (n.onStack()) {
            _pf->TEXT();
            _pf->ALIGN();

            /* If this is an int constant visible only in this file (be it a global
             * constant or a local one) it isn't saved in memory but is simply 
             * replaced (in all its occurences) by its initial value. Therefore, 
             * we can't get its address and load it so we simply push the value 
             * we know it has to the stack. */
            if (type->isConstant() && type->getId() == T_INT && 
                type->getPointerDepth() == 0 && type->getQualifier() == Q_NONE) {

                NodeValue *initialValue = symbol->getInitialValue();

                if (initialValue == NULL) {
                    generror("Found a constant with no initial value", n);
                    return;
                }

                initialValue->accept(*this);
            } else {
                int displacement = symbol->getDisplacement();   
                if (displacement == 0) {
                    _pf->ADDR(name);
                } else {
                    _pf->LOCAL(displacement);
                }

                /* Should we load the value or just leave the address? In the latter
                 * case we don't need to do anything else. In the first case, call
                 * LOAD or LOAD2 depending on the size of the variable */
                if (n.shouldLoad()){
                    switch (type->getSize()) {
                        case 4:
                            _pf->LOAD();
                            break;
                        case 8:
                            _pf->LOAD2();
                            break;
                    }
                }
            }
        /* if we should put the identifier value directly in memory...
         *
         * Note: This is only possible for constant identifiers used in the 
         *       initialization assignment of another identifier */
        } else {
            if (!type->isConstant()) {
                generror("Attempting to put value of non-const identifier in RODATA/BSS/DATA", n);
                return;
            }

            /* Since identifier is constant, its initial value is its actual value */
            NodeValue *value = symbol->getInitialValue();

            if (value == NULL) {
                generror("Found a constant identifier with no initial value.", n);
                return;
            }

            /* Make value be loaded into the active memory zone */
            value->setOnStack(false);
            /* Load it */
            value->accept(*this);
        }
		n.setType(type->copy(true));
	}
}

void At::nodeInclusiveSection(NodeInclusiveSection &n) {
	NodeExpression* condition = n.getCondition();
	NodeBlock &block = n.getBlock();
	_pf->TEXT();
	std::string label = _pf->label();

    /* An empty condition is seen as true so we only need to setup a JZ
     * instruction if there is indeed a condition. */
    if (condition != NULL) {
        condition->accept(*this);
        _pf->JZ(label);
    }

	block.accept(*this);

    /* An inclusive section with empty condition behaves as an exclusive
     * section so we need to jump to the final section. */
    if (condition == NULL) {
        _pf->JMP(_activeFuncBody->getFinalLabel());
    }

	_pf->LABEL(label);
}

void At::nodeIndex(NodeIndex &n) {
	NodeIdentifier* first = (NodeIdentifier *)n.getIdentifier();
	NodeList* second = (NodeList *)n.getIndexList();
    Type *indexedType = NULL;

	_pf->TEXT();
    _pf->ALIGN();
	
    /* Load only the address of the identifier */
    first->setLoad(false);
	first->accept(*this);

    /* Initial indexation type is the type of the identifier */
    indexedType = first->getType();

    if (indexedType == NULL) {
        generror("Uknown type of first argument", n);
        return;
    }

	for (int i = 0; i < second->size(); i++){
        /* Load the content of the address left at the top of the stack */
		_pf->LOAD();
        indexedType = indexedType->dereference();

        if (indexedType == NULL) {
            generror("Tried to index a non-pointer object", n);
            return;
        }

		NodeExpression* expr = (NodeExpression *)&second->elementAt(i);
        expr->accept(*this);
        if(expr->getType()->getId() != T_INT) {
			generror("Can't index with non-integer value", n);
		}
        _pf->INT(indexedType->getSize());
        _pf->MUL();
        _pf->ADD();
	}

	if (n.shouldLoad()) {
		if(indexedType->getSize() == 8)
			_pf->LOAD2();
        else
			_pf->LOAD();
	}

	n.setType(indexedType->copy(true));
}

void At::nodeInitialSection(NodeInitialSection &n) {
    NodeBlock &block = n.getBlock();
    block.setCreateNewNameSpace(false);
    block.accept(*this);
}

void At::nodeInstr(NodeInstr &n) {
    n.getExpression().accept(*this);
    Type *t = n.getExpression().getType();

    /* Every expression leaves a value on the stack with its result.
     * Since expr; won't do anything special with that result (as opposed
     * to expr! which prints it) we must trash it to avoid accumulating
     * too many values on the stack */
    if (t != NULL) {
        _pf->TRASH(t->getSize());
    }
}

void At::nodeIntegerValue(NodeIntegerValue &n) {
    if (n.onStack()) {
        _pf->INT(n.getValue());
    } else {
        _pf->CONST(n.getValue());
    }
}

void At::nodeIter(NodeIter &n) {
	NodeExpression *condition = n.getCond();
	NodeExpression *inc = n.getInc();
	NodeInstr *instr = n.getInstr();
	Node *initial = n.getInitial(); 
    std::string conditionlbl = _pf->label();
    std::string initiallbl = _pf->label();
    std::string inclbl = _pf->label();
    std::string finallbl = _pf->label();

    n.setInitialLabel(initiallbl);
    n.setIncrementLabel(inclbl);
    n.setConditionLabel(conditionlbl);
    n.setFinalLabel(finallbl);

    NodeIter *oldIter = _activeIter;
    _activeIter = &n;

    _tabid.pushNameSpace();

    _pf->TEXT();
    _pf->ALIGN();
	
	if (initial != NULL) {
		initial->accept(*this);
        if (n.initialIsExpression()) {
            Type *t = ((NodeExpression*)initial)->getType();

            if (t != NULL) {
                _pf->TRASH(t->getSize());
            }
        }
	}
	_pf->JMP(conditionlbl);
    _pf->LABEL(initiallbl);

    if (instr != NULL) {
        instr->accept(*this);
    }

    _pf->LABEL(inclbl);
    if (inc != NULL) {
        inc->accept(*this);
        Type *t = inc->getType();

        // Trash the increment value left on the stack
        if (t != NULL) {
            _pf->TRASH(t->getSize());
        }
    }
    
    _pf->LABEL(conditionlbl);
    if (condition != NULL) {
        condition->accept(*this);
        _pf->JNZ(initiallbl);
    } else {
        _pf->JMP(initiallbl);
    }

    _pf->LABEL(finallbl);
	
    _tabid.popNameSpace();

    /* A return instruction in a if block doesn't mean there can be no more
     * instructions following the if so set the return flag to false */
    _returnExecuted = false;
    _nextExecuted = false;
    _stopExecuted = false;

    _activeIter = oldIter;
}

void At::nodeLe(NodeLe &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->LE();
            break;
		case T_REAL:
			_pf->DCMP();
			_pf->INT(0);
			_pf->LE();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodeList(NodeList &n) {
    NodeListIterator it;
    std::vector< Node* > &vec = n.nodes();

    for (it = vec.begin(); it != vec.end(); it++) {
        (*it)->accept(*this);
    }
}

void At::nodeLt(NodeLt &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->LT();
			break;
		case T_REAL:
			_pf->DCMP();
			_pf->INT(0);
			_pf->LT();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodeMinus(NodeMinus &n) {
	NodeExpression* first = n.first();

	first->accept(*this);

	Type *firstType = first->getType();

    if (firstType == NULL ) {
        generror("Type of argument unknown.", n);
        return;
    }
    if(firstType->getPointerDepth() > 0) {
		generror("Operation not valid on strigs", n);
		return; 
	}
	
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
		case T_REAL:
			_pf->NEG();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodeMod(NodeMod &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->MOD();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
		case T_REAL:
			generror("Operation not valid on reals", n);
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodeMult(NodeMult &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->MUL();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
		case T_REAL:
			_pf->DMUL();
			break;
	}
	
	n.setType(firstType->copy());
	
}

void At::nodeNe(NodeNe &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->NE();
			break;
		case T_REAL:
			_pf->DCMP();
			_pf->INT(0);
			_pf->NE();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodeNeg(NodeNeg &n) {
	NodeExpression* first = n.first();

	first->accept(*this);

	Type *firstType = first->getType();

    if (firstType == NULL) {
        generror("Type of argument unknown.", n);
        return;
    }
    if(firstType->getPointerDepth() > 0) {
		generror("Operation not valid on strigs", n);
		return; 
	}
	
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
		case T_REAL:
			_pf->NOT();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodeNext(NodeNext &n) {
    _pf->TEXT();
    _pf->ALIGN();
    _pf->JMP(_activeIter->getIncrementLabel());
    _nextExecuted = true;
}

void At::nodeOr(NodeOr &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	first->accept(*this);
	second->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType)) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
		case T_REAL:
			_pf->OR();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodePlus(NodePlus &n) {
	NodeExpression* first = n.first();

	first->accept(*this);

	Type *firstType = first->getType();

    if (firstType == NULL) {
        generror("Type of argument unknown.", n);
        return;
    }
    if(firstType->getPointerDepth() > 0) {
		generror("Operation not valid on strigs", n);
		return; 
	}
	
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
		case T_REAL:
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
	}
	
	n.setType(new Type(T_INT));
}

void At::nodePow(NodePow &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();

	second->accept(*this);
	first->accept(*this);

	Type *firstType = first->getType();
	Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }
	
	if (!firstType->isCompatible(secondType) || firstType->getPointerDepth() > 0) {
		generror("Incompatible types (" + firstType->getName() + 
				 " vs " + secondType->getName() + ")", n);
        return;
	}
	_pf->TEXT();
	switch (firstType->getId()) {
		case T_INT:
			_pf->CALL("powerOf");
            _pf->TRASH(8);
            _pf->PUSH();
			break;
		case T_STRING:
			generror("Operation not valid on strings", n);
			break;
		case T_REAL:
			generror("Operation not valid on reals", n);
			break;
	}
	
	n.setType(new Type(T_INT, 0));
}

void At::nodePrint(NodePrint &n) {
    NodeExpression &expression = n.getExpression();
    expression.accept(*this);

    // Determine type of evaluated argument
    Type *type = expression.getType();

    if (type == NULL) {
        generror("Couldn't determine type of expression to print", n);
    } else {
        if (type->getPointerDepth() == 0) {
            switch (type->getId()) {
                case T_STRING:
                    _pf->CALL("prints"); // Call print routine for strings
                    break;
                case T_INT:
                    _pf->CALL("printi"); // Call print routine for integers
                    break;
                case T_REAL:
                    _pf->CALL("printd"); // Call print routine for doubles
                    break;
                default:
                    generror("Can't print expression of type: " + type->getName(), n);
            }
        } else {
            _pf->CALL("printi"); // Call print routine for integers (pointers)
        }
        _pf->TRASH(type->getSize());  // Remove the expression value from the stack
    }


    /* If this is a !! operation, we have to add a new line */
    if (n.putNewLine()) 
        _pf->CALL("println");
}

void At::nodeRead(NodeRead &n) {
    NodeOperator *parent = n.getParent();
    NodeExpression *otherArg = NULL;
    TypeVisitor v(_tabid);
    Type *t = NULL;

    /* If node is inside an operation it has a parent... */
    if (parent != NULL) {
        /* If the first argument of the parent operator is this node, the
         * other argument is the second one. Otherwise it's the first one. */
        if (parent->first() == &n) {
            otherArg = parent->second();
        } else {
            otherArg = parent->first();
        }

        /* If we were able to find another argument, use it to determine the type of the
         * read by sending it the TypeVisitor. */
        if (otherArg != NULL) {
            otherArg->accept(v);

            /* Get the type the TypeVisitor guessed based on the subtree. If the visitor
             * didn't visit anything or was unable to determine the type, t == NULL */
            t = v.getType();
        }
        
        /* If we were unable to find the type of any of the arguments, use the parent 
         * operator's type */
        if (t == NULL) {
            v.reset();
            parent->accept(v);
            t = v.getType();
        }
    }
    /* If node is not inside an operation but we are generating an actual argument,
     * get the type from the actual arg type */
    else if (_currentArgType !=  NULL) {
        t = _currentArgType;
    }

    /* If we were unable to determine the type, default to int */
    if (t == NULL) {
        _pf->CALL("readi");
        _pf->PUSH();
        n.setType(new Type(T_INT));
    /* Else, based on the determined type, call different read functions */
    } else {
        bool pointer = t->getPointerDepth();

        if (t->getId() == T_INT && !pointer) {
            _pf->CALL("readi");
            _pf->PUSH();
            n.setType(t->copy());
        }
        else if (t->getId() == T_REAL && !pointer) {
            _pf->CALL("readd");
            _pf->DPUSH();
            n.setType(t->copy());
        }
        else {
            generror("Can't read type '" + t->getName() + "'", n);
        }
    }
}

void At::nodeRealValue(NodeRealValue &n) {
    if (n.onStack()) {
        std::string label = _pf->label();
        _pf->RODATA();
        _pf->LABEL(label);
        _pf->DOUBLE(n.getValue());
        
        _pf->TEXT();
        _pf->ADDR(label);
        _pf->LOAD2();
    } else {
        _pf->DOUBLE(n.getValue());
    }
}

void At::nodeReturn(NodeReturn &n) {
    _pf->JMP(_activeFuncBody->getFinalLabel());
    _returnExecuted = true;
}

void At::nodeSection(NodeSection &n) {
    n.getBlock().accept(*this);

    /* A section with no condition behaves as an exclusive section with
     * condition = true so when we finish this section we must jump to the
     * end */
    _pf->JMP(_activeFuncBody->getFinalLabel());
}

void At::nodeStop(NodeStop &n) {
    _pf->TEXT();
    _pf->ALIGN();
    _pf->JMP(_activeIter->getFinalLabel());
    _stopExecuted = true;
}

void At::nodeStringValue(NodeStringValue &n) {
    std::string label = _pf->label(); 
    /* If string should be loaded to the stack... */
    if (n.onStack()) {
        /* Create a new label for this string */
        _pf->RODATA();     // Strings are read-only data
        _pf->ALIGN();      // Make sure we are aligned
        _pf->LABEL(label);   // Set the string label
        STR2CHR(n.getValue()); // Generate CHR instruction for each character
        _pf->TEXT();       // Return to TEXT
        _pf->ADDR(label);  // Put the string's address in the stack
    /* If string should be put directly in one of the memory zones... */
    } else {
        _pf->ID(label);
        _pf->RODATA();
        _pf->ALIGN();
        _pf->LABEL(label);
        STR2CHR(n.getValue());
    }
}

void At::nodeSub(NodeSub &n) {
	NodeExpression* first = n.first();
	NodeExpression* second = n.second();
	TypeVisitor v1(_tabid);
	TypeVisitor v2(_tabid);
	Type* t1 = NULL;
	Type* t2 = NULL;
	bool _pntFlag = false;
	first->accept(v1);
	t1 = v1.getType();
	second->accept(v2);
	t2 = v2.getType();
	
	Type* pntType = NULL;
	
	NodeExpression* pnt = NULL;
	NodeExpression* value = NULL;
	
	_pf->TEXT();
	
	if (t1 != NULL && t2 != NULL) {
		if (t1->getPointerDepth() == 0 && t1->getId() == T_INT && t2->getPointerDepth() > 0){
			generror("Incompatible types (" + t1->getName() + 
						 " vs " + t2->getName() + ")", n);
            return;
		}
		else if (t2->getPointerDepth() == 0 && t2->getId() == T_INT && t1->getPointerDepth() > 0){
			pnt = first;
			pntType = t1;
			value = second;
		}
		
		if( pnt != NULL && value != NULL){
			pnt->accept(*this);
			value->accept(*this);
			
			_pf->INT(pntType->dereference()->getSize());
				
			_pf->MUL();
			
			_pf->SUB();
			n.setType(pnt->getType()->copy());
            return;
		}
	}
    first->accept(*this);
    second->accept(*this);
    
    Type *firstType = first->getType();
    Type *secondType = second->getType();

    if (firstType == NULL || secondType == NULL) {
        generror("Type(s) of argument(s) unknown.", n);
        return;
    }

    if (!firstType->isCompatible(secondType)) {
        generror("Incompatible types (" + firstType->getName() + 
                 " vs " + secondType->getName() + ")", n);
        return;
    }
    
    /* If we are subtracting pointers */
    if (firstType->getPointerDepth() > 0) {
        _pf->SUB();
        _pf->INT(firstType->dereference()->getSize());
        _pf->DIV();
    /* If we are subtracting anything else... */
    } else {
        switch (firstType->getId()) {
            case T_INT:
                _pf->SUB();
                break;
            case T_STRING:
                generror("Operation not valid on strings", n);
                break;
            case T_REAL:
                _pf->DSUB();
                break;
        }
    }

    n.setType(firstType->copy());
    return;
}

void At::nodeVarDeclare(NodeVarDeclare &n) {
    const std::string &name = n.getName();
    std::string label = name;
    Type *type = n.getType();
    NodeValue* initialValue = n.getInitialValue();
    bool constant = type->isConstant();
    eQualifier qualifier = type->getQualifier();

    if (_tabid.nameConflict(name)) {
        generror("Identifier '" + name + "' is already in use.", n);
        return;
    }

    /* If initialValue is an identifier, its type will be NULL since we haven't
     * executed nodeIdentifier for this node. Therefore, use the Type visitor to
     * figure out the type of the identifier. */
    if (initialValue != NULL && initialValue->getType() == NULL) {
        TypeVisitor v(_tabid);
        initialValue->accept(v);
        if (v.getType() == NULL) {
            generror("Couldn't figure out the type of the initial value of '" + name + "'", n);
            return;
        }
        initialValue->setType(v.getType()->copy(true));
    }

    if (initialValue != NULL && !type->isCompatible(initialValue->getType())) {
        if (type->getPointerDepth() != 0 && initialValue->getType()->getId() == T_INT) {
            NodeIntegerValue *intValue = (NodeIntegerValue*) initialValue;
            if (intValue->getValue() != 0) {
                generror("Pointers can only be instantiated by a 0 integer", n);
                return;
            }
        } 
        /* If we have a string initialized with a single integer, use its value as the
         * character code of its single char. */
        else if (type->getId() == T_STRING && !type->getPointerDepth() &&
                 initialValue->getType()->getId() == T_INT &&
                 !initialValue->getType()->getPointerDepth()) {
            ConstIntValueVisitor v(_tabid);
            initialValue->accept(v);
            if (!v.foundValue()) {
                generror("Unable to determine type of constant integer in initial value.", n);
                return;
            }
            initialValue = new NodeStringValue(std::string(1, (char)v.getValue()));
        }
        else {
            generror("Incompatible types between variable and initial value (" + type->getName() + " vs " + initialValue->getType()->getName() + ")", n);
            return;
        }
    }

    /* Before doing anything else, check if this variable is actually a non-public int const
     * with a const initial value.
     * In case it is, we won't store its value anywhere in the application's memory and will
     * simply replace all its occurences with its initial value. */
    if (constant && initialValue != NULL && type->getId() == T_INT && qualifier == Q_NONE &&
        initialValue->getType()->isConstant()) {
        _tabid.addVarName(name, new SymbolVar(type->copy(true), 0, initialValue));
        return;
    } 
    /* Global variables are put in memory while local ones are put in the stack */
    else if (_tabid.isGlobalNameSpace()) {
        if (initialValue != NULL && !initialValue->getType()->isConstant()) {
            generror("Attempting to put value of non-const identifier in RODATA/BSS/DAATA", n);
            return;
        }

        /* If variable is instantiated put it in DATA. Otherwise put it in BSS */
        if (!constant) {
            if (initialValue != NULL) {
                _pf->DATA();
            } else {
                _pf->BSS();
            }
        } 
        /* If this is a const put it in RODATA */
        else if (initialValue != NULL) {
            _pf->RODATA();
        }
        else if (qualifier != Q_USE) {
            generror("Constants without use qualifier must be instantiated", n);
            return;
        }

        _pf->ALIGN();

        if (qualifier == Q_PUBLIC) {
            _pf->GLOBL(label);
            _pf->LABEL(label);
        }
        else if (qualifier == Q_USE) {
            _pf->EXTRN(label);
            if (initialValue != NULL) {
                generror("Definitions can't have USE qualifier", n);
            }
        }
        else {
            _pf->LABEL(label);
        }

        /* If variable has an initial value, put it in its memory location.
         * Otherwise just allocate enough bytes to hold it */
        if (initialValue != NULL) {
            initialValue->setOnStack(false);
            initialValue->accept(*this);
        } 
        else if (qualifier != Q_USE) {
            _pf->BYTE(type->getSize());
        }

        _tabid.addVarName(name, new SymbolVar(type->copy(true), 0, initialValue)); // Add it to the tabid
    } else {
        _pf->TEXT();
        _pf->ALIGN();
        int displacement = _tabid.getMinimumDisplacement();
        displacement -= type->getSize();

        if (initialValue != NULL) {
            initialValue->accept(*this);
            _pf->LOCAL(displacement);
            switch (type->getSize()) {
                case 4:
                    _pf->STORE();
                    break;
                case 8:
                    _pf->STORE2();
                    break;
            }
        } 
        else if (constant) {
            generror("Local constants must be instantiated", n);
        }

        _tabid.addVarName(name, new SymbolVar(type->copy(true), displacement, initialValue));
    }
}


void At::generror(const std::string &msg, const Node &n) {
    _parser->error("Semantic error: " + msg, n);
}
