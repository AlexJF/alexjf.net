#include "NodeLt.hpp"

NodeLt::NodeLt(Node* arg1, Node* arg2, int lineno, int columnno) :
	NodeBinary(arg1, arg2, lineno, columnno) {
}

void NodeLt::accept(Visitor& c) { 
    c.nodeLt(*this); 
}

void NodeLt::print(std::ostream &out) {
	out << "NodeLt: ";
	NodeBinary::print(out);
}
