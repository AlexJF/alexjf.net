#include "NodeReturn.hpp"

NodeReturn::NodeReturn(int lineno, int columnno) : 
    Node(lineno, columnno) {
}

void NodeReturn::accept(Visitor& c) { 
    c.nodeReturn(*this); 
}

void NodeReturn::print(std::ostream &out) {
	out << "NodeReturn" << std::endl;
}
