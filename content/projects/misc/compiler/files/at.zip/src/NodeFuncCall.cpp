#include "NodeFuncCall.hpp"
#include "NodeIdentifier.hpp"
#include "NodeList.hpp"

NodeFuncCall::NodeFuncCall(Node* id, Node* argList, int lineno, int columnno) :
    NodeExpression(NULL, lineno, columnno) {
    _id = (NodeIdentifier*) id;
    if (argList != NULL) {
        _argList = (NodeList*) argList;
    } else {
        _argList = NULL;
    }
}

const std::string& NodeFuncCall::getName() const {
    return _id->getName();
}

NodeList* NodeFuncCall::getArgList() const {
    return _argList;
}
				 
void NodeFuncCall::accept(Visitor& c) { 
    c.nodeFuncCall(*this); 
}

void NodeFuncCall::print(std::ostream &out) {
	out << "NodeFuncCall: {" << std::endl;
    out << "Function: " << getName() << std::endl;
    out << "Args: ";
    if (_argList == NULL) {
        out << "NULL" << std::endl;
    } else {
        _argList->print(out);
    }
}
