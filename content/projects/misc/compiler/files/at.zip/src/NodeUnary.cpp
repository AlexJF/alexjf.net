#include "NodeUnary.hpp"

NodeUnary::NodeUnary(Node* arg, int lineno, int columnno) : 
	NodeOperator(arg, NULL, lineno, columnno) {
}

void NodeUnary::print(std::ostream &out) {
	out << "NodeUnary: {" << std::endl;
    if (first() != NULL) {
        first()->print(out);
    } else {
        out << "NULL" << std::endl;
    }
    out << "}" << std::endl;
}
