#include "NodeGt.hpp"

NodeGt::NodeGt(Node* arg1, Node* arg2, int lineno, int columnno) : 
    NodeBinary(arg1, arg2, lineno, columnno) {
}

void NodeGt::accept(Visitor& c) {
    c.nodeGt(*this); 
}

void NodeGt::print(std::ostream &out) {
	out << "NodeGt: ";
	NodeBinary::print(out);
}
