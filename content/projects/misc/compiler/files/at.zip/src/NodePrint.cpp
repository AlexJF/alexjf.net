#include "NodePrint.hpp"

NodePrint::NodePrint(Node* arg, bool newline, int lineno, int columnno) :
	NodeInstr(arg, lineno, columnno), 
    _newline(newline) {
}

bool NodePrint::putNewLine() {
    return _newline;
}

void NodePrint::accept(Visitor &c) {
    c.nodePrint(*this);
}

void NodePrint::print(std::ostream &out) {
	out << "NodePrint: ";
	NodeInstr::print(out);
}
