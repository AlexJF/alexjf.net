#include "NodeNeg.hpp"

NodeNeg::NodeNeg(Node* arg, int lineno, int columnno) : 
	NodeUnary(arg, lineno,  columnno) {
}

void NodeNeg::accept(Visitor& c) { 
    c.nodeNeg(*this); 
}

void NodeNeg::print(std::ostream &out) {
	out << "NodeNeg: ";
	NodeUnary::print(out);
}
