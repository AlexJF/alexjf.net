#include "NodePow.hpp"

NodePow::NodePow(Node* arg1, Node* arg2, int lineno, int columnno) :
	NodeBinary(arg1, arg2, lineno, columnno) {
}
				 
void NodePow::accept(Visitor& c) { 
    c.nodePow(*this); 
}

void NodePow::print(std::ostream &out) {
	out << "NodePow: ";
	NodeBinary::print(out);
}

