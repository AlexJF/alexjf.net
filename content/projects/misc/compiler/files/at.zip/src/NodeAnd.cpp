#include "NodeAnd.hpp"

NodeAnd::NodeAnd(Node* arg1, Node* arg2, int lineno, int columnno) :
    NodeBinary (arg1, arg2, lineno, columnno) {
}

void NodeAnd::accept(Visitor& c) { 
    c.nodeAnd(*this); 
}

void NodeAnd::print(std::ostream &out) {
		out << "NodeAnd: ";
		NodeBinary::print(out);
}
