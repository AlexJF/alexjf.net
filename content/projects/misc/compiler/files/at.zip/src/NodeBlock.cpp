#include "NodeBlock.hpp"
#include "NodeList.hpp"

NodeBlock::NodeBlock(Node *var_decls, Node *instrs, int lineno, int columnno) :
    Node(lineno, columnno),
    _newNS(true) {
    if (var_decls != NULL) {
        _var_decls = (NodeList*) var_decls;
    } else {
        _var_decls = NULL;
    }

    if (instrs != NULL) {
        _instrs = (NodeList*) instrs;
    } else {
        _instrs = NULL;
    }
}

NodeBlock::~NodeBlock() {
    delete _var_decls;
    delete _instrs;
}

NodeList* NodeBlock::getVarDecls() {
    return _var_decls;
}

NodeList* NodeBlock::getInstrs() {
    return _instrs;
}

void NodeBlock::setCreateNewNameSpace(bool value) {
    _newNS = value;
}

bool NodeBlock::createNewNameSpace() {
    return _newNS;
}

void NodeBlock::accept(Visitor &c) {
    c.nodeBlock(*this);
}

void NodeBlock::print(std::ostream &out) {
    out << "NodeBlock: {" << std::endl;
    if (_var_decls != NULL) {
        _var_decls->print(out);
    }
    if (_instrs != NULL) {
        out << "Instrs: ";
        _instrs->print(out);
    }
    out << "}" << std::endl;
}
