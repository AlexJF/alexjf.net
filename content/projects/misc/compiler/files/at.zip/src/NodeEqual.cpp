#include "NodeEqual.hpp"

NodeEqual::NodeEqual(Node* arg1, Node* arg2, int lineno, int columnno) : 
    NodeBinary(arg1, arg2, lineno, columnno) {
}

void NodeEqual::accept(Visitor& c) { 
    c.nodeEqual(*this); 
}

void NodeEqual::print(std::ostream &out) {
	out << "NodeEqual: ";
	NodeBinary::print(out);
}
