#include "NodeFuncBody.hpp"
#include "NodeValue.hpp"
#include "NodeInitialSection.hpp"
#include "NodeFinalSection.hpp"
#include "NodeList.hpp"

NodeFuncBody::NodeFuncBody(Node *defValue, Node *initialSection, Node *sections, 
                           Node *finalSection, int lineno, int columnno) :
    Node(lineno, columnno),
    _funcDecl(NULL) {
    if (defValue != NULL) {
        _defValue = (NodeValue*) defValue;
    } else {
        _defValue = NULL;
    }

    if (initialSection != NULL) {
        _initialSection = (NodeInitialSection*) initialSection;
    } else {
        _initialSection = NULL;
    }

    _sections = (NodeList*) sections;

    if (finalSection != NULL) {
        _finalSection = (NodeFinalSection*) finalSection;
    } else  {
		_finalSection = NULL;
	}
}

NodeFuncBody::~NodeFuncBody() {
    delete _defValue;
    delete _initialSection;
    delete _sections;
    delete _finalSection;
}

NodeValue* NodeFuncBody::getInitialValue() {
    return _defValue;
}

NodeInitialSection* NodeFuncBody::getInitialSection() {
    return _initialSection;
}

NodeList&  NodeFuncBody::getSections() {
    return *_sections;
}

NodeFinalSection* NodeFuncBody::getFinalSection() {
    return _finalSection;
}

NodeFuncDeclare* NodeFuncBody::getFunctionDeclaration() {
    return _funcDecl;
}

void NodeFuncBody::setFunctionDeclaration(NodeFuncDeclare* n) {
    _funcDecl = n;
}

const std::string& NodeFuncBody::getFinalLabel() {
    return _finalLabel;
}

void NodeFuncBody::setFinalLabel(const std::string &lbl) {
    _finalLabel = lbl;
}

void NodeFuncBody::accept(Visitor &c) {
    c.nodeFuncBody(*this);
}

void NodeFuncBody::print(std::ostream &out) {
    out << "Node Func Body: {" << std::endl;
    if (_defValue != NULL) {
        out << "Default Value: ";
        _defValue->print(out);
    }
    if (_initialSection != NULL) {
        out << "Initial Section:";
        _initialSection->print(out);
    }
    out << "Sections: ";
    _sections->print(out);
    if (_finalSection != NULL) {
        out << "Final Section: ";
        _finalSection->print(out);
    }
    out << "}" << std::endl;
}
