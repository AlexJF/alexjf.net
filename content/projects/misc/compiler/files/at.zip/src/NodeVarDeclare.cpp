#include "NodeVarDeclare.hpp"
#include "NodeIdentifier.hpp"
#include "NodeValue.hpp"

NodeVarDeclare::NodeVarDeclare(Type *type, Node *identifier, Node *value, int lineno, 
                               int columnno) : 
    Node(lineno, columnno), 
    _type(type) {

    _identifier = (NodeIdentifier*) identifier;

    if (value != NULL) {
        _value = (NodeValue*) value;
    } else {
        _value = NULL;
    }
}

NodeVarDeclare::~NodeVarDeclare() {
    delete _identifier;
    delete _value;
    delete _type;
}

Type* NodeVarDeclare::getType() const {
    return _type;
}

const std::string& NodeVarDeclare::getName() const {
    return _identifier->getName();
}

NodeValue* NodeVarDeclare::getInitialValue() const {
    return _value;
}

void NodeVarDeclare::accept(Visitor &c) {
    c.nodeVarDeclare(*this);
}

void NodeVarDeclare::print(std::ostream &out) {
	out << "NodeVarDeclare: {" << std::endl;
    out << "Type: " << _type->getName() << std::endl;
    out << "Identifier: ";
    _identifier->print(out);
    if (_value != NULL) {
        out << "Initial value: ";
        _value->print(out);
    }
    out << "}" << std::endl;
}
