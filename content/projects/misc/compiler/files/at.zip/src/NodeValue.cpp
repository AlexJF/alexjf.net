#include "NodeValue.hpp"

NodeValue::NodeValue(Type *t, int lineno, int columnno) :
    NodeExpression(t, lineno, columnno),
    _stack(true) {
}

bool NodeValue::onStack() const {
    return _stack;
}

void NodeValue::setOnStack(bool stack) {
    _stack = stack;
}
