#include "NodeBinary.hpp"

NodeBinary::NodeBinary(Node* arg1, Node* arg2, int lineno, int columno) :
	NodeOperator(arg1, arg2, lineno, columno) { 
}

void NodeBinary::print(std::ostream &out) {
	out << "NodeBinary: {" << std::endl;
    if (first() != NULL) {
        first()->print(out);
    } else {
        out << "NULL" << std::endl;
    }
    if (second() != NULL) {
        second()->print(out);
    } else {
        out << "NULL" << std::endl;
    }
    out << "}" << std::endl;
}
