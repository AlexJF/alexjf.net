#include "NodeNext.hpp"

NodeNext::NodeNext(const int lineno, const int columnno) : 
    Node(lineno, columnno) {
}

void NodeNext::accept(Visitor& c) { 
    c.nodeNext(*this); 
}

void NodeNext::print(std::ostream &out) {
	out << "NodeNext" << std::endl;
}
