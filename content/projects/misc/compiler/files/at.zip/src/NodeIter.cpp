#include "NodeIter.hpp"
#include "NodeExpression.hpp"

NodeIter::NodeIter(Node* initial, Node* expr_cond, Node* expr_inc, Node* instr, 
                   int lineno, int columnno) :
	Node(lineno, columnno),
    _initIsExpr(false) { 
    _initial = initial;

    if (expr_cond != NULL) {
        _expr_cond = (NodeExpression*) expr_cond;
    } else {
        _expr_cond = NULL;
    }

    if (expr_inc != NULL) {
        _expr_inc = (NodeExpression*) expr_inc;
    } else {
        _expr_inc = NULL;
    }

    _instr = instr;
}

NodeIter::~NodeIter() {
    delete _initial;
    delete _expr_cond;
    delete _expr_inc;
    delete _instr;
}
				 
void NodeIter::accept(Visitor& c) { 
    c.nodeIter(*this); 
}

void NodeIter::print(std::ostream &out) {
	out << "NodeIter: {" << std::endl;
    if (_initial != NULL) {
        out << "Initial: ";
        _initial->print(out);
    }
	if (_expr_cond != NULL) {
        out << "Condition: ";
        _expr_cond->print(out);
    }
	if (_expr_inc != NULL) {
        out << "Increment: ";
        _expr_inc->print(out);
    }
	_instr->print(out);
    out << "}" << std::endl;
}

NodeExpression* NodeIter::getCond() {
	return _expr_cond;
}
NodeExpression* NodeIter::getInc() { 
	return _expr_inc;
}
NodeInstr* NodeIter::getInstr() {
	return (NodeInstr *)_instr;
}
Node* NodeIter::getInitial() {
	return _initial;
}

void NodeIter::setInitialLabel(const std::string &lbl) {
    _initiallbl = lbl;
}

const std::string& NodeIter::getInitialLabel() {
    return _initiallbl;
}

void NodeIter::setConditionLabel(const std::string &lbl) {
    _condlbl = lbl;
}

const std::string& NodeIter::getConditionLabel() {
    return _condlbl;
}

void NodeIter::setIncrementLabel(const std::string &lbl) {
    _inclbl = lbl;
}

const std::string& NodeIter::getIncrementLabel() {
    return _inclbl;
}

void NodeIter::setFinalLabel(const std::string &lbl) {
    _finallbl = lbl;
}

const std::string& NodeIter::getFinalLabel() {
    return _finallbl;
}

bool NodeIter::initialIsExpression() const {
    return _initIsExpr;
}

bool NodeIter::setInitialIsExpression(bool val) {
    _initIsExpr = val;
}
