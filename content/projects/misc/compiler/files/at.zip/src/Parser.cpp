#include "Parser.hpp"
#include <FlexLexer.h>
#include "Node.hpp"


Parser::Parser(const std::string &infile, bool debugLex, bool debugYacc) {
    yydebug = debugYacc;
    _lexer = new yyFlexLexer();
    _lexer->set_debug(debugLex);
    _filename = infile;
    if (_filename.length() > 0) {
        _lexer->switch_streams(new std::ifstream(_filename.c_str()), 0);
    }
}

Parser::~Parser() {
    delete _lexer;
}

int Parser::getNumErrors() {
    return _nerrs; 
}

int Parser::parse() {
    _nerrs = 0;
    previousline = -1;
    parser = this;
    return yyparse();
}

Node* Parser::getTree() {
    return _tree;
}

void Parser::setTree(Node *tree) {
    _tree = tree;
}

void Parser::error(const std::string &msg, const Node& n) {
    error(msg, n.getLine(), n.getColumn(), NULL);
}

void Parser::error(const std::string &msg, const std::string &text) {
    error(msg, _lexer->lineno(), columnno, text.length() == 0 ? _lexer->YYText() : text.c_str());
}

void Parser::error(const std::string &msg, int line, int column, const char *text) {
    _nerrs++;
    if (_filename == "")
        std::cerr << msg << ": line " << line;
    else
        std::cerr << _filename << ": line " << line << ": " << msg;
    if (text != 0) std::cerr << " at or before \"" << text << "\"";
    std::cerr << " (column " << column << ")";
    std::cerr << std::endl;
}

int Parser::lex() {
    int result = _lexer->yylex(); 
    lineno = _lexer->lineno();
    return result;
}
