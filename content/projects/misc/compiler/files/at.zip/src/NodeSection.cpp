#include "NodeSection.hpp"
#include "NodeBlock.hpp"

NodeSection::NodeSection(Node *block, int lineno, int columnno) :
    Node(lineno, columnno) {
    _block = (NodeBlock*) block;
}

NodeSection::~NodeSection() {
    delete _block;
}

NodeBlock& NodeSection::getBlock() {
    return *_block;
}

void NodeSection::accept(Visitor &c) {
    c.nodeSection(*this);
}

void NodeSection::print(std::ostream &out) {
    out << "NodeSection: ";
    _block->print(out);
}
