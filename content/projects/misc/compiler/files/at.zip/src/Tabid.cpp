#include "Tabid.hpp"

Tabid::Tabid() {
    pushNameSpace();
}

Tabid::~Tabid() {
    std::vector<VarNameSpace*>::iterator it;

    for (it = _varNameSpaces.begin(); it != _varNameSpaces.end(); it++) {
        delete (*it);
    }

    _varNameSpaces.clear();
}

int Tabid::getNumberNameSpaces() const {
    return _varNameSpaces.size();
}

void Tabid::pushNameSpace() {
    _varNameSpaces.push_back(new VarNameSpace());
}

unsigned int Tabid::popNameSpace() {
    /* We can't pop the global namespace */
    if (_varNameSpaces.size() == 1) {
        return 0;
    }

    VarNameSpace* ns = _varNameSpaces.back();
    SymbolVar* s = NULL;
    unsigned int namespaceSize = 0;

    ns->resetIterator();

    while ((s = ns->iterate()) != NULL) {
        namespaceSize += s->getType()->getSize();
    }

    _varNameSpaces.pop_back();
    delete ns;

    return namespaceSize;
}

void Tabid::addVarName(const std::string &name, SymbolVar *s) {
    _varNameSpaces.back()->add(name, s);
}

void Tabid::addFuncName(const std::string &name, SymbolFunc *s) {
    _funcNameSpace.add(name, s);
}

SymbolVar* Tabid::getVarSymbol(const std::string &name) {
    SymbolVar* symbol = NULL;

    std::vector<VarNameSpace*>::reverse_iterator rit;

    for (rit = _varNameSpaces.rbegin(); rit != _varNameSpaces.rend(); rit++) {
        symbol = (*rit)->get(name);

        if (symbol != NULL) {
            return symbol;
        }
    }

    return symbol;
}

SymbolFunc* Tabid::getFuncSymbol(const std::string &name) {
    /* A name in a higher namespace may obfuscate a function name so check if there is
     * a variable with the same name in a higher namespace. If there is, we can't access
     * the function so return NULL. */
    if (getVarSymbol(name) != NULL) {
        return NULL;
    } else {
        return _funcNameSpace.get(name);
    }
}

int Tabid::getMinimumDisplacement() const {
    int minimum = 0;

    std::vector<VarNameSpace*>::const_reverse_iterator rit;

    for (rit = _varNameSpaces.rbegin(); rit != _varNameSpaces.rend(); rit++) {
        VarNameSpace *ns = *rit;
        (*rit)->resetIterator();
        SymbolVar *s = NULL;
        int displacement = 0;

        while ((s = ns->iterate()) != NULL) {
            displacement = s->getDisplacement();

            if (displacement < minimum) {
                minimum = displacement;
            }
        }

        /* If we already found a variable symbol with a negative displacement,
         * any other variable in a lower namespace will have a higher displacement
         * since it was declared first so we don't need to look any further. */
        if (minimum != 0) {
            break;
        }
    }

    return minimum;
}

bool Tabid::nameConflict(const std::string &name) {
    /* If we are in the global namespace, we have to check for conflicts with the function
     * namespace aswell */
    if (_varNameSpaces.size() == 1) {
        return _varNameSpaces.back()->get(name) != NULL || getFuncSymbol(name) != NULL;
    } else {
        return _varNameSpaces.back()->get(name) != NULL;
    }
}

bool Tabid::isGlobalNameSpace() const {
    return _varNameSpaces.size() == 1;
}
