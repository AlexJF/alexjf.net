#include "Type.hpp"

Type::Type(eType type_id, unsigned int pointer_depth, bool constant, eQualifier qualifier) :
    _typeid(type_id),
    _constant(constant),
    _qualifier(qualifier),
    _pointer_depth(pointer_depth) {
}

eType Type::getId() const {
    return _typeid;
}

std::string Type::getName() const {
    std::string name;

    switch (_qualifier) {
        case Q_USE:
            name += "use ";
            break;
        case Q_PUBLIC:
            name += "public ";
            break;
    }

    if (_constant) {
        name += "const ";
    }

    for (unsigned int i = 0; i < _pointer_depth; i++) {
        name += "<";
    }

    switch (_typeid) {
        case T_VOID:
            name += "void";
            break;
        case T_INT:
            name += "int";
            break;
        case T_REAL:
            name += "real";
            break;
        case T_STRING:
            name += "string";
            break;
    }
    
    for (unsigned int i = 0; i < _pointer_depth; i++) {
        name += ">";
    }

    return name;
}

unsigned int Type::getPointerDepth() const {
    return _pointer_depth;
}

unsigned int Type::getSize() const {
    /* If type represents a pointer its size is 4 bytes. */
    if (_pointer_depth > 0) {
        return 4;
    }

    /* Else we have to check the id to know the type size. */
    switch (_typeid) {
        case T_VOID:
            return 0;
        case T_INT:
        case T_STRING:
            return 4;
        case T_REAL:
            return 8;
    }
}

void Type::setConstant(bool constant) {
    _constant = constant;
}

bool Type::isConstant() const {
    return _constant;
}

void Type::setQualifier(eQualifier qualifier) {
    _qualifier = qualifier;
}

eQualifier Type::getQualifier() const {
    return _qualifier;
}

bool Type::isCompatible(Type *t) const {
    if (t == NULL) {
        return false;
    }

    return _typeid == t->getId() && _pointer_depth == t->getPointerDepth();
}

Type* Type::dereference() const {
    unsigned int depth = getPointerDepth();
    if (depth > 0)
        return new Type(_typeid, depth-1);
    else
        return NULL;
}

Type* Type::reference() const {
    return new Type(_typeid, getPointerDepth() + 1);
}

std::ostream& operator<<(std::ostream &os, const Type &t) {
    for (unsigned int i = 0; i < t.getPointerDepth(); i++) {
        os << "pointer to ";
    }
    os << t.getName();
}

Type* Type::copy(bool copyConstAndQual) const {
    if (copyConstAndQual) {
        return new Type(_typeid, _pointer_depth, _constant, _qualifier);
    } else {
        return new Type(_typeid, _pointer_depth);
    }
}
