#include "NodeNe.hpp"

NodeNe::NodeNe(Node* arg1, Node* arg2, int lineno, int columnno) : 
	NodeBinary(arg1, arg2, lineno,  columnno) {
}

void NodeNe::accept(Visitor& c) { 
    c.nodeNe(*this); 
}

void NodeNe::print(std::ostream &out) {
	out << "NodeNe: ";
    NodeBinary::print(out);
}
