#include "MaxBytesVisitor.hpp"

MaxBytesVisitor::MaxBytesVisitor() :
    _bytes(0),
    _maxBytes(0) {
}

int MaxBytesVisitor::getMaxBytesAllocated() {
    return _maxBytes;
}

void MaxBytesVisitor::nodeAdd(NodeAdd &n) {
}

void MaxBytesVisitor::nodeAddress(NodeAddress &n) {
}

void MaxBytesVisitor::nodeAlloc(NodeAlloc &n) {
}

void MaxBytesVisitor::nodeAnd(NodeAnd &n) {
}

void MaxBytesVisitor::nodeAssign(NodeAssign &n) {
}

void MaxBytesVisitor::nodeBlock(NodeBlock &n) {
    NodeList* var_decls = n.getVarDecls();
    NodeList* instrs = n.getInstrs();

    if (n.createNewNameSpace()) {
        _tabid.pushNameSpace();
    }

    if (var_decls != NULL)
        var_decls->accept(*this);

    if (instrs != NULL)
        instrs->accept(*this);

    if (n.createNewNameSpace()) {
        _bytes -= _tabid.popNameSpace();
    }
}

void MaxBytesVisitor::nodeCond(NodeCond &n) {
    n.getInstr()->accept(*this);
}

void MaxBytesVisitor::nodeCondList(NodeCondList &n) {
	NodeList* first = n.getListCond();

    if (first != NULL) {
        first->accept(*this);
    }

    Node *second = n.getElse();

    if (second != NULL) {
        second->accept(*this);
    }
}

void MaxBytesVisitor::nodeDiv(NodeDiv &n) {
}

void MaxBytesVisitor::nodeEqual(NodeEqual &n) {
}

void MaxBytesVisitor::nodeExclusiveSection(NodeExclusiveSection &n) {
    nodeSection(n);
}

void MaxBytesVisitor::nodeFinalSection(NodeFinalSection &n) {
    nodeSection(n);
}

void MaxBytesVisitor::nodeFuncBody(NodeFuncBody &n) {
    NodeInitialSection *initialSection = n.getInitialSection();
    NodeList &sections = n.getSections();
    NodeFinalSection *finalSection = n.getFinalSection();
    NodeFuncDeclare *funcDeclare = n.getFunctionDeclaration();
    Type *fdt = funcDeclare->getType();

    if (fdt->getId() != T_VOID) {
        _tabid.addVarName("@", new SymbolVar(fdt->copy(), -fdt->getSize()));
        _bytes += fdt->getSize();
        if (_maxBytes < _bytes) {
            _maxBytes = _bytes;
        }
    }

    if (initialSection != NULL) {
        initialSection->accept(*this);
    }

    sections.accept(*this);

    if (finalSection != NULL) {
        finalSection->accept(*this);
    }
}

void MaxBytesVisitor::nodeFuncCall(NodeFuncCall &n) {
}

void MaxBytesVisitor::nodeFuncDeclare(NodeFuncDeclare &n) {
}

void MaxBytesVisitor::nodeGe(NodeGe &n) {
}

void MaxBytesVisitor::nodeGt(NodeGt &n) {
}

void MaxBytesVisitor::nodeIdentifier(NodeIdentifier &n) {
}

void MaxBytesVisitor::nodeInclusiveSection(NodeInclusiveSection &n) {
    nodeSection(n);
}

void MaxBytesVisitor::nodeIndex(NodeIndex &n) {
}

void MaxBytesVisitor::nodeInitialSection(NodeInitialSection &n) {
    NodeBlock &block = n.getBlock();
    block.setCreateNewNameSpace(false);
    block.accept(*this);
}

void MaxBytesVisitor::nodeInstr(NodeInstr &n) {
}

void MaxBytesVisitor::nodeIntegerValue(NodeIntegerValue &n) {
}

void MaxBytesVisitor::nodeIter(NodeIter &n) {
    Node *initial = n.getInitial();
    Node *instr = n.getInstr();

    _tabid.pushNameSpace();

    if (initial != NULL) {
        initial->accept(*this);
    }

    if (instr != NULL) {
        instr->accept(*this);
    }

    _bytes -= _tabid.popNameSpace();
}

void MaxBytesVisitor::nodeLe(NodeLe &n) {
}

void MaxBytesVisitor::nodeList(NodeList &n) {
    NodeListIterator it;
    std::vector< Node* > &vec = n.nodes();

    for (it = vec.begin(); it != vec.end(); it++) {
        (*it)->accept(*this);
    }
}

void MaxBytesVisitor::nodeLt(NodeLt &n) {
}

void MaxBytesVisitor::nodeMinus(NodeMinus &n) {
}

void MaxBytesVisitor::nodeMod(NodeMod &n) {
}

void MaxBytesVisitor::nodeMult(NodeMult &n) {
}

void MaxBytesVisitor::nodeNe(NodeNe &n) {
}

void MaxBytesVisitor::nodeNeg(NodeNeg &n) {
}

void MaxBytesVisitor::nodeNext(NodeNext &n) {
}

void MaxBytesVisitor::nodeOr(NodeOr &n) {
}

void MaxBytesVisitor::nodePlus(NodePlus &n) {
}

void MaxBytesVisitor::nodePow(NodePow &n) {
}

void MaxBytesVisitor::nodePrint(NodePrint &n) {
}

void MaxBytesVisitor::nodeRead(NodeRead &n) {
}

void MaxBytesVisitor::nodeRealValue(NodeRealValue &n) {
}

void MaxBytesVisitor::nodeReturn(NodeReturn &n) {
}

void MaxBytesVisitor::nodeSection(NodeSection &n) {
    n.getBlock().accept(*this);
}

void MaxBytesVisitor::nodeStop(NodeStop &n) {
}

void MaxBytesVisitor::nodeStringValue(NodeStringValue &n) {
}

void MaxBytesVisitor::nodeSub(NodeSub &n) {
}

void MaxBytesVisitor::nodeVarDeclare(NodeVarDeclare &n) {
    const std::string &name = n.getName();
    Type *type = n.getType();
    NodeValue *initialValue = n.getInitialValue();

    int var_size = type->getSize();
    _tabid.addVarName(name, new SymbolVar(type->copy()));
    _bytes += var_size;

    if (_bytes > _maxBytes) {
        _maxBytes = _bytes;
    }
}

void MaxBytesVisitor::nodeWhen(NodeWhen &n) {
}
