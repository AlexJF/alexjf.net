import os, subprocess, sys

def runTest(path, compilerPath):
    if not os.path.isdir(path):
        return

    files = os.listdir(path)
    files.sort()

    numAtFiles = 0
    numSuccess = 0
    numFail = 0
    numUnexpected = 0

    for f in files:
        fullpath = os.path.join(path, f)
        (root, ext) = os.path.splitext(f)

        if ext == ".at":
            numAtFiles += 1
            print("\n\n=====================================================")
            print("Testing " + f)
            print("----------------")
            try: 
                print("Compiling...")
                p = subprocess.Popen([compilerPath, fullpath], stdin = subprocess.PIPE, stdout = subprocess.PIPE, stderr = subprocess.PIPE)
                stdoutdata, stderrdata = p.communicate()

                stdoutdata = stdoutdata.decode("utf-8")
                stderrdata = stderrdata.decode("utf-8")

                print("Return code: " + str(p.returncode))

                if len(stdoutdata) > 0:
                    print("stdout:")
                    print(stdoutdata)
                if len(stderrdata) > 0:
                    print("stderr:")
                    print(stderrdata)

                if p.returncode == 0 and (len(stderrdata) > 0 or len(stdoutdata) > 0):
                    print("** Compiler printed to stderr/stdout but didn't return error code")
                    numUnexpected += 1
                elif p.returncode != 0 and (len(stderrdata) == 0):
                    print("** Compiler reported an error but didn't output any messages")
                    numUnexpected += 1

                if p.returncode != 0:
                    print("Fail")
                    numFail += 1
                    continue

                print("\nAssembling...")

                executableFile = os.path.join(path, root)

                p = subprocess.Popen(['nasm', '-felf32', executableFile + ".asm"], stdin = subprocess.PIPE, stdout = subprocess.PIPE, stderr = subprocess.PIPE)

                stdoutdata, stderrdata = p.communicate()

                stdoutdata = stdoutdata.decode("utf-8")
                stderrdata = stderrdata.decode("utf-8")

                if len(stdoutdata) > 0:
                    print("stdout:")
                    print(stdoutdata)
                if len(stderrdata) > 0:
                    print("stderr:")
                    print(stderrdata)

                if not os.path.isfile(executableFile + ".o"):
                    print("Fail")
                    numFail += 1
                    continue

                print("\nLinking...")

                executableFile = os.path.join(path, root)

                p = subprocess.Popen(['ld', '-melf_i386', executableFile + ".o", "runtime/librun.a", "-o", executableFile], stdin = subprocess.PIPE, stdout = subprocess.PIPE, stderr = subprocess.PIPE)

                stdoutdata, stderrdata = p.communicate()

                stdoutdata = stdoutdata.decode("utf-8")
                stderrdata = stderrdata.decode("utf-8")

                if len(stdoutdata) > 0:
                    print("stdout:")
                    print(stdoutdata)
                if len(stderrdata) > 0:
                    print("stderr:")
                    print(stderrdata)

                if not os.path.isfile(executableFile):
                    print("Fail")
                    numFail += 1
                    continue

                inFilePath = os.path.join(executableFile + ".in")
                stdindata = None
                if (os.path.isfile(inFilePath)):
                    fin = open(inFilePath, "rb")
                    stdindata = fin.read()
                    fin.close()

                print("\nRunning...")

                p = subprocess.Popen([executableFile], stdin = subprocess.PIPE, stdout = subprocess.PIPE, stderr = subprocess.PIPE)

                stdoutdata, stderrdata = p.communicate(stdindata)

                stdoutdata = stdoutdata.decode("utf-8")
                stderrdata = stderrdata.decode("utf-8")

                if len(stdoutdata) > 0:
                    print("stdout:")
                    print(stdoutdata)
                if len(stderrdata) > 0:
                    print("stderr:")
                    print(stderrdata)

                if p.returncode != 0:
                    print("Fail - Return code: " + str(p.returncode))
                    numFail += 1
                    continue

                outFilePath = os.path.join(executableFile + ".out")

                if (os.path.isfile(outFilePath)):
                    fout = open(outFilePath, "r")
                    expectedOutData = fout.read()
                    fout.close()

                    if expectedOutData != stdoutdata:
                        print("Output data differs from expected")
                        numUnexpected += 1
                        continue

                outFilePath = os.path.join(executableFile + "tr.out")

                if (os.path.isfile(outFilePath)):
                    fout = open(outFilePath, "r")
                    expectedOutData = fout.read()
                    fout.close()

                    if expectedOutData != stdoutdata:
                        print("Output data differs from expected")
                        numUnexpected += 1
                        continue

                numSuccess += 1
                print("Success")
            except OSError as e:
                print(str(e))

            print("=======================================\n")

    print("Total files: " + str(numAtFiles))
    print("Total successes: " + str(numSuccess))
    print("Total fails: " + str(numFail))
    print("Total unexpected output: " + str(numUnexpected))

if len(sys.argv) <= 1:
    print("Expected path to directory of test files")
    exit()

scriptDir = os.path.dirname(sys.argv[0])

if scriptDir:
    os.chdir(scriptDir)

compilerPath = os.path.join(os.getcwd(), 'at')

runTest(sys.argv[1], compilerPath)
