import os, subprocess, sys
import re

def generate(path):
    if not os.path.isdir(path):
        return

    files = os.listdir(path)
    files.sort()

    try: 
        for f in files:
            (name, ext) = os.path.splitext(f)

            if name.startswith("Node"):
                fdata = open(os.path.join(path, f), "r")
                data = fdata.read()
                fdata.close()
                fdata = open(os.path.join(path, f), "w")
                fdata.write(re.sub("accept\(Compiler", "accept(Visitor", data))
                fdata.close()

    except Exception as e:
        print(str(e))


scriptDir = os.path.dirname(sys.argv[0])

if scriptDir:
    os.chdir(scriptDir)

generate('src')
generate('include')
