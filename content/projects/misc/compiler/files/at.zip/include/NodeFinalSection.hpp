#ifndef NODEFINALSECTION_H_INCLUDED
#define NODEFINALSECTION_H_INCLUDED

#include "NodeSection.hpp"

class NodeFinalSection : public NodeSection {
    public:
        NodeFinalSection(Node *block, int lineno = 0, int columnno = 0);
        virtual ~NodeFinalSection();

        void setLabel(const std::string &lbl);

        void accept(Visitor &c);
        void print(std::ostream &out = std::cout);

    private:
        std::string _label;
};

#endif
