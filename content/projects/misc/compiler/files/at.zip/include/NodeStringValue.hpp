#ifndef NODESTRINGVALUE_H_INCLUDED
#define NODESTRINGVALUE_H_INCLUDED

#include <string>
#include "NodeValue.hpp"

class NodeStringValue : public NodeValue {
    public:
        NodeStringValue(const std::string &val, int lineno = 0, int columnno = 0);
        NodeStringValue(Node *list, int lineno = 0, int columnno = 0);
        const std::string& getValue();
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);

    private:
        std::string _value;
};

#endif
