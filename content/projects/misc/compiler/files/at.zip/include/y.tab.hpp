#define REALVALUE 257
#define INTVALUE 258
#define CHARVALUE 259
#define STRINGVALUE 260
#define IDENTIFIER 261
#define EQUAL 262
#define GE 263
#define LE 264
#define NE 265
#define OR 266
#define AND 267
#define CONST 268
#define VOID 269
#define INT 270
#define STRING 271
#define REAL 272
#define PUBLIC 273
#define USE 274
#define NEXT 275
#define STOP 276
#define RETURN 277
#define PRINTEXP 278
#define WHEN 279
#define IFX 280
#define UMINUS 281
#define UPLUS 282
#define DECLS 283
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union { 
    Node *n; 
    Type *t;
    bool b;
    int i;
} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
extern YYSTYPE yylval;
