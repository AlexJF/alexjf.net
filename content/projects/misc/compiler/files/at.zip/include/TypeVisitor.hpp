#ifndef TYPEVISITOR_H_INCLUDED
#define TYPEVISITOR_H_INCLUDED

#include <string>
#include "Visitor.hpp"
#include "Nodes.hpp"
#include "Tabid.hpp"

/* This class is responsible for guessing the types of all expressions that
 * accept it. It assumes every expression is valid and that types are compatible
 * so, in case of an assignment operator, it always sets the operator's type to the
 * type of the first argument.
 *
 * If applied to anything other than Expression nodes, the type is set to NULL
 * just as if it is unable to determine the type of an expression. */

class TypeVisitor : public Visitor {
    public:
        TypeVisitor(Tabid &tabid);
        ~TypeVisitor();

        void reset();
        Type* getType() const;

        virtual void nodeAdd(NodeAdd &n);
        virtual void nodeAddress(NodeAddress &n);
        virtual void nodeAlloc(NodeAlloc &n);
        virtual void nodeAnd(NodeAnd &n);
        virtual void nodeAssign(NodeAssign &n);
        virtual void nodeBlock(NodeBlock &n);
        virtual void nodeCond(NodeCond &n);
        virtual void nodeCondList(NodeCondList &n);
        virtual void nodeDiv(NodeDiv &n);
        virtual void nodeEqual(NodeEqual &n);
        virtual void nodeExclusiveSection(NodeExclusiveSection &n);
        virtual void nodeFinalSection(NodeFinalSection &n);
        virtual void nodeFuncBody(NodeFuncBody &n);
        virtual void nodeFuncCall(NodeFuncCall &n);
        virtual void nodeFuncDeclare(NodeFuncDeclare &n);
        virtual void nodeGe(NodeGe &n);
        virtual void nodeGt(NodeGt &n);
        virtual void nodeIdentifier(NodeIdentifier &n);
        virtual void nodeInclusiveSection(NodeInclusiveSection &n);
        virtual void nodeIndex(NodeIndex &n);
        virtual void nodeInitialSection(NodeInitialSection &n);
        virtual void nodeInstr(NodeInstr &n);
        virtual void nodeIntegerValue(NodeIntegerValue &n);
        virtual void nodeIter(NodeIter &n);
        virtual void nodeLe(NodeLe &n);
        virtual void nodeList(NodeList &n);
        virtual void nodeLt(NodeLt &n);
        virtual void nodeMinus(NodeMinus &n);
        virtual void nodeMod(NodeMod &n);
        virtual void nodeMult(NodeMult &n);
        virtual void nodeNe(NodeNe &n);
        virtual void nodeNeg(NodeNeg &n);
        virtual void nodeNext(NodeNext &n);
        virtual void nodeOr(NodeOr &n);
        virtual void nodePlus(NodePlus &n);
        virtual void nodePow(NodePow &n);
        virtual void nodePrint(NodePrint &n);
        virtual void nodeRead(NodeRead &n);
        virtual void nodeRealValue(NodeRealValue &n);
        virtual void nodeReturn(NodeReturn &n);
        virtual void nodeSection(NodeSection &n);
        virtual void nodeStop(NodeStop &n);
        virtual void nodeStringValue(NodeStringValue &n);
        virtual void nodeSub(NodeSub &n);
        virtual void nodeVarDeclare(NodeVarDeclare &n);
        virtual void nodeWhen(NodeWhen &n);

    private:
        void guessOperatorType(NodeOperator &n);

        Type *_type;
        Tabid &_tabid;
        bool _first;
        bool _downwards;
};

#endif
