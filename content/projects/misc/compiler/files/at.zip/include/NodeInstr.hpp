#ifndef NODEINSTR_H_INCLUDED
#define NODEINSTR_H_INCLUDED

#include "Node.hpp"

class NodeExpression;

class NodeInstr : public Node {
    public:
        NodeInstr(Node *expr, int lineno = 0, int columnno = 0);
        virtual ~NodeInstr();

        NodeExpression& getExpression();

        virtual void accept(Visitor &c);
        virtual void print(std::ostream &out = std::cout);
    private:
        NodeExpression *_expr;
};

#endif
