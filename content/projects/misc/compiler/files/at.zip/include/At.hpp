#ifndef AT_H_INCLUDED
#define AT_H_INCLUDED

#include <string>
#include "Compiler.hpp"
#include "Tabid.hpp"

class Parser;
class Postfix;

class At : public Compiler {
    public:
        At(const std::string &in = "", const std::string &out = "", 
           bool debugLex = false, bool debugYacc = false, bool printTree = false);
        ~At();

        bool parse();
        bool generate();

        void STR2CHR(const std::string &str);

        void nodeAdd(NodeAdd &n);
        void nodeAddress(NodeAddress &n);
        void nodeAlloc(NodeAlloc &n);
        void nodeAnd(NodeAnd &n);
        void nodeAssign(NodeAssign &n);
        void nodeBlock(NodeBlock &n);
        void nodeCond(NodeCond &n);
        void nodeCondList(NodeCondList &n);
        void nodeDiv(NodeDiv &n);
        void nodeEqual(NodeEqual &n);
        void nodeExclusiveSection(NodeExclusiveSection &n);
        void nodeFinalSection(NodeFinalSection &n);
        void nodeFuncBody(NodeFuncBody &n);
        void nodeFuncCall(NodeFuncCall &n);
        void nodeFuncDeclare(NodeFuncDeclare &n);
        void nodeGe(NodeGe &n);
        void nodeGt(NodeGt &n);
        void nodeIdentifier(NodeIdentifier &n);
        void nodeInclusiveSection(NodeInclusiveSection &n);
        void nodeIndex(NodeIndex &n);
        void nodeInitialSection(NodeInitialSection &n);
        void nodeInstr(NodeInstr &n);
        void nodeIntegerValue(NodeIntegerValue &n);
        void nodeIter(NodeIter &n);
        void nodeLe(NodeLe &n);
        void nodeList(NodeList &n);
        void nodeLt(NodeLt &n);
        void nodeMinus(NodeMinus &n);
        void nodeMod(NodeMod &n);
        void nodeMult(NodeMult &n);
        void nodeNe(NodeNe &n);
        void nodeNeg(NodeNeg &n);
        void nodeNext(NodeNext &n);
        void nodeOr(NodeOr &n);
        void nodePlus(NodePlus &n);
        void nodePow(NodePow &n);
        void nodePrint(NodePrint &n);
        void nodeRead(NodeRead &n);
        void nodeRealValue(NodeRealValue &n);
        void nodeReturn(NodeReturn &n);
        void nodeSection(NodeSection &n);
        void nodeStop(NodeStop &n);
        void nodeStringValue(NodeStringValue &n);
        void nodeSub(NodeSub &n);
        void nodeVarDeclare(NodeVarDeclare &n);
        void nodeWhen(NodeWhen &n);

    private:
        Parser *_parser;
        Postfix *_pf;
        Tabid _tabid;
        bool _printTree;

        bool _returnExecuted;
        bool _nextExecuted;
        bool _stopExecuted;

        NodeFuncBody *_activeFuncBody;
        NodeIter *_activeIter;
        Type *_currentArgType;

        void generror(const std::string &msg, const Node &n);
};
#endif
