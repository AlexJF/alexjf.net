#ifndef SYMBOL_H_INCLUDED
#define SYMBOL_H_INCLUDED

#include "Type.hpp"

class NodeVarDeclare;
class NodeValue;

class SymbolVar {
    public:
        SymbolVar(Type *t, int displacement = 0, NodeValue *initialValue = NULL);
        ~SymbolVar();

        Type* getType() const;
        int getDisplacement() const;
        NodeValue* getInitialValue() const;

    private:
        Type *_t;
        int _displacement;
        NodeValue *_initialValue;
};

class SymbolFunc {
    public:
        SymbolFunc(Type *t, NodeVarDeclare **args, unsigned int nargs);
        virtual ~SymbolFunc();

        Type* getType() const;
        NodeVarDeclare* getArg(unsigned int pos) const;
        unsigned int getNumArgs() const;

    private:
        Type *_t;
        NodeVarDeclare **_args;
        unsigned int _nargs;
};

#endif
