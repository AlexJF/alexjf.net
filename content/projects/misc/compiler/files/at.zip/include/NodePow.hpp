#ifndef NODEPOW_H_INCLUDED
#define NODEPOW_H_INCLUDED

#include "NodeBinary.hpp"

class NodePow : public NodeBinary {
    public:
        NodePow(Node* arg1, Node* arg2, int lineno = 0, int column = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
