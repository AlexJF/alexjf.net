#ifndef NODENE_H_INCLUDED
#define NODENE_H_INCLUDED

#include "NodeBinary.hpp"

class NodeNe : public NodeBinary {
    public:
        NodeNe(Node* arg1, Node* arg2, int lineno = 0, int columnno = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
