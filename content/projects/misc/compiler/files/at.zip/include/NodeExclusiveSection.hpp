#ifndef NODEEXCLUSIVESECTION_H_INCLUDED
#define NODEEXCLUSIVESECTION_H_INCLUDED

#include "NodeSection.hpp"

class NodeExpression;

class NodeExclusiveSection : public NodeSection {
    public:
        NodeExclusiveSection(Node* condition, Node *block, int lineno = 0, int columnno = 0);
        ~NodeExclusiveSection();

        NodeExpression* getCondition();

        void accept(Visitor &c);
        void print(std::ostream &out = std::cout);

    private:
        NodeExpression *_condition;
};

#endif
