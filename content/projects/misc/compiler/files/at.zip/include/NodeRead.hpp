#ifndef NODEREAD_H_INCLUDED
#define NODEREAD_H_INCLUDED

#include "NodeExpression.hpp"

class NodeRead : public NodeExpression {
    public:
        NodeRead(int lineno = 0, int columno = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
