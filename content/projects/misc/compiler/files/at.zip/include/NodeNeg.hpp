#ifndef NODENEG_H_INCLUDED
#define NODENEG_H_INCLUDED

#include "NodeUnary.hpp"

class NodeNeg : public NodeUnary {
    public:
        NodeNeg(Node* arg, int lineno = 0, int columnno = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
