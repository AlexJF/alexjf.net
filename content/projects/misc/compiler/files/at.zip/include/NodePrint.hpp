#ifndef NODEPRINT_H_INCLUDED
#define NODEPRINT_H_INCLUDED

#include "NodeInstr.hpp"

class NodePrint : public NodeInstr {
    public:
        NodePrint(Node* arg, bool newline = false, int lineno = 0, int columno = 0);

        bool putNewLine();

        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
    private:
		bool _newline;
};

#endif
