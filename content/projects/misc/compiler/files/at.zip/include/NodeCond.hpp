#ifndef NODECOND_H_INCLUDED
#define NODECOND_H_INCLUDED

#include "Node.hpp"

class NodeExpression;

class NodeCond : public Node {
    public:
        NodeCond(Node *cond, Node *instr, int lineno = 0, int columnno = 0);
        virtual ~NodeCond();
		
		NodeExpression* getCondition();
		Node *getInstr();
        void accept(Visitor &c);
        void print(std::ostream &out = std::cout);

    private:
        NodeExpression *_cond;
        Node *_instr;
};

#endif
