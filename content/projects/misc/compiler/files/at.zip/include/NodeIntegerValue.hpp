#ifndef NODEINTEGERVALUE_H_INCLUDED
#define NODEINTEGERVALUE_H_INCLUDED

#include "NodeValue.hpp"

class NodeIntegerValue : public NodeValue {
    public:
        NodeIntegerValue(int value, int lineno = 0, int columnno = 0);
        int getValue();
        void makeNegative();
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);

    private:
        int _value;
};

#endif
