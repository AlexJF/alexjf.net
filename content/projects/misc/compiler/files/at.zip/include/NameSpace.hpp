#ifndef NAMESPACE_H_INCLUDED
#define NAMESPACE_H_INCLUDED

#include <map>
#include <string>

template <typename T>
class NameSpace {
    public:
        NameSpace() {}
        virtual ~NameSpace() {
            typename std::map< std::string, T* >::iterator it;

            for (it = _map.begin(); it != _map.end(); it++) {
                delete it->second;
            }

            _map.clear();
        }

        void add(const std::string &name, T *element) {
            delete _map[name];
            _map[name] = element;
        }

        void remove(const std::string &name) {
            add(name, NULL);
        }

        T* get(const std::string &name) {
            typename std::map< std::string, T* >::iterator it;

            it = _map.find(name);

            if (it == _map.end()) {
                return NULL;
            } else {
                return it->second;
            }
        }

        unsigned int size() {
            return _map.size();
        }
        
        const std::map< std::string, T*>& getMap() {
            return _map;
        }

        void resetIterator() {
            _it = _map.begin();
        }

        T* iterate() {
            if (_it == _map.end()) {
                return NULL;
            } else {
                T* t = _it->second;
                _it++;
                return t;
            }
        }

    private:
        std::map< std::string, T* > _map;
        typename std::map< std::string, T* >::iterator _it;
};

#endif
