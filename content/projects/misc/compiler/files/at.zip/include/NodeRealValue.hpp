#ifndef NODEREALVALUE_H_INCLUDED
#define NODEREALVALUE_H_INCLUDED

#include "NodeValue.hpp"

class NodeRealValue : public NodeValue {
    public:
        NodeRealValue(double value, int lineno = 0, int columnno = 0);
        double getValue();
        void makeNegative();
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);

    private:
        double _value; 
};

#endif
