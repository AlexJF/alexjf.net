#ifndef NODEINDEX_H_INCLUDED
#define NODEINDEX_H_INCLUDED

#include "NodeExpression.hpp"

class NodeIndex : public NodeExpression {
	public:
		NodeIndex(Node* id, Node* index, int lineno = 0, int columnno = 0);
		~NodeIndex();
		
        void accept(Visitor& c);
		void print(std::ostream &out = std::cout);
		bool shouldLoad();
		void setLoad(bool load);
		NodeIdentifier* getIdentifier();
		NodeList* getIndexList();

	private:
		NodeIdentifier* _id;
		NodeList* _indexList;
		bool _shouldLoad;
};

#endif
