#ifndef NODEPLUS_H_INCLUDED
#define NODEPLUS_H_INCLUDED

#include "NodeUnary.hpp"

class NodePlus : public NodeUnary {
    public:
        NodePlus(Node* arg, int lineno = 0, int columnno = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
