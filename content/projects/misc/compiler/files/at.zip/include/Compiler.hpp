#ifndef COMPILER_H_INCLUDED
#define COMPILER_H_INCLUDED

#include <string>
#include "Visitor.hpp"

class Compiler : public Visitor {
    public:
        ~Compiler();

        static std::string extension(const std::string &filename, const std::string &ext);

        virtual bool parse() = 0;
        virtual bool generate() = 0;

        void printTree();
        Node* getTree();

        virtual void nodeAdd(NodeAdd &n) = 0;
        virtual void nodeAddress(NodeAddress &n) = 0;
        virtual void nodeAlloc(NodeAlloc &n) = 0;
        virtual void nodeAnd(NodeAnd &n) = 0;
        virtual void nodeAssign(NodeAssign &n) = 0;
        virtual void nodeBlock(NodeBlock &n) = 0;
        virtual void nodeCond(NodeCond &n) = 0;
        virtual void nodeCondList(NodeCondList &n) = 0;
        virtual void nodeDiv(NodeDiv &n) = 0;
        virtual void nodeEqual(NodeEqual &n) = 0;
        virtual void nodeExclusiveSection(NodeExclusiveSection &n) = 0;
        virtual void nodeFinalSection(NodeFinalSection &n) = 0;
        virtual void nodeFuncBody(NodeFuncBody &n) = 0;
        virtual void nodeFuncCall(NodeFuncCall &n) = 0;
        virtual void nodeFuncDeclare(NodeFuncDeclare &n) = 0;
        virtual void nodeGe(NodeGe &n) = 0;
        virtual void nodeGt(NodeGt &n) = 0;
        virtual void nodeIdentifier(NodeIdentifier &n) = 0;
        virtual void nodeInclusiveSection(NodeInclusiveSection &n) = 0;
        virtual void nodeIndex(NodeIndex &n) = 0;
        virtual void nodeInitialSection(NodeInitialSection &n) = 0;
        virtual void nodeInstr(NodeInstr &n) = 0;
        virtual void nodeIntegerValue(NodeIntegerValue &n) = 0;
        virtual void nodeIter(NodeIter &n) = 0;
        virtual void nodeLe(NodeLe &n) = 0;
        virtual void nodeList(NodeList &n) = 0;
        virtual void nodeLt(NodeLt &n) = 0;
        virtual void nodeMinus(NodeMinus &n) = 0;
        virtual void nodeMod(NodeMod &n) = 0;
        virtual void nodeMult(NodeMult &n) = 0;
        virtual void nodeNe(NodeNe &n) = 0;
        virtual void nodeNeg(NodeNeg &n) = 0;
        virtual void nodeNext(NodeNext &n) = 0;
        virtual void nodeOr(NodeOr &n) = 0;
        virtual void nodePlus(NodePlus &n) = 0;
        virtual void nodePow(NodePow &n) = 0;
        virtual void nodePrint(NodePrint &n) = 0;
        virtual void nodeRead(NodeRead &n) = 0;
        virtual void nodeRealValue(NodeRealValue &n) = 0;
        virtual void nodeReturn(NodeReturn &n) = 0;
        virtual void nodeSection(NodeSection &n) = 0;
        virtual void nodeStop(NodeStop &n) = 0;
        virtual void nodeStringValue(NodeStringValue &n) = 0;
        virtual void nodeSub(NodeSub &n) = 0;
        virtual void nodeVarDeclare(NodeVarDeclare &n) = 0;

    protected:
        void setTree(Node *tree);

    private:
        Node* _tree;
};

#endif
