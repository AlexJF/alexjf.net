#ifndef NODEFUNCCALL_H_INCLUDED
#define NODEFUNCCALL_H_INCLUDED

#include "NodeExpression.hpp"

class NodeIdentifier;
class NodeList;

class NodeFuncCall : public NodeExpression {
	public:
		NodeFuncCall(Node* id, Node* argList, int lineno = 0, int columnno = 0);

        const std::string& getName() const;
        NodeList* getArgList() const;

		void accept(Visitor& c);
		void print(std::ostream &out = std::cout);

    private:
        NodeIdentifier *_id;
        NodeList *_argList;
};
#endif
