#ifndef TYPE_H_INCLUDED
#define TYPE_H_INCLUDED

#include <iostream>

enum eType {T_VOID, T_INT, T_REAL, T_STRING};
enum eQualifier {Q_NONE, Q_PUBLIC, Q_USE};

class Type {
    public:
        Type(eType type_id, unsigned int pointer_depth = 0, bool constant = false, 
             eQualifier qualifier = Q_NONE);

        eType getId() const;
        std::string getName() const;
        unsigned int getPointerDepth() const;
        unsigned int getSize() const;

        void setConstant(bool constant);
        bool isConstant() const;

        void setQualifier(eQualifier qualifier);
        eQualifier getQualifier() const;

        bool isCompatible(Type *t) const;

        Type* dereference() const;
        Type* reference() const;
        Type* copy(bool copyConstantAndQual = false) const;

        friend std::ostream& operator<<(std::ostream &os, const Type &t);
    private:
        eType _typeid;
        unsigned int _pointer_depth;
        bool _constant;
        eQualifier _qualifier;
};

#endif
