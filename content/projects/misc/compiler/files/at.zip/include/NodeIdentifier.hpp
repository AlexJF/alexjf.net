#ifndef NODEIDENTIFIER_H_INCLUDED
#define NODEIDENTIFIER_H_INCLUDED

#include "NodeValue.hpp"

class NodeIdentifier : public NodeValue {
    public:
        NodeIdentifier(const std::string &name, int lineno = 0, int columno = 0);

        const std::string& getName() const;

        void setLoad(bool load);
        bool shouldLoad() const;

        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);

    private:
        std::string _name;
        NodeValue* _value;
        bool _load;
};

#endif
