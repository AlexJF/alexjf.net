#ifndef NODEITER_H_INCLUDED
#define NODEITER_H_INCLUDED

#include "Node.hpp"

class NodeExpression;

class NodeIter : public Node {
	public: 
		NodeIter(Node* initial, Node* expr_cond, Node* expr_inc, Node* instr, int lineno = 0, int columnno = 0);
        ~NodeIter();

		void accept(Visitor& c);
		void print(std::ostream &out = std::cout);

		NodeExpression* getCond();
		NodeExpression* getInc();
		NodeInstr* getInstr();
		Node* getInitial();
        bool initialIsExpression() const;
        bool setInitialIsExpression(bool val);

        void setInitialLabel(const std::string &lbl);
        const std::string& getInitialLabel();
        void setIncrementLabel(const std::string &lbl);
        const std::string& getIncrementLabel();
        void setConditionLabel(const std::string &lbl);
        const std::string& getConditionLabel();
        void setFinalLabel(const std::string &lbl);
        const std::string& getFinalLabel();
	private:
		Node *_initial; 
        NodeExpression *_expr_cond; 
        NodeExpression *_expr_inc; 
        Node *_instr;
        bool _initIsExpr;

        std::string _initiallbl;
        std::string _inclbl;
        std::string _condlbl;
        std::string _finallbl;
};
#endif
