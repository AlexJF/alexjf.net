#ifndef NODEVALUE_H_INCLUDED
#define NODEVALUE_H_INCLUDED

#include "NodeExpression.hpp"

class Type;

class NodeValue : public NodeExpression {
    public:
        NodeValue(Type *t, int lineno, int columnno);

        bool onStack() const;
        void setOnStack(bool stack);

    private:
        bool _stack;
};

#endif
