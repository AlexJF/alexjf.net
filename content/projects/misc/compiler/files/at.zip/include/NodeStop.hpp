#ifndef NODESTOP_H_INCLUDED
#define NODESTOP_H_INCLUDED

#include "Node.hpp"

class NodeStop : public Node {
    public:
        NodeStop(int lineno = 0, int columnno = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
