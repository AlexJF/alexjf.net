#ifndef NODESECTION_H_INCLUDED
#define NODESECTION_H_INCLUDED

#include "Node.hpp"

class NodeBlock;

class NodeSection : public Node {
    public:
        NodeSection(Node *block, int lineno = 0, int columnno = 0);
        virtual ~NodeSection();

        NodeBlock& getBlock();

        void accept(Visitor &c);
        void print(std::ostream &out = std::cout);

    private:
        NodeBlock *_block;
};

#endif
