#ifndef NODEGE_H_INCLUDED
#define NODEGE_H_INCLUDED

#include "NodeBinary.hpp"

class NodeGe : public NodeBinary {
    public:
        NodeGe(Node *arg1, Node *arg2, int lineno = 0, int columnno = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
