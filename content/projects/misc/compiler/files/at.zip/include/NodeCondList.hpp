#ifndef NODECONDLIST_H_INCLUDED
#define NODECONDLIST_H_INCLUDED

#include "Node.hpp"

class NodeList;

class NodeCondList : public Node {
    public:
        NodeCondList(Node *condList, Node *nodeElse = NULL, int lineno = 0, int columnno = 0);
        virtual ~NodeCondList();

        void accept(Visitor &c);
        void print(std::ostream &out = std::cout);
        Node* getElse();
        NodeList* getListCond();

    private:
        NodeList *_condList;
        Node *_else;
};

#endif
