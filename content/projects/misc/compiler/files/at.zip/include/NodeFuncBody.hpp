#ifndef NODEFUNCBODY_H_INCLUDED
#define NODEFUNCBODY_H_INCLUDED

#include "Node.hpp"

class NodeValue;
class NodeInitialSection;
class NodeList;
class NodeFinalSection;
class NodeFuncDeclare;

class NodeFuncBody : public Node {
    public:
        NodeFuncBody(Node *defValue, Node *initialSection, Node *sections, 
                     Node *finalSection, const int lineno = 0, const int columnno = 0);
        ~NodeFuncBody();

        NodeValue* getInitialValue();
        NodeInitialSection* getInitialSection();
        NodeList&  getSections();
        NodeFinalSection* getFinalSection();
        NodeFuncDeclare* getFunctionDeclaration();
        void setFunctionDeclaration(NodeFuncDeclare* n);

        const std::string& getFinalLabel();
        void setFinalLabel(const std::string &lbl);

        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);

    private:
        NodeValue *_defValue;
        NodeInitialSection *_initialSection;
        NodeList *_sections;
        NodeFinalSection *_finalSection;
        NodeFuncDeclare *_funcDecl;
        std::string _finalLabel;
};

#endif
