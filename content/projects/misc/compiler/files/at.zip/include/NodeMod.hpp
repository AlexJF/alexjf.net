#ifndef NODEMOD_H_INCLUDED
#define NODEMOD_H_INCLUDED

#include "NodeBinary.hpp"

class NodeMod : public NodeBinary {
    public:
        NodeMod(Node* arg1, Node* arg2, int lineno = 0, int column = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};
#endif
