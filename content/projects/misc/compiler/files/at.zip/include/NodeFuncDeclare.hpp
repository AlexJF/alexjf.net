#ifndef NODEFUNCDECLARE_H_INCLUDED
#define NODEFUNCDECLARE_H_INCLUDED

#include "Node.hpp"
#include "Type.hpp"

class NodeIdentifier;
class NodeFuncBody;
class NodeList;

class NodeFuncDeclare : public Node {
    public:
        NodeFuncDeclare(Type *type, Node* identifier, Node* argList, Node *body, int lineno = 0, int columnno = 0);
        ~NodeFuncDeclare();

        const std::string& getName();
        Type* getType();
        NodeList* getArgList();
        NodeFuncBody* getBody();

        eQualifier getQualifier();

        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);

    private:
        eQualifier _qualifier; 
        Type *_type;
        NodeIdentifier *_identifier; 
        NodeList *_argList;
        NodeFuncBody *_body;
};

#endif
