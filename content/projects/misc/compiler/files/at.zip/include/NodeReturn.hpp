#ifndef NODERETURN_H_INCLUDED
#define NODERETURN_H_INCLUDED

#include "Node.hpp"

class NodeReturn : public Node {
    public:
        NodeReturn(int lineno = 0, int columnno = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
