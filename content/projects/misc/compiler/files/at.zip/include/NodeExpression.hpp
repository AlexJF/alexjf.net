#ifndef NODEEXPRESSION_H_INCLUDED
#define NODEEXPRESSION_H_INCLUDED

#include "Node.hpp"

class Type;
class NodeOperator;

class NodeExpression : public Node {
    public:
        NodeExpression(Type* t, int lineno = 0, int columnno = 0);
        virtual ~NodeExpression();

        void setParent(NodeOperator *parent);
        NodeOperator* getParent();

        Type* getType();
        void setType(Type *t);
    private:
        Type *_t;
        NodeOperator *_parent;
};

#endif
