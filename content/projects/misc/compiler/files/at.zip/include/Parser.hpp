#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>

class Parser; // Forward declaration
class yyFlexLexer;

extern int previousline;
extern int columnno;
extern int lineno;
extern int yydebug;
extern int yyparse();
extern Parser *parser;

class Node;

class Parser {
    public:
        Parser(const std::string &infile = "", bool debugLex = false, bool debugYacc = false);
        ~Parser();
        
        int getNumErrors();
        int parse();
        int debugLex();

        Node* getTree(); 
        void setTree(Node *t);

        void error(const std::string &msg, const Node &n);
        void error(const std::string &msg, const std::string &text = "");
        void error(const std::string &msg, int line, int column, const char *text = 0);

        int lex(); 

    private:
        yyFlexLexer *_lexer;
        int _nerrs;
        Node *_tree;
        std::string _filename;
};

#endif
