#ifndef NODEINCLUSIVESECTION_H_INCLUDED
#define NODEINCLUSIVESECTION_H_INCLUDED

#include "NodeSection.hpp"

class NodeExpression;

class NodeInclusiveSection : public NodeSection {
    public:
        NodeInclusiveSection(Node* condition, Node *block, int lineno = 0, int columnno = 0);
        virtual ~NodeInclusiveSection();

        NodeExpression* getCondition();

        void accept(Visitor &c);
        void print(std::ostream &out = std::cout);

    private:
        NodeExpression *_condition;
};

#endif
