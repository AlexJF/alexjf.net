#ifndef NODENEXT_H_INCLUDED
#define NODENEXT_H_INCLUDED

#include "Node.hpp"

class NodeNext : public Node {
    public:
        NodeNext(const int lineno = 0, const int columno = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
