#ifndef NODEWHEN_H_INCLUDED
#define NODEWHEN_H_INCLUDED

#include "Node.hpp"

class NodeExpression;

class NodeWhen : public Node {
    public:
        NodeWhen(Node *expr, Node *cond, int lineno = 0, int columnno = 0);
        virtual ~NodeWhen();
		
		NodeExpression* getCondition();
		NodeExpression *getExpression();
        void accept(Visitor &c);
        void print(std::ostream &out = std::cout);

    private:
        NodeExpression *_cond;
        NodeExpression *_expr;
};

#endif
