#ifndef NODEBLOCK_H_INCLUDED
#define NODEBLOCK_H_INCLUDED

#include "Node.hpp"

class NodeList;

class NodeBlock : public Node {
    public:
        NodeBlock(Node *var_decls, Node *instrs, int lineno = 0, int columnno = 0);
        virtual ~NodeBlock();

        NodeList* getVarDecls();
        NodeList* getInstrs();

        void setCreateNewNameSpace(bool value);
        bool createNewNameSpace();

        void accept(Visitor &c);
        void print(std::ostream &out = std::cout);

    private:
        bool _newNS;
        NodeList *_var_decls;
        NodeList *_instrs;
};

#endif
