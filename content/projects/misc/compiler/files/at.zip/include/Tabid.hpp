#ifndef TABID_H_INCLUDED
#define TABID_H_INCLUDED

#include <vector>
#include <map>

#include "NameSpace.hpp"
#include "Symbol.hpp"

typedef NameSpace<SymbolVar> VarNameSpace;
typedef NameSpace<SymbolFunc> FuncNameSpace;

class Tabid {
    public:
        Tabid();
        virtual ~Tabid();

        int getNumberNameSpaces() const;

        void pushNameSpace();
        /* Pops the highest namespace and returns its size in bytes so the caller
         * can trash those bytes */
        unsigned int popNameSpace();

        void addVarName(const std::string &name, SymbolVar *s);
        void addFuncName(const std::string &name, SymbolFunc *s);

        SymbolVar* getVarSymbol(const std::string &name);
        SymbolFunc* getFuncSymbol(const std::string &name);

        int getMinimumDisplacement() const;

        /* This returns true if the provided name exists in either the variable
         * namespace or the function namespace. To check if it exists only in
         * one of those, use the getters and check for NULL */
        bool nameConflict(const std::string &name);

        /* Returns true if active namespace is the global one (the first one) */
        bool isGlobalNameSpace() const;

    private:
        std::vector< VarNameSpace* > _varNameSpaces;
        /* We don't need a vector of function namespaces because functions can't be declared
         * inside other functions */
        FuncNameSpace _funcNameSpace; 
};

#endif
