#ifndef NODE_H_INCLUDED
#define NODE_H_INCLUDED

#include <iostream>
#include "Compiler.hpp"
#include "Parser.hpp"

class Compiler;

class Node {
    public:
        Node(int line = 0, int column = 0);
        virtual ~Node();

        int getLine() const;
        int getColumn() const;
        virtual void accept(Visitor& c) = 0;
        virtual void print(std::ostream &out = std::cout) = 0;
    private:
        int	_line; // user defined attributes
        int _column;
};
#endif
