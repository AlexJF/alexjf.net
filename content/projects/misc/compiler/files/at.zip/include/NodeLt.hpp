#ifndef NODELT_H_INCLUDED
#define NODELT_H_INCLUDED

#include "NodeBinary.hpp"

class NodeLt : public NodeBinary {
    public:
        NodeLt(Node* arg1, Node* arg2, int lineno = 0, int columnno = 0);
        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);
};

#endif
