#ifndef NODEVARDECLARE_H_INCLUDED
#define NODEVARDECLARE_H_INCLUDED

#include "Node.hpp"
#include "Type.hpp"

class NodeIdentifier;
class NodeValue;

class NodeVarDeclare : public Node {
    public:
        NodeVarDeclare(Type *type, Node *identifier, Node *value = NULL, int lineno = 0, int columnno = 0);
        ~NodeVarDeclare();

        Type* getType() const;
        const std::string& getName() const;
        NodeValue* getInitialValue() const;

        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);

    private:
        Type *_type;
        NodeIdentifier *_identifier; 
        NodeValue *_value;
};

#endif
