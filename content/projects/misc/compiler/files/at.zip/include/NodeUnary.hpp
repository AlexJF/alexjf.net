#ifndef NODEUNARY_H_INCLUDED
#define NODEUNARY_H_INCLUDED

#include "NodeOperator.hpp"

class NodeUnary : public NodeOperator {
    public:
        NodeUnary(Node* arg, int lineno = 0, int columnno = 0);

        void print(std::ostream &out = std::cout);
};

#endif 
