#ifndef NODEOPERATOR_H_INCLUDED
#define NODEOPERATOR_H_INCLUDED

#include "NodeExpression.hpp"

class NodeOperator : public NodeExpression {
    public:
        NodeOperator(Node* arg1, Node* arg2, int lineno = 0, int columnno = 0);
        virtual ~NodeOperator();

        NodeExpression* first(); 
        NodeExpression* second(); 

        virtual void print(std::ostream &out = std::cout) = 0;

    private:
        NodeExpression *_arg1, *_arg2;
};

#endif 
