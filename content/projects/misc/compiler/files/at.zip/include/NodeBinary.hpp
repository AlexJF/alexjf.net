#ifndef NODEBINARY_H_INCLUDED
#define NODEBINARY_H_INCLUDED

#include "NodeOperator.hpp"

class NodeBinary : public NodeOperator {
    public:
        NodeBinary(Node* arg1, Node* arg2, int lineno = 0, int columno = 0);

        void print(std::ostream &out = std::cout);
};

#endif
