#ifndef NODELIST_H_INCLUDED
#define NODELIST_H_INCLUDED

#include <vector>
#include "Node.hpp"

class Node;

typedef std::vector< Node* >::iterator NodeListIterator;

class NodeList : public Node {
    public:
        NodeList(int lineno = 0, int columnno = 0);
        ~NodeList();
        int size();
        std::vector<Node*>& nodes();
        Node& elementAt(int i);
        void prepend(Node* n);
        void append(Node* n);

        void accept(Visitor& c);
        void print(std::ostream &out = std::cout);

    protected:
        std::vector<Node*> _list; // subNode: list of nodes
};
#endif
