﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseClasses
{
    public class HostWithJobs : Host, ICloneable
    {
        private int? _hostCPUUsage;
        private double? _jobsQoSRevenue;
        private int? _powerConsumption;

        public HostWithJobs(int id, int numCPUs, IList<Job> jobs)
            : base(id, numCPUs)
        {
            Jobs = jobs;
        }

        public int HostCPUUsage
        {
            get
            {
                if (!_hostCPUUsage.HasValue)
                    CalculateHostCPUUsage();

                return _hostCPUUsage.Value;
            }
        }

        public IList<Job> Jobs { get; private set; }

        public double JobsQoSRevenue
        {
            get
            {
                if (!_jobsQoSRevenue.HasValue)
                    CalculateJobsQoSRevenue();

                return _jobsQoSRevenue.Value;
            }
        }

        public int MaxHostLoad { get { return NumCPUs * 100; } }

        public int PowerConsumption
        {
            get
            {
                if (!_powerConsumption.HasValue)
                    CalculatePowerConsumption();

                return _powerConsumption.Value;
            }
        }

        public int PowerCosts { get { return PowerConsumption * BaseSolution.PowerCost; } }

        public double Revenue { get { return JobsQoSRevenue - PowerCosts; } }

        public HostWithJobs Clone()
        {
            return new HostWithJobs(ID, NumCPUs, new List<Job>(Jobs.Select(j => j.Clone())));
        }

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        public void InvalidateCalculations()
        {
            _powerConsumption = null;
            _jobsQoSRevenue = null;
            _hostCPUUsage = null;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Host {0} with {1} CPUs and {2} Jobs:{3}", ID, NumCPUs, Jobs.Count, Environment.NewLine);
            sb.AppendFormat("\t JobQoSRevenue: {0}; Power-Consumption: {1}; Total Revenue: {2}; Total Load: {3}{4}",
                JobsQoSRevenue, PowerConsumption, Revenue, HostCPUUsage, Environment.NewLine);

            foreach (var job in Jobs.OrderBy(j => j.ID))
            {
                sb.AppendLine(job.ToString());
            }

            return sb.ToString();
        }

        private void CalculateHostCPUUsage()
        {
            _hostCPUUsage = Jobs.Sum(j => j.OfferedCPUUsage);
        }

        private void CalculateJobsQoSRevenue()
        {
            if (IsHostOverloaded())
                _jobsQoSRevenue = int.MinValue;
            else
                _jobsQoSRevenue = Jobs.Sum(j => j.QoSRevenuePerHour);
        }

        private void CalculatePowerConsumption()
        {
            int hostCPUUsage = HostCPUUsage;
            _powerConsumption = 0;

            for (int i = 0; i < NumCPUs && hostCPUUsage > 0; i++)
            {
                _powerConsumption += BaseSolution.PowerConsumtionPerCPU[i];

                hostCPUUsage -= 100;
            }
        }

        private bool IsHostOverloaded()
        {
            return HostCPUUsage > MaxHostLoad;
        }
    }
}