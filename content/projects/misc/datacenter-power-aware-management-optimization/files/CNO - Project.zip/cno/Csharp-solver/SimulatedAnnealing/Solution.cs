﻿using BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulatedAnnealing
{
    public class Solution : BaseSolution
    {
        private int _numberOfCPUUsageChanges;
        private int? _numberOfNeighbours;
        private int _numberOfReassignments;
        private int _numberOfSwappingOperations;

        public Solution(List<HostWithJobs> schedule)
            : base(schedule)
        {
        }

        public int NumberOfNeighbours
        {
            get
            {
                if (!_numberOfNeighbours.HasValue)
                    CalculateNumberOfNeighbours();

                return _numberOfNeighbours.Value;
            }
        }

        public Operation GetOperation(int randomOperationIndex)
        {
            if (_numberOfSwappingOperations > randomOperationIndex)
                return GetSwappingOperation(randomOperationIndex);
            // else

            randomOperationIndex -= _numberOfSwappingOperations;
            if (_numberOfReassignments > randomOperationIndex)
                return GetReassigningOperation(randomOperationIndex);
            // else

            randomOperationIndex -= _numberOfReassignments;
            return GetCPUUsageChangeOperation(randomOperationIndex);
        }

        public override void InvalidateCalculations()
        {
            base.InvalidateCalculations();

            _numberOfNeighbours = null;
        }

        private void CalculateNumberOfNeighbours()
        {
            int jobsConsideredForSwapping = 0;
            int numHosts = Schedule.Count;
            _numberOfNeighbours = 0;

            /// swapping
            foreach (var host in Schedule)
            {
                jobsConsideredForSwapping += host.Jobs.Count;
                _numberOfNeighbours += ((NumJobs - jobsConsideredForSwapping) * host.Jobs.Count);
            }
            _numberOfSwappingOperations = _numberOfNeighbours.Value;

            _numberOfReassignments = NumJobs * (numHosts - 1);
            _numberOfNeighbours += _numberOfReassignments;

            _numberOfCPUUsageChanges = NumJobs;
            _numberOfNeighbours += _numberOfCPUUsageChanges;
        }

        private Operation GetCPUUsageChangeOperation(int randomOperationIndex)
        {
            for (int i = 0; i < Schedule.Count; i++)
            {
                if (randomOperationIndex < Schedule[i].Jobs.Count)
                    return new ChangeCPUOperation(Schedule[i], i, Schedule[i].Jobs[randomOperationIndex], randomOperationIndex);
                else
                    randomOperationIndex -= Schedule[i].Jobs.Count;
            }

            throw new IndexOutOfRangeException();
        }

        private Operation GetReassigningOperation(int randomOperationIndex)
        {
            int numHostsMinusOne = Schedule.Count - 1;
            int currentHostIndex = 0;

            foreach (var host in Schedule)
            {
                int operationsInHost = host.Jobs.Count * numHostsMinusOne;

                if (randomOperationIndex < operationsInHost)
                    return GetReassigningOperation(host, currentHostIndex, randomOperationIndex);
                else
                    randomOperationIndex -= operationsInHost;

                currentHostIndex++;
            }

            throw new IndexOutOfRangeException();
        }

        private Operation GetReassigningOperation(HostWithJobs host, int hostIndex, int randomOperationIndex)
        {
            int numHostsMinuxOne = Schedule.Count - 1;
            int jobIndex = randomOperationIndex / numHostsMinuxOne;
            int newHostIndex = randomOperationIndex % numHostsMinuxOne;

            if (newHostIndex >= hostIndex) // move one further since the current host should be ignored
                newHostIndex++;

            return new ReassigningOperation(host, hostIndex, host.Jobs[jobIndex], jobIndex, Schedule[newHostIndex], newHostIndex);
        }

        private Operation GetSwappingOperation(int randomOperationIndex)
        {
            int jobsConsideredForSwapping = 0;
            int numHosts = Schedule.Count;
            int currentHostIndex = 0;

            /// swapping
            foreach (var host in Schedule)
            {
                jobsConsideredForSwapping += host.Jobs.Count;
                int swappingOperationsInHost = ((NumJobs - jobsConsideredForSwapping) * host.Jobs.Count);

                if (randomOperationIndex < swappingOperationsInHost)
                    return GetSwappingOperation(host, currentHostIndex, NumJobs - jobsConsideredForSwapping, randomOperationIndex);
                else
                    randomOperationIndex -= swappingOperationsInHost;

                currentHostIndex++;
            }

            throw new IndexOutOfRangeException();
        }

        private Operation GetSwappingOperation(HostWithJobs host, int hostIndex, int jobsAvailableForSwapping, int randomOperationIndex)
        {
            int jobAIndex = randomOperationIndex / jobsAvailableForSwapping;

            randomOperationIndex -= (jobAIndex * jobsAvailableForSwapping);

            for (int i = hostIndex + 1; i < Schedule.Count; i++)
            {
                if (randomOperationIndex < Schedule[i].Jobs.Count)
                    return new SwappingOperation(host, hostIndex, Schedule[hostIndex].Jobs[jobAIndex], jobAIndex, Schedule[i], i, Schedule[i].Jobs[randomOperationIndex], randomOperationIndex);
                else
                    randomOperationIndex -= Schedule[i].Jobs.Count;
            }

            throw new IndexOutOfRangeException();
        }
    }
}