﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BaseClasses
{
    public class Host : IEquatable<Host>
    {
        public Host(int id, int numCPUs)
        {
            ID = id;
            NumCPUs = numCPUs;
        }

        public int ID { get; private set; }

        public int NumCPUs { get; private set; }

        public HostWithJobs AssignJobs(IList<Job> jobs)
        {
            return new HostWithJobs(ID, NumCPUs, jobs);
        }

        public bool Equals(Host other)
        {
            if (other != null)
                return ID == other.ID;
            else
                return false;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as Host);
        }
    }
}