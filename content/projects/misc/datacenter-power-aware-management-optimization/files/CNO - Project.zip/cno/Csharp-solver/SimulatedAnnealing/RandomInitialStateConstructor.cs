﻿using BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulatedAnnealing
{
    public class RandomInitialStateConstructor
    {
        private IEnumerable<Host> _hosts;
        private IEnumerable<Job> _jobs;
        private Random _random = new Random();

        public RandomInitialStateConstructor(IEnumerable<Host> hosts, IEnumerable<Job> jobs)
        {
            _hosts = hosts;
            _jobs = jobs;
        }

        public Solution InitialSolution { get; private set; }

        public Solution CreateInitialSolution()
        {
            var hostsWithJobs = _hosts.Select(h => new HostWithJobs(h.ID, h.NumCPUs, new List<Job>())).ToList();

            foreach (var job in _jobs)
            {
                int index = _random.Next(hostsWithJobs.Count);
                int cpuUsageDif = job.MaxCPUUsage - job.MinCPUUsage + 1;

                job.OfferedCPUUsage = _random.Next(cpuUsageDif) + job.MinCPUUsage;
                hostsWithJobs[index].Jobs.Add(job);
            }

            InitialSolution = new Solution(hostsWithJobs);
            return InitialSolution;
        }
    }
}