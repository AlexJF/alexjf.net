﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseClasses
{
    public abstract class BaseSolution
    {
        private int? _numJobs;
        private double? _revenue;

        public BaseSolution()
        {
            Schedule = new List<HostWithJobs>();
        }

        public BaseSolution(IEnumerable<HostWithJobs> schedule)
        {
            Schedule = new List<HostWithJobs>(schedule);
        }

        public IEnumerable<Job> Jobs
        {
            get
            {
                foreach (var host in Schedule)
                {
                    foreach (var job in host.Jobs)
                    {
                        yield return job;
                    }
                }
            }
        }

        public int NumJobs
        {
            get
            {
                if (!_numJobs.HasValue)
                    CalculateNumJobs();

                return _numJobs.Value;
            }
        }

        public double Revenue
        {
            get
            {
                if (!_revenue.HasValue)
                    CalculateRevenue();

                return _revenue.Value;
            }
        }

        public IList<HostWithJobs> Schedule { get; private set; }

        public List<HostWithJobs> GetScheduleCopy()
        {
            return new List<HostWithJobs>(Schedule.AsParallel().Select(h => h.Clone()));
        }

        public virtual void InvalidateCalculations()
        {
            _revenue = null;
            _numJobs = null;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Solution with a revenue of {0}:{1}", Revenue, Environment.NewLine);

            foreach (var host in Schedule.OrderBy(h => h.ID))
            {
                sb.AppendLine(host.ToString());
            }

            return sb.ToString();
        }

        private void CalculateNumJobs()
        {
            _numJobs = Schedule.Sum(h => h.Jobs.Count);
        }

        private void CalculateRevenue()
        {
            _revenue = Schedule.Sum(h => h.Revenue);
        }

        #region Static Properties

        static BaseSolution()
        {
            RandomOperator = new Random();
        }

        public static int[] PowerConsumtionPerCPU { get; private set; }

        public static int PowerCost { get; private set; }

        public static Random RandomOperator { get; private set; }

        public static void SetPowerConsumptionsAndCosts(int powerCost, int[] powerConsumptionPerCPU)
        {
            if (powerConsumptionPerCPU == null)

                throw new ArgumentNullException("powerConsumptionPerCPU");

            if (PowerConsumtionPerCPU != null)

                throw new InvalidOperationException("Power Consumtions and Cost have already been set");

            PowerConsumtionPerCPU = powerConsumptionPerCPU;
            PowerCost = powerCost;
        }

        #endregion Static Properties
    }
}