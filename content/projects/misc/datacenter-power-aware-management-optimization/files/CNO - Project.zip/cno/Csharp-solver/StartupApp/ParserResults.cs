﻿using BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StartupApp
{
    public class ParserResults
    {
        public ParserResults(int powerCost, int[] powerConsumptionPerCPU, int[] numCPUsPerHost, List<int[]> jobInfos)
        {
            PowerCost = powerCost;
            PowerConsumptionPerCPU = powerConsumptionPerCPU;
            Hosts = new List<Host>();
            Jobs = new List<Job>();

            for (int i = 0; i < numCPUsPerHost.Length; i++)
            {
                Hosts.Add(new Host(i, numCPUsPerHost[i]));
            }

            for (int i = 0; i < jobInfos.Count; i++)
            {
                var curJobInfo = jobInfos[i];
                Jobs.Add(new Job(i, curJobInfo[0], curJobInfo[1], curJobInfo[2]));
            }
        }

        public List<Host> Hosts { get; private set; }

        public List<Job> Jobs { get; private set; }

        public int[] PowerConsumptionPerCPU { get; private set; }

        public int PowerCost { get; private set; }
    }
}