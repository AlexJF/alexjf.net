﻿using BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimulatedAnnealing
{
    public class ReassigningOperation : Operation
    {
        protected Job _job;
        protected int _jobIndex;
        protected HostWithJobs _newHost;
        protected int _newHostIndex;
        protected HostWithJobs _oldHost;
        protected int _oldHostIndex;

        public ReassigningOperation(HostWithJobs oldHost, int oldHostIndex, Job job, int jobIndex, HostWithJobs newHost, int newHostIndex)
        {
            this._oldHost = oldHost;
            this._oldHostIndex = oldHostIndex;
            this._job = job;
            this._jobIndex = jobIndex;
            this._newHost = newHost;
            this._newHostIndex = newHostIndex;
        }

        public override void Execute(BaseSolution solution)
        {
            var currentOldHost = solution.Schedule[_oldHostIndex];

            if (!currentOldHost.Equals(_oldHost) || !currentOldHost.Jobs[_jobIndex].Equals(_job)
                || !solution.Schedule[_newHostIndex].Equals(_newHost))
            {
                throw new InvalidOperationException("Host or Job have changed since the operation has been created.");
            }

            _oldHost.Jobs.RemoveAt(_jobIndex);
            _newHost.Jobs.Add(_job);
        }

        protected override int[] GetAffectedHosts()
        {
            return new int[] { _oldHostIndex, _newHostIndex };
        }
    }
}