﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StartupApp
{
    public class InputFileParser
    {
        private string _inputFilePath;

        public InputFileParser(string inputFilePath)
        {
            _inputFilePath = inputFilePath;
        }

        /**
8                   // max num of cpus
8 7 6 5 4 3 2 1     // powerconsumption/(additional)cpu

10                  // num of hosts
3 8 3 4 8 8 1 8 6 2 // CPUs/host

10                  // num of jobs
82 164 475          // Min CPU-Usage, Max CPU-Usage, Revenue/h
33 52 422
55 96 371
31 83 378
30 70 481
14 71 268
38 170 346
33 62 314
96 296 1056
237 286 1031

15                  // Power Cost
         */

        public ParserResults Parse()
        {
            char[] splitSeperator = new char[] { ' ' };
            string line;
            string[] splittedLine;

            int powerCost;
            int[] powerConsumptionPerCPU;
            int[] numCPUsPerHost;
            List<int[]> jobInfos = new List<int[]>();

            using (var sr = new StreamReader(_inputFilePath))
            {
                sr.ReadLine();
                splittedLine = sr.ReadLine().Split(splitSeperator, StringSplitOptions.RemoveEmptyEntries);
                powerConsumptionPerCPU = ConvertToIntArray(splittedLine);

                sr.ReadLine();
                sr.ReadLine();
                splittedLine = sr.ReadLine().Split(splitSeperator, StringSplitOptions.RemoveEmptyEntries);
                numCPUsPerHost = ConvertToIntArray(splittedLine);

                sr.ReadLine();
                sr.ReadLine();
                while ((line = sr.ReadLine()).Trim() != string.Empty)
                {
                    splittedLine = line.Split(splitSeperator, StringSplitOptions.RemoveEmptyEntries);
                    jobInfos.Add(ConvertToIntArray(splittedLine));
                }

                line = sr.ReadLine();
                powerCost = int.Parse(line.Trim());
            }

            return new ParserResults(powerCost, powerConsumptionPerCPU, numCPUsPerHost, jobInfos);
        }

        private int[] ConvertToIntArray(string[] splittedLine)
        {
            int[] ret = new int[splittedLine.Length];

            for (int i = 0; i < ret.Length; i++)
            {
                ret[i] = int.Parse(splittedLine[i]);
            }

            return ret;
        }
    }
}