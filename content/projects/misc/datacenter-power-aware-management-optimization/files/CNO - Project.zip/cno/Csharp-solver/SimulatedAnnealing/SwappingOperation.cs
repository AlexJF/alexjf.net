﻿using BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimulatedAnnealing
{
    public class SwappingOperation : ReassigningOperation
    {
        private Job _jobB;
        private int _jobBIndex;

        public SwappingOperation(HostWithJobs hostA, int hostAIndex, Job jobA, int jobAIndex, HostWithJobs hostB, int hostBIndex, Job jobB, int jobBIndex)
            : base(hostA, hostAIndex, jobA, jobAIndex, hostB, hostBIndex)
        {
            this._jobB = jobB;
            this._jobBIndex = jobBIndex;
        }

        public override void Execute(BaseSolution solution)
        {
            base.Execute(solution);

            if (!solution.Schedule[_newHostIndex].Jobs[_jobBIndex].Equals(_jobB))
                throw new InvalidOperationException("Host or Job have changed since the operation has been created.");

            _newHost.Jobs.RemoveAt(_jobBIndex);
            _oldHost.Jobs.Add(_jobB);
        }
    }
}