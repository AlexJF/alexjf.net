﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseClasses
{
    public abstract class BaseSolver
    {
        public abstract BaseSolution Solution { get; }

        public abstract void Solve(IEnumerable<Host> hosts, IEnumerable<Job> jobs);
    }
}