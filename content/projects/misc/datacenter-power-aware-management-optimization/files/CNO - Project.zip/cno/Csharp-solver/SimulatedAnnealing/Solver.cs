﻿using BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulatedAnnealing
{
    public class Solver : BaseSolver
    {
        private const double HeatPreservingFactor = 0.99999;
        private const int InitialTemperature = 10;
        private const double MinTemperature = 1;

        private Random _random = new Random();
        private Solution _solution;
        private double _temperature = InitialTemperature;

        public override BaseSolution Solution { get { return _solution; } }

        public override void Solve(IEnumerable<Host> hosts, IEnumerable<Job> jobs)
        {
            CreateInitialSolution(hosts, jobs);
            var currentSollution = new Solution(Solution.GetScheduleCopy());

            do
            {
                var tmpSolution = new Solution(currentSollution.GetScheduleCopy());
                var randomNeighbour = GetRandomNeighbour(tmpSolution);

                randomNeighbour.Execute(tmpSolution);
                randomNeighbour.TryToFix(tmpSolution);
                randomNeighbour.PostExecute(tmpSolution);

                if (tmpSolution.Revenue > currentSollution.Revenue)
                {
                    currentSollution = tmpSolution;

                    if (tmpSolution.Revenue > Solution.Revenue)
                        _solution = tmpSolution;
                }
                else
                {
                    double randomHighestAllowedValue = _random.NextDouble() * InitialTemperature;
                    double revenueDifference = currentSollution.Revenue - tmpSolution.Revenue + 1; //if they are equal, 0 would mean that it always gets switched

                    if ((revenueDifference / _temperature) < randomHighestAllowedValue)
                    {
                        currentSollution = tmpSolution;
                    }
                }

                RecalculateTemperature();
            } while (_temperature >= MinTemperature);
        }

        private void CreateInitialSolution(IEnumerable<Host> hosts, IEnumerable<Job> jobs)
        {
            var constructor = new GreedyInitialStateConstructor(hosts, jobs);
            //var constructor = new RandomInitialStateConstructor(hosts, jobs);
            constructor.CreateInitialSolution();
            _solution = constructor.InitialSolution;

            if (Solution == null)
                throw new NotImplementedException();
        }

        private Operation GetRandomNeighbour(Solution solution)
        {
            int numOfNeighbours = solution.NumberOfNeighbours;
            int index = _random.Next(numOfNeighbours);

            return solution.GetOperation(index);
        }

        private void RecalculateTemperature()
        {
            _temperature = _temperature * HeatPreservingFactor;
        }
    }
}