﻿using BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulatedAnnealing
{
    public class GreedyInitialStateConstructor
    {
        private IEnumerable<Host> _hosts;
        private IEnumerable<Job> _jobs;

        public GreedyInitialStateConstructor(IEnumerable<Host> hosts, IEnumerable<Job> jobs)
        {
            _hosts = hosts;
            _jobs = jobs;
        }

        public Solution InitialSolution { get; private set; }

        public Solution CreateInitialSolution()
        {
            int cpuUsageAvailable = _hosts.Sum(h => h.NumCPUs) * 100;
            int cpuUsageRequired = _jobs.Sum(j => j.MaxCPUUsage);

            InitialSolution = null;

            if (cpuUsageRequired <= cpuUsageAvailable)
                InitialSolution = CreateMaxUsageSolution();

            if (InitialSolution == null)
            {
                cpuUsageRequired = _jobs.Sum(j => j.MinCPUUsage);

                if (cpuUsageRequired <= cpuUsageAvailable)
                    InitialSolution = CreateMinUsageSolution();
            }

            return InitialSolution;
        }

        private bool AddJobToFirstHoste(Job job, int jobResourcesRequired, IEnumerable<HostWithJobs> orderedHosts)
        {
            foreach (var host in orderedHosts)
            {
                if ((host.HostCPUUsage + jobResourcesRequired) <= host.MaxHostLoad)
                {
                    host.Jobs.Add(job);
                    host.InvalidateCalculations();
                    return true;
                }
            }

            return false;
        }

        private Solution CreateMaxUsageSolution()
        {
            return InternalCreateSolution(j => j.MaxCPUUsage);
        }

        private Solution CreateMinUsageSolution()
        {
            return InternalCreateSolution(j => j.MinCPUUsage);
        }

        private Solution InternalCreateSolution(Func<Job, int> getResourcesRequired)
        {
            var orderedJobs = _jobs.OrderByDescending(getResourcesRequired);
            var orderedHosts = _hosts.OrderByDescending(h => h.NumCPUs).
                                    Select(h => new HostWithJobs(h.ID, h.NumCPUs, new List<Job>())).ToList();

            foreach (var job in orderedJobs)
            {
                job.OfferedCPUUsage = getResourcesRequired(job);
                if (!AddJobToFirstHoste(job, getResourcesRequired(job), orderedHosts))
                    return null;
            }

            return new Solution(orderedHosts);
        }
    }
}