﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BaseClasses
{
    public class Job : ICloneable, IEquatable<Job>
    {
        public Job(int id, int minCPUUsage, int maxCPUUsage, int revenuePerHour)
        {
            ID = id;
            MinCPUUsage = minCPUUsage;
            MaxCPUUsage = maxCPUUsage;
            RevenuePerHour = revenuePerHour;
        }

        public int ID { get; private set; }

        public int MaxCPUUsage { get; private set; }

        public int MinCPUUsage { get; private set; }

        public int OfferedCPUUsage { get; set; }

        public double QoSRevenuePerHour { get { return QoSSatisfaction * RevenuePerHour; } }

        public double QoSSatisfaction { get { return OfferedCPUUsage / MaxCPUUsage; } }

        public int RevenuePerHour { get; private set; }

        public double RevenuePerMaxCPUUsage { get { return RevenuePerHour / MaxCPUUsage; } }

        public Job Clone()
        {
            return new Job(ID, MinCPUUsage, MaxCPUUsage, RevenuePerHour) { OfferedCPUUsage = OfferedCPUUsage };
        }

        public bool Equals(Job other)
        {
            if (other != null)
                return ID == other.ID;
            else
                return false;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as Job);
        }

        object ICloneable.Clone()
        {
            return this.Clone();
        }

        public override string ToString()
        {
            return string.Format("Job {0} with Min-, MaxCPU ({1}, {2}), Revenue/h ({3}), OfferedCPU ({4}), QoSRevenue ({5})",
                    ID, MinCPUUsage, MaxCPUUsage, RevenuePerHour, OfferedCPUUsage, QoSRevenuePerHour);
        }
    }
}