﻿using BaseClasses;
using SimulatedAnnealing;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StartupApp
{
    public class Program
    {
        private static void Main(string[] args)
        {
            var parser = new InputFileParser(args[0]);
            var inputData = parser.Parse();

            BaseSolution.SetPowerConsumptionsAndCosts(inputData.PowerCost, inputData.PowerConsumptionPerCPU);
            var solver = new Solver();

            Stopwatch sw = new Stopwatch();
            sw.Start();
            solver.Solve(inputData.Hosts, inputData.Jobs);
            sw.Stop();
            Console.WriteLine(solver.Solution);
            Console.WriteLine();
            Console.WriteLine(solver.Solution.Revenue);
            Console.WriteLine(sw.Elapsed);
            Console.ReadLine();
        }
    }
}