﻿using BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimulatedAnnealing
{
    internal class ChangeCPUOperation : Operation
    {
        private HostWithJobs _host;
        private int _hostIndex;
        private Job _job;
        private int _jobIndex;

        public ChangeCPUOperation(HostWithJobs host, int hostIndex, Job job, int jobIndex)
        {
            this._host = host;
            this._hostIndex = hostIndex;
            this._job = job;
            this._jobIndex = jobIndex;
        }

        public override void Execute(BaseSolution solution)
        {
            var currentHost = solution.Schedule[_hostIndex];

            if (!currentHost.Equals(_host) || !currentHost.Jobs[_jobIndex].Equals(_job))
                throw new InvalidOperationException("Host or Job have changed since the operation has been created.");

            if (_job.OfferedCPUUsage == _job.MaxCPUUsage)
                _job.OfferedCPUUsage = _job.MinCPUUsage;
            else if (_job.OfferedCPUUsage == _job.MinCPUUsage)
                _job.OfferedCPUUsage = _job.MaxCPUUsage;
            else if (BaseSolution.RandomOperator.Next() % 2 == 0)
                _job.OfferedCPUUsage = _job.MinCPUUsage;
            else
                _job.OfferedCPUUsage = _job.MaxCPUUsage;
        }

        protected override int[] GetAffectedHosts()
        {
            return new int[] { _hostIndex };
        }
    }
}