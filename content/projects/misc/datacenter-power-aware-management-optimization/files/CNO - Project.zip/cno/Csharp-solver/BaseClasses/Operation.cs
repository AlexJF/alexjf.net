﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BaseClasses
{
    public abstract class Operation
    {
        public abstract void Execute(BaseSolution solution);

        public virtual void PostExecute(BaseSolution solution)
        {
            foreach (var hostIndex in GetAffectedHosts())
            {
                solution.Schedule[hostIndex].InvalidateCalculations();
            }

            solution.InvalidateCalculations();
        }

        public virtual void TryToFix(BaseSolution solution)
        {
            TryToFix(solution, GetAffectedHosts());
        }

        protected abstract int[] GetAffectedHosts();

        protected virtual void TryToFix(BaseSolution solution, params int[] affectedHosts)
        {
            foreach (var affectedHostIndex in affectedHosts)
            {
                TryToFix(solution, affectedHostIndex);
            }
        }

        protected virtual void TryToFix(BaseSolution solution, int affectedHostIndex)
        {
            var affectedHost = solution.Schedule[affectedHostIndex];

            if (affectedHost.HostCPUUsage > affectedHost.MaxHostLoad)
                ReduceHostLoad(affectedHost);
            else if (affectedHost.HostCPUUsage < affectedHost.MaxHostLoad)
                RaiseHostLoad(affectedHost);
        }

        private void RaiseHostLoad(HostWithJobs host)
        {
            int loadDifference = host.MaxHostLoad - host.HostCPUUsage;

            foreach (var job in host.Jobs.OrderByDescending(j => j.RevenuePerMaxCPUUsage))
            {
                if (job.OfferedCPUUsage < job.MaxCPUUsage)
                {
                    int maxRaise = job.MaxCPUUsage - job.OfferedCPUUsage;

                    if (maxRaise < loadDifference)
                    {
                        job.OfferedCPUUsage += maxRaise;
                        loadDifference -= maxRaise;
                    }
                    else
                    {
                        job.OfferedCPUUsage += loadDifference;
                        break;
                    }
                }
            }
        }

        private void ReduceHostLoad(HostWithJobs host)
        {
            int loadDifference = host.HostCPUUsage - host.MaxHostLoad;

            foreach (var job in host.Jobs.OrderBy(j => j.RevenuePerMaxCPUUsage))
            {
                if (job.OfferedCPUUsage > job.MinCPUUsage)
                {
                    int maxReduction = job.OfferedCPUUsage - job.MinCPUUsage;

                    if (maxReduction < loadDifference)
                    {
                        job.OfferedCPUUsage -= maxReduction;
                        loadDifference -= maxReduction;
                    }
                    else
                    {
                        job.OfferedCPUUsage -= loadDifference;
                        break;
                    }
                }
            }
        }
    }
}