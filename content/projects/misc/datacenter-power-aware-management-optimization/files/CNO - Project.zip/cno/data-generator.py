import sys, random

maxCpusInNode = 8
powerCost = 15

if len(sys.argv) < 3:
    print("Usage: ./data-generator.py <numNodes> <numTasks>")
    exit()

print(str(maxCpusInNode))
print(" ".join(reversed([str(i + 1) for i in range(maxCpusInNode)])))

print(" ")

numNodes = int(sys.argv[1])
numTasks = int(sys.argv[2])

print(str(numNodes))

for i in range(numNodes):
    numCpus = int(round(random.gauss(maxCpusInNode / 2, maxCpusInNode / 2)))
    numCpus = max(numCpus, 1)
    numCpus = min(numCpus, maxCpusInNode)

    print(str(numCpus), end=" ")

print(" ")
print(" ")

print(str(numTasks))
for i in range(numTasks):
    usedCpus = min(1 + int(random.expovariate(1)), maxCpusInNode)
    minCons = random.randint(1, 100) * usedCpus
    maxCons = random.randint(minCons, 100 * usedCpus)
    revenue = 200 + 3*random.randint(minCons, maxCons) + int(round(random.gauss(0, 100 * usedCpus - maxCons)))
    print(minCons, maxCons, revenue)

print(" ")
print(str(powerCost))
