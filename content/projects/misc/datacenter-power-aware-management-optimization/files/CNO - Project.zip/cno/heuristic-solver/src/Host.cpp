#include "Host.hpp"

Host::Host(int id, int numCPUs) : _id(id), _numCPUs(numCPUs) {
}

int Host::getId() const {
	return _id;
}

int Host::getCPUCount() const {
	return _numCPUs;
}
