#include "AssignmentOperation.hpp"

AssignmentOperation::AssignmentOperation(Job *job, Host *host, Host *oldHost) :
	_job(job), _host(host), _previousHost(oldHost) {
}

Solution& AssignmentOperation::execute(Solution &solution) {
	if (_host != nullptr) {
		solution.changeAssignment(_job, _host);
	} else {
		solution.removeAssignment(_job);
	}
	return solution;
}

Solution& AssignmentOperation::undo(Solution &solution) {
	if (_previousHost != nullptr) {
		solution.changeAssignment(_job, _previousHost);
	} else {
		solution.removeAssignment(_job);
	}
	return solution;
}

bool AssignmentOperation::equals(Operation const &other) const {
	if (AssignmentOperation const* p = dynamic_cast<AssignmentOperation const*>(&other)) {
		return _job == p->_job && _host == p->_host && _previousHost == p->_previousHost;
    }
    else {
    	return false;
    }
}

bool AssignmentOperation::isReverseOf(Operation const &other) const {
	if (AssignmentOperation const* p = dynamic_cast<AssignmentOperation const*>(&other)) {
		return _job == p->_job && _host == p->_previousHost && _previousHost == p->_host;
    }
    else {
    	return false;
    }
}
