#ifndef GRASPTSSOLVER_HPP_
#define GRASPTSSOLVER_HPP_

#include <map>
#include <chrono>

#include "Solver.hpp"
#include "Solution.hpp"

class GRASPTSSolver: public Solver {
	public:
		GRASPTSSolver(unsigned int cpuIncrements, unsigned int consP,
				unsigned int searchP, unsigned int maxIterations,
				unsigned int eliteSetSize, unsigned int tabuListSize,
				int maxTime = -1);

		std::unique_ptr<Solution> solve() override;

        std::unique_ptr<Solution> construct() const;
        std::unique_ptr<Solution> localSearch(Solution solution) const;
        void addToEliteSet(std::unique_ptr<Solution> solution);
        std::unique_ptr<Solution> pathRelinking(Solution solution) const;

        void checkTimeLimit(const Solution &currentSolution) const;
	private:
        class TimeoutException {
        	public:
        		TimeoutException(const Solution &currentSolution) :
        			_currentSolution(new Solution(currentSolution)) {}

        		std::unique_ptr<Solution>& getCurrentSolution() {
        			return _currentSolution;
        		}
        	private:
        		std::unique_ptr<Solution> _currentSolution;
        };

        unsigned int _consP;
        unsigned int _searchP;
        unsigned int _maxIterations;
        unsigned int _eliteSetSize;
        unsigned int _tabuListSize;
        int _maxTime;
        std::chrono::steady_clock::time_point _startTime;
        std::multimap<double, std::unique_ptr<Solution>> _eliteSet;
};

#endif /* GRASPTSSOLVER_HPP_ */
