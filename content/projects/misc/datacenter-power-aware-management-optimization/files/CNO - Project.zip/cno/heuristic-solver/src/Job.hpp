#ifndef JOB_HPP_
#define JOB_HPP_

class Job {
    public:
        Job(int id, int minCon, int maxCon, double revenueHour);

        int getId() const;
        int getMinimumCPU() const;
        int getMaximumCPU() const;
        double getRevenuePerHour() const;

    private:
        int _id, _minCon, _maxCon;
        double _revenueHour;
};

#endif /* JOB_HPP_ */
