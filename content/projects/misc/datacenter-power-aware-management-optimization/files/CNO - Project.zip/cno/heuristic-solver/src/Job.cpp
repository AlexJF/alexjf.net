#include "Job.hpp"

Job::Job(int id, int minCon, int maxCon, double revenueHour) :
	_id(id), _minCon(minCon), _maxCon(maxCon), _revenueHour(revenueHour) {
}

int Job::getId() const {
	return _id;
}

int Job::getMinimumCPU() const {
	return _minCon;
}

int Job::getMaximumCPU() const {
	return _maxCon;
}

double Job::getRevenuePerHour() const {
	return _revenueHour;
}
