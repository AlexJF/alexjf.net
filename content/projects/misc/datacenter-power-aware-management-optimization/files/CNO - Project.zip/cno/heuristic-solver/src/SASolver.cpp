/*
 * SASolver.cpp
 *
 *  Created on: 26.05.2013
 *      Author: Peter
 */
#include <iostream>
#include <algorithm>
#include <list>
#include <random>
#include <memory>
#include <deque>
#include <chrono>

#include "SASolver.hpp"
#include "Operation.hpp"
#include "AssignmentOperation.hpp"
#include "SwapOperation.hpp"
#include "ChangeCpuUsageOperation.hpp"

using namespace std;

SASolver::SASolver(unsigned int cpuIncrements, unsigned int initialTemperature,
					double heatPreservingFactor, double minTemperature):
		Solver(cpuIncrements), _initialTemperature(initialTemperature),
		_heatPreservingFactor(heatPreservingFactor), _minTemperature(minTemperature),
		_currentTemperature(initialTemperature),
		_randomGenerator(std::chrono::system_clock::now().time_since_epoch().count()),
		_random(0, _initialTemperature) {
}

std::unique_ptr<Solution> SASolver::solve() {
	std::unique_ptr<Solution> bestSolution = std::unique_ptr<Solution>(new Solution(*this));
	std::unique_ptr<Solution> currentSolution = std::unique_ptr<Solution>(new Solution(*this));
	double oldUtility, newUtility;

	do {
		auto randomOperation = getRandomOperation(*currentSolution.get());
		oldUtility = currentSolution->getUtility();
		randomOperation->execute(*currentSolution.get());
		newUtility = currentSolution->getUtility();

		if (newUtility > oldUtility) {
			if (newUtility > bestSolution->getUtility())
				bestSolution.reset(new Solution(*currentSolution.get()));
		}
		else {
			double randomHighestAllowedValue = _random(_randomGenerator);
			double utilityDifference = oldUtility - newUtility + 1; //if they are equal, 0 would mean that it always gets switched

			if ((utilityDifference/_currentTemperature) >= randomHighestAllowedValue) {
				randomOperation->undo(*currentSolution.get());
			}
		}

		recalculateTemperature();
	} while (_currentTemperature >= _minTemperature);

	return bestSolution;
}

void SASolver::recalculateTemperature() {
	this->_currentTemperature = this->_currentTemperature * this->_heatPreservingFactor;
}

std::unique_ptr<Operation> SASolver::getRandomOperation(Solution& solution) {
	auto possibleOps = solution.getPossibleOperations(false);
	int numOfOperations = possibleOps.size();
	int index = this->random() % numOfOperations;

	for (auto &operation : possibleOps) {
		if (index == 0){
			return std::move(operation);
		}
		else {
			index--;
		}
	}

	throw std::exception();
}
