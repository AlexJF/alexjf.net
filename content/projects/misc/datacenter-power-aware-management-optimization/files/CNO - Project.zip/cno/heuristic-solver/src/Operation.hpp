#ifndef OPERATION_HPP_
#define OPERATION_HPP_

#include "Solution.hpp"

class Operation {
	public:
		virtual ~Operation() = default;

		virtual Solution& execute(Solution &solution) = 0;
		virtual Solution& undo(Solution &solution) = 0;

		friend
		bool operator==(const Operation &lhs, const Operation &rhs) {
			return lhs.equals(rhs);
		}

		virtual bool equals(Operation const &other) const = 0;
		virtual bool isReverseOf(Operation const &other) const = 0;

	private:
		double _utility = 0;

		friend void Solution::orderOperations(std::list<std::unique_ptr<Operation>> &);
};

#endif /* OPERATION_HPP_ */
