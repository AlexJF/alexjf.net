#ifndef CHANGECPUOPERATION_HPP_
#define CHANGECPUOPERATION_HPP_

#include "Operation.hpp"

class ChangeCpuUsageOperation: public Operation {
	public:
		ChangeCpuUsageOperation(Job *job, int oldCpuUsage, int newCpuUsage);

		Solution& execute(Solution &solution) override;
		Solution& undo(Solution &solution) override;

		bool equals(Operation const &other) const override;
		bool isReverseOf(Operation const &other) const override;
	private:
		Job *_job;
		int _oldCpuUsage;
		int _newCpuUsage;
};

#endif /* CHANGECPUOPERATION_HPP_ */
