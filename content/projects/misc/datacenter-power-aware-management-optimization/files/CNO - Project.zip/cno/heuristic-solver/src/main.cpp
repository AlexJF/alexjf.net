#include <cstdlib>
#include <iostream>
#include <memory>

#include "Solver.hpp"
#include "GRASPTSSolver.hpp"
#include "SASolver.hpp"
#include "Solution.hpp"

int main(int argc, char **argv) {
	std::string solverName("GRASPTS");
	std::unique_ptr<Solver> solver;

	if (argc <= 2) {
		std::cerr << "Usage: ./heuristic-solver <data file> <solver type> <solver params>*" << std::endl;
		return 1;
	}

	solverName.assign(argv[2]);

	if (solverName == "GRASPTS") {
		if (argc - 3 < 6) {
			std::cerr << "Insufficient params for solver GRASPTS." << std::endl
					  << "Got " << (argc - 3) << " expected 6:" << std::endl
					  << "<cpuIncrements> <constructinoP> <searchP> <maxIterations> <eliteSetSize> <tabuListSize> [<maxTime>]" << std::endl;
			return 3;
		}

		unsigned int cpuIncrements = atoi(argv[3]);
		unsigned int consP = atoi(argv[4]);
		unsigned int searchP = atoi(argv[5]);
		unsigned int maxIterations = atoi(argv[6]);
		unsigned int eliteSetSize = atoi(argv[7]);
		unsigned int tabuListSize = atoi(argv[8]);
		int maxTime = -1;

		if (argc > 9) {
			maxTime = atoi(argv[9]);
		}

		solver = std::unique_ptr<Solver>(new GRASPTSSolver(cpuIncrements, consP, searchP, maxIterations, eliteSetSize, tabuListSize, maxTime));
		solver->parseInput(std::string(argv[1]));
		auto startTime = std::chrono::steady_clock::now();
		std::unique_ptr<Solution> solution = solver->solve();
		auto endTime = std::chrono::steady_clock::now();
		auto elapsedSeconds = std::chrono::duration_cast<std::chrono::seconds>(
				endTime - startTime).count();

		if (solution.get() != nullptr) {
			solution->print(std::cout);
		} else {
			std::cout << "No solution found" << std::endl;
		}

		std::cout << "Total time: " << elapsedSeconds << " seconds" << std::endl;
	}
	else if (solverName == "SA") {
		if (argc - 3 < 3) {
			std::cerr << "Insufficient params for solver SA." << std::endl
					  << "Got " << (argc - 3) << " expected 3:" << std::endl
					  << "<cpuIncrements> <initialTemperature> <heatPreservingFactor> [<minTemperature>=1]" << std::endl;
			return 3;
		}

		unsigned int cpuIncrements = atoi(argv[3]);
		unsigned int initialTemperature = atoi(argv[4]);
		double heatPreservingFactor = atof(argv[5]);
		double minTemperatur = 1;

		if (argc > 6) {
			minTemperatur = atof(argv[6]);
		}

		solver = std::unique_ptr<Solver>(new SASolver(cpuIncrements, initialTemperature, heatPreservingFactor, minTemperatur));
		solver->parseInput(std::string(argv[1]));
		auto startTime = std::chrono::steady_clock::now();
		std::unique_ptr<Solution> solution = solver->solve();
		auto endTime = std::chrono::steady_clock::now();
		auto elapsedSeconds = std::chrono::duration_cast<std::chrono::milliseconds>(
				endTime - startTime).count();

		if (solution.get() != nullptr) {
			solution->print(std::cout);
		} else {
			std::cout << "No solution found" << std::endl;
		}

		std::cout << "Total time: " << elapsedSeconds << " ms" << std::endl;
	}
	else {
		std::cerr << "Unknown solver: '" << solverName << "'" << std::endl
				  << "Available solvers:" << std::endl
				  << " - GRASPTS" << std::endl;
		return 2;
	}

	return 0;
}
