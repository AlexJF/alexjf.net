#include <iostream>
#include <algorithm>
#include <list>
#include <random>
#include <memory>
#include <deque>

#include "GRASPTSSolver.hpp"
#include "Operation.hpp"
#include "AssignmentOperation.hpp"

GRASPTSSolver::GRASPTSSolver(unsigned int cpuIncrements, unsigned int consP,
		unsigned int searchP, unsigned int maxIterations,
		unsigned int eliteSetSize, unsigned int tabuListSize, int maxTime) :
	Solver(cpuIncrements), _consP(consP), _searchP(searchP),
	_maxIterations(maxIterations), _eliteSetSize(eliteSetSize),
	_tabuListSize(tabuListSize), _maxTime(maxTime), _startTime(),
	_eliteSet() {
}

std::unique_ptr<Solution> GRASPTSSolver::solve() {
	_startTime = std::chrono::steady_clock::now();
	try {
		for (unsigned int i = 0; i < _maxIterations; i++) {
			auto solution = construct();
			auto bestLocalSearchSolution = localSearch(*solution.get());
			auto bestRelinkingSolution = pathRelinking(*bestLocalSearchSolution.get());
			addToEliteSet(std::move(bestRelinkingSolution));
		}
	} catch (TimeoutException &e) {
		addToEliteSet(std::move(e.getCurrentSolution()));
	}

	if (_eliteSet.size() == 0) {
		return std::unique_ptr<Solution>(nullptr);
	} else {
		return std::move(_eliteSet.rbegin()->second);
	}
}

std::unique_ptr<Solution> GRASPTSSolver::construct() const {
	const std::vector<std::unique_ptr<Job>> &jobs = getJobs();
	std::unique_ptr<Solution> solution = std::unique_ptr<Solution>(new Solution(*this));

    unsigned int numOperationsApplied = 0;

	while (solution->getNumberJobsAssigned() != jobs.size()
           && numOperationsApplied < jobs.size() * 4) {
		checkTimeLimit(*solution.get());

		std::list<std::unique_ptr<Operation>> possibleOps = solution->getPossibleOperations(false);
		unsigned int numPossibleOps = possibleOps.size();

		if (numPossibleOps == 0) {
			std::cerr << "This shouldn't happen..." << std::endl;
			break;
		}

		std::vector<std::unique_ptr<Operation>> shuffledPossibleOps;
		shuffledPossibleOps.reserve(numPossibleOps);

		for (auto &possibleOp : possibleOps) {
			shuffledPossibleOps.push_back(std::move(possibleOp));
		}

		// Shuffle to introduce randomness
		std::shuffle(shuffledPossibleOps.begin(), shuffledPossibleOps.end(), random);

		std::list<std::unique_ptr<Operation>> selectedOperations;
		unsigned int numSelectedOps = std::min(numPossibleOps, _consP);

		// Select min(p, numPossibleOperations) operations
		for (unsigned int i = 0; i < numSelectedOps; i++) {
			selectedOperations.push_back(std::move(shuffledPossibleOps[i]));
		}

		// Order them according to utility
		solution->orderOperations(selectedOperations);
		// Apply best one
		solution->applyOperation(*selectedOperations.back());

        numOperationsApplied++;
	}

	return solution;
}

std::unique_ptr<Solution> GRASPTSSolver::localSearch(Solution solution) const {
	auto tabuList = std::list<std::unique_ptr<Operation>>();
	unsigned int roundsWithoutImprovement = 0;
	std::unique_ptr<Solution> bestSolution(new Solution(solution));

	while (roundsWithoutImprovement < _searchP) {
		checkTimeLimit(*bestSolution.get());

		auto possibleOps = solution.getPossibleOperations();

		// This shouldn't happen but anyway...
		if (possibleOps.size() == 0) {
			std::cerr << "How the hell didn't I find solutions???" << std::endl;
			break;
		}

		// Reverse possible operations. Best operations are now on the beginning
		std::reverse(possibleOps.begin(), possibleOps.end());

		// Get the first operation which is not in the tabuList
		auto bestOperationIter = std::find_if(possibleOps.begin(), possibleOps.end(),
				[&](const std::unique_ptr<Operation> &op) {
			return tabuList.end() == std::find_if(tabuList.begin(), tabuList.end(),
					[&](const std::unique_ptr<Operation> &tabuOp) {
				return *op == *tabuOp || op->isReverseOf(*tabuOp.get());
			});
		});

		// If all possible solutions are on the tabu list, exit
		if (bestOperationIter == possibleOps.end()) {
			break;
		}

		auto &bestOperation = *bestOperationIter;
		Operation *bestOperationRaw = bestOperation.get();
		solution.applyOperation(*bestOperationRaw);
		tabuList.push_back(std::move(bestOperation));

		if (tabuList.size() > _tabuListSize) {
			tabuList.pop_front();
		}

		double newUtility = solution.getUtility();

		// We only need to check if new solution is better
		// than our previous best
		if (bestSolution.get() != nullptr && newUtility > bestSolution->getUtility()) {
			roundsWithoutImprovement = 0;
			bestSolution.reset(new Solution(solution));
		} else {
			roundsWithoutImprovement++;
		}
	}

	return bestSolution;
}

void GRASPTSSolver::addToEliteSet(std::unique_ptr<Solution> solutionPtr) {
	Solution *solution = solutionPtr.get();
	auto newSolutionIt = _eliteSet.insert(std::make_pair(solution->getUtility(),
			std::move(solutionPtr)));

	// If this new addition made the set go over the limit, remove
	// the solution with lower utility that is most similar to the solution
	// just added.
	if (_eliteSet.size() > _eliteSetSize) {
		Solution *lowerCloserSolution = nullptr;
		int lowerCloserSolutionDistance = 0;
		bool first = true;
		for (auto &eliteSolutionPair : _eliteSet) {
			Solution *eliteSolution = eliteSolutionPair.second.get();

			if (eliteSolution == solution) {
				break;
			}

			int currentDistance = solution->getDistanceTo(*eliteSolution);

			if (first || lowerCloserSolutionDistance > currentDistance) {
				lowerCloserSolutionDistance = currentDistance;
				lowerCloserSolution = eliteSolution;
				first = false;
			}
		}

		// If the new solution was actually the worse, remove it
		if (lowerCloserSolution == nullptr) {
			_eliteSet.erase(newSolutionIt);
		}
		// Else, remove the lowestCloserSolution
		else {
			for (auto it = _eliteSet.begin(); it != _eliteSet.end(); it++) {
				if (it->second.get() == lowerCloserSolution) {
					_eliteSet.erase(it);
					break;
				}
			}
		}
	}
}

std::unique_ptr<Solution> GRASPTSSolver::pathRelinking(Solution solution) const {
	std::unique_ptr<Solution> bestSolution(new Solution(solution));

	// Can't do path relinking with 0 other solutions
	if (_eliteSet.size() < 1) {
		return bestSolution;
	}

	// Chooser will choose one random elite
	std::uniform_int_distribution<int> eliteChooser(0, _eliteSet.size() - 1);
	int destinationSolutionIndex = eliteChooser(random);
	Solution *destinationSolution = nullptr;

	int i = 0;
	for (auto &eliteSolution : _eliteSet) {
		if (destinationSolutionIndex == i) {
			destinationSolution = eliteSolution.second.get();
		}
		i++;
	}

	std::list<std::unique_ptr<Operation>> possibleOps;

	while (true) {
		checkTimeLimit(*bestSolution.get());

		possibleOps = solution.getPossibleOperationsTowards(*destinationSolution);

		// If no more options are possible we have reached our destination
		// (or maybe some possible dead end? doesn't matter, stop)
		if (possibleOps.size() == 0) {
			break;
		}

		// Lets be greedy
		auto &bestOperation = possibleOps.back();
		solution.applyOperation(*bestOperation.get());

		if (solution.getUtility() > bestSolution->getUtility()) {
			bestSolution.reset(new Solution(solution));
		}
	}

	return bestSolution;
}

void GRASPTSSolver::checkTimeLimit(const Solution &currentSolution) const {
	if (_maxTime < 0) {
		return;
	}

	auto currentTime = std::chrono::steady_clock::now();
	auto elapsedSeconds = std::chrono::duration_cast<std::chrono::seconds>(
			currentTime - _startTime).count();

	if (elapsedSeconds >= _maxTime) {
		throw TimeoutException(currentSolution);
	}
}
