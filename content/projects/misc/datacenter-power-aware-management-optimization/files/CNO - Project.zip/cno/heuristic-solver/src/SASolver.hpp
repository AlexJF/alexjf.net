/*
 * SASolver.hpp
 *
 *  Created on: 26.05.2013
 *      Author: Peter
 */

#ifndef SASOLVER_HPP_
#define SASOLVER_HPP_

#include <random>

#include "Solver.hpp"
#include "Solution.hpp"

class SASolver: public Solver {
public:
	SASolver(unsigned int cpuIncrements, unsigned int initialTemperature,
			double heatPreservingFactor, double minTemperature = 1);
	std::unique_ptr<Solution> solve() override;
private:
	unsigned int _initialTemperature;
	double _heatPreservingFactor;
	double _minTemperature;
	double _currentTemperature;
	std::default_random_engine _randomGenerator;
	std::uniform_real_distribution<double> _random;

	void recalculateTemperature();
	std::unique_ptr<Operation> getRandomOperation(Solution& solution);
};

#endif /* SASOLVER_HPP_ */
