#ifndef SOLUTION_HPP_
#define SOLUTION_HPP_

#include <memory>
#include <map>
#include <ostream>
#include <list>
#include "Solver.hpp"

class Host;
class Job;
class Operation;

class Solution {
	public:
		Solution(const Solver &solver);

		/**
		 * Return a list of possible operations that can be applied to the
		 * current solution maintaining the constraints.
		 *
		 * @param[in] ordered If operations should be ordered by utility (asc).
		 *
		 * @return List of pointers to operations.
		 */
		std::list<std::unique_ptr<Operation>> getPossibleOperations(bool ordered = true);

		std::list<std::unique_ptr<Operation>> getPossibleOperationsTowards(Solution &destination,
				bool ordered = true);

		/**
		 * Applies provided operation in-place.
		 *
		 * @param[in] Operation to apply.
		 * @return A reference to this solution with the applied operation.
		 */
		Solution& applyOperation(Operation &op);

		unsigned int getNumberJobsAssigned() const;

		void changeAssignment(Job *job, Host *host);
		void removeAssignment(Job *job);
		void swapAssignment(Job *job1, Job *job2);
		void changeCPUUsage(Job *job, int newCpuUsage);

		double getUtility() const;
		int getDistanceTo(const Solution &solution) const;

		void orderOperations(std::list<std::unique_ptr<Operation>> &ops);

		void print(std::ostream &output) const;

	private:
		const Solver &_solver;
		mutable double _utility;
		mutable bool _utilityKnown;

		std::map<Job*, Host*> _assignments;
		std::map<Host*, int> _hostCpuUsages;
		std::map<Job*, int> _jobCpuUsages;
};

#endif /* SOLUTION_HPP_ */
