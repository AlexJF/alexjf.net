#ifndef ASSIGNOPERATION_HPP_
#define ASSIGNOPERATION_HPP_

#include "Operation.hpp"

class AssignmentOperation : public Operation {
	public:
		AssignmentOperation(Job *job, Host *host, Host *oldHost = nullptr);

		Solution& execute(Solution &solution) override;
		Solution& undo(Solution &solution) override;

		bool equals(Operation const &other) const override;
		bool isReverseOf(Operation const &other) const override;

	private:
		Job *_job;
		Host *_host;
		Host *_previousHost;
};

#endif /* ASSIGNOPERATION_HPP_ */
