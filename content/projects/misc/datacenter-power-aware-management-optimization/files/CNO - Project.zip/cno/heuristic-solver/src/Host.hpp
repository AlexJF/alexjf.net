#ifndef HOST_HPP_
#define HOST_HPP_

class Host {
    public:
        Host(int id, int numCPUs);

        int getId() const;
        int getCPUCount() const;

    private:
        int _id, _numCPUs;
};

#endif /* HOST_HPP_ */
