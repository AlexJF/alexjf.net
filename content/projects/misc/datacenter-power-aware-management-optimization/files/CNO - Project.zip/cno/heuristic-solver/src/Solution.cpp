#include <memory>
#include <set>
#include <algorithm>
#include <cstdlib>

#include "Host.hpp"
#include "Job.hpp"
#include "Solution.hpp"
#include "AssignmentOperation.hpp"
#include "SwapOperation.hpp"
#include "ChangeCpuUsageOperation.hpp"

Solution::Solution(const Solver &solver) :
	_solver(solver), _utility(0), _utilityKnown(false),
	_assignments(), _hostCpuUsages(), _jobCpuUsages() {
}

std::list<std::unique_ptr<Operation>> Solution::getPossibleOperations(bool ordered) {
	const std::vector<std::unique_ptr<Job>> &allJobs = _solver.getJobs();
	const std::vector<std::unique_ptr<Host>> &allHosts = _solver.getHosts();
	auto ops = std::list<std::unique_ptr<Operation>>();

	std::list<Job*> assignedJobs;

	// Test for assignment and create possible assignment operations
	// These operations can apply to both unassigned and assigned jobs as long as there
	// is enough free CPU at the destination
	for (auto &jobManagedPointer : allJobs) {
		Job *job = jobManagedPointer.get();
		bool assigned = _assignments.count(job) > 0;
		int jobCpu = assigned ? _jobCpuUsages[job] : job->getMinimumCPU();
		Host *currentHost = assigned ? _assignments[job] : nullptr;

		for (auto &hostManagedPointer : allHosts) {
			Host *host = hostManagedPointer.get();

			// If current job is assigned, don't try assigning to same host.
			if (currentHost == host) {
				continue;
			}

			int hostTotalCpu = host->getCPUCount() * 100;
			int remainingCpu = hostTotalCpu - _hostCpuUsages[host];

			if (remainingCpu >= jobCpu) {
				ops.push_back(std::unique_ptr<Operation>(
						new AssignmentOperation(job, host, currentHost)));
			}
		}

		// If assigned, add it to an assigned collection to try swaps later on
		if (assigned) {
			assignedJobs.push_back(job);
		}
	}

	for (Job *jobA : assignedJobs) {
		int cpuUsageA = _jobCpuUsages[jobA];
		Host *hostA = _assignments[jobA];
		int cpuAvailableAtA = hostA->getCPUCount() * 100 - _hostCpuUsages[hostA] + cpuUsageA;

		// Check if we can swap with other jobs
		for (Job *jobB : assignedJobs) {
			if (jobA->getId() >= jobB->getId()) {
				continue;
			}

			int cpuUsageB = _jobCpuUsages[jobB];
			Host *hostB = _assignments[jobB];

			// Don't try to swap with another job on the same host, that's just stupid...
			if (hostA == hostB) {
				continue;
			}

			int cpuAvailableAtB = hostB->getCPUCount() * 100 - _hostCpuUsages[hostB] + cpuUsageB;

			if (cpuUsageA <= cpuAvailableAtB &&
				cpuUsageB <= cpuAvailableAtA) {
				ops.push_back(std::unique_ptr<Operation>(
						new SwapOperation(jobA, jobB)));
			}
		}

		cpuAvailableAtA -= cpuUsageA;
		int minCpuUsageA = jobA->getMinimumCPU();
		int maxCpuUsageA = jobA->getMaximumCPU();
		int cpuIncrements = _solver.getCpuIncrements();

		// Check if we can increase used CPU
		if (cpuUsageA < maxCpuUsageA) {
			int maxCpuIncreaseA = std::min(maxCpuUsageA - cpuUsageA, std::min(cpuAvailableAtA, cpuIncrements));

			ops.push_back(std::unique_ptr<Operation>(
					new ChangeCpuUsageOperation(jobA, cpuUsageA, cpuUsageA + maxCpuIncreaseA)));
		}
		if (cpuUsageA > minCpuUsageA) {
			int maxCpuDecreaseA = std::min(cpuUsageA - minCpuUsageA, cpuIncrements);
			ops.push_back(std::unique_ptr<Operation>(
					new ChangeCpuUsageOperation(jobA, cpuUsageA, cpuUsageA - maxCpuDecreaseA)));
		}
	}

	if (ordered) {
		orderOperations(ops);
	}

	return ops;
}

std::list<std::unique_ptr<Operation>> Solution::getPossibleOperationsTowards(
		Solution &destination, bool ordered) {
	const std::vector<std::unique_ptr<Job>> &allJobs = _solver.getJobs();

	auto ops = std::list<std::unique_ptr<Operation>>();

	std::list<Job*> assignedJobs;

	for (auto &jobManagedPointer : allJobs) {
		Job *job = jobManagedPointer.get();
		bool locallyAssigned = _assignments.count(job) > 0;
		bool destinationAssigned = destination._assignments.count(job) > 0;

		// If we have to assign job
		if (!locallyAssigned && destinationAssigned) {
			Host *assignedHostDestination = destination._assignments[job];
			int minJobCpu = job->getMinimumCPU();
			int hostTotalCpu = assignedHostDestination->getCPUCount() * 100;
			int remainingCpu = hostTotalCpu - _hostCpuUsages[assignedHostDestination];

			if (remainingCpu >= minJobCpu) {
				ops.push_back(std::unique_ptr<Operation>(
						new AssignmentOperation(job, assignedHostDestination)));
			}
		}
		// If job is already assigned locally but not on destination
		else if (locallyAssigned && !destinationAssigned) {
			Host *assignedHostLocal = _assignments[job];
			ops.push_back(std::unique_ptr<Operation>(new AssignmentOperation(job, nullptr, assignedHostLocal)));
		}
		// If job is assigned in both
		else if (locallyAssigned && destinationAssigned) {
			assignedJobs.push_back(job);
		}
	}

	// For each job assigned on both solutions
	for (Job *job : assignedJobs) {
		Host *assignedHostLocal = _assignments[job];
		Host *assignedHostDestination = destination._assignments[job];
		int cpuUsageLocal = _jobCpuUsages[job];
		int cpuUsageDestination = destination._jobCpuUsages[job];
		int cpuAvailableAtLocalHost = assignedHostLocal->getCPUCount() * 100
				- _hostCpuUsages[assignedHostLocal];
		int cpuAvailableAtDestinationHost = assignedHostDestination->getCPUCount() * 100
				- _hostCpuUsages[assignedHostDestination];

		// If they are in different hosts, try to put job in correct host
		// either by swapping with a job which is also on the wrong host
		// or by changing the assignment.
		if (assignedHostLocal != assignedHostDestination) {
			// If we can move it to correct host directly, do it
			if (cpuUsageLocal <= cpuAvailableAtDestinationHost) {
				ops.push_back(std::unique_ptr<Operation>(
						new AssignmentOperation(job, assignedHostDestination, assignedHostLocal)));
			}
			// If not we can only move to correct host with a swap
			else {
				for (Job *jobSwap : assignedJobs) {
					Host *swapHost = _assignments[jobSwap];
					// If the other job isn't in our target host, skip it
					if (swapHost != assignedHostDestination) {
						continue;
					}

					// If this is the same job or a job in the correct position, skip it
					if (jobSwap == job
						|| swapHost == destination._assignments[jobSwap]) {
						continue;
					}
					// Otherwise, this job is different from the swap source and is not
					// in the correct host so it's feasible to swap it as long as cpu
					// usages are compatible.
					else {
						int cpuUsageSwap = _jobCpuUsages[jobSwap];
						int cpuAvailableAtSwapHost = swapHost->getCPUCount() * 100
							- _hostCpuUsages[swapHost] + cpuUsageSwap;
						if (cpuUsageLocal <= cpuAvailableAtSwapHost &&
							cpuUsageSwap <= cpuAvailableAtLocalHost + cpuUsageLocal) {
							ops.push_back(std::unique_ptr<Operation>(new SwapOperation(job, jobSwap)));
						}
					}
				}
			}
		}

		// If job in the 2 solutions has different cpu usages,
		// create cpu usage change operations.
		int cpuIncrement = _solver.getCpuIncrements();
		int delta = cpuUsageDestination - cpuUsageLocal;
		if (delta > 0) {
			int maxIncrement = std::min(cpuIncrement, std::min(delta, cpuAvailableAtLocalHost));
			if (maxIncrement > 0) {
				ops.push_back(std::unique_ptr<Operation>(new ChangeCpuUsageOperation(job,
						cpuUsageLocal, cpuUsageLocal + maxIncrement)));
			}
		}
		else if (delta < 0) {
			int maxDecrement = std::min(cpuIncrement, -delta);
			if (maxDecrement > 0) {
				ops.push_back(std::unique_ptr<Operation>(new ChangeCpuUsageOperation(job,
						cpuUsageLocal, cpuUsageLocal - maxDecrement)));
			}
		}
	}

	if (ordered) {
		orderOperations(ops);
	}

	return ops;
}

Solution& Solution::applyOperation(Operation &op) {
	return op.execute(*this);
}

unsigned int Solution::getNumberJobsAssigned() const {
	return _assignments.size();
}

void Solution::changeAssignment(Job *job, Host *host) {
	// If job is already assigned, do a swap
	if (_assignments.count(job) > 0) {
		Host *previousHost = _assignments[job];
		int previousJobCpuUsage = _jobCpuUsages[job];
		_hostCpuUsages[previousHost] -= previousJobCpuUsage;

		// If this is a valid host, do the swap
		if (host != nullptr) {
			_hostCpuUsages[host] += previousJobCpuUsage;
			_assignments[job] = host;
		}
		// Otherwise remove assignment
		else {
			_assignments.erase(job);
			_jobCpuUsages.erase(job);
		}
	}
	// Else this is a new assignment
	else if (host != nullptr) {
		// Start with minimum cpu usage. This can be increased with other operations.
		int minCpuUsage = job->getMinimumCPU();
		_jobCpuUsages[job] = minCpuUsage;
		_assignments[job] = host;
		_hostCpuUsages[host] += minCpuUsage;
	}

	_utilityKnown = false;
}

void Solution::removeAssignment(Job *job) {
	if (_assignments.count(job) == 0) {
		return;
	}
	Host *host = _assignments[job];
	int cpuUsage = _jobCpuUsages[job];
	_hostCpuUsages[host] -= cpuUsage;
	_jobCpuUsages.erase(job);
	_assignments.erase(job);

	_utilityKnown = false;
}

void Solution::swapAssignment(Job *job1, Job *job2) {
	Host *previousHostJob1 = _assignments[job1];
	Host *previousHostJob2 = _assignments[job2];
	int cpuUsageJob1 = _jobCpuUsages[job1];
	int cpuUsageJob2 = _jobCpuUsages[job2];

	_assignments[job1] = previousHostJob2;
	_assignments[job2] = previousHostJob1;

	_hostCpuUsages[previousHostJob1] += cpuUsageJob2 - cpuUsageJob1;
	_hostCpuUsages[previousHostJob2] += cpuUsageJob1 - cpuUsageJob2;

	_utilityKnown = false;
}

void Solution::changeCPUUsage(Job *job, int newCpuUsage) {
	if (_assignments.count(job) == 0) {
		return;
	}

	int previousCpuUsage = _jobCpuUsages[job];
	_jobCpuUsages[job] = newCpuUsage;
_hostCpuUsages[_assignments[job]] += newCpuUsage - previousCpuUsage;

	_utilityKnown = false;
}

double Solution::getUtility() const {
	if (_utilityKnown) {
		return _utility;
	}

	double jobRevenue = 0;

	for (auto &assignment : _assignments) {
		jobRevenue += assignment.first->getRevenuePerHour();
	}

	double qosPenalty = 0;
 	for (auto &jobCpuUsage : _jobCpuUsages) {
 		double offeredCpu = jobCpuUsage.second;
 		double maxCpu = jobCpuUsage.first->getMaximumCPU();
 		double revenue = jobCpuUsage.first->getRevenuePerHour();
		qosPenalty += (1 - offeredCpu / maxCpu) * revenue;
	}

	double powerCost = 0;
	const std::vector<int> &powerPerCpu = _solver.getPowerPerCpu();
	double powerCostHour = _solver.getPowerCost();
	for (auto &hostCpuUsage : _hostCpuUsages) {
		int totalCpuUsage = hostCpuUsage.second;
		int numCpusOn = ceil(totalCpuUsage / 100.);

		for (int i = 0; i < numCpusOn; i++) {
			powerCost += powerPerCpu[i];
		}
	}
	powerCost *= powerCostHour;

	_utility = jobRevenue - qosPenalty - powerCost;
	_utilityKnown = true;

	return _utility;
}

int Solution::getDistanceTo(const Solution &solution) const {
	int distance = 0;

	auto &allJobs = _solver.getJobs();

	for (auto &jobManagedPtr : allJobs) {
		Job *job = jobManagedPtr.get();
		Host *assignedHostA = nullptr;
		Host *assignedHostB = nullptr;

		if (_assignments.count(job) > 0) {
			assignedHostA = _assignments.at(job);
		}

		if (_assignments.count(job) > 0) {
			assignedHostB = solution._assignments.at(job);
		}

		// If jobs are located in different hosts, add 1 to the distance
		// since we need at least 1 operation to fix this difference
		if (assignedHostA != assignedHostB) {
			distance++;
		}

		// If jobs have different cpu usages, add 1 to the distance
		// since we need at least 1 operation to fix this difference.
		if (_jobCpuUsages.at(job) != solution._jobCpuUsages.at(job)) {
			distance++;
		}
	}

	return distance;
}

void Solution::orderOperations(std::list<std::unique_ptr<Operation>> &ops) {
	std::map<Operation*, double> utilityValues;

	for (auto &opManagedPtr : ops) {
		Operation *op = opManagedPtr.get();
		op->execute(*this);
		op->_utility = getUtility();
		op->undo(*this);
	}

	ops.sort([&](std::unique_ptr<Operation> &op1,
				 std::unique_ptr<Operation> &op2) {
		return op1->_utility < op2->_utility;
	});
}

void Solution::print(std::ostream &output) const {
	auto hostComparison = [](const Host *h1, const Host *h2) {
		return h1->getId() < h2->getId();
	};
	std::map<Host*, std::list<Job*>, decltype(hostComparison)> hostAssignments(hostComparison);

	for (auto &hostManagedPtr : _solver.getHosts()) {
		hostAssignments[hostManagedPtr.get()];
	}

	for (auto &assignment : _assignments) {
		hostAssignments[assignment.second].push_back(assignment.first);
	}

	for (auto &hostAssignment : hostAssignments) {
		Host *host = hostAssignment.first;
		std::list<Job*> &jobList = hostAssignment.second;
		output << "Host " << host->getId() << " (" << _hostCpuUsages.at(host) << "):" << std::endl;

		if (jobList.size() == 0) {
			output << "    No jobs assigned" << std::endl;
		} else {
			for (Job *job : jobList) {
				output << "    Job " << job->getId() << " (" << _jobCpuUsages.at(job) << ")" << std::endl;
			}
		}
	}

	output << std::endl << "Unassigned jobs:" << std::endl;

	unsigned int numberUnassignedJobs = 0;
	for (auto &job : _solver.getJobs()) {
		Job *jobRaw = job.get();

		if (_assignments.count(jobRaw) == 0) {
			output << "    Job " << job->getId() << std::endl;
			numberUnassignedJobs++;
		}
	}

	if (numberUnassignedJobs == 0) {
		output << "    None" << std::endl;
	} else {
		output << std::endl << "    Total: " << numberUnassignedJobs << std::endl;
	}

	output << std::endl << "Total utility: " << getUtility() << std::endl;
}
