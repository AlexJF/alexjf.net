#ifndef SOLVER_HPP_
#define SOLVER_HPP_

#include <vector>
#include <memory>
#include <chrono>
#include <random>
#include "Host.hpp"
#include "Job.hpp"

class Solution;

class Solver {
    public:
        Solver(unsigned int cpuIncrements);
        virtual ~Solver() = default;

        void parseInput(const std::string &inputDataFile);
        virtual std::unique_ptr<Solution> solve() = 0;

        const std::vector<int>& getPowerPerCpu() const;
        virtual unsigned int getCpuIncrements() const;
		const std::vector<std::unique_ptr<Host>>& getHosts() const;
		const std::vector<std::unique_ptr<Job>>& getJobs() const;

        double getPowerCost() const;

    protected:
		static std::default_random_engine random;

    private:
        std::vector<int> _powerPerCpu;
        std::vector<std::unique_ptr<Host>> _hosts;
        std::vector<std::unique_ptr<Job>> _jobs;

        double _powerCost;
        unsigned int _cpuIncrements;
};
#endif /* SOLVER_HPP_ */
