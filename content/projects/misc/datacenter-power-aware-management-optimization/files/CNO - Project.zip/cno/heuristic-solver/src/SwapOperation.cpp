#include "SwapOperation.hpp"

SwapOperation::SwapOperation(Job* job1, Job* job2) :
	_job1(job1), _job2(job2) {
}

Solution& SwapOperation::execute(Solution &solution) {
	solution.swapAssignment(_job1, _job2);
	return solution;
}

Solution& SwapOperation::undo(Solution &solution) {
	return execute(solution);
}

bool SwapOperation::equals(Operation const &other) const {
	if (SwapOperation const* p = dynamic_cast<SwapOperation const*>(&other)) {
		return (_job1 == p->_job1 && _job2 == p->_job2) || (_job1 == p->_job2 && _job2 == p->_job1);
    }
    else {
    	return false;
    }
}

bool SwapOperation::isReverseOf(Operation const &other) const {
	return equals(other);
}
