#include <fstream>
#include <memory>

#include "Solver.hpp"
#include "Host.hpp"
#include "Job.hpp"

std::default_random_engine Solver::random(std::chrono::system_clock::now().time_since_epoch().count());

Solver::Solver(unsigned int cpuIncrements) :
	_powerPerCpu(), _hosts(), _jobs(), _powerCost(0) , _cpuIncrements(cpuIncrements) {
}

void Solver::parseInput(const std::string &inputDataFile) {
    int maxCPUs = 0;
    std::ifstream f(inputDataFile);
    f >> maxCPUs;

    _powerPerCpu.resize(maxCPUs);

    for (int i = 0; i < maxCPUs; i++) {
        f >> _powerPerCpu[i];
    }

    int numHosts = 0;
    f >> numHosts;

    _hosts.reserve(numHosts);

    for (int i = 0; i < numHosts; i++) {
        int cpusInHost = 0;
        f >> cpusInHost;
        _hosts.push_back(std::unique_ptr<Host>(new Host(i, cpusInHost)));
    }

    int numJobs = 0;
    f >> numJobs;

    _jobs.reserve(numJobs);

    for (int i = 0; i < numJobs; i++) {
        int minCons = 0;
        int maxCons = 0;
        double revenueHour = 0;

        f >> minCons >> maxCons >> revenueHour;
        _jobs.push_back(std::unique_ptr<Job>(new Job(i, minCons, maxCons, revenueHour)));
    }

    f >> _powerCost;
}

unsigned int Solver::getCpuIncrements() const {
	return _cpuIncrements;
}

const std::vector<int>& Solver::getPowerPerCpu() const {
	return _powerPerCpu;
}

const std::vector<std::unique_ptr<Host>>& Solver::getHosts() const {
	return _hosts;
}

const std::vector<std::unique_ptr<Job>>& Solver::getJobs() const {
	return _jobs;
}

double Solver::getPowerCost() const {
	return _powerCost;
}
