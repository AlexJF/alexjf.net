#ifndef SWAPOPERATION_HPP_
#define SWAPOPERATION_HPP_

#include "Operation.hpp"

class SwapOperation: public Operation {
	public:
		SwapOperation(Job *job1, Job *job2);

		Solution& execute(Solution &solution) override;
		Solution& undo(Solution &solution) override;

		bool equals(Operation const &other) const override;
		bool isReverseOf(Operation const &other) const override;

	private:
		Job *_job1, *_job2;
};

#endif /* SWAPOPERATION_HPP_ */
