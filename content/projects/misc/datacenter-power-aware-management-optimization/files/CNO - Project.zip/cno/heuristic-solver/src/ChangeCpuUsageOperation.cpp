#include "ChangeCpuUsageOperation.hpp"

ChangeCpuUsageOperation::ChangeCpuUsageOperation(Job* job, int oldCpuUsage, int newCpuUsage) :
	_job(job), _oldCpuUsage(oldCpuUsage), _newCpuUsage(newCpuUsage) {
}

Solution& ChangeCpuUsageOperation::execute(Solution &solution) {
	solution.changeCPUUsage(_job, _newCpuUsage);
	return solution;
}

Solution& ChangeCpuUsageOperation::undo(Solution &solution) {
	solution.changeCPUUsage(_job, _oldCpuUsage);
	return solution;
}

bool ChangeCpuUsageOperation::equals(Operation const &other) const {
	if (ChangeCpuUsageOperation const* p = dynamic_cast<ChangeCpuUsageOperation const*>(&other)) {
		return _job == p->_job && _oldCpuUsage == p->_oldCpuUsage && _newCpuUsage == p->_newCpuUsage;
    }
    else {
    	return false;
    }
}

bool ChangeCpuUsageOperation::isReverseOf(Operation const &other) const {
	if (ChangeCpuUsageOperation const* p = dynamic_cast<ChangeCpuUsageOperation const*>(&other)) {
		return _job == p->_job && _oldCpuUsage == p->_newCpuUsage && _newCpuUsage == p->_oldCpuUsage;
    }
    else {
    	return false;
    }
}
