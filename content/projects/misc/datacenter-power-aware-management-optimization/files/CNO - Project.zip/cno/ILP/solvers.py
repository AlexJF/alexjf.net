import sys, os, subprocess
from os.path import basename

MPS_TEMP_FILE = "tmp/mps.mps"
GLPK_PATH = "glpsol"
GUROBI_PATH = "gurobi_cl"
CBC_PATH = "~/Downloads/Cbc-2.8.1/build/bin/cbc"
CPLEX_PATH = "cplex"

def writeTo (content, output):
    if output is None:
        print content
    else:
        outfile = open(output, 'w')
        outfile.write(content)
     
def generateMPS(input, output=None):
    inputData = []
    with open(input) as file:
        for line in file:
            data = line.strip()
            if not data:
                continue
            else:
                inputData.append(data)

    # Read all parameters
    step = 0
    maxCPUs = int(inputData[0])
    pwr = [float(value) for value in inputData[1].split()[:maxCPUs]]
    noHosts = int(inputData[2])
    cpus = [int(value) for value in inputData[3].split()[:noHosts]]
    noJobs = int(inputData[4])
    consmin = []
    consmax = []
    revenue = []
    for i in range(5,5+noJobs):
        values = inputData[i].split()
        consmin.append(int(values[0]))
        consmax.append(int(values[1]))
        revenue.append(float(values[2]))
    powerCost = float(inputData[5+noJobs])
    
    bigM = maxCPUs * noHosts * 100
    
    # Generate MPS  
    # NAME
    content = "NAME DCModelInt\n"
    
    # ROWS
    content += "ROWS\n" 
    # Objective function
    content += " N z\n"
    # Processors constraints
    for h in range(1,noHosts+1):
        for i in range(2,maxCPUs+1):
            content += " G Processor[%d,%d]\n" % (h,i) 
    # Unique constraints
    for j in range(1,noJobs+1):
        content += " L Unique[%d]\n" % j
    # MaxCPU constraints
    for h in range(1,noHosts+1):
        content += " L MaxCPU[%d]\n" % h
    # Capacity constraints
    for h in range(1,noHosts+1):
        content += " L Capacity[%d]\n" % h
    # Margin CPU constraints
    for j in range(1,noJobs+1):
        content += " G MarginCPU1[%d]\n" % j
    for j in range(1,noJobs+1):
        content += " L MarginCPU2[%d]\n" % j
    # QoSAux(1-4) constraints
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            content += " G QosAux1[%d,%d]\n" % (h, j)
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            content += " L QosAux2[%d,%d]\n" % (h, j)
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            content += " L QosAux3[%d,%d]\n" % (h, j)
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            content += " L QosAux4[%d,%d]\n" % (h, j)
    
    # COLUMNS
    content += "COLUMNS\n"
    content += " M0000001 'MARKER' 'INTORG'\n"
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            # Schedule
            content += " schedule[%d,%d] z %d Unique[%d] 1\n" % (h,j,-revenue[j-1],j)
            content += " schedule[%d,%d] QosAux1[%d,%d] -1 QosAux2[%d,%d] %d\n" % (h,j,h,j,h,j,-bigM)
            content += " schedule[%d,%d] QosAux3[%d,%d] 1 QosAux4[%d,%d] %d\n" % (h,j,h,j,h,j,bigM)
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            # Quota
            content += " quota[%d,%d] Capacity[%d] 1 QosAux1[%d,%d] 1\n" % (h, j, h, h, j)
            content += " quota[%d,%d] QosAux2[%d,%d] 1 QosAux3[%d,%d] 1\n" % (h, j, h, j, h, j)
            content += " quota[%d,%d] QosAux4[%d,%d] -1\n" % (h, j, h, j)
    for h in range(1,noHosts+1):
        # pr
        for i in range(1,maxCPUs+1):
            if i == 1:
                content += " pr[%d,%d] z %f Processor[%d,%d] 1\n" % (h, i, (pwr[i-1] * powerCost), h, i+1)
                content += " pr[%d,%d] MaxCPU[%d] 1 Capacity[%d] -100\n" % (h, i, h, h)
            elif i == maxCPUs:
                content += " pr[%d,%d] z %f Processor[%d,%d] -1\n" % (h, i, (pwr[i-1] * powerCost), h, i)
                content += " pr[%d,%d] MaxCPU[%d] 1 Capacity[%d] -100\n" % (h, i, h, h)
            else:
                content += " pr[%d,%d] z %f Processor[%d,%d] -1\n" % (h, i, (pwr[i-1] * powerCost), h, i)
                content += " pr[%d,%d] Processor[%d,%d] 1 MaxCPU[%d] 1\n" % (h, i, h, i+1, h)
                content += " pr[%d,%d] Capacity[%d] -100\n" % (h, i, h)
    # jcpu
    for j in range(1,noJobs+1):
        content += " jcpu[%d] z %f MarginCPU1[%d] 1\n" % (j, -revenue[j-1]/consmax[j-1], j)
        content += " jcpu[%d] MarginCPU2[%d] 1\n" % (j, j)
        for h in range(1,noHosts+1):
            content += " jcpu[%d] QosAux3[%d,%d] -1\n" % (j, h, j)
        for h in range(1,noHosts+1):
            content += " jcpu[%d] QosAux4[%d,%d] 1\n" % (j, h, j)
    
    content += " M0000002 'MARKER' 'INTEND'\n"
    
    # Add the constant to z
    for j in range(1,noJobs+1):
        content += " rev[%d] z 1\n" % j
    
    # RHS
    content += "RHS\n" 
    # Unique
    for j in range(1,noJobs+1):
        content += " RHS1 Unique[%d] 1\n" % j
    # Max CPU
    for h in range(1,noHosts+1):
        content += " RHS1 MaxCPU[%d] %d\n" % (h, cpus[h-1])
    # Margin CPU
    for j in range(1,noJobs+1):
        content += " RHS1 MarginCPU1[%d] %d\n" % (j, consmin[j-1])
    for j in range(1,noJobs+1):
        content += " RHS1 MarginCPU2[%d] %d\n" % (j, consmax[j-1])
    # QosAux
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            content += " RHS1 QosAux3[%d,%d] 1\n" % (h, j)
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            content += " RHS1 QosAux4[%d,%d] %d\n" % (h, j, bigM)
    
    # BOUNDS
    content += "BOUNDS\n"
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            # Schedule
            content += " UP BND1 schedule[%d,%d] 1\n" % (h, j)
    for h in range(1,noHosts+1):
        for j in range(1,noJobs+1):
            # Quota
            content += " PL BND1 quota[%d,%d]\n" % (h, j)
    for h in range(1,noHosts+1):
        # pr
        for i in range(1,maxCPUs+1):
            content += " UP BND1 pr[%d,%d] 1\n" % (h, i)
    # jcpu
    for j in range(1,noJobs+1):
        content += " PL BND1 jcpu[%d]\n" % j
        
    for j in range(1,noJobs+1):
        content += " FX BND1 rev[%d] %f\n" % (j, revenue[j-1])
    
    
    # ENDATA
    content += "ENDATA\n"
    
    # Output
    writeTo(content, output)

if len(sys.argv) < 3:
    print "python solverwrapper.py <option> <input file> [<output file>]"
    print "<option> can be mps, glpk, gurobi, cbc or cplex"
    print "<output file> is only applicable for mps option"
    exit(0)
    
option = sys.argv[1]
if option != "mps" and option != "glpk" and option != "gurobi" and option != "cbc" and option != "cplex":
    print "<option> can only be mps, glpk, gurobi, cbc or cplex"
    exit(0)

input = sys.argv[2]
output = None
if len(sys.argv) > 3:
   output = sys.argv[3]
   
if option == "mps":
    generateMPS(input, output)
else:
    generateMPS(input, MPS_TEMP_FILE)
    if option == "glpk":
        subprocess.call("%s %s" % (GLPK_PATH, MPS_TEMP_FILE), shell=True)
    elif option == "gurobi":
        subprocess.call("%s %s" % (GUROBI_PATH, MPS_TEMP_FILE), shell=True)
    elif option == "cbc":
        subprocess.call("%s %s" % (CBC_PATH, MPS_TEMP_FILE), shell=True)
    elif option == "cplex":
        subprocess.call("%s -c \"read %s\" \"mipopt\"" % (CPLEX_PATH, MPS_TEMP_FILE), shell=True)
    

   

