#!/usr/bin/python

import sys, os
from os.path import basename

def convert(input, output=None):
    if output is None:
        output = "mod_%s" % input
    outfile = open(output, 'w')

    step = 0
    jobs_count = 0
    consmin = []
    consmax = []
    revenue = []
    penalty = ''
    with open(input) as file:
        for line in file:
            data = line.strip()
            if not data:
                continue

            elif step == 0:
                outfile.write("param maxCPUs := %s ;\n" % data)
                step = 1
            elif step == 1:
                outfile.write("param pwr := \n")
                index = 1
                for value in data.split():
                    outfile.write("%d %s\n" % (index, value))
                    index += 1
                outfile.write(";\n\n")
                step = 2
            elif step == 2:
                outfile.write("param noHosts := %s ;\n" % data)
                step = 3
            elif step == 3:
                outfile.write("param cpus := \n")
                index = 1
                for value in data.split():
                    outfile.write("%d %s\n" % (index, value))
                    index += 1
                outfile.write(";\n\n")
                step = 4
            elif step == 4:
                jobs_count = int(data)
                outfile.write("param noJobs := %s ;\n\n" % data)
                step = 5
            elif step == 5:
                values = [int(v) for v in data.split()]
                if jobs_count > 0:
                    consmin.append(values[0])
                    consmax.append(values[1])
                    revenue.append(values[2])
                    jobs_count -= 1
                else: 
                    outfile.write("param powerCost := %s ;\n" % data)
                    penalty = data
                    step = 6
            elif step == 6:
                penalty = data
                step = 7

    outfile.write("param qosPenalty := %s ;\n\n" % penalty)

    outfile.write("param consmin :=\n")
    index = 1
    for v in consmin:
        outfile.write("%d %d\n" % (index, v))
        index += 1
    outfile.write(";\n\n")

    outfile.write("param consmax :=\n")
    index = 1
    for v in consmax:
        outfile.write("%d %d\n" % (index, v))
        index += 1 
    outfile.write(";\n\n")

    outfile.write("param revenue :=\n")
    index = 1
    for v in revenue:
        outfile.write("%d %d\n" % (index, v))
        index += 1
    outfile.write(";\n")         


if len(sys.argv) < 2:
    print "Wrong usage! Please provide input filename or directory"
    exit(1)

inpath = sys.argv[1]
outpath = None
if len(sys.argv) > 2:
   outpath = sys.argv[2]

if os.path.isdir(inpath):
    if outpath is None:
		outpath = "./"
    for dirname, _, filenames in os.walk(inpath):
        for filename in filenames:
            if ".data" in filename:
                convert(os.path.join(dirname, filename), os.path.join(outpath, "mod_"+os.path.splitext(filename)[0]+".dat"))
else:
    convert(inpath, outpath)
