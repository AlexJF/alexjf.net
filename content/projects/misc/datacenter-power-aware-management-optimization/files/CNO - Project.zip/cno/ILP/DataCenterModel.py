from __future__ import division
from coopr.pyomo import *

model = AbstractModel()

# Parameters
model.maxCPUs = Param(within=PositiveIntegers)
model.I = RangeSet(1, model.maxCPUs)
model.I_sub = RangeSet(2, model.maxCPUs)
model.pwr = Param(model.I, within=PositiveReals)

model.noHosts = Param(within=PositiveIntegers)
model.H = RangeSet(1, model.noHosts)
model.cpus = Param(model.H, within=PositiveIntegers)

model.noJobs = Param(within=PositiveIntegers)
model.J = RangeSet(1, model.noJobs)
model.consmin = Param(model.J, within=PositiveIntegers)
model.consmax = Param(model.J, within=PositiveIntegers)
model.revenue = Param(model.J, within=PositiveReals)

model.powerCost = Param(within=NonNegativeReals)
model.qosPenalty = Param(within=NonNegativeReals)

# Ranges
model.HJ = model.H * model.J
model.HI = model.H * model.I
model.HI_sub = model.H * model.I_sub

# Variables
model.schedule = Var(model.HJ, domain=Boolean)
model.quota = Var(model.HJ, domain=NonNegativeIntegers)
model.pr = Var(model.HI, domain=Boolean)
model.jcpu = Var(model.J, domain=NonNegativeIntegers)

# Health
# QoS cost: denominator is (max-min+1) in case (max==min), also it means that the range is [min,max] inclusive
model.notHealthy = Var(model.J, domain=NonNegativeReals)
def not_healthy(model, j):
	return model.notHealthy[j] == (1 - model.jcpu[j] / model.consmax[j])
model.HealthConstraint = Constraint(model.J, rule=not_healthy)

# Objective Function 
def benefit(model):
    return sum( sum(model.schedule[h,j] * model.revenue[j] for j in model.J) for h in model.H) \
         - sum( sum(model.pr[h,i] * model.pwr[i] * model.powerCost for i in model.I) for h in model.H) \
         - sum( model.notHealthy[j] * model.revenue[j] for j in model.J) 
model.OBJ = Objective(rule=benefit, sense=maximize)

# Constraints
def processor(model, h, i):
	return model.pr[h,i-1] >= model.pr[h,i]
model.Processor = Constraint(model.HI_sub, rule=processor)

def unique(model, j):
    return sum( model.schedule[h,j] for h in model.H) <= 1
model.Unique = Constraint(model.J, rule=unique)

def max_cpu(model, h):
    return sum( model.pr[h,i] for i in model.I) <= model.cpus[h]
model.MaxCPU = Constraint(model.H, rule=max_cpu)

def capacity(model, h):
    return sum( model.quota[h,j] for j in model.J) <= sum( model.pr[h,i] for i in model.I) * 100
model.Capacity = Constraint(model.H, rule=capacity)

def margin_cpu(model, j):
    return (model.consmin[j], model.jcpu[j], model.consmax[j])
model.MarginCPU = Constraint(model.J, rule=margin_cpu)

# QoSAux1: Still this is not necessary. Just put it here to comply with the paper
def qos_aux_1(model, h, j):
	return model.quota[h,j] >= model.schedule[h,j]
def qos_aux_2(model, h, j):
	return model.quota[h,j] <= model.schedule[h,j] * model.maxCPUs * model.noHosts * 100
def qos_aux_3(model, h, j):
	return (model.quota[h,j] - model.jcpu[j]) <= (1- model.schedule[h,j])
def qos_aux_4(model, h, j):
	return (model.jcpu[j] - model.quota[h,j]) <= (1 - model.schedule[h,j]) * model.maxCPUs * model.noHosts * 100
model.QoSAux1 = Constraint(model.HJ, rule=qos_aux_1)
model.QoSAux2 = Constraint(model.HJ, rule=qos_aux_2)
model.QoSAux3 = Constraint(model.HJ, rule=qos_aux_3)
model.QoSAux4 = Constraint(model.HJ, rule=qos_aux_4)

