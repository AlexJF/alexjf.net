import os, itertools, subprocess

def avg(l):
    return sum(l) / len(l)

execLocation = './heuristic-solver/build/Release/heuristic-solver'
dataFilesDir = 'heuristic-solver/data/'
solverType = "GRASPTS"
resultsDir = os.path.join("results", solverType)

dataFiles = ['overload.data'] #os.listdir(dataFilesDir)
cpuIncrements = [1,25,50,75,100]
constructionPs = [100]
searchPs = [200]
maxIterationValues = [5]
eliteSetSizes = [10]
tabuSetSizes = [400]
timeLimits = [-1]

numExecutionsPerCombination = 5

if not os.path.isdir(resultsDir):
    os.makedirs(resultsDir)

for f, c, cp, sp, mi, es, ts, tl in itertools.product(dataFiles,
        cpuIncrements, constructionPs, searchPs, maxIterationValues, 
        eliteSetSizes, tabuSetSizes, timeLimits):
    command = "%s %s %s %d %d %d %d %d %d %d" % (execLocation, 
            os.path.join(dataFilesDir, f), 
            solverType, c, cp, sp, mi, es, ts, tl)

    utilities = []
    times = []

    for i in range(numExecutionsPerCombination):
        print("%d -> %s" % (i, command))
        output = subprocess.check_output(command, universal_newlines = True, shell=True)
        outputLines = output.splitlines()

        utilityLine = outputLines[-2]
        timeLine = outputLines[-1]

        print(utilityLine)
        print(timeLine)

        utility = float(utilityLine.split()[2])
        time = float(timeLine.split()[2])

        utilities.append(utility)
        times.append(time)

    with open(os.path.join(resultsDir, f), 'a') as r:
        r.write("%s\nNum Executions: %d\n" % 
                (command, numExecutionsPerCombination))
        r.write("Average time: %f\nAverage utility:%f\n" %
                (avg(times), avg(utilities)))
