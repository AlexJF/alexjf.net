var savedQuantities = Array();
var items = Array();

function updateSavedQuantity(name, quantity) {
    savedQuantities[name] = quantity;
}

function clearItems() {
    for (var i = 0; i < shoppingListModel.count; i++) {
        var name = shoppingListModel.get(i).name;
        shoppingListBase.removedItem(items[name]);
    }

    items = Array();
    savedQuantities = Array();
    shoppingListModel.clear();
    shoppingList.visible = false;
    noResults.visible = true;
    shoppingListBase.itemCount = 0;
}

function addItem(item, name, quantity) {
    if (savedQuantities[name] != null) {
        quantity = savedQuantities[name];
    }

    items[name] = item;
    shoppingListModel.append({"name": name, "quantity": quantity});
    shoppingList.visible = true;
    noResults.visible = false;
    shoppingListBase.itemCount++;
}

function removeItem(name) {
    for (var i = 0; i < shoppingListModel.count; ++i) {
        var objType = shoppingListModel.get(i);

        if (objType.name == name) {
            shoppingListModel.remove(i);
            shoppingListBase.removedItem(items[name]);

            if (shoppingListModel.count == 0) {
                shoppingList.visible = false;
                noResults.visible = true;
            }
            shoppingListBase.itemCount--;
            return;
        }
    }
}
