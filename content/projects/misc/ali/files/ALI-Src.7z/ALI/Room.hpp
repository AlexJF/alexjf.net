#ifndef HPP_ROOM
#define HPP_ROOM

#include <QtDeclarative>

class DoorData;
class Object;

class Room : public QObject {
    Q_OBJECT

    public:
        Room(const QString &id, const QString &name, float x, float y, float w, float h); 
        ~Room();

        // Properties:
        Q_PROPERTY(QString id READ getId CONSTANT)
        QString getId();

        Q_PROPERTY(QString name READ getName CONSTANT)
        QString getName();

        Q_PROPERTY(QPointF position READ getPosition CONSTANT)
        QPointF getPosition(); 

        Q_PROPERTY(QSizeF size READ getSize CONSTANT)
        QSizeF getSize();

        Q_PROPERTY(QDeclarativeListProperty<Object> objects READ getObjectsDeclarative CONSTANT)
        QDeclarativeListProperty<Object> getObjectsDeclarative(); 
        QList<Object*> getObjects();

        Q_PROPERTY(QDeclarativeListProperty<DoorData> doors READ getDoors CONSTANT)
        QDeclarativeListProperty<DoorData> getDoors(); 

        void addObject(Object *object);
        void addDoor(DoorData *door);

    private:
        QString _id, _name;
        QPointF _pos;
        QSizeF _size;
        QMap<QString, Object*> _objects;
        QList<DoorData*> _doors;
};

class DoorData : public QObject {
    Q_OBJECT
    Q_PROPERTY(QPointF position READ getPosition CONSTANT)
    Q_PROPERTY(QSizeF size READ getSize CONSTANT)
    Q_PROPERTY(int rotation READ getRotation CONSTANT)
    Q_PROPERTY(bool mirror READ getMirror CONSTANT)

    public:
        DoorData(double x, double y, int rotation = 0, bool mirror = false, double w = 0.75, double h = 0.75);

        QPointF getPosition();
        QSizeF getSize();
        int getRotation();
        bool getMirror();

    private:
        QPointF _pos;
        QSizeF _size;
        int _rotation;
        bool _mirror;
};
        

#endif
