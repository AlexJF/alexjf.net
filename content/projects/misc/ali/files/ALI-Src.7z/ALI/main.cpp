#include <QApplication>
#include <QtDeclarative>
#include <QDeclarativeView>
#include <QDeclarativeEngine>
#include "Building.hpp"
#include "Room.hpp"
#include "Object.hpp"
#include "Door.hpp"
#include "ObjectType.hpp"
#include "ObjectTypeManager.hpp"

int main(int argc, char *argv[]) {
    QApplication::setGraphicsSystem("raster");
    QApplication app(argc, argv);

    QDeclarativeView view;
    qmlRegisterType<Building>();
    qmlRegisterType<Room>();
    qmlRegisterType<DoorData>();
    qmlRegisterType<Object>();
    qmlRegisterType<ObjectType>();
    qmlRegisterType<Pair>();
    qmlRegisterType<Door>("Doors", 1, 0, "Door");

    Building *building = new Building();
    //Divisoes
    Room *bedroom1 = new Room("bed1", "Quarto 1", 0, 0, 3, 5);
    bedroom1->addDoor(new DoorData(2.25, 4));
    building->addRoom(bedroom1);
    Room *bedroom2 = new Room("bed2", "Quarto 2", 6, 0, 3, 5);
    bedroom2->addDoor(new DoorData(0, 4, 0, true));
    building->addRoom(bedroom2);
    Room *bath1 = new Room("bath1", "Casa de Banho", 3, 0, 3, 3);
    bath1->addDoor(new DoorData(0.25, 2.25, 90));
    building->addRoom(bath1);
    Room *hall = new Room("hall", "Hall", 3, 3, 3, 2);
    building->addRoom(hall);
    Room *living = new Room("living", "Sala de Estar", 0, 5, 6, 4);
    living->addDoor(new DoorData(5, 0, 0, true));
    living->addDoor(new DoorData(5, 3.25, 180));
    building->addRoom(living);
    Room *kitchen = new Room("kitchen", "Cozinha", 6, 5, 3, 4);
    kitchen->addDoor(new DoorData(0, 2, 0, true));
    building->addRoom(kitchen);

    ObjectTypeManager *manager = ObjectTypeManager::getInstance();
    
    //Tipos de objectos
    ObjectType *higieneProducts = new ObjectType("Produtos de Higiene");
    manager->addObjectType(higieneProducts);
    ObjectType *jewels = new ObjectType("Joalharia");
    manager->addObjectType(jewels);
    ObjectType *furniture = new ObjectType("Moveis");
    manager->addObjectType(furniture);
    ObjectType *textiles = new ObjectType("Texteis");
    manager->addObjectType(textiles);
    ObjectType *electronics = new ObjectType(QString::fromUtf8("Aparelhos Electrónicos"));
    manager->addObjectType(electronics);
    ObjectType *appliances = new ObjectType(QString::fromUtf8("Electrodomésticos"));
    manager->addObjectType(appliances);
    ObjectType *officeObjects = new ObjectType(QString::fromUtf8("Objectos de escritório"));
    manager->addObjectType(officeObjects);
    ObjectType *beautyProducts = new ObjectType("Produtos de Beleza");
    manager->addObjectType(beautyProducts);
    ObjectType *clothesAndAccessories = new ObjectType(QString::fromUtf8("Roupas e Acessórios"));
    manager->addObjectType(clothesAndAccessories);
    ObjectType *decorativeObjects = new ObjectType("Objectos Decorativos");
    manager->addObjectType(decorativeObjects);
    ObjectType *pocketObjects = new ObjectType("Objectos de bolso");
    manager->addObjectType(pocketObjects);
    ObjectType *food = new ObjectType("Alimentos");
    manager->addObjectType(food);
    ObjectType *fruit = new ObjectType("Fruta");
    manager->addObjectType(fruit);
    ObjectType *apples = new ObjectType(QString::fromUtf8("Maçãs"),5);
    manager->addObjectType(apples);
    ObjectType *bananas = new ObjectType("Bananas",4);
    manager->addObjectType(bananas);
    ObjectType *dairy = new ObjectType(QString::fromUtf8("Lacticínios"));
    manager->addObjectType(dairy);
    ObjectType *milk = new ObjectType("Leite",2);
    manager->addObjectType(milk);
    ObjectType *yogurts = new ObjectType("Iogurtes",8);
    manager->addObjectType(yogurts);
    ObjectType *eggs = new ObjectType("Ovos", 6);
    manager->addObjectType(eggs);
    ObjectType *carbohydrates = new ObjectType("Hidratos de Carbono");
    manager->addObjectType(carbohydrates);
    ObjectType *rice = new ObjectType("Arroz",4);
    manager->addObjectType(rice);
    ObjectType *bread = new ObjectType(QString::fromUtf8("Pão"),1);
    manager->addObjectType(bread);
    ObjectType *books = new ObjectType("Livros");
    manager->addObjectType(books);
    ObjectType *hams = new ObjectType("Presuntos",2);
    manager->addObjectType(hams);


    //Sub-tipos de objectos
    food->addSubType(fruit);
    food->addSubType(hams);
    fruit->addSubType(apples);
    fruit->addSubType(bananas);
    food->addSubType(dairy);
    dairy->addSubType(milk);
    dairy->addSubType(yogurts);
    dairy->addSubType(eggs);
    food->addSubType(carbohydrates);
    carbohydrates->addSubType(rice);
    carbohydrates->addSubType(bread);

    //Objectos
    
    //// Quarto 1
    /*Object *pearlNecklace = new Object("colar1", QString::fromUtf8("Colar Pérolas"), 2.5, 7.75, 0.5, 0.2);
    Object *watch = new Object("relogio1", QString::fromUtf8("RelÃ³gio prata"), 0, 0);*/
    Object *closet1 = new Object("armario1", QString::fromUtf8("Armário 1"), 0, 0, 0.4, 1);
    furniture->addObject(closet1);
    bedroom1->addObject(closet1);
    Object *singleBed = new Object("cama1", QString::fromUtf8("Cama individual"), 2, 0, 1, 2);
    furniture->addObject(singleBed);
    bedroom1->addObject(singleBed);
    Object *supportTable1 = new Object("mesaApoio1", QString::fromUtf8("Mesa de Apoio 1"), 0, 3.5, 0.5, 1.5);
    furniture->addObject(supportTable1);
    bedroom1->addObject(supportTable1);



    //// Quarto 2
    Object *closet2 = new Object("armario2", QString::fromUtf8("Armário 2"), 2, 0, 1, 0.4);
    furniture->addObject(closet2);
    bedroom2->addObject(closet2);
    Object *doubleBed = new Object("cama2", QString::fromUtf8("Cama dupla"), 1, 2.5, 2, 1.5);
    furniture->addObject(doubleBed);
    bedroom2->addObject(doubleBed);
    Object *supportTable2 = new Object("mesaApoio2", QString::fromUtf8("Mesa de Apoio 2"), 0, 0, 0.4, 1.5);
    furniture->addObject(supportTable2);
    bedroom2->addObject(supportTable2);
    Object *bedsideTable1 = new Object("mesaCabeceira1", QString::fromUtf8("Mesa de Cabeceira 1"), 2.7, 4, 0.3, 0.3);
    furniture->addObject(bedsideTable1);
    bedroom2->addObject(bedsideTable1);
    Object *bedsideTable2 = new Object("mesaCabeceira2", QString::fromUtf8("Mesa de Cabeceira 2"), 2.7, 2.2, 0.3, 0.3);
    furniture->addObject(bedsideTable2);
    bedroom2->addObject(bedsideTable2);
    Object *pencil = new Object("lapiseira", QString::fromUtf8("Lapiseira"), 0.1, 0.1, 0.1, 0.02, 2);
    officeObjects->addObject(pencil);
    pocketObjects->addObject(pencil);
    bedroom2->addObject(pencil);
    Object *calculator = new Object("calculadora", QString::fromUtf8("Calculadora"), 0.3, 0.02, 0.06, 0.1, 2);
    officeObjects->addObject(calculator);
    pocketObjects->addObject(calculator);
    bedroom2->addObject(calculator);

    //// Casa de Banho
	Object *jacuzzi = new Object("jacuzzi", QString::fromUtf8("Jacuzzi"), 0, 0, 1.2, 1.2);
	furniture->addObject(jacuzzi);
    bath1->addObject(jacuzzi);
    
    Object *lavatorio = new Object("lavatorio", QString::fromUtf8("Lavatorio"), 1.5, 0, 0.3, 0.25);
	furniture->addObject(lavatorio);
    bath1->addObject(lavatorio);
    
    Object *armario3 = new Object("armario3", QString::fromUtf8("Armário 3"), 2.6, 0, 0.4, 0.7);
    furniture->addObject(armario3);
    bath1->addObject(armario3);
    
    Object *pastaDeDentes = new Object("pasta", QString::fromUtf8("Pasta de Dentes"), 2.8, 0, 0.05, 0.1);
    higieneProducts->addObject(pastaDeDentes);
    bath1->addObject(pastaDeDentes);
    
    Object *escovaDeDentes = new Object("escovadentes", QString::fromUtf8("Escova de Dentes"), 2.7, 0.2, 0.1, 0.05);
    higieneProducts->addObject(escovaDeDentes);
    bath1->addObject(escovaDeDentes);
    
    Object *maquilhagem = new Object("maquilhagem", QString::fromUtf8("Maquilhagem"), 2.8, 0.5, 0.2, 0.2);
    beautyProducts->addObject(maquilhagem);
    bath1->addObject(maquilhagem);
    
    Object *escovaCabelo = new Object("escovacabelo", QString::fromUtf8("Escova de Cabelo"), 2.6, 0.4, 0.05, 0.1);
    beautyProducts->addObject(escovaCabelo);
    bath1->addObject(escovaCabelo);
    
    Object *balanca = new Object("balanca", QString::fromUtf8("Balança"), 2.7, 1.0, 0.3, 0.3);
    electronics->addObject(balanca);
    bath1->addObject(balanca);
    
    //// Hall
    Object *sapateira = new Object("sapateira", QString::fromUtf8("Sapateira"), 2.3, 0, 0.7, 0.25);
    furniture->addObject(sapateira);
    hall->addObject(sapateira);
    
    Object *vaso = new Object("vaso", QString::fromUtf8("Vaso"), 1.5, 1.8, 0.2, 0.2);
    furniture->addObject(vaso);
    hall->addObject(vaso);

    Object *supportTable3 = new Object("mesaApoio3", QString::fromUtf8("Mesa de Apoio 3"),0.7, 1.8, 0.5, 0.25);
    furniture->addObject(supportTable3);
    hall->addObject(supportTable3);
    
    Object *wallet = new Object("carteira", QString::fromUtf8("Carteira"), 0.9, 1.8, 0.1, 0.1,2);
    pocketObjects->addObject(wallet);
    hall->addObject(wallet);

    
    
    
    //// Sala
    Object *sofa = new Object("sofa", QString::fromUtf8("Sofá"), 2, 2.5, 0.75, 1.2);
    furniture->addObject(sofa);
    living->addObject(sofa);
    Object *armchair = new Object("poltrona", QString::fromUtf8("Poltrona"), 3, 3.5, 0.4, 0.4);
    furniture->addObject(armchair);
    living->addObject(armchair);
    Object *table = new Object("mesa", QString::fromUtf8("Mesa de Refeições"), 3, 0.5, 1.5, 1.5);
    furniture->addObject(table);
    living->addObject(table);
    Object *standingHanger = new Object("cabidePe", QString::fromUtf8("Cabide de Pe"), 5.8, 3.8, 0.2, 0.2);
    furniture->addObject(standingHanger);
    living->addObject(standingHanger);
    Object *tvTable1 = new Object("tvTable", QString::fromUtf8("Mesa TV1"), 0, 2.7, 0.4, 0.8);
    furniture->addObject(tvTable1);
    living->addObject(tvTable1);
    Object *tv1 = new Object("tv1", QString::fromUtf8("TV 1"), 0, 2.9, 0.1, 0.4);
    electronics->addObject(tv1);
    living->addObject(tv1);
    Object *bookShelf = new Object("bookshelf", QString::fromUtf8("Estante Livros"), 0, 0, 2, 0.3);
    furniture->addObject(bookShelf);
    living->addObject(bookShelf);
    Object *command1 = new Object("comandoTv", QString::fromUtf8("Comando TV 1"), 2.3, 2.8, 0.1, 0.04, 2);
    electronics->addObject(command1);
    pocketObjects->addObject(command1);
    living->addObject(command1);
    Object *book1 = new Object("livro1", QString::fromUtf8("Livro de História"), 0.4, 0.1, 0.05, 0.15, 2);
    books->addObject(book1);
    living->addObject(book1);
    Object *book2 = new Object("livro2", QString::fromUtf8("Livro de Ciências"), 0.8, 0.1, 0.05, 0.15, 2);
    books->addObject(book2);
    living->addObject(book2);
    Object *book3 = new Object("livro3", QString::fromUtf8("Agenda"), 0.1, 0.1, 0.1, 0.07, 2);
    books->addObject(book3);
    living->addObject(book3);



    //// Cozinha
    Object *fridge = new Object("frigorifico", QString::fromUtf8("Frigorifico"), 2.5, 0, 0.5, 0.5);
    appliances->addObject(fridge);
    kitchen->addObject(fridge);
    Object *washingMachine = new Object("maquinaRoupa", QString::fromUtf8("Maquina Lavar Roupa"), 2.5, 0, 0.5, 0.5);
    appliances->addObject(washingMachine);
    kitchen->addObject(washingMachine);
    Object *stove = new Object("fogao", QString::fromUtf8("Fogão"), 2.5, 3.5, 0.5, 0.5);
    appliances->addObject(stove);
    kitchen->addObject(stove);
    Object *kitchenTable = new Object("kitchenTable", QString::fromUtf8("Mesa de Cozinha"), 0.5, 2.7, 1, 1);
    furniture->addObject(kitchenTable);
    kitchen->addObject(kitchenTable);
    Object *fruitBasket = new Object("fruitBasket", QString::fromUtf8("Cesto de Frutas"), 0.9, 2.9, 0.2, 0.2, 2);
    decorativeObjects->addObject(fruitBasket);
    kitchen->addObject(fruitBasket);
    Object *apple1 = new Object("maca1", QString::fromUtf8("Maçã 1"), 0.91, 3, 0.06, 0.06, 3);
    apples->addObject(apple1);
    kitchen->addObject(apple1);
    Object *apple2 = new Object("maca2", QString::fromUtf8("Maçã 2"), 1, 2.9, 0.06, 0.06, 3);
    apples->addObject(apple2);
    kitchen->addObject(apple2);
    Object *banana1 = new Object("banana1", QString::fromUtf8("Banana 1"), 0.93, 3.05, 0.1, 0.04, 3);
    bananas->addObject(banana1);
    kitchen->addObject(banana1);
    Object *milk1 = new Object("leite1", QString::fromUtf8("Leite 1"), 2.7, 0.25, 0.07, 0.07, -1);
    milk->addObject(milk1);
    kitchen->addObject(milk1);
    Object *milk2 = new Object("leite2", QString::fromUtf8("Leite 2"), 2.7, 0.25, 0.07, 0.07, -1);
    milk->addObject(milk2);
    kitchen->addObject(milk2);
    Object *milk3 = new Object("leite3", QString::fromUtf8("Leite 3"), 2.7, 0.25, 0.07, 0.07, -1);
    milk->addObject(milk3);
    kitchen->addObject(milk3);
    Object *yogurt1 = new Object("iogurte1", QString::fromUtf8("Iogurte 1"), 2.7, 0.25, 0.07, 0.07, -1);
    yogurts->addObject(yogurt1);
    kitchen->addObject(yogurt1);
    Object *egg1 = new Object("ovo1", QString::fromUtf8("Ovo 1"), 2.7, 0.25, 0.07, 0.07, -1);
    eggs->addObject(egg1);
    kitchen->addObject(egg1);
    Object *egg2 = new Object("ovo2", QString::fromUtf8("Ovo 2"), 2.7, 0.25, 0.07, 0.07, -1);
    eggs->addObject(egg2);
    kitchen->addObject(egg2);
    Object *egg3 = new Object("ovo3", QString::fromUtf8("Ovo 3"), 2.7, 0.25, 0.07, 0.07, -1);
    eggs->addObject(egg3);
    kitchen->addObject(egg3);
    /*Object *egg4 = new Object("ovo4", QString::fromUtf8("Ovo 4"), 2.7, 0.25, 0.07, 0.07, -1);
    eggs->addObject(egg4);
    kitchen->addObject(egg4);
    Object *egg5 = new Object("ovo5", QString::fromUtf8("Ovo 5"), 2.7, 0.25, 0.07, 0.07, -1);
    eggs->addObject(egg5);
    kitchen->addObject(egg5);
    Object *egg6 = new Object("ovo6", QString::fromUtf8("Ovo 6"), 2.7, 0.25, 0.07, 0.07, -1);
    eggs->addObject(egg6);
    kitchen->addObject(egg6);
    Object *egg7 = new Object("ovo7", QString::fromUtf8("Ovo 7"), 2.7, 0.25, 0.07, 0.07, -1);
    eggs->addObject(egg7);
    kitchen->addObject(egg7);*/
    //Object *rice1 = new Object("arroz1", QString::fromUtf8("Arroz 1"), 0, 0);
    Object *bread1 = new Object("pao1", QString::fromUtf8("Pão 1"), 0.6, 3.2, 0.1, 0.1, 2);
    bread->addObject(bread1);
    kitchen->addObject(bread1);
    Object *bread2 = new Object("pao2", QString::fromUtf8("Pão 2"), 0.7, 3.2, 0.1, 0.1, 2);
    bread->addObject(bread2);
    kitchen->addObject(bread2);
    Object *bread3 = new Object("pao2", QString::fromUtf8("Pão 3"), 0.8, 3.2, 0.1, 0.1, 2);
    bread->addObject(bread3);
    kitchen->addObject(bread3);
    Object *smokedHam = new Object("presunto1", QString::fromUtf8("Presunto 1"), 0.8, 3.4, 0.15, 0.1, 1);
    hams->addObject(smokedHam);
    kitchen->addObject(smokedHam);
    /*Object *rawHam = new Object("presunto2", QString::fromUtf8("Presunto 2"), 1.2, 3.4, 0.15, 0.1, 1);
    hams->addObject(rawHam);
    kitchen->addObject(rawHam);*/
    
	Object *keys = new Object("chaves", QString::fromUtf8("Chaves de Casa"), 0, 0);
    pocketObjects->addObject(keys);
	
	Object *notebook = new Object("pcPortatil", QString::fromUtf8("Portátil Toshiba"), 0, 0);
    officeObjects->addObject(notebook);

    //Entradas e saidas de objectos
    building->addInOut(new Pair (wallet, QDateTime::fromString("16/11/2011 12:10", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (pencil, QDateTime::fromString("15/11/2011 12:26", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (jacuzzi, QDateTime::fromString("15/11/2011 09:11", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (table, QDateTime::fromString("14/11/2011 14:35", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (stove, QDateTime::fromString("13/11/2011 14:35", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (book3, QDateTime::fromString("13/11/2011 14:30", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (bookShelf, QDateTime::fromString("13/11/2011 14:29", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (balanca, QDateTime::fromString("11/11/2011 15:00", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (pastaDeDentes, QDateTime::fromString("11/11/2011 12:00", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (notebook, QDateTime::fromString("11/11/2011 08:10", "dd/MM/yyyy hh:mm"), QString("out")));
	building->addInOut(new Pair (wallet, QDateTime::fromString("07/11/2011 08:10", "dd/MM/yyyy hh:mm"), QString("out")));
	building->addInOut(new Pair (calculator, QDateTime::fromString("06/11/2011 18:10", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (keys, QDateTime::fromString("05/11/2011 08:40", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (keys, QDateTime::fromString("04/11/2011 21:48", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (keys, QDateTime::fromString("04/11/2011 20:20", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (keys, QDateTime::fromString("04/11/2011 18:22", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (keys, QDateTime::fromString("04/11/2011 12:30", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (keys, QDateTime::fromString("04/11/2011 08:55", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (keys, QDateTime::fromString("04/11/2011 08:43", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (keys, QDateTime::fromString("03/11/2011 18:50", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (keys, QDateTime::fromString("03/11/2011 08:35", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (keys, QDateTime::fromString("02/11/2011 19:02", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (keys, QDateTime::fromString("02/11/2011 08:38", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (keys, QDateTime::fromString("01/11/2011 18:36", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (keys, QDateTime::fromString("01/11/2011 08:30", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (keys, QDateTime::fromString("30/10/2011 18:42", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (keys, QDateTime::fromString("30/10/2011 08:23", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (bread2, QDateTime::fromString("03/11/2011 10:25", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (bread3, QDateTime::fromString("29/10/2011 10:20", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (sofa, QDateTime::fromString("10/12/2010 20:00", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (wallet, QDateTime::fromString("07/11/2010 19:20", "dd/MM/yyyy hh:mm"), QString("in")));

    building->addInOut(new Pair (command1, QDateTime::fromString("23/10/2011 18:50", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (command1, QDateTime::fromString("12/08/2011 14:10", "dd/MM/yyyy hh:mm"), QString("out")));
    building->addInOut(new Pair (command1, QDateTime::fromString("02/03/2011 12:20", "dd/MM/yyyy hh:mm"), QString("in")));
    building->addInOut(new Pair (command1, QDateTime::fromString("01/10/2010 08:30", "dd/MM/yyyy hh:mm"), QString("out")));


    //Object *bureau = new Object("comoda", QString::fromUtf8("Cómoda"), 2, 7.25, 2, 0.75);
    //Object *tv2 = new Object("tv2", QString::fromUtf8("TV 2"), 0, 0);
    //Object *mp3 = new Object("mp3", QString::fromUtf8("Mp3"), 0, 0);
    //Object *command2 = new Object("comandoTv", QString::fromUtf8("Comando TV 2"), 0, 0);
    /*
    Object *cd = new Object("cd", QString::fromUtf8("CD Jazz"), 0, 0);   
    Object *perfume1 = new Object("perfume1", QString::fromUtf8("Perfume Dior"), 0, 0);
    Object *perfume2 = new Object("perfume2", QString::fromUtf8("Perfume Gucci"), 0.25, 2.2, 0.25, 0.25);
    Object *showerGel = new Object("gelBanho", QString::fromUtf8("Gel de Banho"), 0, 0);
    Object *baton1 = new Object("baton1", QString::fromUtf8("Baton Vermelho"), 0, 0);
    Object *baton2 = new Object("baton2", QString::fromUtf8("Baton Rosa"), 0.3, 3.5, 0.1, 0.1);
    Object *toothbrush1 = new Object("escovaDentes1", QString::fromUtf8("Escova de dentes azul"), 0, 0);
    Object *toothbrush2 = new Object("escovaDentes2", QString::fromUtf8("Escova de dentes verde"), 0, 0);
    Object *hairbrush = new Object("escovaCabelo", QString::fromUtf8("Escova de cabelo"), 0, 0);
    Object *towel1 = new Object("toalha1", QString::fromUtf8("Toalha de banho 1"), 0, 0);
    Object *towel2 = new Object("toalha2", QString::fromUtf8("Toalha de banho 2"), 0, 0);
    Object *blanket = new Object("manta", QString::fromUtf8("Manta polar"),0,0);
    Object *quilt = new Object("colcha", QString::fromUtf8("Colcha"),4, 2.5, 2, 3 );
    Object *pad1 = new Object("almofada1", QString::fromUtf8("Almofada 1"),6.25, 3, 0.5, 0.75);
    Object *pad2 = new Object("almofada2", QString::fromUtf8("Almofada 2"),6.25, 4.25, 0.5, 0.75);
    Object *curtains1 = new Object("cortinas", QString::fromUtf8("Cortinas Sala"), 0, 0);
    Object *curtains2 = new Object("cortinas", QString::fromUtf8("Cortinas Sala"), 0, 0);
    Object *carpet1 = new Object("tapete1", QString::fromUtf8("Tapete 1"), 0, 0);
    Object *carpet2 = new Object("tapete2", QString::fromUtf8("Tapete 2"), 0, 0);
    Object *carpet3 = new Object("tapete3", QString::fromUtf8("Tapete 3"), 1, 2, 2, 4);
    Object *coat = new Object("casaco", QString::fromUtf8("Casaco de Pele"), 0, 0);
    Object *shoes = new Object("sapatos", QString::fromUtf8("Sapatos de camurÃ§a"), 0, 0);
    Object *handBag = new Object("mala", QString::fromUtf8("Mala Preta"), 5.5, 6.75, 0.4, 0.6);
    Object *belt = new Object("cinto", QString::fromUtf8("Cinto de Couro"), 3.5, 4.5 , 0.25, 0.5);
    Object *mirror = new Object("espelho", QString::fromUtf8("Espelho dourado"), 0, 0);
    Object *frame = new Object("moldura", QString::fromUtf8("Molura"), 0, 0);
    Object *vessel = new Object("vaso", QString::fromUtf8("Vaso"), 0, 0);
    Object *lamp1 = new Object("candeeiro1", QString::fromUtf8("Candeeiro 1"), 0, 0);
    Object *lamp2 = new Object("candeeiro1", QString::fromUtf8("Candeeiro 2"), 0, 0);
    Object *lamp3 = new Object("candeeiro1", QString::fromUtf8("Candeeiro 3"), 0, 0);
    Object *StandingLamp = new Object("candeeiroPe", QString::fromUtf8("CandeeiroPe"), 0, 0);*/


    view.rootContext()->setContextProperty("buildingData", building);
    view.rootContext()->setContextProperty("objTypeManager", manager);
    view.setSource(QUrl("qrc:/main.qml"));
    view.show();
    int exitCode = app.exec();

    delete building;

    return exitCode;
}
