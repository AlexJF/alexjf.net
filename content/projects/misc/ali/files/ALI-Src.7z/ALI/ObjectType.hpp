#ifndef HPP_OBJECTTYPE
#define HPP_OBJECTTYPE

#include <QtDeclarative>
#include "Object.hpp"

class ObjectType : public QObject {
    Q_OBJECT

    public:
        ObjectType(const QString &name, int threshold = 0); 
        virtual ~ObjectType();

        // Properties:
        Q_PROPERTY(QString name READ getName CONSTANT)
        QString getName();

        Q_PROPERTY(int threshold READ getThreshold CONSTANT)
        int getThreshold(); 

        Q_PROPERTY(int quantity READ getQuantity CONSTANT)
        int getQuantity();

        Q_PROPERTY(int diff READ getDiff CONSTANT)
        int getDiff();

        Q_PROPERTY(QDeclarativeListProperty<Object> objects READ getObjectsDeclarative CONSTANT)
        QDeclarativeListProperty<Object> getObjectsDeclarative();
        QList<Object*> getObjects();
		
        Q_PROPERTY(QDeclarativeListProperty<ObjectType> subTypes READ getSubTypes CONSTANT)
        QDeclarativeListProperty<ObjectType> getSubTypes(); 

        void addObject(Object *object);
        void addSubType(ObjectType *subType);

        ObjectType* getParent();

    private:
        bool setParent(ObjectType *parent);

        QString _name;
        int _threshold;
        ObjectType *_parent;
		QMap<QString, Object*> _objects;
		QMap<QString, ObjectType*> _subTypes;
};

#endif
 
