#ifndef HPP_BUILDING
#define HPP_BUILDING

#include <QtDeclarative>

class Room;
class Object;

class Pair : QObject {
	Q_OBJECT
    
    public:
		Pair(Object*, const QDateTime &date, QString string);
		Q_PROPERTY(Object* object READ getObject CONSTANT)
		Q_PROPERTY(QDateTime date READ getDate CONSTANT)
		Q_PROPERTY(QString inOut READ getInOut CONSTANT)
		Q_PROPERTY(QString toStringDate READ toString CONSTANT)
		
		Object* getObject();
		QDateTime getDate();
		QString getInOut();
		QString toString();
	private: 
		Object* _object;
		QDateTime _date;
		QString _inOut;
};


class Building : public QObject {
    Q_OBJECT

    public:
        Building();
        virtual ~Building();

        Q_PROPERTY(QDeclarativeListProperty<Room> rooms READ getRooms CONSTANT)
        QDeclarativeListProperty<Room> getRooms(); 

        Q_PROPERTY(QSizeF totalSize READ getTotalSize CONSTANT)
        QSizeF getTotalSize();

        void addRoom(Room *room);
        Q_INVOKABLE Room* getRoomByName(const QString &name);

	//Q_INVOKABLE QDeclarativeListProperty<Object> findObject(const QString &objectName, const QString &typeObjectName, const QString &roomName);
	Q_INVOKABLE void filterObjects(const QString &objectName, const QString &typeObjectName, const QString &roomName);
	
        Q_INVOKABLE void filterInOutObjects(const QString &objectName, const QString &typeObjectName, const QString &roomName, const QString &objectBeginDate, const QString &objectBeginHour, const QString &objectEndDate, const QString &objectEndHour,bool objectOnlyIn,bool objectOnlyOut);

        Q_PROPERTY(QDeclarativeListProperty<Object> filteredObjects READ getFilteredObjects CONSTANT)
        QDeclarativeListProperty<Object> getFilteredObjects();
        
        Q_PROPERTY(QDeclarativeListProperty<Pair> filteredInOutObjects READ getFilteredInOutObjects CONSTANT)
        QDeclarativeListProperty<Pair> getFilteredInOutObjects();
		
	Q_PROPERTY(QDeclarativeListProperty<Pair> inOutsObjects READ getInOutsObjects CONSTANT)
	QDeclarativeListProperty<Pair> getInOutsObjects();

    Q_INVOKABLE bool objectExists(const QString &objname);
	
	void addInOut(Pair*);
    
	private:
        QList<Object*> getObjects();
        bool objectInList(const QList<Object*> &list,Object *obj);
		void filterObjectByRoom(const QString &roomName);
		void filterObjectByType(const QString &typeObjectName);
		void filterObjectByName(const QString &objectName);
		void filterInOutsObjectByRoom(const QString &roomName);
		void filterInOutsObjectByType(const QString &typeObjectName);
		void filterInOutsObjectByName(const QString &objectName);
		void filterInOutsObjectByBeginDateTime(const QString &objectDate, const QString &objectHour);
		void filterInOutsObjectByEndDateTime(const QString &objectDate, const QString &objectHour);
                void filterInOutsObjectByOnlyIn(bool objectOnlyIn);
                void filterInOutsObjectByOnlyOut(bool objectOnlyOut);

        QMap<QString, Room*> _rooms;
       	QList<Pair*> _inOutsObjects; 
       	QList<Pair*> _filteredInOutObjects;
        QList<Object*> _filteredObjects;
        QSizeF _totalSize;
};

#endif
