#include "ObjectType.hpp"
#include "ObjectTypeManager.hpp"

void objectsAppend(QDeclarativeListProperty<Object>* prop, Object* value);
int objectsCount(QDeclarativeListProperty<Object>* prop);
Object* objectsAt(QDeclarativeListProperty<Object>* prop, int index);

void objectTypesAppend(QDeclarativeListProperty<ObjectType>* prop, ObjectType* value) {
     Q_UNUSED(prop);
     Q_UNUSED(value);
     return; //Append not supported
}

int objectTypesCount(QDeclarativeListProperty<ObjectType>* prop) {
    return static_cast<QMap<QString, ObjectType*>*>(prop->data)->count();
}

ObjectType* objectTypesAt(QDeclarativeListProperty<ObjectType>* prop, int index) {
    return static_cast<QMap<QString, ObjectType*>*>(prop->data)->values().at(index);
}

ObjectType::ObjectType(const QString &name, int threshold) : 
    _name(name), _threshold(threshold), _parent(NULL) {
}

ObjectType::~ObjectType() {
    QMap<QString, Object*>::iterator it_obj;

    for (it_obj = _objects.begin(); it_obj != _objects.end(); ++it_obj) {
        it_obj.value()->disassociateWithType(this);
    }

    _objects.clear();
    qDeleteAll(_subTypes);
    _subTypes.clear();
}

QString ObjectType::getName() {
    return _name;
}

int ObjectType::getThreshold() {
    return _threshold;
}

QDeclarativeListProperty<Object> ObjectType::getObjectsDeclarative() {
	return QDeclarativeListProperty<Object>(this, &_objects, objectsAppend, objectsCount, objectsAt); 
}

QList<Object*> ObjectType::getObjects() {
    return _objects.values();
}

QDeclarativeListProperty<ObjectType> ObjectType::getSubTypes() {
	return QDeclarativeListProperty<ObjectType>(this, &_subTypes, objectTypesAppend, objectTypesCount, objectTypesAt); 
}

void ObjectType::addObject(Object *object) {
    if (object == NULL) {
        return;
    }

    _objects.insert(object->getName(), object);

    if (_parent != NULL) {
        _parent->addObject(object);
    }

    object->associateWithType(this);
}

void ObjectType::addSubType(ObjectType *subType) {
    if (subType == NULL) {
        return;
    }
    
    if (subType->setParent(this)) {
        _subTypes.insert(subType->getName(), subType);
    }
}

bool ObjectType::setParent(ObjectType *parent) {
    if (_parent != NULL) return false;
    _parent = parent;
    return true;
}

ObjectType* ObjectType::getParent() {
    return _parent;
}

int ObjectType::getQuantity() {
    return _objects.count();
}

int ObjectType::getDiff() {
    return getQuantity() - getThreshold();
}
