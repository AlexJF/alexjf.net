var currentFocusedObject = null;
var allObjects = Array();
var zoomToObject = false;
var firstZoom = true;

function parseAllObjects() {
    allObjects = Array();
    var rooms = building.getRooms();

    for (var i = 0; i < rooms.length; i++) {
        var room = rooms[i];

        if (room.objectName != "Room") continue;

        var objects = room.getObjects();

        for (var j = 0; j < objects.length; j++) {
            var object = objects[j];

            if (object.objectName != "Object") continue;
            allObjects.push(object);
        }
    }
}

function findObjectByName(objName) {
    for (var i = 0; i < allObjects.length; i++) {
        var object = allObjects[i];

        if (object.name == objName) {
            return object;
        }
    }

    return null;
}

function resetFocus() {
    if (currentFocusedObject != null) {
        currentFocusedObject.highlighted = false;
    }
    currentFocusedObject = null;
    highlight.visible = false;
}

function focusObjectByName(objName) {
    if (objName == "") {
        resetFocus();
    }

    var obj = findObjectByName(objName);
    
    if (obj == null) {
        resetFocus();
    }

    focusObject(obj);
}

function focusObject(obj) {
    movementAnims.stop();
    highlight.visible = false;
    var animateMovement = false;

    if (obj != null) {
        zoomToObject = true;
        firstZoom = true;

        if (currentFocusedObject != null) {
            currentFocusedObject.xChanged.disconnect();
            currentFocusedObject.yChanged.disconnect();
            currentFocusedObject.widthChanged.disconnect();
            currentFocusedObject.heightChanged.disconnect();
        } 

        currentFocusedObject = obj;
        obj.highlighted = true;
        currentFocusedObject.xChanged.connect(focusObject);
        currentFocusedObject.yChanged.connect(focusObject);
        currentFocusedObject.widthChanged.connect(focusObject);
        currentFocusedObject.heightChanged.connect(focusObject);

        animateMovement = true;
    } 

    if (currentFocusedObject != null) {
        var objPosition = building.mapFromItem(currentFocusedObject, 0, 0);
        highlight.x = objPosition.x + wrapper.x;
        highlight.y = objPosition.y + wrapper.y;
        highlight.width = currentFocusedObject.width;
        highlight.height = currentFocusedObject.height;
        highlight.visible = true;


        /*if (firstZoom) {
            if (map.zoomLevel != 3) {
                map.zoomLevel = 3;
            } else {
                animateMovement = true;
            }
            firstZoom = false;
        } */

        if (zoomToObject) {
            var contentX = Math.max(0, Math.min(highlight.x + highlight.width / 2 - map.width / 2, map.contentWidth - map.width));
            var contentY = Math.max(0, Math.min(highlight.y + highlight.height / 2 - map.height / 2, map.contentHeight - map.height));

            if (animateMovement) {
                movementXAnim.to = contentX;
                movementYAnim.to = contentY;
                movementAnims.start();
            } else {
                map.contentX = contentX;
                map.contentY = contentY;
            }
        } 

    }
}

function zoomIn() {
    if (map.zoomLevel < map.maxZoomLevel) {
        map.zoomLevel++;
    }
}

function zoomOut() {
    if (map.zoomLevel > 1) {
        map.zoomLevel--;
    }
}

function onFlickStarted() {
    zoomToObject = false;
}
