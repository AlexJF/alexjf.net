#ifndef HPP_OBJECT
#define HPP_OBJECT

#include <QtDeclarative>
#include "Object.hpp"

class ObjectType;
class Room;

class Object : public QObject {
    Q_OBJECT

    friend class ObjectType;

    public:
        Object(const QString &id, const QString &name, float x, float y, float w = 0, float h = 0, int z = 1); 

        // Properties:
        Q_PROPERTY(QString id READ getId CONSTANT)
        QString getId();

        Q_PROPERTY(QString name READ getName WRITE setName NOTIFY nameChanged)
        QString getName();
        void setName(const QString &name);

        Q_PROPERTY(Room* room READ getRoom CONSTANT)
		Room* getRoom();

        Q_PROPERTY(QPointF position READ getPosition CONSTANT)
        QPointF getPosition(); 

        Q_PROPERTY(QSizeF size READ getSize CONSTANT)
        QSizeF getSize();

        Q_PROPERTY(int z READ getZ CONSTANT)
        int getZ();

        Q_PROPERTY(QDeclarativeListProperty<ObjectType> associatedTypes READ getAssociatedTypes CONSTANT)
        QDeclarativeListProperty<ObjectType> getAssociatedTypes();

        bool isOfType(const QString &typeName);

		void associateWithRoom(Room *room);
		void disassociateWithRoom();

    signals:
        void nameChanged();
		
	private:
        void associateWithType(ObjectType *type);
        void disassociateWithType(ObjectType *type);
        void updateAllTypes();

        QString _id, _name;
        QPointF _pos;
        QSizeF _size;
        int _z;
        QMap<QString, ObjectType*> _types;
        QMap<QString, ObjectType*> _allTypes;
		Room* _room;
};

#endif
