#include "Room.hpp"
#include "Object.hpp"

void objectsAppend(QDeclarativeListProperty<Object>* prop, Object* value) {
     Q_UNUSED(prop);
     Q_UNUSED(value);
     return; //Append not supported
}

int objectsCount(QDeclarativeListProperty<Object>* prop) {
    return static_cast<QMap<QString, Object*>*>(prop->data)->count();
}

Object* objectsAt(QDeclarativeListProperty<Object>* prop, int index) {
    return static_cast<QMap<QString, Object*>*>(prop->data)->values().at(index);
}

Room::Room(const QString &id, const QString &name, float x, float y, float w, float h) : _id(id), _name(name), _pos(x, y), _size(w, h) {
}

Room::~Room() {
    qDeleteAll(_objects);
    _objects.clear();
    qDeleteAll(_doors);
    _doors.clear();
}

QString Room::getId() {
    return _id;
}

QString Room::getName() {
    return _name;
}

QPointF Room::getPosition() { 
    return _pos; 
}

QSizeF Room::getSize() {
    return _size;
}

QDeclarativeListProperty<Object> Room::getObjectsDeclarative() { 
    return QDeclarativeListProperty<Object>(this, &_objects, objectsAppend, objectsCount, objectsAt); 
}

QList<Object*> Room::getObjects() {
    return _objects.values();
}

QDeclarativeListProperty<DoorData> Room::getDoors() { 
    return QDeclarativeListProperty<DoorData>(this, _doors); 
}

void Room::addObject(Object *object) {
    if (object == NULL) {
        return;
    }

    _objects.insert(object->getName(), object);

    object->associateWithRoom(this);
}

void Room::addDoor(DoorData *door) {
    if (door == NULL) {
        return;
    }

    _doors.append(door);
}

DoorData::DoorData(double x, double y, int rotation, bool mirror, double w, double h) : 
    _pos(x, y), _size(w, h), _rotation(rotation), _mirror(mirror) {
}

QPointF DoorData::getPosition() {
    return _pos;
}

QSizeF DoorData::getSize() {
    return _size;
}

int DoorData::getRotation() {
    return _rotation;
}

bool DoorData::getMirror() {
    return _mirror;
}
