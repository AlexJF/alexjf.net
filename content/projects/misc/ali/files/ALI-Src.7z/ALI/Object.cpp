#include "Object.hpp"
#include "ObjectType.hpp"

Object::Object(const QString &id, const QString &name, float x, float y, float w, float h, int z) : 
    _id(id), _name(name), _pos(x, y), _size(w, h), _z(z) {
}

QString Object::getId() {
    return _id;
}

QString Object::getName() {
    return _name;
}

Room* Object::getRoom() {
	return _room;
}

QPointF Object::getPosition() { 
    return _pos; 
}

QSizeF Object::getSize() {
    return _size;
}

int Object::getZ() {
    return _z;
}

void Object::associateWithType(ObjectType *type) {
    if (type != NULL) {
        _types.insert(type->getName(), type);
        updateAllTypes();
    }
}

void Object::associateWithRoom(Room *room) {
	if (room != NULL) {
		_room = room;	
	}
}

void Object::disassociateWithRoom() {
	_room = NULL;
}

void Object::disassociateWithType(ObjectType *type) {
    if (type != NULL) {
        _types.remove(type->getName());
        updateAllTypes();
    }
}

void Object::updateAllTypes() {
    _allTypes.clear();
    QList<ObjectType*> types = _types.values();

    for (int i = 0; i < types.count(); ++i) {
        ObjectType *type = types[i];
        _allTypes.insert(type->getName(), type);

        ObjectType *parent = type;

        while ((parent = parent->getParent())) {
            _allTypes.insert(parent->getName(), parent);
        }
    }
}

bool Object::isOfType(const QString &typeName) {
    return _types.contains(typeName);
}

void objectTypeAppend(QDeclarativeListProperty<ObjectType>* prop, ObjectType* value) {
     Q_UNUSED(prop);
     Q_UNUSED(value);
     return; //Append not supported
}

int objectTypeCount(QDeclarativeListProperty<ObjectType>* prop) {
    return static_cast<QMap<QString, ObjectType*>*>(prop->data)->count();
}

ObjectType* objectTypeAt(QDeclarativeListProperty<ObjectType>* prop, int index) {
    return static_cast<QMap<QString, ObjectType*>*>(prop->data)->values().at(index);
}

QDeclarativeListProperty<ObjectType> Object::getAssociatedTypes() {
    return QDeclarativeListProperty<ObjectType>(this, &_allTypes, objectTypeAppend, objectTypeCount, objectTypeAt);
}

void Object::setName(const QString &name) {
    _name = name;
    emit nameChanged();
}
