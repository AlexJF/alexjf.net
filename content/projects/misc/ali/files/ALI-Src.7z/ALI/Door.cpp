#include "Door.hpp"
#include <QPainter>

Door::Door(QDeclarativeItem *parent) : QDeclarativeItem(parent),
    _thickness(1), _color("#000000"), _mirror(false) {
    setFlag(QGraphicsItem::ItemHasNoContents, false);
}

void Door::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
    QPen pen(_color, _thickness);
    painter->setPen(pen);
    painter->setRenderHints(QPainter::Antialiasing, true);

    QRectF rect = boundingRect();

    QPainterPath path;

    if (_mirror) {
        path.moveTo(0, 0);
        path.lineTo(rect.width(), 0);
        path.quadTo(QPointF(rect.width(), rect.height()), QPointF(0, rect.height()));
    } else {
        path.moveTo(rect.width(), 0);
        path.lineTo(0, 0);
        path.quadTo(QPointF(0, rect.height()), QPointF(rect.width(), rect.height()));
    }

    path.closeSubpath();
    
    painter->drawPath(path);
}

int Door::getThickness() const {
    return _thickness;
}

void Door::setThickness(const int thickness) {
    _thickness = thickness;
}

QColor Door::getColor() const {
    return _color;
}

void Door::setColor(const QColor &color) {
    _color = color;
}

bool Door::getMirror() const {
    return _mirror;
}

void Door::setMirror(bool mirror) {
    _mirror = mirror;
}
