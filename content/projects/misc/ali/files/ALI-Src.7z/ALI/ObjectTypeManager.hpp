#ifndef HPP_OBJECTTYPEMANAGER
#define HPP_OBJECTTYPEMANAGER

#include <QtDeclarative>
#include "ObjectType.hpp"
#include "Object.hpp"

class ObjectTypeManager : public QObject {
    Q_OBJECT

	public:
		virtual ~ObjectTypeManager();
		
		static ObjectTypeManager* getInstance();
		
		void addObjectType(ObjectType *typeObject);
                QList<ObjectType*> searchObjectTypes(const QString &name);
		
		ObjectType* getObjectTypeByName(const QString &name);

                Q_INVOKABLE void filterObjectTypes(const QString &typeObjectName);

        Q_PROPERTY(QDeclarativeListProperty<ObjectType> typesWithThreshold READ getTypesWithThreshold CONSTANT)
        QDeclarativeListProperty<ObjectType> getTypesWithThreshold();

        Q_PROPERTY(QDeclarativeListProperty<ObjectType> filteredObjectTypes READ getFilteredObjectTypes CONSTANT)
        QDeclarativeListProperty<ObjectType> getFilteredObjectTypes();

		
    private:
        ObjectTypeManager(); 
        void updateTypesWithThreshold();

        static ObjectTypeManager *_instance;
        QMap<QString, ObjectType*> _objectTypes;
        QList<ObjectType*> _typesWithThreshold;
        QList<ObjectType*> _filteredObjectTypes;
};

#endif
 
