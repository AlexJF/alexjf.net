#ifndef HPP_DOOR
#define HPP_DOOR

#include <QDeclarativeItem>

class Door : public QDeclarativeItem {
    Q_OBJECT
    Q_PROPERTY(QColor color READ getColor WRITE setColor NOTIFY colorChanged);
    Q_PROPERTY(int thickness READ getThickness WRITE setThickness NOTIFY thicknessChanged);
    Q_PROPERTY(bool mirror READ getMirror WRITE setMirror NOTIFY mirrorChanged);

    signals:
        void colorChanged();
        void thicknessChanged();
        void mirrorChanged();

    public:
        Door(QDeclarativeItem *parent = NULL); 

        QColor getColor() const;
        void setColor(const QColor &color);

        int getThickness() const;
        void setThickness(const int thickness);

        bool getMirror() const;
        void setMirror(bool mirror);

        void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = 0);

    private:
        int _thickness;
        QColor _color;
        bool _mirror;
};

#endif
