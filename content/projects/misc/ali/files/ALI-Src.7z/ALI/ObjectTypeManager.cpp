#include "ObjectTypeManager.hpp"
#include "ObjectType.hpp"

ObjectTypeManager* ObjectTypeManager::_instance = NULL;

ObjectTypeManager::ObjectTypeManager() {
}

ObjectTypeManager::~ObjectTypeManager() {
    qDeleteAll(_objectTypes);
    qDeleteAll(_filteredObjectTypes);
    _filteredObjectTypes.clear();
    _objectTypes.clear();
}

ObjectTypeManager* ObjectTypeManager::getInstance(){

	if (!_instance) {
        _instance = new ObjectTypeManager();
    }

	return _instance;
}

ObjectType* ObjectTypeManager::getObjectTypeByName(const QString &name) {
    return _objectTypes.value(name, NULL);
}

QList<ObjectType*> ObjectTypeManager::searchObjectTypes(const QString &name) {
    QMap<QString, ObjectType*>::iterator it;
    QList<ObjectType*> results;

    for (it = _objectTypes.begin(); it != _objectTypes.end(); it++) {
        ObjectType *objectType = it.value();

        if (objectType->getName().contains(name, Qt::CaseInsensitive)) {
            results.append(objectType);
        }
    }

    return results;
}

void ObjectTypeManager::addObjectType(ObjectType *typeObject) {
    if (typeObject == NULL) {
        return;
    }

    _objectTypes.insert(typeObject->getName(), typeObject);
}

QDeclarativeListProperty<ObjectType> ObjectTypeManager::getTypesWithThreshold() {
    updateTypesWithThreshold();
    return QDeclarativeListProperty<ObjectType>(this, _typesWithThreshold);
}

void ObjectTypeManager::updateTypesWithThreshold() {
    _typesWithThreshold.clear();
    QList<ObjectType*> objTypes = _objectTypes.values();

    for (int i = 0; i < objTypes.count(); i++) {
        if (objTypes[i]->getDiff() < 0 && objTypes[i]->getThreshold() > 0) {
            _typesWithThreshold.append(objTypes[i]);
        }
    }

    for (int i = 0; i < objTypes.count(); i++) {
        if (objTypes[i]->getDiff() >= 0 && objTypes[i]->getThreshold() > 0) {
            _typesWithThreshold.append(objTypes[i]);
        }
    }
}


QDeclarativeListProperty<ObjectType> ObjectTypeManager::getFilteredObjectTypes() {
    return QDeclarativeListProperty<ObjectType>(this,_filteredObjectTypes);
}

void ObjectTypeManager::filterObjectTypes(const QString &objectTypeName) {

    _filteredObjectTypes=_typesWithThreshold;

    if (objectTypeName != "") {

    for (int i = _filteredObjectTypes.count() - 1; i >= 0; --i) {
        if (!(_filteredObjectTypes[i]->getName().contains(objectTypeName, Qt::CaseInsensitive)) && (_filteredObjectTypes[i]->getThreshold()>0)) {
            _filteredObjectTypes.removeAt(i);
        }
    }
    }
}


