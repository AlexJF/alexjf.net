#include "Building.hpp"
#include "ObjectTypeManager.hpp"
#include "Room.hpp"
#include "Object.hpp"
#include <iostream>

void roomsAppend(QDeclarativeListProperty<Room>* prop, Room* value) {
     Q_UNUSED(prop);
     Q_UNUSED(value);
     return; //Append not supported
}

int roomsCount(QDeclarativeListProperty<Room>* prop) {
    return static_cast<QMap<QString, Room*>*>(prop->data)->count();
}

Room* roomsAt(QDeclarativeListProperty<Room>* prop, int index) {
    return static_cast<QMap<QString, Room*>*>(prop->data)->values().at(index);
}

Building::Building() {
}

Building::~Building() {
    qDeleteAll(_rooms);
    _rooms.clear();
}

QDeclarativeListProperty<Room> Building::getRooms() { 
    return QDeclarativeListProperty<Room>(this, &_rooms, roomsAppend, roomsCount, roomsAt); 
}

QSizeF Building::getTotalSize() {
    return _totalSize;
}

void Building::addRoom(Room *room) {
    if (room == NULL) {
        return;
    }

    QPointF roomPos = room->getPosition();
    QSizeF roomSize = room->getSize();

    float maxX = roomPos.x() + roomSize.width();

    if (maxX > _totalSize.width()) {
        _totalSize.setWidth(maxX);
    }

    float maxY = roomPos.y() + roomSize.height();

    if (maxY > _totalSize.height()) {
        _totalSize.setHeight(maxY);
    }

    _rooms.insert(room->getName(), room);
}

Room* Building::getRoomByName(const QString &name) {
    return _rooms.value(name, NULL);
}

QList<Object*> Building::getObjects() {
    QMap<QString, Room*>::iterator it;
    QList<Object*>::iterator it2;
    QMap<QString, Object*> finalObjects;
    QList<Object*> objects;

    for (it = _rooms.begin(); it != _rooms.end(); it++){
        Room *room = it.value();
        objects = room->getObjects();

        for (it2 = objects.begin(); it2 != objects.end(); it2++){
            finalObjects.insert((*it2)->getName(), *it2);
        }
    }

    return finalObjects.values();
}

bool Building::objectInList(const QList<Object*> &list, Object *obj) {
    for (int i = 0; i < list.count(); i++) {
        if (list[i]->getName() == obj->getName()) {
            return true;
        }
    }

    return false;
}

void Building::filterObjectByRoom(const QString &roomName) {
    QList<Object*> roomObjects;

    if (roomName != "") {
        Room *room = getRoomByName(roomName);

        if (room == NULL) {
            return;
        }

        QList<Object*> roomObjects = room->getObjects();
		
        for (int i = _filteredObjects.count() - 1; i >= 0; --i) {
            if (!roomObjects.contains(_filteredObjects[i])) {
                _filteredObjects.removeAt(i);
            }
        }
    }
}

void Building::filterObjectByType(const QString &objectTypeName) {
	if (objectTypeName != "") {
        QList<Object*> typeObjects;

        ObjectTypeManager *manager = ObjectTypeManager::getInstance();
        QList<ObjectType*> objectTypes = manager->searchObjectTypes(objectTypeName);

        for (int j =  _filteredObjects.count() - 1; j >= 0; --j){ 
            bool foundType = false;
            for (int i = 0; i < objectTypes.count(); ++i) {
                if (_filteredObjects[j]->isOfType(objectTypes[i]->getName())) {
                    foundType = true;
                }
            }

            if (!foundType) {
                _filteredObjects.removeAt(j);
            }
        }
	}
}

void Building::filterObjectByName(const QString &objectName) {
	if (objectName != "") {
        for (int i = _filteredObjects.count() - 1; i >= 0; --i) {
            Object *object = _filteredObjects[i];
            if (!object->getName().contains(objectName, Qt::CaseInsensitive)) {
                _filteredObjects.removeAt(i);
            }
        }
	}
}

void Building::filterInOutsObjectByRoom(const QString &roomName) {
    QList<Object*> roomObjects;

    if (roomName != "") {
        Room *room = getRoomByName(roomName);

        if (room == NULL) {
            return;
        }

        QList<Object*> roomObjects = room->getObjects();
		
        for (int i = _filteredInOutObjects.count() - 1; i >= 0; --i) {
            if (!roomObjects.contains(_filteredInOutObjects[i]->getObject())) {
                _filteredInOutObjects.removeAt(i);
            }
        }
    }
}

void Building::filterInOutsObjectByType(const QString &objectTypeName) {
	if (objectTypeName != "") {
        QList<Object*> typeObjects;

        ObjectTypeManager *manager = ObjectTypeManager::getInstance();
        QList<ObjectType*> objectTypes = manager->searchObjectTypes(objectTypeName);

        for (int j =  _filteredInOutObjects.count() - 1; j >= 0; --j){ 
            bool foundType = false;
            for (int i = 0; i < objectTypes.count(); ++i) {
                if (_filteredInOutObjects[j]->getObject()->isOfType(objectTypes[i]->getName())) {
                    foundType = true;
                }
            }

            if (!foundType) {
                _filteredInOutObjects.removeAt(j);
            }
        }
	}
}

void Building::filterInOutsObjectByName(const QString &objectName) {
	if (objectName != "") {
        for (int i = _filteredInOutObjects.count() - 1; i >= 0; --i) {
            Object *object = _filteredInOutObjects[i]->getObject();
            if (!object->getName().contains(objectName, Qt::CaseInsensitive)) {
                _filteredInOutObjects.removeAt(i);
            }
        }
        }
}


void Building::filterInOutsObjectByBeginDateTime(const QString &objectDate, const QString &objectHour) {
    QDate date = QDate::fromString(objectDate, "dd/MM/yyyy");
    QTime time = QTime::fromString(objectHour, "hh:mm");

    if (!date.isValid() && !time.isValid()) return;

    QDateTime datetime;

    if (date.isValid()) {
        datetime = QDateTime(date, time);
    }

    for (int i = _filteredInOutObjects.count() - 1; i >= 0; --i) {
        QDateTime dateTime = _filteredInOutObjects[i]->getDate();
        if (!date.isValid()) datetime = QDateTime(dateTime.date(), time);
        if (dateTime < datetime) {
            _filteredInOutObjects.removeAt(i);
        }
    }
}

void Building::filterInOutsObjectByEndDateTime(const QString &objectDate, const QString &objectHour) {
    QDate date = QDate::fromString(objectDate, "dd/MM/yyyy");
    QTime time = QTime::fromString(objectHour, "hh:mm");

    if (!date.isValid() && !time.isValid()) return;

    if (!time.isValid()) {
        time = QTime(23, 59);
    }

    QDateTime datetime(date, time);

    for (int i = _filteredInOutObjects.count() - 1; i >= 0; --i) {
        QDateTime dateTime = _filteredInOutObjects[i]->getDate();
        if (!date.isValid()) datetime = QDateTime(dateTime.date(), time);
        if (dateTime > datetime) {
            _filteredInOutObjects.removeAt(i);
        }
    }
}

void Building::filterInOutsObjectByOnlyIn(bool objectIn){
    if (!objectIn){
        for (int i = _filteredInOutObjects.count() - 1; i >= 0; --i) {
            if (_filteredInOutObjects[i]->getInOut().contains("in", Qt::CaseInsensitive)) {
                _filteredInOutObjects.removeAt(i);
            }
        }
    }
}

void Building::filterInOutsObjectByOnlyOut(bool objectOut){
    if (!objectOut){
        for (int i = _filteredInOutObjects.count() - 1; i >= 0; --i) {
            if (_filteredInOutObjects[i]->getInOut().contains("out", Qt::CaseInsensitive)) {
                _filteredInOutObjects.removeAt(i);
            }
        }
    }
}




//QDeclarativeListProperty<Object> Building::findObject(const QString &objectName, const QString &typeObjectName, const QString &roomName){
void Building::filterObjects(const QString &objectName, const QString &typeObjectName, const QString &roomName){
    _filteredObjects = getObjects();
	filterObjectByRoom(roomName);
	filterObjectByType(typeObjectName);
	filterObjectByName(objectName);
}

void Building::filterInOutObjects(const QString &objectName, const QString &typeObjectName, const QString &roomName, const QString &objectBeginDate, const QString &objectBeginHour, const QString &objectEndDate, const QString &objectEndHour, bool objectOnlyIn, bool objectOnlyOut) {
    _filteredInOutObjects = _inOutsObjects;
	filterInOutsObjectByRoom(roomName);
	filterInOutsObjectByType(typeObjectName);
	filterInOutsObjectByName(objectName);
	filterInOutsObjectByBeginDateTime(objectBeginDate, objectBeginHour);
	filterInOutsObjectByEndDateTime(objectEndDate, objectEndHour);
    filterInOutsObjectByOnlyIn(objectOnlyIn);
    filterInOutsObjectByOnlyOut(objectOnlyOut);
}

QDeclarativeListProperty<Object> Building::getFilteredObjects() {
    return QDeclarativeListProperty<Object>(this, _filteredObjects);
}

int inOutsCount(QDeclarativeListProperty<Pair>* prop) {
	return static_cast<QList<Pair*>*>(prop->data)->count();
}

Pair* inOutsAt(QDeclarativeListProperty<Pair>* prop, int index) {
	return static_cast<QList<Pair*>*>(prop->data)->value(index);
}

void inOutsAppend(QDeclarativeListProperty<Pair>* prop, Pair* value) {
	Q_UNUSED(prop);
	Q_UNUSED(value);
	return; //Append not supported
}

QDeclarativeListProperty<Pair> Building::getInOutsObjects() {
	return QDeclarativeListProperty<Pair>(this, &_inOutsObjects, inOutsAppend, inOutsCount, inOutsAt);
}

QDeclarativeListProperty<Pair> Building::getFilteredInOutObjects() {
    return QDeclarativeListProperty<Pair>(this, &_filteredInOutObjects, inOutsAppend, inOutsCount, inOutsAt);
}

Pair::Pair(Object* obj, const QDateTime &date, QString string) {
	_object = obj;
	_date = date;
	_inOut = string;
}

Object* Pair::getObject() {
	return _object;
}

QDateTime Pair::getDate() {
	return _date;
}

QString Pair::getInOut() {
	return _inOut;
}

QString Pair::toString() {
	return _date.toString("dd/MM/yyyy hh:mm");
}

void Building::addInOut(Pair* pair) {
	_inOutsObjects.append(pair);
}

bool Building::objectExists(const QString &objname) {
    QList<Object *> objects = getObjects();
    for (int i = objects.count() - 1; i >= 0; --i) {
        Object *object = objects[i];

        if (object->getName() == objname) {
            return true;
        }
    }
    return false;
}
