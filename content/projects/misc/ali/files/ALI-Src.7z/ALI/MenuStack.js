var menus = Array();
var stack = Array();

function ini(menu, menu2, menu3) {
	menu.visible = true;
	stack.push(menu);
	
	menus.push(menu);
	menus.push(menu2);
	menus.push(menu3);
}

function push(menu) {
	stack[stack.length - 1].visible = false;
	menus[menu].visible = true;
	stack.push(menus[menu]);

	helpDialog.title = menus[menu].help.title
	helpDialog.content = menus[menu].help.content
	console.log(menus[menu].help.title);
    if (stack.length > 1) {
        back.visible = true;
        home.visible = true;
    }
}

function pop() {
	if (stack.length == 1) {
		return;
	}

	stack[stack.length - 1].visible = false;
	stack.pop();
	stack[stack.length - 1].visible = true;

	helpDialog.title =  stack[stack.length - 1].help.title
	helpDialog.content = stack[stack.length - 1].help.content

    if (stack.length == 1) {
        back.visible = false;
    	home.visible = false;
	}
}

function top() {
    return stack[stack.length - 1];
}

function reset() {
	stack[stack.length - 1].visible = false;
	stack = Array();
	mainMenu.visible = true;
	stack.push(mainMenu);
	home.visible = false;
    back.visible = false;
}
