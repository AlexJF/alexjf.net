/***************************************************************
 * Name:      MainFrame.cpp
 * Purpose:   Code for the Main Frame of the application
 * Author:    Alexandre Fonseca (alexandrejorgefonseca@gmail.com)
 * Created:   2008-07-02
 * Copyright: Alexandre Fonseca (http://revolt.hyperhub.info)
 * License:
 **************************************************************/
#include "MainFrame.h"

//(*InternalHeaders(MainFrame)
#include <wx/bitmap.h>
#include <wx/settings.h>
#include <wx/font.h>
#include <wx/intl.h>
#include <wx/image.h>
#include <wx/string.h>
//*)

#include <wx/icon.h>
#include <wx/aboutdlg.h>
#include <wx/busyinfo.h>


//(*IdInit(MainFrame)
const long MainFrame::ID_LBL_FILESLIST = wxNewId();
const long MainFrame::ID_LST_FILES = wxNewId();
const long MainFrame::ID_BTN_FILEADD = wxNewId();
const long MainFrame::ID_BTN_SEARCHDIR = wxNewId();
const long MainFrame::ID_BTN_REMOVEFILES = wxNewId();
const long MainFrame::ID_LBL_TOTALS = wxNewId();
const long MainFrame::ID_LBL_TOTALLINES = wxNewId();
const long MainFrame::ID_LBL_NORMALLINES = wxNewId();
const long MainFrame::ID_LBL_EMPTYLINES = wxNewId();
const long MainFrame::ID_LBL_COMMENTLINES = wxNewId();
const long MainFrame::ID_BTN_REPORT = wxNewId();
const long MainFrame::ID_BTN_REFRESH = wxNewId();
const long MainFrame::ID_PNL_MAIN = wxNewId();
const long MainFrame::ID_MNU_ADDFILE = wxNewId();
const long MainFrame::ID_MNU_SEARCHDIR = wxNewId();
const long MainFrame::ID_MNU_REPORT = wxNewId();
const long MainFrame::ID_STATUSBAR = wxNewId();
//*)

BEGIN_EVENT_TABLE(MainFrame,wxFrame)
	//(*EventTable(MainFrame)
	//*)
END_EVENT_TABLE()

MainFrame::MainFrame(wxWindow* parent,wxWindowID id,const wxPoint& pos,const wxSize& size)
{
	//(*Initialize(MainFrame)
	wxBoxSizer* szr_TotalLblHor;
	wxBoxSizer* szr_TitleHor;
	wxBoxSizer* szr_VertListCtrls;
	wxBoxSizer* szr_BtnHor;
	wxMenu* FileMenu;
	wxBoxSizer* szr_MainVert;
	wxBoxSizer* szr_HorList;

	Create(parent, wxID_ANY, _("Line Stat"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE|wxSYSTEM_MENU, _T("wxID_ANY"));
	SetClientSize(wxSize(500,300));
	pnl_Main = new wxPanel(this, ID_PNL_MAIN, wxPoint(179,314), wxDefaultSize, wxSTATIC_BORDER|wxTAB_TRAVERSAL, _T("ID_PNL_MAIN"));
	szr_MainVert = new wxBoxSizer(wxVERTICAL);
	szr_TitleHor = new wxBoxSizer(wxHORIZONTAL);
	lbl_FilesList = new wxStaticText(pnl_Main, ID_LBL_FILESLIST, _("Files to analyse:"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_LBL_FILESLIST"));
	szr_TitleHor->Add(lbl_FilesList, 1, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_MainVert->Add(szr_TitleHor, 0, wxTOP|wxBOTTOM|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
	szr_HorList = new wxBoxSizer(wxHORIZONTAL);
	lst_Files = new wxListCtrl(pnl_Main, ID_LST_FILES, wxDefaultPosition, wxDefaultSize, wxLC_REPORT|wxLC_HRULES|wxLC_VRULES|wxVSCROLL|wxHSCROLL, wxDefaultValidator, _T("ID_LST_FILES"));
	szr_HorList->Add(lst_Files, 1, wxBOTTOM|wxLEFT|wxRIGHT|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_VertListCtrls = new wxBoxSizer(wxVERTICAL);
	btn_FileAdd = new wxBitmapButton(pnl_Main, ID_BTN_FILEADD, wxBitmap(wxImage(_T("images/add.png"))), wxDefaultPosition, wxSize(24,24), wxBU_AUTODRAW, wxDefaultValidator, _T("ID_BTN_FILEADD"));
	btn_FileAdd->SetDefault();
	btn_FileAdd->SetToolTip(_("Add file(s)"));
	szr_VertListCtrls->Add(btn_FileAdd, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	btn_SearchDir = new wxBitmapButton(pnl_Main, ID_BTN_SEARCHDIR, wxBitmap(wxImage(_T("images/searchdir.png"))), wxDefaultPosition, wxSize(24,24), wxBU_AUTODRAW, wxDefaultValidator, _T("ID_BTN_SEARCHDIR"));
	btn_SearchDir->SetDefault();
	btn_SearchDir->SetToolTip(_("Search a directory"));
	szr_VertListCtrls->Add(btn_SearchDir, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	btn_RemoveFiles = new wxBitmapButton(pnl_Main, ID_BTN_REMOVEFILES, wxBitmap(wxImage(_T("images/delete.png"))), wxDefaultPosition, wxSize(24,24), wxBU_AUTODRAW, wxDefaultValidator, _T("ID_BTN_REMOVEFILES"));
	btn_RemoveFiles->SetDefault();
	btn_RemoveFiles->SetToolTip(_("Remove file(s) from the list"));
	szr_VertListCtrls->Add(btn_RemoveFiles, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	szr_HorList->Add(szr_VertListCtrls, 0, wxTOP|wxBOTTOM|wxRIGHT|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_MainVert->Add(szr_HorList, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	szr_TotalLblHor = new wxBoxSizer(wxHORIZONTAL);
	szr_TotalLblHor->Add(-1,-1,2, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	lbl_Totals = new wxStaticText(pnl_Main, ID_LBL_TOTALS, _("Totals"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_LBL_TOTALS"));
	wxFont lbl_TotalsFont = wxSystemSettings::GetFont(wxSYS_DEFAULT_GUI_FONT);
	if ( !lbl_TotalsFont.Ok() ) lbl_TotalsFont = wxSystemSettings::GetFont(wxSYS_DEFAULT_GUI_FONT);
	lbl_TotalsFont.SetPointSize((int)(lbl_TotalsFont.GetPointSize() * 1.000000));
	lbl_TotalsFont.SetWeight(wxBOLD);
	lbl_Totals->SetFont(lbl_TotalsFont);
	szr_TotalLblHor->Add(lbl_Totals, 0, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_TotalLblHor->Add(-1,-1,1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	lbl_TotalLines = new wxStaticText(pnl_Main, ID_LBL_TOTALLINES, _("Lines: 0"), wxDefaultPosition, wxDefaultSize, wxALIGN_CENTRE, _T("ID_LBL_TOTALLINES"));
	szr_TotalLblHor->Add(lbl_TotalLines, 0, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_TotalLblHor->Add(-1,-1,1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	lbl_NormalLines = new wxStaticText(pnl_Main, ID_LBL_NORMALLINES, _("Normal Lines: 0"), wxDefaultPosition, wxDefaultSize, wxALIGN_CENTRE, _T("ID_LBL_NORMALLINES"));
	szr_TotalLblHor->Add(lbl_NormalLines, 0, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_TotalLblHor->Add(-1,-1,1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	lbl_EmptyLines = new wxStaticText(pnl_Main, ID_LBL_EMPTYLINES, _("Empty Lines: 0"), wxDefaultPosition, wxDefaultSize, wxALIGN_CENTRE, _T("ID_LBL_EMPTYLINES"));
	szr_TotalLblHor->Add(lbl_EmptyLines, 0, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_TotalLblHor->Add(-1,-1,1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	lbl_CommentLines = new wxStaticText(pnl_Main, ID_LBL_COMMENTLINES, _("Comment Lines: 0"), wxDefaultPosition, wxDefaultSize, wxALIGN_CENTRE, _T("ID_LBL_COMMENTLINES"));
	szr_TotalLblHor->Add(lbl_CommentLines, 0, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_TotalLblHor->Add(-1,-1,2, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	szr_MainVert->Add(szr_TotalLblHor, 0, wxBOTTOM|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
	szr_BtnHor = new wxBoxSizer(wxHORIZONTAL);
	btn_Report = new wxButton(pnl_Main, ID_BTN_REPORT, _("Get Report"), wxDefaultPosition, wxDefaultSize, wxSIMPLE_BORDER, wxDefaultValidator, _T("ID_BTN_REPORT"));
	btn_Report->Disable();
	szr_BtnHor->Add(btn_Report, 0, wxLEFT|wxRIGHT|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 10);
	szr_BtnHor->Add(-1,-1,1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	btn_Refresh = new wxButton(pnl_Main, ID_BTN_REFRESH, _("Refresh"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BTN_REFRESH"));
	btn_Refresh->Disable();
	szr_BtnHor->Add(btn_Refresh, 0, wxLEFT|wxRIGHT|wxALIGN_RIGHT|wxALIGN_CENTER_VERTICAL, 10);
	szr_MainVert->Add(szr_BtnHor, 0, wxTOP|wxBOTTOM|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
	pnl_Main->SetSizer(szr_MainVert);
	szr_MainVert->Fit(pnl_Main);
	szr_MainVert->SetSizeHints(pnl_Main);
	MenuBar = new wxMenuBar();
	FileMenu = new wxMenu();
	mnu_AddFile = new wxMenuItem(FileMenu, ID_MNU_ADDFILE, _("&Add File(s)...\tCTRL+F"), _("Adds one or more files to the list"), wxITEM_NORMAL);
	FileMenu->Append(mnu_AddFile);
	mnu_SearchDir = new wxMenuItem(FileMenu, ID_MNU_SEARCHDIR, _("&Search in Directory...\tCTRL+D"), _("Searches a directory for files to add to the list"), wxITEM_NORMAL);
	FileMenu->Append(mnu_SearchDir);
	FileMenu->AppendSeparator();
	mnu_Report = new wxMenuItem(FileMenu, ID_MNU_REPORT, _("Get &Report\tCTRL+R"), _("Shows a dialog with a report of line counts grouped by extension."), wxITEM_NORMAL);
	FileMenu->Append(mnu_Report);
	mnu_Report->Enable(false);
	FileMenu->AppendSeparator();
	mnu_Exit = new wxMenuItem(FileMenu, wxID_EXIT, _("&Exit\tALT+F4"), _("Exits the Application"), wxITEM_NORMAL);
	FileMenu->Append(mnu_Exit);
	MenuBar->Append(FileMenu, _("&File"));
	HelpMenu = new wxMenu();
	mnu_About = new wxMenuItem(HelpMenu, wxID_ABOUT, _("A&bout\tCTRL+A"), wxEmptyString, wxITEM_NORMAL);
	HelpMenu->Append(mnu_About);
	MenuBar->Append(HelpMenu, _("&Help"));
	SetMenuBar(MenuBar);
	StatusBar = new wxStatusBar(this, ID_STATUSBAR, 0, _T("ID_STATUSBAR"));
	int __wxStatusBarWidths_1[2] = { -10, -10 };
	int __wxStatusBarStyles_1[2] = { wxSB_NORMAL, wxSB_NORMAL };
	StatusBar->SetFieldsCount(2,__wxStatusBarWidths_1);
	StatusBar->SetStatusStyles(2,__wxStatusBarStyles_1);
	SetStatusBar(StatusBar);
	dlg_SelectFile = new wxFileDialog(this, _("Select file"), wxEmptyString, wxEmptyString, wxFileSelectorDefaultWildcardStr, wxFD_OPEN|wxFD_FILE_MUST_EXIST|wxFD_MULTIPLE|wxSTATIC_BORDER, wxDefaultPosition, wxDefaultSize, _T("wxFileDialog"));

	Connect(ID_LST_FILES,wxEVT_COMMAND_LIST_DELETE_ITEM,(wxObjectEventFunction)&MainFrame::OnListItemCountChanged);
	Connect(ID_LST_FILES,wxEVT_COMMAND_LIST_INSERT_ITEM,(wxObjectEventFunction)&MainFrame::OnListItemCountChanged);
	Connect(ID_BTN_FILEADD,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&MainFrame::OnAddFile);
	Connect(ID_BTN_SEARCHDIR,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&MainFrame::OnSearchDirectory);
	Connect(ID_BTN_REMOVEFILES,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&MainFrame::OnRemoveFile);
	Connect(ID_BTN_REPORT,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&MainFrame::OnGetReport);
	Connect(ID_BTN_REFRESH,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&MainFrame::OnRefresh);
	Connect(ID_MNU_ADDFILE,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&MainFrame::OnAddFile);
	Connect(ID_MNU_SEARCHDIR,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&MainFrame::OnSearchDirectory);
	Connect(ID_MNU_REPORT,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&MainFrame::OnGetReport);
	Connect(wxID_EXIT,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&MainFrame::OnExit);
	Connect(wxID_ABOUT,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&MainFrame::OnAbout);
	//*)

    SetIcon(wxIcon(_T("APPICON")));

	obj_FileAnalyzer = new FileAnalyzer();
	obj_FileAnalyzer->AssociateListCtrl(lst_Files);

    dlg_SearchDir = new SearchDirDialog(this);

    StatusBar->SetStatusText(_T("Number of Files: 0"), 1);
}

MainFrame::~MainFrame()
{
	//(*Destroy(MainFrame)
	//*)
}

void MainFrame::OnAddFile(wxCommandEvent& event)
{
    if (dlg_SelectFile->ShowModal() == wxID_OK) {
        wxArrayString filepaths;
        dlg_SelectFile->GetPaths(filepaths);
        for (int unsigned i = 0; i < filepaths.GetCount(); i++) {
            obj_FileAnalyzer->AddFile(filepaths[i]);
        }
    }
}

void MainFrame::OnRefresh(wxCommandEvent& event)
{
    obj_FileAnalyzer->RefreshAllFiles();
}

void MainFrame::OnSearchDirectory(wxCommandEvent& event)
{
    if (dlg_SearchDir->ShowModal() == wxID_OK) {
        wxArrayString fileList;
        wxArrayString extList = obj_FileAnalyzer->ParseExtensions(dlg_SearchDir->GetExtensions());
        wxWindowDisabler disableAll;
        wxBusyInfo info(_T("Searching..."), this);
        obj_FileAnalyzer->SearchDirectory(dlg_SearchDir->GetDirectoryPath(), dlg_SearchDir->GetDirectoryLvl(), extList);
    }
}

void MainFrame::OnRemoveFile(wxCommandEvent& event)
{
    wxIntArray selectedItems;
    int item = -1;
    do {
        item = lst_Files->GetNextItem(item, wxLIST_NEXT_ALL, wxLIST_STATE_SELECTED);
        selectedItems.Add(item);
    } while (item != -1);

    for (int i = selectedItems.Count() - 1; i >= 0; i--) {
        obj_FileAnalyzer->RemoveFile(selectedItems.Item(i));
    }
}

void MainFrame::OnGetReport(wxCommandEvent& event)
{
    ReportDialog reportDlg(this, obj_FileAnalyzer->CreateReport());
    reportDlg.ShowModal();
}

void MainFrame::OnListItemCountChanged(wxListEvent& event)
{
    //Update "Total" labels
    LineCount totals = obj_FileAnalyzer->GetTotalLines();
    lbl_TotalLines->SetLabel(wxString::Format(_T("Lines: %d"), totals.empty + totals.comment + totals.normal));
    lbl_NormalLines->SetLabel(wxString::Format(_T("Normal Lines: %d"), totals.normal));
    lbl_EmptyLines->SetLabel(wxString::Format(_T("Empty Lines: %d"), totals.empty));
    lbl_CommentLines->SetLabel(wxString::Format(_T("Comment Lines: %d"), totals.comment));

    int numberOfFiles = obj_FileAnalyzer->GetFileCount();

    //Update statusbar filecount
    StatusBar->SetStatusText(wxString::Format(_T("Number of Files: %d"), numberOfFiles), 1);

    if (numberOfFiles == 0) {
        btn_Report->Enable(false);
        btn_Refresh->Enable(false);
        mnu_Report->Enable(false);
    } else {
        btn_Report->Enable(true);
        btn_Refresh->Enable(true);
        mnu_Report->Enable(true);
    }
}

void MainFrame::OnAbout(wxCommandEvent& event)
{
    wxAboutDialogInfo aboutInfo;
    aboutInfo.SetName(_T("Line Stat"));
    aboutInfo.AddDeveloper(_T("Revolt aka Alexandre Fonseca"));
    aboutInfo.SetVersion(_T("1.0"));
    aboutInfo.SetDescription(_T("Line Stat is a program which aims to help you monitor the amount of data in your current or old projects\nby displaying statistics regarding the number of lines in the files.\n\nIt was developed in C++ with wxWidgets."));

    wxAboutBox(aboutInfo);
}

void MainFrame::OnExit(wxCommandEvent& event)
{
    Close();
}
