/***************************************************************
 * Name:      FileAnalyzer.cpp
 * Purpose:   Implements the FileAnalyzer class
 * Author:    Alexandre Fonseca (alexandrejorgefonseca@gmail.com)
 * Created:   2008-07-03
 * Copyright: Alexandre Fonseca (http://revolt.hyperhub.info)
 * License:
 **************************************************************/

#include "FileAnalyzer.h"
#include <wx/arrimpl.cpp>
WX_DEFINE_OBJARRAY(FileArray); //Implement the file array object

/* -------------- File class implementation -----------------*/
File::File(const wxString &filepath)
{
    _filepath = filepath;
    _lines.normal = 0;
    _lines.empty = 0;
    _lines.comment = 0;
    Refresh();
}

File::~File()
{
}

void File::Refresh()
{
    _lines.comment = 0;
    _lines.empty = 0;
    _lines.normal = 0;

    if (!Exists()) {
        return;
    }
    wxFFile file(_filepath);

    //If we were unable to open the file, return 0 as total line count
    if (!file.IsOpened()) {
        return;
    }

    wxString fileContent;

    if (!file.ReadAll(&fileContent, wxConvLocal)) { //Read file content
        file.Close();
        return;
    }

    //wxMessageBox(fileContent + wxString::Format(_T("\n\n\n Length: %d"), fileContent.Length()) + _T("\nPath: ") + filepath);

    wxStringTokenizer lineSplitter;
    lineSplitter.SetString(fileContent, _T("\n"), wxTOKEN_RET_EMPTY_ALL);

    long totalLines = 0;
    totalLines = lineSplitter.CountTokens(); //Get total number of lines

    bool onComment = false;
    bool onString = false;
    char strDel = '\0';
    wxString line;

    while (lineSplitter.HasMoreTokens()) {
        line = lineSplitter.GetNextToken();
        line.Trim(false);
        line.Trim();
        if (line.IsEmpty()) {
            if (onComment) {
                _lines.comment++;
                continue;
            }
            else if (onString) {
                _lines.normal++;
                continue;
            }
            else {
                _lines.empty++;
                continue;
            }
        }
        if (line.StartsWith(_T("//")) && !onString && !onComment) {
            _lines.comment++;
            continue;
        }

        bool alreadyAdded = false;
        int lineLength = line.Length();

        for (int i = 0; i < lineLength; i++) {
            char currentChar = line.GetChar(i);
            switch (currentChar)
            {
                case '/':
                    if (i + 1 < lineLength) {
                        //Start of multi-line comment
                        if (line.GetChar(i + 1) == '*' && !onString && !onComment) {
                            onComment = true;
                            if (i != 0) {
                                _lines.normal++;
                                alreadyAdded = true;
                            }
                            i++;
                        }
                        //Inline comment but not at the start of the line. Count line as normal and jump to next one
                        else if (line.GetChar(i + 1) == '/' && !onComment) {
                            _lines.normal++;
                            alreadyAdded = true;
                        }
                    }
                break;
                case '*':
                    //End of multi-line comment
                    if (i + 1 < lineLength) {
                        if (line.GetChar(i + 1) == '/' && !onString && onComment) {
                            onComment = false;
                            //If it is the last thing on the line, increment comment count (otherwise line would be considered as normal)
                            if (i + 2 >= line.Length()) {
                                _lines.comment++;
                                alreadyAdded = true;
                            }
                            i++;
                        }
                    }
                break;
                case '\"':
                case '\'':
                    //End of String
                    if (onString && currentChar == strDel) {
                        if (i - 1 >= 0) {
                            //If string delimiter isn't preceeded by a \ then it is valid as a delimiter
                            if (line.GetChar(i - 1) != '\\') {
                                onString = false;
                                strDel = '\0';
                            }
                        } else {
                            onString = false;
                            strDel = '\0';
                        }
                    }
                    //Start of new string
                    else if(!onString && !onComment) {
                        onString = true;
                        strDel = currentChar;
                    }
                break;
            }
            if (alreadyAdded) {
                break;
            }
        }

        if (!alreadyAdded) {
            if (onComment) {
                _lines.comment++;
            } else {
                _lines.normal++;
            }
        }
    }

    file.Close(); //Close file since we won't need to read it anymore
}

LineCount File::GetLineCount()
{
    return _lines;
}

bool File::Exists()
{
    return wxFile::Exists(_filepath);
}

wxString File::GetPath()
{
    return _filepath;
}

wxString File::GetExtension()
{
    wxFileName filename(_filepath);
    return filename.GetExt();
}

wxString File::GetName()
{
    wxFileName filename(_filepath);
    return filename.GetName();
}

wxString File::GetDirectory()
{
    wxFileName filename(_filepath);
    return filename.GetHomeDir();
}

/* -------------- End of File class implementation ------------*/

/* -------------- FileAnalyzer class implementation -----------*/

FileAnalyzer::FileAnalyzer()
{
    _listctrl = NULL;
    _files = new FileArray();
}

FileAnalyzer::~FileAnalyzer()
{
    delete _files;
}

void FileAnalyzer::AssociateListCtrl(wxListCtrl *listctrl)
{
    _listctrl = listctrl;
    _listctrl->ClearAll();

    wxListItem column;
	column.SetAlign(wxLIST_FORMAT_LEFT);

    column.SetText(_T("File:"));
    _listctrl->InsertColumn(0, column);

    column.SetText(_T("Total Lines:"));
    _listctrl->InsertColumn(1, column);

    column.SetText(_T("Normal Lines:"));
    _listctrl->InsertColumn(2, column);

    column.SetText(_T("Empty Lines:"));
    _listctrl->InsertColumn(3, column);

    column.SetText(_T("Comment Lines:"));
    _listctrl->InsertColumn(4, column);

    _listctrl->SetColumnWidth(0, wxLIST_AUTOSIZE_USEHEADER);
    _listctrl->SetColumnWidth(1, wxLIST_AUTOSIZE_USEHEADER);
    _listctrl->SetColumnWidth(2, wxLIST_AUTOSIZE_USEHEADER);
    _listctrl->SetColumnWidth(3, wxLIST_AUTOSIZE_USEHEADER);
    _listctrl->SetColumnWidth(4, wxLIST_AUTOSIZE_USEHEADER);
}

bool FileAnalyzer::AddFile(const wxString &filepath)
{
    File newfile(filepath);
    if (!newfile.Exists()) {
        return false;
    }

    //If file already exists exit function
    if (GetIndex(filepath) != -1) {
        return false;
    }

    _files->Add(newfile);

    if (_listctrl != NULL) {
        int newItemIndex = _listctrl->GetItemCount();
        _listctrl->InsertItem(newItemIndex, filepath);

        LineCount lines = newfile.GetLineCount();

        _listctrl->SetItem(newItemIndex, 1, wxString::Format(_T("%d"), lines.normal + lines.comment + lines.empty));
        _listctrl->SetItem(newItemIndex, 2, wxString::Format(_T("%d"), lines.normal));
        _listctrl->SetItem(newItemIndex, 3, wxString::Format(_T("%d"), lines.empty));
        _listctrl->SetItem(newItemIndex, 4, wxString::Format(_T("%d"), lines.comment));

        _listctrl->SetColumnWidth(0, wxLIST_AUTOSIZE);
    }

    return true;
}

int FileAnalyzer::GetIndex(const wxString &filepath)
{
    for (int i = 0; i < _files->GetCount(); i++) {
        if (_files->Item(i).GetPath() == filepath) {
            return i;
        }
    }
    return -1;
}

bool FileAnalyzer::GetFile(File &ext_file_object, int index)
{
    if (index >= 0 && index < _files->GetCount()) {
        ext_file_object = _files->Item(index);
        return true;
    }
    return false;
}

void FileAnalyzer::RemoveFile(int index)
{
    if (index >= 0 && index < _files->GetCount()) {
        _files->RemoveAt(index);
        if (_listctrl != NULL) {
            _listctrl->DeleteItem(index);
        }
    }
    //wxMessageBox(wxString::Format(_T("%d files on list\n%d files on array"), _listctrl->GetItemCount(), _files->GetCount()));
}

void FileAnalyzer::RemoveFile(const wxString &filepath)
{
    for (int i = 0; i < _files->GetCount(); i++) {
        if (_files->Item(i).GetPath() == filepath) {
            _files->RemoveAt(i);
            if (_listctrl != NULL) {
                _listctrl->DeleteItem(i);
            }
            return;
        }
    }
}

void FileAnalyzer::RemoveAll()
{
    _files->Clear();
    if (_listctrl != NULL) {
        _listctrl->DeleteAllItems();
    }
}

void FileAnalyzer::RefreshAllFiles()
{
    for (int i = _files->GetCount() - 1; i >= 0; i--) {
        File currentFile = _files->Item(i);
        if (!currentFile.Exists()) {
            _files->RemoveAt(i);
            if (_listctrl != NULL) {
                _listctrl->DeleteItem(i);
            }
        }
        currentFile.Refresh();
        if (_listctrl != NULL) {
            LineCount lines = currentFile.GetLineCount();

            _listctrl->SetItem(i, 1, wxString::Format(_T("%d"), lines.normal + lines.comment + lines.empty));
            _listctrl->SetItem(i, 2, wxString::Format(_T("%d"), lines.normal));
            _listctrl->SetItem(i, 3, wxString::Format(_T("%d"), lines.empty));
            _listctrl->SetItem(i, 4, wxString::Format(_T("%d"), lines.comment));
        }
    }
}

void FileAnalyzer::SearchDirectory(const wxString &dirPath, int subLvl, const wxArrayString &extensions, int curLvl)
{
    if (!wxDir::Exists(dirPath)) {
        return;
    }

    //Get files from subdirectories if we must
    if (subLvl == -1 || curLvl < subLvl) {
        wxDir curDirectory(dirPath);
        wxFileName curDirectoryPath(dirPath, wxEmptyString);
        if (!curDirectory.IsOpened()) {
            return;
        }
        wxString curSubDirectoryName;
        bool cont = curDirectory.GetFirst(&curSubDirectoryName, wxEmptyString, wxDIR_DIRS);
        while (cont) {
            SearchDirectory(curDirectoryPath.GetPath(wxPATH_GET_SEPARATOR) + curSubDirectoryName, subLvl, extensions, curLvl + 1);
            cont = curDirectory.GetNext(&curSubDirectoryName);
        }
    }

    wxArrayString fileList;

    //Get files from current directory
    if (extensions.IsEmpty()) { //If no extensions specified
        wxDir::GetAllFiles(dirPath, &fileList, wxEmptyString, wxDIR_FILES);
    } else {
        for (int i = 0; i < extensions.Count(); i++) {
            wxDir::GetAllFiles(dirPath, &fileList, _T("*.") + extensions.Item(i), wxDIR_FILES);
        }
    }

    for (int i = 0; i < fileList.GetCount(); i++) {
        AddFile(fileList.Item(i));
    }
}

wxArrayString FileAnalyzer::ParseExtensions(wxString extensions)
{
    wxArrayString extensionList;

    //If no extensions were specified
    if (extensions.IsEmpty()) {
        return extensionList;
    }
    wxStringTokenizer extList(extensions, _T(","));
    if (extList.CountTokens() == 0) { //If a single extensions was specified
        extensionList.Add(extensions.Trim().Trim(false));
    } else { //If multiple extensions were specified
        while (extList.HasMoreTokens()) {
            extensionList.Add(extList.GetNextToken().Trim().Trim(false));
        }
    }

    return extensionList;
}

int FileAnalyzer::GetFileCount()
{
    return _files->GetCount();
}

LineCount FileAnalyzer::GetTotalLines()
{
    LineCount total;
    total.empty = 0;
    total.comment = 0;
    total.normal = 0;
    for (int i = 0; i < _files->GetCount(); i++) {
        LineCount curFileLineCount = _files->Item(i).GetLineCount();
        total.empty += curFileLineCount.empty;
        total.comment += curFileLineCount.comment;
        total.normal += curFileLineCount.normal;
    }
    return total;
}

int OrderByExtensionAsc(File **item1, File **item2)
{
    // sort the items by their extensions

    return (*item1)->GetExtension().CmpNoCase((*item2)->GetExtension());
}

wxString FileAnalyzer::CreateReport()
{
    wxString exportText = _T("Line Stat Report\n-------------------------------\n\n");

    FileArray files_copy(*_files);

    files_copy.Sort(OrderByExtensionAsc);

    int totalNormal = 0, totalEmpty = 0, totalComment = 0, totalFiles = 0;

    wxString currentExtension;
    int curnormal = 0, curempty = 0, curcomment = 0, curnumberOfFiles = 0;

    for (int i = 0; i < files_copy.GetCount(); i++) {
        if (currentExtension != files_copy.Item(i).GetExtension()) {
            if (!currentExtension.IsEmpty()) {
                //Write the section of the report related to the previous extension
                exportText += wxString::Format(_T("-------------------------------\n%s files (%d)\n-------------------------------\nNormal Lines: %d\nComment Lines: %d\nEmpty Lines: %d\n-------------------------------\nTotal Lines: %d\n\n"), currentExtension.MakeUpper().c_str(), curnumberOfFiles, curnormal, curcomment, curempty, curnormal + curcomment + curempty);
                //Increment total variables
                totalNormal += curnormal;
                totalComment += curcomment;
                totalEmpty += curempty;
                totalFiles += curnumberOfFiles;
                //Reset variables
                curnormal = 0, curempty = 0, curcomment = 0, curnumberOfFiles = 0;
            }
            currentExtension = files_copy.Item(i).GetExtension();
        }
        LineCount currentFileLines = files_copy.Item(i).GetLineCount();
        curnormal += currentFileLines.normal;
        curempty += currentFileLines.empty;
        curcomment += currentFileLines.comment;
        curnumberOfFiles++;
    }
    //Write the section of the report related to the last group of extensions
    exportText += wxString::Format(_T("-------------------------------\n%s files (%d)\n-------------------------------\nNormal Lines: %d\nComment Lines: %d\nEmpty Lines: %d\n-------------------------------\nTotal Lines: %d\n\n"), currentExtension.MakeUpper().c_str(), curnumberOfFiles, curnormal, curcomment, curempty, curnormal + curcomment + curempty);
    totalNormal += curnormal;
    totalComment += curcomment;
    totalEmpty += curempty;
    totalFiles += curnumberOfFiles;
    //Finish by writing a summary of all extensions
    exportText += wxString::Format(_T("\n-------------------------------\nAll Files (%d)\n-------------------------------\nNormal Lines: %d\nComment Lines: %d\nEmpty Lines: %d\n-------------------------------\nTotal Lines: %d"), totalFiles, totalNormal, totalComment, totalEmpty, totalNormal + totalComment + totalEmpty);

    return exportText;
}
