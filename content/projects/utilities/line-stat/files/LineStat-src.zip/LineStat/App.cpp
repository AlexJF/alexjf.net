/***************************************************************
 * Name:      App.cpp
 * Purpose:   Code for Application Class
 * Author:    Alexandre Fonseca (alexandrejorgefonseca@gmail.com)
 * Created:   2008-07-02
 * Copyright: Alexandre Fonseca (http://revolt.hyperhub.info)
 * License:
 **************************************************************/

#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#include "App.h"

//(*AppHeaders
#include "MainFrame.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(App);

bool App::OnInit()
{
	//(*AppInitialize
	bool wxsOK = true;
	wxInitAllImageHandlers();
	if ( wxsOK )
	{
		MainFrame* Frame = new MainFrame(0);
		Frame->Show();
		SetTopWindow(Frame);
	}
	//*)
	return wxsOK;
}
