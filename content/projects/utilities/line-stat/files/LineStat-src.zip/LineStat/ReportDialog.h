#ifndef REPORTDIALOG_H
#define REPORTDIALOG_H

//(*Headers(ReportDialog)
#include <wx/sizer.h>
#include <wx/textctrl.h>
#include <wx/filedlg.h>
#include <wx/button.h>
#include <wx/dialog.h>
//*)

#include <wx/clipbrd.h>

class ReportDialog: public wxDialog
{
	public:

		ReportDialog(wxWindow* parent, const wxString &report);
		virtual ~ReportDialog();

		//(*Declarations(ReportDialog)
		wxButton* btn_File;
		wxFileDialog* dlg_SaveFile;
		wxTextCtrl* txt_Report;
		wxButton* btn_Close;
		//*)

	protected:

		//(*Identifiers(ReportDialog)
		static const long ID_TXT_REPORT;
		static const long ID_BTN_FILE;
		static const long ID_BTN_CLOSE;
		//*)

	private:

		//(*Handlers(ReportDialog)
		void OnClose(wxCommandEvent& event);
		void OnCopyToClipboard(wxCommandEvent& event);
		void OnSaveFile(wxCommandEvent& event);
		//*)

		DECLARE_EVENT_TABLE()
};

#endif
