/***************************************************************
 * Name:      MainFrame.h
 * Purpose:   Defines the Main Frame of the window
 * Author:    Alexandre Fonseca (alexandrejorgefonseca@gmail.com)
 * Created:   2008-07-02
 * Copyright: Alexandre Fonseca (http://revolt.hyperhub.info)
 * License:
 **************************************************************/
#ifndef MAINFRAME_H
#define MAINFRAME_H

//(*Headers(MainFrame)
#include <wx/listctrl.h>
#include <wx/sizer.h>
#include <wx/stattext.h>
#include <wx/menu.h>
#include <wx/panel.h>
#include <wx/filedlg.h>
#include <wx/bmpbuttn.h>
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/statusbr.h>
//*)

#include <wx/dynarray.h>
#include "FileAnalyzer.h"
#include "SearchDirDialog.h"
#include "ReportDialog.h"

WX_DEFINE_ARRAY_INT(int, wxIntArray);

class MainFrame: public wxFrame
{
	public:

		MainFrame(wxWindow* parent,wxWindowID id=wxID_ANY,const wxPoint& pos=wxDefaultPosition,const wxSize& size=wxDefaultSize);
		virtual ~MainFrame();

		//(*Declarations(MainFrame)
		wxButton* btn_Refresh;
		wxButton* btn_Report;
		wxFileDialog* dlg_SelectFile;
		wxMenuItem* mnu_AddFile;
		wxMenuItem* mnu_Exit;
		wxStaticText* lbl_CommentLines;
		wxStaticText* lbl_Totals;
		wxStaticText* lbl_FilesList;
		wxStaticText* lbl_EmptyLines;
		wxMenuItem* mnu_About;
		wxBitmapButton* btn_FileAdd;
		wxBitmapButton* btn_RemoveFiles;
		wxMenuItem* mnu_SearchDir;
		wxStaticText* lbl_TotalLines;
		wxPanel* pnl_Main;
		wxMenuItem* mnu_Report;
		wxBitmapButton* btn_SearchDir;
		wxStatusBar* StatusBar;
		wxListCtrl* lst_Files;
		wxMenu* HelpMenu;
		wxStaticText* lbl_NormalLines;
		wxMenuBar* MenuBar;
		//*)

        SearchDirDialog* dlg_SearchDir;

        FileAnalyzer* obj_FileAnalyzer;

	protected:

		//(*Identifiers(MainFrame)
		static const long ID_LBL_FILESLIST;
		static const long ID_LST_FILES;
		static const long ID_BTN_FILEADD;
		static const long ID_BTN_SEARCHDIR;
		static const long ID_BTN_REMOVEFILES;
		static const long ID_LBL_TOTALS;
		static const long ID_LBL_TOTALLINES;
		static const long ID_LBL_NORMALLINES;
		static const long ID_LBL_EMPTYLINES;
		static const long ID_LBL_COMMENTLINES;
		static const long ID_BTN_REPORT;
		static const long ID_BTN_REFRESH;
		static const long ID_PNL_MAIN;
		static const long ID_MNU_ADDFILE;
		static const long ID_MNU_SEARCHDIR;
		static const long ID_MNU_REPORT;
		static const long ID_STATUSBAR;
		//*)

	private:

		//(*Handlers(MainFrame)
		void OnAddFile(wxCommandEvent& event);
		void OnRefresh(wxCommandEvent& event);
		void OnSearchDirectory(wxCommandEvent& event);
		void OnRemoveFile(wxCommandEvent& event);
		void OnExport(wxCommandEvent& event);
		void OnListItemCountChanged(wxListEvent& event);
		void OnAbout(wxCommandEvent& event);
		void OnExit(wxCommandEvent& event);
		void OnGetReport(wxCommandEvent& event);
		//*)

		DECLARE_EVENT_TABLE()
		void AddFileToList(const wxString &filepath);
		void SetLineCounts(long index, const LineCount &lines);
		void UpdateCountLabels();
		void UpdateFileCount();
};

#endif
