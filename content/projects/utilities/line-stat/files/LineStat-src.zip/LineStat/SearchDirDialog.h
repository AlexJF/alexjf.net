/***************************************************************
 * Name:      SearchDirDialog.h
 * Purpose:   Defines a Dialog which allows a user to Search a Directory for files
 * Author:    Alexandre Fonseca (alexandrejorgefonseca@gmail.com)
 * Created:   2008-07-02
 * Copyright: Alexandre Fonseca (http://revolt.hyperhub.info)
 * License:
 **************************************************************/

#ifndef SEARCHDIRDIALOG_H
#define SEARCHDIRDIALOG_H

//(*Headers(SearchDirDialog)
#include <wx/sizer.h>
#include <wx/stattext.h>
#include <wx/textctrl.h>
#include <wx/spinctrl.h>
#include <wx/button.h>
#include <wx/dirdlg.h>
#include <wx/dialog.h>
//*)

#include <wx/msgdlg.h>

class SearchDirDialog: public wxDialog
{
	public:

		SearchDirDialog(wxWindow* parent);
		virtual ~SearchDirDialog();

		wxString GetDirectoryPath() { return _dirPath; }
		int GetDirectoryLvl() { return _dirLvl; }
		wxString GetExtensions() { return _ext; }

		//(*Declarations(SearchDirDialog)
		wxStaticText* lbl_Extensions;
		wxTextCtrl* txt_Directory;
		wxStaticText* lbl_SubDirLvl;
		wxTextCtrl* txt_Extensions;
		wxStaticText* lbl_Directory;
		wxStaticText* lbl_SearchLvlInfinite;
		wxSpinCtrl* spn_SubDirLvl;
		wxButton* btn_Directory;
		wxDirDialog* dirDlg;
		//*)

	protected:

		//(*Identifiers(SearchDirDialog)
		static const long ID_LBL_DIRECTORY;
		static const long ID_TXT_DIRECTORY;
		static const long ID_BTN_DIRECTORY;
		static const long ID_LBL_SUBDIRLVL;
		static const long ID_SPN_SUBDIRLVL;
		static const long ID_LBL_SEARCHLVLINFINITE;
		static const long ID_LBL_EXTENSIONS;
		static const long ID_TXT_EXTENSIONS;
		//*)

	private:

        wxString _dirPath;
        int _dirLvl;
        wxString _ext;

		//(*Handlers(SearchDirDialog)
		void OnSelectDir(wxCommandEvent& event);
		void OnClose(wxCloseEvent& event);
		//*)

		bool TransferDataFromWindow();

		DECLARE_EVENT_TABLE()
};

#endif
