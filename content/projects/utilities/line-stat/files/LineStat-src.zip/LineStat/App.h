/***************************************************************
 * Name:      App.h
 * Purpose:   Defines Application Class
 * Author:    Alexandre Fonseca (alexandrejorgefonseca@gmail.com)
 * Created:   2008-07-02
 * Copyright: Alexandre Fonseca (http://revolt.hyperhub.info)
 * License:
 **************************************************************/

#ifndef APP_H
#define APP_H

#include <wx/app.h>

class App : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // APP_H
