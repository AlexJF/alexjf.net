/***************************************************************
 * Name:      SearchDirDialog.cpp
 * Purpose:   Implements the SearchDirDialog
 * Author:    Alexandre Fonseca (alexandrejorgefonseca@gmail.com)
 * Created:   2008-07-02
 * Copyright: Alexandre Fonseca (http://revolt.hyperhub.info)
 * License:
 **************************************************************/
#include "SearchDirDialog.h"

//(*InternalHeaders(SearchDirDialog)
#include <wx/intl.h>
#include <wx/string.h>
//*)

#include <wx/dir.h>

//(*IdInit(SearchDirDialog)
const long SearchDirDialog::ID_LBL_DIRECTORY = wxNewId();
const long SearchDirDialog::ID_TXT_DIRECTORY = wxNewId();
const long SearchDirDialog::ID_BTN_DIRECTORY = wxNewId();
const long SearchDirDialog::ID_LBL_SUBDIRLVL = wxNewId();
const long SearchDirDialog::ID_SPN_SUBDIRLVL = wxNewId();
const long SearchDirDialog::ID_LBL_SEARCHLVLINFINITE = wxNewId();
const long SearchDirDialog::ID_LBL_EXTENSIONS = wxNewId();
const long SearchDirDialog::ID_TXT_EXTENSIONS = wxNewId();
//*)

BEGIN_EVENT_TABLE(SearchDirDialog,wxDialog)
	//(*EventTable(SearchDirDialog)
	//*)
END_EVENT_TABLE()

SearchDirDialog::SearchDirDialog(wxWindow* parent)
{
	//(*Initialize(SearchDirDialog)
	wxBoxSizer* BoxSizer2;
	wxBoxSizer* szr_HorContent;
	wxBoxSizer* BoxSizer1;
	wxBoxSizer* szr_VertMain;
	wxStdDialogButtonSizer* szr_DialogButtons;

	Create(parent, wxID_ANY, _("Search Directory"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE, _T("wxID_ANY"));
	SetMinSize(wxSize(200,100));
	szr_VertMain = new wxBoxSizer(wxVERTICAL);
	szr_HorContent = new wxBoxSizer(wxHORIZONTAL);
	lbl_Directory = new wxStaticText(this, ID_LBL_DIRECTORY, _("Directory:"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_LBL_DIRECTORY"));
	szr_HorContent->Add(lbl_Directory, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	txt_Directory = new wxTextCtrl(this, ID_TXT_DIRECTORY, wxEmptyString, wxDefaultPosition, wxSize(200,-1), 0, wxDefaultValidator, _T("ID_TXT_DIRECTORY"));
	szr_HorContent->Add(txt_Directory, 1, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
	btn_Directory = new wxButton(this, ID_BTN_DIRECTORY, _("..."), wxDefaultPosition, wxSize(26,23), 0, wxDefaultValidator, _T("ID_BTN_DIRECTORY"));
	szr_HorContent->Add(btn_Directory, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	szr_VertMain->Add(szr_HorContent, 0, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	BoxSizer1 = new wxBoxSizer(wxHORIZONTAL);
	lbl_SubDirLvl = new wxStaticText(this, ID_LBL_SUBDIRLVL, _("Subdirectory Search Level:"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_LBL_SUBDIRLVL"));
	BoxSizer1->Add(lbl_SubDirLvl, 0, wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
	spn_SubDirLvl = new wxSpinCtrl(this, ID_SPN_SUBDIRLVL, _T("0"), wxDefaultPosition, wxSize(55,21), 0, -1, 100, 0, _T("ID_SPN_SUBDIRLVL"));
	spn_SubDirLvl->SetValue(_T("0"));
	BoxSizer1->Add(spn_SubDirLvl, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	lbl_SearchLvlInfinite = new wxStaticText(this, ID_LBL_SEARCHLVLINFINITE, _("Infinite = -1"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_LBL_SEARCHLVLINFINITE"));
	BoxSizer1->Add(lbl_SearchLvlInfinite, 1, wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_VertMain->Add(BoxSizer1, 0, wxBOTTOM|wxLEFT|wxRIGHT|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	BoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
	lbl_Extensions = new wxStaticText(this, ID_LBL_EXTENSIONS, _("Extensions:"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_LBL_EXTENSIONS"));
	BoxSizer2->Add(lbl_Extensions, 0, wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
	txt_Extensions = new wxTextCtrl(this, ID_TXT_EXTENSIONS, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_TXT_EXTENSIONS"));
	txt_Extensions->SetToolTip(_("List of extensions delimited by commas"));
	BoxSizer2->Add(txt_Extensions, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	szr_VertMain->Add(BoxSizer2, 0, wxBOTTOM|wxLEFT|wxRIGHT|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_DialogButtons = new wxStdDialogButtonSizer();
	szr_DialogButtons->AddButton(new wxButton(this, wxID_OK, wxEmptyString));
	szr_DialogButtons->AddButton(new wxButton(this, wxID_CANCEL, wxEmptyString));
	szr_DialogButtons->Realize();
	szr_VertMain->Add(szr_DialogButtons, 0, wxBOTTOM|wxLEFT|wxRIGHT|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	SetSizer(szr_VertMain);
	dirDlg = new wxDirDialog(this, _("Select directory"), wxEmptyString, wxDD_DEFAULT_STYLE, wxDefaultPosition, wxDefaultSize, _T("wxDirDialog"));
	szr_VertMain->Fit(this);
	szr_VertMain->SetSizeHints(this);

	Connect(ID_BTN_DIRECTORY,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&SearchDirDialog::OnSelectDir);
	//*)

	_dirPath = wxEmptyString;
	_dirLvl = 0;
	_ext = wxEmptyString;
}

SearchDirDialog::~SearchDirDialog()
{
	//(*Destroy(SearchDirDialog)
	//*)
}

bool SearchDirDialog::TransferDataFromWindow()
{
    _dirPath = txt_Directory->GetLabel();
    _dirLvl = spn_SubDirLvl->GetValue();
    _ext = txt_Extensions->GetLabel();

    if (wxDir::Exists(_dirPath) == false) {
        wxMessageBox(_T("The directory you specified doesn't exist"));
        return false;
    } else {
        return true;
    }
}

void SearchDirDialog::OnSelectDir(wxCommandEvent& event)
{
    dirDlg->SetPath(txt_Directory->GetLabel());
    if (dirDlg->ShowModal() == wxID_OK) {
        txt_Directory->SetLabel(dirDlg->GetPath());
    }
}
