/***************************************************************
 * Name:      FileAnalyzer.h
 * Purpose:   Declares the FileAnalyzer class
 * Author:    Alexandre Fonseca (alexandrejorgefonseca@gmail.com)
 * Created:   2008-07-03
 * Copyright: Alexandre Fonseca (http://revolt.hyperhub.info)
 * License:
 **************************************************************/

#ifndef FILECOLLECTION_H_INCLUDED
#define FILECOLLECTION_H_INCLUDED

#include <wx/ffile.h>
#include <wx/tokenzr.h>
#include <wx/strconv.h>
#include <wx/dir.h>
#include <wx/file.h>
#include <wx/filename.h>
#include <wx/listctrl.h>
#include <wx/msgdlg.h>

struct LineCount {
    long normal;
    long empty;
    long comment;
};

class File {
    public:
        File(const wxString &filepath);
        virtual ~File();

        LineCount GetLineCount();
        void Refresh();

        bool Exists();

        wxString GetPath();

        wxString GetExtension();
        wxString GetName();
        wxString GetDirectory();

    private:
        wxString _filepath;
        LineCount _lines;
};

WX_DECLARE_OBJARRAY(File, FileArray); //Declares the FileArray object

class FileAnalyzer {
    public:
        FileAnalyzer();
        ~FileAnalyzer();

        //Allows the user to associate a list control that gets automatically updated with the contents of this class
        void AssociateListCtrl(wxListCtrl *listctrl);

        bool AddFile(const wxString &filepath);

        int GetIndex(const wxString &filepath);
        bool GetFile(File &ext_file_object, int index);

        void RemoveFile(int index);
        void RemoveFile(const wxString &filepath);
        void RemoveAll();

        void RefreshAllFiles();

        wxArrayString ParseExtensions(wxString extensions);
        void SearchDirectory(const wxString &dirPath, int subLvl, const wxArrayString &extensions, int curLvl = 0);

        int GetFileCount();
        LineCount GetTotalLines();
        wxString CreateReport();

    private:
        wxListCtrl *_listctrl;
        FileArray *_files;
};

#endif // FILECOLLECTION_H_INCLUDED
