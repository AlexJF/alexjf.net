#include "ReportDialog.h"

//(*InternalHeaders(ReportDialog)
#include <wx/intl.h>
#include <wx/string.h>
//*)

#include <wx/ffile.h>

//(*IdInit(ReportDialog)
const long ReportDialog::ID_TXT_REPORT = wxNewId();
const long ReportDialog::ID_BTN_FILE = wxNewId();
const long ReportDialog::ID_BTN_CLOSE = wxNewId();
//*)

BEGIN_EVENT_TABLE(ReportDialog,wxDialog)
	//(*EventTable(ReportDialog)
	//*)
END_EVENT_TABLE()

ReportDialog::ReportDialog(wxWindow* parent, const wxString &report)
{
	//(*Initialize(ReportDialog)
	wxBoxSizer* szr_Buttons;
	wxBoxSizer* szr_HorContent;
	wxBoxSizer* szr_VertMain;

	Create(parent, wxID_ANY, _("Report"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE|wxRESIZE_BORDER, _T("wxID_ANY"));
	szr_VertMain = new wxBoxSizer(wxVERTICAL);
	szr_HorContent = new wxBoxSizer(wxHORIZONTAL);
	txt_Report = new wxTextCtrl(this, ID_TXT_REPORT, wxEmptyString, wxDefaultPosition, wxSize(400,300), wxTE_MULTILINE|wxTE_DONTWRAP, wxDefaultValidator, _T("ID_TXT_REPORT"));
	szr_HorContent->Add(txt_Report, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 10);
	szr_VertMain->Add(szr_HorContent, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	szr_Buttons = new wxBoxSizer(wxHORIZONTAL);
	szr_Buttons->Add(20,-1,0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	btn_File = new wxButton(this, ID_BTN_FILE, _("Save to File"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BTN_FILE"));
	szr_Buttons->Add(btn_File, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	szr_Buttons->Add(-1,-1,1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	btn_Close = new wxButton(this, ID_BTN_CLOSE, _("Close"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BTN_CLOSE"));
	szr_Buttons->Add(btn_Close, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	szr_Buttons->Add(20,-1,0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
	szr_VertMain->Add(szr_Buttons, 0, wxBOTTOM|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
	SetSizer(szr_VertMain);
	dlg_SaveFile = new wxFileDialog(this, _("Select file"), wxEmptyString, wxEmptyString, _("*.txt"), wxFD_DEFAULT_STYLE|wxFD_SAVE|wxFD_OVERWRITE_PROMPT, wxDefaultPosition, wxDefaultSize, _T("wxFileDialog"));
	szr_VertMain->Fit(this);
	szr_VertMain->SetSizeHints(this);

	Connect(ID_BTN_FILE,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&ReportDialog::OnSaveFile);
	Connect(ID_BTN_CLOSE,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&ReportDialog::OnClose);
	//*)
	txt_Report->SetValue(report);
}

ReportDialog::~ReportDialog()
{
	//(*Destroy(ReportDialog)
	//*)
}


void ReportDialog::OnClose(wxCommandEvent& event)
{
    Close();
}

void ReportDialog::OnSaveFile(wxCommandEvent& event)
{
    if (dlg_SaveFile->ShowModal() == wxID_OK) {
        wxFFile file(dlg_SaveFile->GetPath(), _T("w"));
        if (file.IsOpened()) {
            file.Write(txt_Report->GetValue());
        }
    }
}
