import cql, time, uuid, random, string, baseclient
import sys

class CassandraTwitterClient(baseclient.TwitterClient):
    def __init__(self, user, nodeInfo, cluster = [], keyspace = 'twitter', port = 9160):
        super(CassandraTwitterClient,self).__init__(user, nodeInfo, cluster)
        self._port = port
        self._keyspace = keyspace

    def _tweet(self, tweetId = None, msg = None):
        latency1, followers = self._queryDb("""
            SELECT follower
            FROM Followers
            WHERE username = :name""",
            name = self.user)

        if tweetId is None:
            tweetId = uuid.uuid1()

        if msg is None:
            validChars = string.letters + string.digits + " "
            msg = "".join(
                [random.choice(validChars) for _ in range(random.randint(20, 140))])

        tweetQueries = [
            "BEGIN BATCH",
            """INSERT INTO Tweets (tweetid, username, body)\
            VALUES (:tweetId, :username, :body)""", 
            """INSERT INTO Userline (username, tweetid, body)\
            VALUES (:username, :tweetId, :body)"""]

        tweetQueries.extend(
            ["""INSERT INTO Timeline (username, tweetid, posted_by, body)\
                VALUES ('%s', :tweetId, :username, :body)""" % str(follower[0])
             for follower in followers])

        tweetQueries.append("APPLY BATCH")

        latency2, _ = self._queryDb("\n".join(tweetQueries), username = str(self.user), 
                tweetId = tweetId, body = str(msg))

        return (latency1 + latency2, (tweetId, msg, time.time()))

    def _getUserline(self, user):
            return self._queryDb("""
            SELECT dateOf(tweetid), body
            FROM Userline
            WHERE username = :name
            ORDER BY tweetid DESC
            LIMIT 50""",
            name = str(self.user))

    def _getTimeline(self):
            return self._queryDb("""
            SELECT dateOf(tweetid), posted_by, body
            FROM Timeline
            WHERE username = :name
            ORDER BY tweetid DESC
            LIMIT 50""",
            name = str(self.user))

    def _tweetFound(self, tweetId):
        _, result = self._queryDb("""
            SELECT tweetid
            FROM Tweets
            WHERE tweetid = :tweetId""",
            tweetId = tweetId)

        return bool(result)

    def _getUsernames(self):
        _, result = self._queryDb("SELECT username FROM Users")

        return [r[0] for r in result]

    def _queryDb(self, query, **kwargs):
        exception = None
        
        for endpoint in self.iterEndpoints():
            con = None
            cursor = None
            try:
                # consistency_level = LOCAL_QUORUM maybe?
                con = cql.connect(endpoint.publicIp, self._port, self._keyspace, 
                                 cql_version='3.0.0', consistency_level='ONE')
                cursor = con.cursor()
                time1 = time.time()
                cursor.execute(query, kwargs)
                results = cursor.fetchall()
                time2 = time.time()

                return (time2 - time1, results)
            except Exception:
                exception = sys.exc_info()
            finally:
                if cursor is not None:
                    cursor.close()
                if con is not None:
                    con.close()
                
        raise exception[1], None, exception[2]
