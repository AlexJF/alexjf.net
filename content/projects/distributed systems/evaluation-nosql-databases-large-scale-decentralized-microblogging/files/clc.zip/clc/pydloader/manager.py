import rpyc, paramiko, time, os
from boto import ec2
import nodeinfo
from nodeinfo import NodeInfo
import subprocess
import sys
from boto.ec2 import instance, blockdevicemapping
import copy
import random
import datetime
import threading
import uuid

remoteCLCDir = "/home/ec2-user/clc/"
slaveLaunchScript = os.path.join(remoteCLCDir, "launchWorkloadSlave.sh")
keyPair = None

ec2Regions = ['eu-west-1', 'us-east-1']
amiImageIds = {'eu-west-1': 'ami-07cfdf73', 
               'us-east-1': 'ami-ef354086'}

def setKeyPair(kp):
    global keyPair
    keyPair = kp

def partitionList(l, n):
    return [l[i:i+n] for i in range(0, len(l), n)]

def measureTime(fn):
    def wrapper(self, *args, **kwargs):
        time1 = time.time()
        result = fn(self, *args, **kwargs)
        time2 = time.time()
        return (time2 - time1, result)
    
    return wrapper

def ec2_launchInstances(regions, numZonesPerRegion, totalInstances, instanceType="t1.micro"):
    """
    Launches totalInstances instances over numZonesPerRegion zones over each
    region specified in regions.
    
    If divisions have remainders, preference will be given to first region (EU)
    and zone in each region. E.g: If 9 nodes are divided between 2 regions with
    2 zones each we end up with:
        - (0, 0) - 3 nodes
        - (0, 1) - 2 nodes
        - (1, 0) - 2 nodes
        - (1, 1) - 2 nodes
    
    Args:
        regions (list): List of region ids where to spawn instances.
        numZonesPerRegion (int): Number of zones per region where to spawn instances.
        totalInstances (int): Number of instances to spawn.
        type (str): Type of instances to spawn: t1.micro, m1.small, m1.medium, ...

    Returns:
        List of NodeInfo describing the endpoints of all connected instances.
    """
    
    if keyPair is None:
        print "Please set key pair name before calling this function"
        return

    launchingInstances = []
    connections = []
    
    if type(regions) is not list:
        regions = [regions]
        
    numberZones = numZonesPerRegion * len(regions)
    nodesPerZone, remainderNodes = divmod(totalInstances, numberZones)
    
    for region in regions:
        conn = ec2.connect_to_region(region)
        connections.append(conn)
        mapping = blockdevicemapping.BlockDeviceMapping()
        eph0 = blockdevicemapping.BlockDeviceType()
        eph1 = blockdevicemapping.BlockDeviceType()
        eph0.ephemeral_name = 'ephemeral0'
        eph1.ephemeral_name = 'ephemeral1'
        mapping['/dev/sdb'] = eph0
        mapping['/dev/sdc'] = eph1
        for zone in [region + chr(ord('a') + i) for i in range(numZonesPerRegion)]:
            for i in range(nodesPerZone):
                reservation = conn.run_instances(amiImageIds[region], key_name=keyPair,
                    instance_type=instanceType, security_groups=['default'], 
                    placement = zone, block_device_map = mapping)
                launchingInstances.append(reservation.instances[0])
                
    if remainderNodes > 0:
        zone = region + "a"
        reservation = conn.run_instances(amiImageIds[regions[0]], key_name=keyPair,
            instance_type=instanceType, security_groups=['default'], 
            placement = zone, block_device_map = mapping)
        launchingInstances.append(reservation.instances[0])
                
    launchedInstances = []
                
    # Wait until each instance reports as running
    for instance in launchingInstances:
        while instance.state != 'running':
            time.sleep(5)
            instance.update()
        launchedInstances.append(NodeInfo(instance.id, instance.placement, 
                                          instance.ip_address, instance.private_ip_address))
            
    # We don't need the connections anymore
    for connection in connections:
        connection.close()
        
    # Wait for OS boot and SSHD loading
    time.sleep(30)
    
    return launchedInstances

def ec2_applyToInstanceList(fun, regions = None):
    """
    Applies a function to all known EC2 instances in 1 or more regions.
    
    Args:
        fun (void f(boto.ec2.instance)) - Function to apply on each instance.
        regions (Optional list) - List of region names on which to apply
            the function. Defaults to all.
    
    Returns:
        List of instances (boto.ec2.instance)
    """
    
    if regions is None:
        regions = ec2Regions
        
    for region in regions:
        conn = ec2.connect_to_region(region)
        reservations = conn.get_all_instances()
        
        for reservation in reservations:
            for instance in reservation.instances:
                fun(instance)
                
def ec2_getInstanceNodeInfos(keys = None, regions = None):
    """
    Return a list of NodeInfo objects associated with running instances.
    
    Args:
        regions (Optional list) - List of instance regions of interest.
        
    Returns:
        List of NodeInfo objects for each running instance.
    """
    
    nodeInfos = []
    
    def instanceToNodeInfo(instance):
        if instance.state != "running":
            return
        if keys is not None and instance.key_name != keys:
            return
        nodeInfos.append(NodeInfo(instance.id, instance.placement, instance.ip_address, instance.private_ip_address))
        
    ec2_applyToInstanceList(instanceToNodeInfo, regions)
    
    return nodeInfos
        
                
def ec2_listInstances(regions = None):
    """
    List information about known EC2 instances in 1 or more regions.
    
    Args:
        regions (Optional list) - List of instance regions of interest.
    """
    
    def printInstance(instance):
        printInstance.foundInstances = True
        print("| %12s | %12s | %12s | %12s | %12s |" % (instance.id, instance.placement, instance.state, instance.instance_type, instance.key_name))
        
    printInstance.foundInstances = False
        
    print("| %12s | %12s | %12s | %12s | %12s |" % ("ID", "Zone", "State", "Type", "Key"))
    ec2_applyToInstanceList(printInstance, regions)
    
    if not printInstance.foundInstances:
        print("No instances found")

def ec2_terminateInstances(keys = None, instances = None):
    """
    Terminates the specified EC2 instances.
    
    Args:
        instances (Optional list) - List of instance ids to terminate.
            If not provided, terminate all running instances.
    """
    
    def terminateInstance(instance):
        if keys is not None and instance.key_name != keys:
            return
        if instances is None or instance.id in instances:
            instance.terminate()
        
    ec2_applyToInstanceList(terminateInstance)

def createSlaves(hosts, sshport = 22, rpcport = 25000, 
        username = 'ec2-user', password = ''):
    """
    Facilitates the creation of a slave list based on different hosts with
    same settings.

    Args:
        hosts (list): List of hostnames or NodeInfo where each slave will be instanced.

    KArgs:
        sshport (int): SSH port to be used by all slaves.
        rpcport (int): RPC port to be used by all slaves.
        username (str): Username to be used during SSH connection.
        password (str): Password to be used during SSH connection (either as
                        passphrase or password for private key if one can be 
                        used).

    Returns:
        A list of RemoteSlave objects.
    """
    
    remoteSlaves = []
    
    for host in hosts:
        if type(host) is NodeInfo:
            host = host.publicIp
            
        remoteSlaves.append(RemoteSlave(host, sshport, rpcport, username, password))

    return remoteSlaves

def slavesToNodeInfo(slaves):
    """
    Retrieves a list of NodeInfos from a set of slaves.
    
    Args:
        slaves (list of RemoteSlaves): Slaves from which to get NodeInfos.
        
    Returns:
        List of NodeInfos, one for each slave.
    """
    
    return [copy.deepcopy(s.nodeInfo) for s in slaves]

def setupCassandraCluster(slaves, normalized = False):
    """
    Sets up a Cassandra cluster using the provided slaves.
    
    Args:
        slaves (list of RemoteSlaves) - Slaves that are to form part of the
            Cassandra cluster.
    """
    
    seeds = {}
    seedInfos = []
    seedSlaves = []
    numNodesPerRegion = {region: 0 for region in ec2Regions}
    
    def setupCassandra(slave):
        if normalized:
            slave.chooseDatabase("cassandranorm")
        else:
            slave.chooseDatabase("cassandra")
        db = slave.database
        
        db.setup(seedInfos, {region[:-2]: min(3, num, int(num / 2) + 1) for region, num in numNodesPerRegion.items()})
        db.start()
    
    # Choose seeds, 1 per zone
    for slave in slaves:
        slaveNodeInfo = slave.nodeInfo
        slaveNodeRegion = slaveNodeInfo.region
        slaveNodeZone = slaveNodeInfo.zone
        
        numNodesPerRegion[slaveNodeRegion] += 1
        
        if slaveNodeZone not in seeds:
            seeds[slaveNodeZone] = slaveNodeInfo
            seedSlaves.append(slave)
            
    seedInfos.extend([s.nodeInfo for s in seedSlaves])
    
    map(setupCassandra, seedSlaves)
            
    # Have each slave setup and start the cassandra service
    map(setupCassandra, [s for s in slaves if s not in seedSlaves])
    
def setupCouchbaseCluster(slaves, ramQuota=None, type=1):
    """
    Sets up a Couchbase cluster using the provided slaves.
    
    Args:
        slaves (list of RemoteSlaves) - Slaves that are to form part of the
            Cassandra cluster.
        sqliteDb (str) - Name of SQLite database from which to populate data.
    """
    
    if len(slaves) < 1:
        return
        
    # Split into groups according to their regions
    groups = {}
    for slave in slaves:
        region = slave.nodeInfo.region
        if region in groups:
            groups[region].append(slave)
        else:
            groups[region] = [slave]
    
    # Setting up clusters
    for region in groups.keys():
        slavesList = groups[region]
        print "Region: %s" % region
        for slave in slavesList:
            slave.chooseDatabase("couchbase", ramQuota=ramQuota, type=type)
            db = slave.database
            nodeInfo = str(slave.nodeInfo)
            print "Setting up server %s" % nodeInfo
            res = db.setup()
            print "Server %s set up: %s" % (nodeInfo, str(res))
    
        # one node adds others
        print "Adding nodes to cluster"
        peerInfos = [slave.nodeInfo for slave in slavesList[1:]]
        res = slavesList[0].database.start(peerInfos)
        print "Nodes added to cluster: %s" % str(res)
    
def setupMongoCluster(slaves):
    """
    Sets up a MongoDB cluster using the provided slaves.
    
    Args:
        slaves (list of RemoteSlaves) - Slaves that are to form part of the
            MongoDB cluster.
        sqliteDb (str) - Name of SQLite database from which to populate data.
    """
    
    clusterInfo = {'configNodes': [], 'shards': []}
    
    def setupMongo(slave):
        slave.chooseDatabase("mongodb")
        slave.database.setup(clusterInfo)
        
    def startMongo(slave):
        slave.database.start()
    
    if len(slaves) / 3 != 0.:
        print("Need a number of slaves multiple of 3 for Mongo")
    
    slavesPerRegion = {region: [] for region in ec2Regions}
    
    for slave in slaves:
        slaveNodeInfo = slave.nodeInfo
        slaveNodeRegion = slaveNodeInfo.region
        
        slavesPerRegion[slaveNodeRegion].append(slaveNodeInfo)
        
    clusterInfo['configNodes'] = [slaves[0] for _, slaves in slavesPerRegion.items() if len(slaves) > 0]
    
    slaveLists = slavesPerRegion.values()
        
    for i in range(len(slaves) / 3):
        shardName = "rs%d" % i
        shardMembers = []
        
        for _ in range(3):
            fullestList = max(slaveLists, key = lambda l: len(l))
            
            shardMembers.append(fullestList.pop())
        
        clusterInfo['shards'].append((shardName, shardMembers))
            
    # Have each slave setup and start the mongo service
    map(setupMongo, slaves)
    map(startMongo, slaves)
      
@measureTime
def populateDatabaseCluster(slaves, datasetId, sqliteDb, replicas=None, type=None):
    """
    Populates a previously set up database cluster using the data
    provided by the specified SQLite database and with the specified id.
    
    Args:
        slaves (list of RemoteSlaves) - List of slaves running the database cluster.
        datasetId (str) - Identifier for this dataset (in our case, 'twitter' or 'wikipedia').
            Valid identifiers are those for which a folder named '<datasetId>-data' exists
            in the root of the pydloader project.
        sqliteDb (str) - Filename of the database from which to get data.
        
    Returns:
        A pair (Time taken by the operation, None)
    """
    if replicas is None:
        slaves[0].database.populate(datasetId, sqliteDb)
    else:
        # Split into groups according to their regions
        groups = {}
        for slave in slaves:
            region = slave.nodeInfo.region
            if region in groups:
                groups[region].append(slave)
            else:
                groups[region] = [slave]
        
        # Populate data for each cluster
        for region in groups.keys():
            print "Region: %s" % region
            groups[region][0].database.populate(datasetId, sqliteDb, replicas=replicas, type=type)
    
def terminateDatabaseCluster(slaves):
    """
    Terminates a database cluster (off any type) running in the specified
    set of slaves.
    
    Args:
        slaves (list of RemoteSlaves) - Slaves running the database cluster 
            to terminate.
    """
    
    def stopAndCleanup(slave):
        db = slave.database
        db.stop()
        db.cleanup()
    
    map(stopAndCleanup, slaves)
    
def constructDatabaseInfoDict(slaves):
    """
    Constructs a database dict that can be sent to the remote startExperiments.
    
    Args:
        slaves (list of RemoteSlaves) - Slaves running the database cluster.
    
    Returns:
        Dict {'type': '<DBType>', 'cluster': [<NodeInfo0>, <NodeInfo1>, ...]}
    """
    
    return {'type': slaves[0].database.type,
            'cluster': [copy.deepcopy(s.nodeInfo) for s in slaves]}
    
def runTwitterExperimentWithCrash(dbSlaves, workloadSlaves, numUsers, experimentTime, 
                                  secondsToCrash, slavesToCrash,
                                  secondsToRecovery, slavesToRecover):
    """
    Same as runTwitterExperiment but introduce a crash after a specified time
    on the specified nodes with an optional recovery some time after.
    
    Args:
        dbSlaves (list of RemoteSlaves) - Slaves running the database cluster.
        worloadSlaves (list of RemoteSlaves) - Slaves that will generate the workload.
        numUsers (int) - Number of users to run in total (they will be spread equally
            between the workload slaves).
        experimentTime (int) - Number of seconds to run the experiment for.
        secondsToCrash (int) - Number of seconds till crash.
        slavesToCrash (list of RemoteSlaves) - Slaves which will crash.
        secondsToRecovery (int) - Number of seconds till recovery starting from crash.
        slavesToRecover (list of RemoteSlaves) - Slaves which will recover from crash.
    """
    
    def recover(nonCrashNodeInfos, slavesToRecover):
        print("Recovery started")
        #for slave in slavesToRecover[:-1]:
        #    slave.database.recover(nonCrashNodeInfos=nonCrashNodeInfos, last=False)
        #if len(slavesToRecover) > 0:
        #    slave = slavesToRecover[-1]
        #    slave.database.recover(nonCrashNodeInfos=nonCrashNodeInfos, last=True)
        print("Recovery activated")
    
    def crash(nonCrashNodeInfos, slavesToCrash, secondsToRecovery, slavesToRecover):
        print("Crash started")
        #for slave in slavesToCrash:
        #    slave.database.crash()
        print("Crash occurred")
            
        t = threading.Timer(secondsToRecovery, recover, [nonCrashNodeInfos, slavesToRecover])
        t.start()
    
    # List of non-crash nodes
    nonCrashNodeInfos = []
    for slave in dbSlaves:
        if slave not in slavesToCrash:
            nonCrashNodeInfos.append(slave.nodeInfo)
    if len(nonCrashNodeInfos) < 1:
        print "Please allow at least one non-crash node"
        return        
    
    t = threading.Timer(secondsToCrash, crash, [nonCrashNodeInfos, slavesToCrash, secondsToRecovery, slavesToRecover])
    t.start()
    return runTwitterExperiment(dbSlaves, workloadSlaves, numUsers, experimentTime)
        
    
def runTwitterExperiment(dbSlaves, workloadSlaves, numUsers, experimentTime):
    """
    Run a twitter experiment in the database cluster managed by the dbSlaves,
    using as workload generators the workloadSlaves, with up to numUsers
    simultaneous users.
    
    Args:
        dbSlaves (list of RemoteSlaves) - Slaves running the database cluster.
        worloadSlaves (list of RemoteSlaves) - Slaves that will generate the workload.
        numUsers (int) - Number of users to run in total (they will be spread equally
            between the workload slaves).
        experimentTime (int) - Number of seconds to run the experiment for.
    Returns:
        List of Dict {'experimentTime': <ExperimentTime>, 'results': <Results>}
        (one dict per slave).
    """
    
    databaseDict = constructDatabaseInfoDict(dbSlaves)
    usersPerWorkloadSlave = numUsers / len(workloadSlaves)
    
    twitterClient = workloadSlaves[0].getTwitterClient(databaseDict, 'manager')
    userList = copy.deepcopy(twitterClient.getUsernames())
    userList.sort()
    userList = userList[:numUsers]
    userAssignments = partitionList(userList, usersPerWorkloadSlave)
    
    experimentId = datetime.datetime.utcnow().strftime("%Y-%m-%d/%H-%M-%S")
    
    return remoteCallOnSlaves(workloadSlaves, "startTwitterExperiment",
        [[databaseDict, userAssignments[i], experimentTime, experimentId] 
         for i in range(len(workloadSlaves))])
    
def runTwitterWaitExperiment(dbSlaves, workloadSlaves):
    """
    Run a twitter wait experiment in the database cluster managed by the dbSlaves,
    by posting a tweet and checking how long it takes until all slaves detect it.
    
    Args:
        dbSlaves (list of RemoteSlaves) - Slaves running the database cluster.
        worloadSlaves (list of RemoteSlaves) - Slaves that will wait for result.
        
    Returns:
        Dictionary containing results of each slave (in the form of a tuple 
        (elapsedTime, localTime)) indexed by instance id.
    """
    
    databaseDict = constructDatabaseInfoDict(dbSlaves)
    
    mainSlave = random.choice(workloadSlaves)
    print("Main slave: %s" % str(mainSlave.nodeInfo))
    twitterClient = mainSlave.getTwitterClient(databaseDict, 'manager')
    tweetId = uuid.uuid1()
    timesOfDetection = {}
    
    def askSlavesToWaitForTweet():
        print("Warming up slaves and making them wait for the tweet")
        results = remoteCallOnSlaves(workloadSlaves, "twitterWaitForTweet",
                [[databaseDict, tweetId] for _ in workloadSlaves])
        print("Got response from slaves")
        for nodeId, result in results.items():
            timesOfDetection[nodeId] = result[1]
            
    t = threading.Thread(target = askSlavesToWaitForTweet)
    t.start()
            
    # Wait 10 seconds for the slaves to warm up ;P
    time.sleep(10)
    print("Slaves should be warmed up now")
    
    _, results = twitterClient.tweet(tweetId = tweetId)
    tweetTime = results[2]
    print("Tweet sent!")
    
    print("Joining...")
    t.join()
    
    return {nodeId: detectTime - tweetTime for nodeId, detectTime in timesOfDetection.items()}
    
def runWikiExperiment(dbSlaves, workloadSlaves, numUsers, experimentTime):
    """
    Run a wikipedia experiment in the database cluster managed by the dbSlaves,
    using as workload generators the workloadSlaves, with up to numUsers
    simultaneous users.
    
    Args:
        dbSlaves (list of RemoteSlaves or dict) - List of slaves running the database 
            cluster or a dict describing the database info.
        worloadSlaves (list of RemoteSlaves) - Slaves that will generate the workload.
        numUsers (int) - Number of users to run in total (they will be spread equally
            between the workload slaves).
        experimentTime (int) - Number of seconds to run the experiment for.
    Returns:
        List of Dict {'experimentTime': <ExperimentTime>, 'results': <Results>}
        (one dict per slave).
    """
    
    if type(dbSlaves) is dict:
        databaseDict = dbSlaves
    else:
        databaseDict = constructDatabaseInfoDict(dbSlaves)
        
    usersPerWorkloadSlave = numUsers / len(workloadSlaves)
    
    userList = [str(i) for i in range(numUsers)]
    random.shuffle(userList)
    userAssignments = partitionList(userList, usersPerWorkloadSlave)
    
    experimentId = datetime.datetime.utcnow().strftime("%Y-%m-%d/%H-%M-%S")
    
    return remoteCallOnSlaves(workloadSlaves, "startWikiExperiment",
        [[databaseDict, userAssignments[i], experimentTime, experimentId] 
         for i in range(len(workloadSlaves))])
    
def runWikiWaitExperiment(dbSlaves, workloadSlaves):
    """
    Run a wikipedia wait experiment in the database cluster managed by the dbSlaves,
    by posting an article and checking how long it takes until all slaves detect it.
    
    Args:
        dbSlaves (list of RemoteSlaves) - Slaves running the database cluster.
        worloadSlaves (list of RemoteSlaves) - Slaves that will wait for result.
        
    Returns:
        Dictionary containing results of each slave (in the form of a tuple 
        (elapsedTime, localTime)) indexed by instance id.
    """
    
    if type(dbSlaves) is dict:
        databaseDict = dbSlaves
    else:
        databaseDict = constructDatabaseInfoDict(dbSlaves)
    
    wikiClient = random.choice(workloadSlaves).getWikiClient(databaseDict, 'manager')
    _, articleId = wikiClient.edit()
    
    return remoteCallOnSlaves(workloadSlaves, "wikiWaitForArticle",
        [[databaseDict, articleId] for _ in workloadSlaves])

def localCallOnSlaves(slaves, functionName, *args):
    """
    Calls the provided function with the provided args on all provided slaves.

    Args:
        slaves (list): List of RemoteSlave objects in which to call a function.
        functionName (str): Name of the function to call.
        *args (list): List of arguments to provide to the function call

    Returns:
        A dictionary with the result of each call in the format {host, result}.
    """

    results = {}

    for slave in slaves:
        results[slave.host] = getattr(slave, functionName)(*args)

def remoteCallOnSlaves(slaves, functionName, args):
    """
    Calls the provided remote function with the provided args on all provided
    slaves.

    Note: Function is called asynchronously in all slaves.

    Args:
        slaves (list): List of RemoteSlave objects in which to call a function.
        functionName (str): Name of the function to call.
        *args (list): List of lists of arguments to provide to the function call.
            len(args) should be equal to len(slaves) and each args[i] is the list
            of args to pass to slave i.

    Returns:
        A dictionary with the result of each call in the format {host, result}.
    """

    asyncFunctions = []
    asyncResults = {}
    results = {}

    for i, slave in enumerate(slaves):
        function = getattr(slave, functionName)
        asyncFunction = rpyc.async(function)
        slaveNodeId = slave.nodeInfo.id
        asyncResults[slaveNodeId] = asyncFunction(*(args[i]))
        asyncFunctions.append(asyncFunction)
        
    print("Asyncs sent")

    while len(results) != len(asyncResults):
        for nodeId, asyncResult in asyncResults.iteritems():
            if asyncResult.ready:
                results[nodeId] = asyncResult.value
        time.sleep(0.1)

    return results

class RemoteSlave(object):
    @property
    def host(self):
        return self._host

    @host.setter
    def host(self, value):
        if self.connected:
            raise Exception("Already connected")
        self._host = value

    @property
    def sshPort(self):
        return self._sshport

    @sshPort.setter
    def sshPort(self, value):
        if self.connected:
            raise Exception("Already connected")
        self._sshport = value

    @property
    def rpcPort(self):
        return self._rpcport

    @rpcPort.setter
    def rpcPort(self, value):
        if self.connected:
            raise Exception("Already connected")
        self._rpcport = value

    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, value):
        if self.connected:
            raise Exception("Already connected")
        self._username = value

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        if self.connected:
            raise Exception("Already connected")
        self._password = value

    @property
    def connected(self):
        return not self._conn.closed if self._conn is not None else False

    def __init__(self, host, sshport = 22, rpcport = 25000, 
            username = 'pydloader', password = ''):
        self._host = host
        self._sshport = sshport
        self._rpcport = rpcport
        self._username = username
        self._password = password
        self._conn = None

    def __del__(self):
        self.kill()

    def __dir__(self):
        d = dir(self.__class__)

        if self.connected:
            d.extend(dir(self._conn.root))

        return sorted(d)

    def __getattr__(self, name):
        if self._conn is None or self._conn.closed:
            try:
                self.launch()
            except Exception:
                raise AttributeError

        return getattr(self._conn.root, name)

    def __str__(self):
        return "RemoteSlave@%s (%s)" % \
            (self._host, "UP" if self.connected else "DOWN")

    def _repr_pretty_(self, p, cycle):
        p.text(repr(self))

    def __repr__(self):
        return str(self)
    
    def reconnect(self):
        if self._conn is not None:
            self._conn.close()
        
        self._conn = None
        
        self.launch()

    def launch(self):
        if self._conn is not None and not self._conn.closed:
            return

        try:
            self._connect()
        except Exception:
            self.updateRemoteFiles()
            self._spawn()
            time.sleep(3)
            self._connect()

    def kill(self):
        if self.connected:
            self._conn.close()
            self._bgsrv.stop()
        self._conn = None
        self._bgsrv = None
        self._sshExec("sudo ps -C 'python slave.py' -o pid --no-headers | sudo xargs kill")

    def _connect(self):
        self._conn = rpyc.connect(self._host, self._rpcport, config = 
                                  {"allow_all_attrs" : True,
                                   "allow_pickle" : True})
        self._bgsrv = rpyc.BgServingThread(self._conn)
        
    def updateRemoteFiles(self):
        print("Updating remote files")
        result = subprocess.call("rsync -az --include 'pydloader/' --include 'twitter-data/' --include 'pydloader/**' --include 'twitter-data/**' --include '*.sh' --exclude '*' -e 'ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -p %d' ../ %s@%s:%s" % 
                        (self._sshport, self._username, self._host, remoteCLCDir), shell=True)
        
        if result != 0:
            sys.stderr.write("Failed to update remote code: %d\n" % result)
            
    def syncRemoteLogs(self):
        result = subprocess.call("rsync -az -e 'ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -p %d' %s@%s:%spydloader/logs/ ../logs/" %
                        (self._sshport, self._username, self._host, remoteCLCDir), shell=True)
        
        if result != 0:
            sys.stderr.write("Failed to sync remote logs with code: %d" % result)

    def _spawn(self):
        self._sshExec("sudo %s" % slaveLaunchScript)

    def _sshExec(self, command):
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(self._host, self._sshport, self._username, self._password)
        try:
            channel = client.get_transport().open_session()
            channel.get_pty()
            print(command)
            channel.exec_command(command)
            
            stdout_data = []
            stderr_data = []
            
            while True:
                if channel.recv_ready():
                    stdout_data.append(channel.recv(4096))
                if channel.recv_stderr_ready():
                    stderr_data.append(channel.recv_stderr(4096))
                if channel.exit_status_ready():
                    break
            
            print 'exit status: ', channel.recv_exit_status()
            print ''.join(stdout_data)
            print ''.join(stderr_data)
            
            channel.close()
        finally:
            client.close()

