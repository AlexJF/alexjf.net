HOST = "localhost"
PORT = "8091"
ADM_USERNAME = "Admin"
ADM_PASSWORD = "password"

BUCKETS_API = "/pools/default/buckets"

BUCKET_NAME = "cbclc"
BUCKET_PORT = 11222
BUCKET_MIN_RAM = 100

LIMIT = 50

WIKI_DESIGN = "wiki"
VIEW_WIKI = "wiki"

WIKI_DOC = {"views":
                {"wiki":
                    {"map":
"function (doc, meta) {\n\
  emit(meta.id, null);\n\
}",
                    "reduce":"_count"}}, 
            "options": 
                {"updateInterval": 5000, "updateMinChanges": 10, "replicaUpdateMinChanges": 20}}