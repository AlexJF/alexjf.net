from couchbase import Couchbase
from couchbase.admin import Admin
import sqlite3
import subprocess, json, os, uuid
import twitter.cbsettings as s
import wikipedia.cbsettings as sw
from database import Database
import time

path = "/media/ephemeral0/couchbase"
data_path = "%s/data" % path
index_path = "%s/index" % path

#cb_home = "/Applications/Couchbase\ Server.app/Contents/Resources/couchbase-core/bin"
#clc_home_dir = "/Users/Casey/BitBucket/clc"

cb_home = "/opt/couchbase/bin"
clc_home_dir = "/home/ec2-user/clc"

class CouchbaseDatabase(Database):
    def __init__(self, nodeInfo, ramQuota, type=1):
        super(CouchbaseDatabase,self).__init__("couchbase%d" % type, nodeInfo)
        self._serverIP = nodeInfo.publicIp
        self._serverPrivateIP = nodeInfo.privateIp
        if ramQuota is None or ramQuota < s.BUCKET_MIN_RAM:
            self._ramQuota = s.BUCKET_MIN_RAM
        else:
            self._ramQuota = ramQuota
        self._admin = None
        
    
    def setup(self):
        """
        Setup Couchbase Server:
        - Start Couchbase
        - node-init
        - cluster-init
        
        """
        if not os.path.isdir(data_path):
            os.makedirs(data_path)
            os.chmod(data_path, 0777)
            os.chmod(path, 0777)
        if not os.path.isdir(index_path):
            os.makedirs(index_path)
            os.chmod(index_path, 0777)
            
        # start couchbase-server
        subprocess.call("service couchbase-server start", shell=True)
        time.sleep(10)
        
        # Init node: set data & index paths
        content = "path=%s&index_path=%s" % (data_path, index_path)
        rawRes = self._admin_request("/nodes/self/controller/settings", content, "POST")
        result = str(rawRes) + "\n"
        
        # Init node: set username & password
        rawRes = self._admin_request("/settings/web", "username=%s&password=%s&port=%s" % (s.ADM_USERNAME, s.ADM_PASSWORD, s.PORT), "POST")
        result = result + str(rawRes) + "\n"
        
        # Init node: set mem quota 
        rawRes = self._admin_request("/pools/default", "memoryQuota=%d" % self._ramQuota, "POST")
        result = result + str(rawRes) + "\n\n"
        
        return result
                
                         
    def cleanup(self):
        """
        Cleanup stored data on local couchbase node:
        - Remove data & index under data_path 
        """
        subprocess.call("rm -rf %s/*" % path, shell = True)
    
    
    def start(self, peerInfos):
        """
        Start Couchbase service: (should only be called by the "leader")
        - Add all servers into cluster
        - Call rebalance
        
        Args:
            peerIndos ([NodeInfo]) - Infos about other servers that should be added to this cluster
        """
        
        # add others
        result = ""
        for info in peerInfos:
            serverIP = info.publicIp
            content = "hostname=%s&user=%s&password=%s" % (serverIP, s.ADM_USERNAME, s.ADM_PASSWORD)
            rawRes = self._admin_request("/controller/addNode", content, "POST")
            result = result + str(rawRes) + "\n"
            
        self.rebalance()
        return result
        
    
    def stop(self):
        """
        Stop Couchbase Server on this node:
        - Remove it from the cluster/rebalance (will make it slower but it will also work 
                when we are removing only this server and not shutting down the whole cluster)
        * COMMENTED
        - Stop Couchbase Server
        * Stop & restart CB server will result in a very long warmup period.
        So bear that in mind when you call this.
        """
        #subprocess.call("%(dir)s/couchbase-cli rebalance \
        #            -c %(ip)s:%(port)s -u %(u)s -p %(pw)s\
        #            --server-remove=%(ip)s:%(port)s" % {'dir': cb_home, 
        #            'ip': self._serverIP, 'port': s.PORT, 'u': s.ADM_USERNAME, 
        #            'pw': s.ADM_PASSWORD}, shell=True)
        subprocess.call("service couchbase-server stop", shell=True)

    def rebalance(self):
        subprocess.call("%(dir)s/couchbase-cli rebalance \
                    -c %(cip)s:%(port)s -u %(u)s -p %(pw)s" % {'dir': cb_home, 
                    'cip': self._serverIP, 'port': s.PORT, 'u': s.ADM_USERNAME, 
                    'pw': s.ADM_PASSWORD}, shell=True)
                    
    #def failover(self):
    #    rawRes = self._admin_request("/controller/failOver", "otpNode=127.0.0.1:%s" % s.PORT, "POST")
    #    return str(rawRes)
        
    def failover(self):
        subprocess.call("%(dir)s/couchbase-cli failover \
                    -c %(ip)s:%(port)s -u %(u)s -p %(pw)s \
                    --server-failover=%(ip)s:%(port)s" % {'dir': cb_home, 
                    'ip': self._serverPrivateIP, 'port': s.PORT, 'u': s.ADM_USERNAME, 
                    'pw': s.ADM_PASSWORD}, shell=True)
                    
    def crash(self):
        self.failover()
        #self.stop()
        
    def recover(self, nonCrashNodeInfos=None, last=False):
        if nonCrashNodeInfos is None or len(nonCrashNodeInfos) < 1:
            return
            
        #self.cleanup()
        #self.setup()
    
        # Just take the first one in the alive list
        clusterIP = nonCrashNodeInfos[0].publicIp
        subprocess.call("%(dir)s/couchbase-cli server-readd \
                    -c %(cip)s:%(p)s --server-add=%(sip)s:%(p)s \
                    -u %(u)s -p %(pw)s --server-add-username=%(u)s \
                    --server-add-password=%(pw)s" % {'dir': cb_home, 
                    'cip': clusterIP, 'p': s.PORT, 'u': s.ADM_USERNAME, 
                    'pw': s.ADM_PASSWORD, 'sip': self._serverIP}, shell=True)
        # If I am the last to be added, run rebalance
        if last:
            self.rebalance()

    def _admin_request(self, path, content, method, content_type="application/x-www-form-urlencoded"):
        if self._admin is None:
            self._admin = Admin(s.ADM_USERNAME, s.ADM_PASSWORD, host=self._serverIP) 
        return self._admin.http_request(path, content=content, method=method, content_type=content_type)
                
    def populate(self, datasetId, sqliteDatabase, replicas=0, type=None):
        """
        Populates data for this cluster using the provided database.
        
        Args:
            datasetId (str) - An identifier for the dataset.
            sqliteDatabase (str) - Name of the database to use for populating data for this cluster.
            nodeInfos (list of all nodes' info) - Used to lower warmup threshold. Will not set this 
                     threshold if the param is not provided (NOT IMPLEMENTED)
            replicas (int) - replication factor
        """
        
        if type is not None:
            self._type = "couchbase%d" % type
            
        if replicas > 3:
            replicas = 3
        
        # Check if bucket exist
        exist = False
        resp = self._admin_request("/pools/default/buckets", "", "GET")
        for bucket in resp.value:
            if bucket["name"] == s.BUCKET_NAME:
                exist = True
            else:
                # Delete any other buckets
                self._admin_request(bucket["uri"], "", "DELETE")                
                
        # Create bucket
        if exist is not True:
            subprocess.call("%(dir)s/couchbase-cli bucket-create -c %(cip)s:%(p)s \
                             --bucket=%(name)s --bucket-type=couchbase \
                             --bucket-port=%(bp)d --bucket-ramsize=%(ram)d \
                             --bucket-replica=%(rep)d -u %(u)s -p %(pw)s --wait" % {'dir': cb_home, 
                             'cip': self._serverIP, 'p': s.PORT, 'name': s.BUCKET_NAME, 
                             'bp': s.BUCKET_PORT, 'ram': self._ramQuota, 'rep': replicas,
                             'u': s.ADM_USERNAME, 'pw': s.ADM_PASSWORD}, shell=True)
            content = "flushEnabled=1&ramQuotaMB=%d" % self._ramQuota
            self._admin_request("/pools/default/buckets/%s" % s.BUCKET_NAME, content, "POST")
        else:
            self._admin_request("/pools/default/buckets/%s/controller/doFlush" % s.BUCKET_NAME, "", "POST")
        
        # Import design documents and data base on "self.type"
        if self._type == "couchbase4":
            self._importTwitter4("%s/%s-data/%s" % (clc_home_dir, datasetId, sqliteDatabase))
        else:
            self._importTwitter123("%s/%s-data/%s" % (clc_home_dir, datasetId, sqliteDatabase))
            
    def _importTwitter123(self, pathToSqliteDb):
        # Couchbase
        cb = Couchbase.connect(host=self._serverIP, bucket=s.BUCKET_NAME)
        
        # Import design documents
        res = cb._design(s.USERS_DESIGN, s.USERS_DOC)
        if res.value is None or "ok" not in res.value or res.value["ok"] == False:
            return str(res)
        if self._type == "couchbase1":
            res = cb._design(s.TWEETS_DESIGN, s.TWEETS_1_DOC)
        elif self._type == "couchbase2":
            res = cb._design(s.TWEETS_DESIGN, s.TWEETS_2_DOC)
        elif self._type == "couchbase3":
            res = cb._design(s.TWEETS_DESIGN, s.TWEETS_3_DOC)
        if res.value is None or "ok" not in res.value or res.value["ok"] == False:
            return str(res)
        
        # SQL
        sqliteConn = sqlite3.connect(pathToSqliteDb)
        sqliteCursor = sqliteConn.cursor()
        
        docsToAdd = {}
        
        ################
        # Create users #
        ################
        print("Phase 1: Get Users and their Followers")
        sqliteCursor.execute("SELECT username FROM Users")
        users = [u[0] for u in sqliteCursor.fetchall()]
        for user in users:
            sqliteCursor.execute("SELECT username FROM Followers WHERE following = :username", dict(username = user))
            rawFollowers = sqliteCursor.fetchall()
            followers = [f[0] for f in rawFollowers]
            docsToAdd[user] = { "type" : "user", "username" : user, "followers": followers}
        
        #################
        # Create tweets #
        #################
        print("Phase 2: Get Tweets and Timeline")
        for user in users:
            sqliteCursor.execute("SELECT tweetid, body FROM Tweets WHERE username = :username", dict(username = user))
            tweets = sqliteCursor.fetchall()
            
            sqliteCursor.execute("SELECT username FROM Followers WHERE following = :username", dict(username = user))
            followers = [fl[0] for fl in sqliteCursor.fetchall()]
            
            for tweet in tweets:
                tweetUUID = uuid.UUID(tweet[0])
                tweetId = "%0.16x-%0.4x-%0.12x" % (tweetUUID.time, tweetUUID.clock_seq, tweetUUID.node)
                tweetBody = tweet[1]
                if self._type == "couchbase3":
                    docsToAdd[tweetId] = {"type": "tweet", "tweetid": tweetId, "username": user, "body": tweetBody, "followers": followers}
                else:
                    docsToAdd[tweetId] = {"type": "tweet", "tweetid": tweetId, "username": user, "body": tweetBody}
                    
                    if self._type == "couchbase2":
                        for follower in followers:
                            docsToAdd["%s_%s" % (follower, tweetId)] = { "type" : "timeline", "username" : follower, "tweetid" : tweetId, "posted_by": user, "body": tweetBody}
                    else:
                        for follower in followers:
                            docsToAdd["%s_%s" % (follower, tweetId)] = { "type" : "timeline", "username" : follower, "tweetid" : tweetId}
                
        print("Phase 4: Import all tweets and timeline")
        cb.set_multi(docsToAdd)
        
        sqliteCursor.close()
        sqliteConn.close()
        print("COMPLETE!")

        ###########################
        # First built for indexes #
        ###########################
        cb._view(s.TWEETS_DESIGN, s.VIEW_USERLINE, params={"limit": "1", "stale":"false"})
        cb._view(s.TWEETS_DESIGN, s.VIEW_TIMELINE, params={"limit": "1", "stale":"false"})
        
    def _importTwitter4(self, pathToSqliteDb):
        # Couchbase
        cb = Couchbase.connect(host=self._serverIP, bucket=s.BUCKET_NAME)
        
        # Import design documents for USERS
        res = cb._design(s.USERS_DESIGN, s.USERS_DOC)
        if res.value is None or "ok" not in res.value or res.value["ok"] == False:
            return str(res)
        res = cb._design(s.TWEETS_DESIGN, s.TWEETS_4_DOC)
        if res.value is None or "ok" not in res.value or res.value["ok"] == False:
            return str(res)
        
        # SQL
        sqliteConn = sqlite3.connect(pathToSqliteDb)
        sqliteCursor = sqliteConn.cursor()
        
        docsToAdd = {}
        
        ################
        # Create users #
        ################
        print("Phase 1: Get Users and their Followers")
        sqliteCursor.execute("SELECT username FROM Users")
        users = [u[0] for u in sqliteCursor.fetchall()]
        timelines = {}
        for user in users:
            sqliteCursor.execute("SELECT username FROM Followers WHERE following = :username", dict(username = user))
            rawFollowers = sqliteCursor.fetchall()
            followers = [f[0] for f in rawFollowers]
            docsToAdd[user] = { "type" : "user", "username" : user, "followers": followers}
            docsToAdd["ul::%s" % user] = {"type": "userline", "username": user, "userline": []}
            docsToAdd["tl::%s" % user] = {"type": "timeline", "username": user, "timeline": []}
        
        #################
        # Create tweets #
        #################
        print("Phase 2: Get Tweets")
        sqliteCursor.execute("SELECT tweetid, username, body FROM Tweets ORDER BY tweetid")
        tweets = sqliteCursor.fetchall()
        tweetsToAdd = {}
        for tweet in tweets:
            tweetUUID = uuid.UUID(tweet[0])
            tweetAuthor = tweet[1]
            tweetBody = tweet[2]
            tweetId = "%0.16x-%0.4x-%0.12x" % (tweetUUID.time, tweetUUID.clock_seq, tweetUUID.node)
            tweetsToAdd[tweetId] = {"type": "tweet", "tweetid": tweetId, "username": tweetAuthor, "body": tweetBody}
            
        print("Phase 3: Get Userline and Timeline")
        tweetIds = sorted(tweetsToAdd)
        for tweetId in tweetIds:
            tweet = tweetsToAdd[tweetId]
            tweetAuthor = tweetsToAdd[tweetId]["username"]
            tweetBody = tweetsToAdd[tweetId]["body"]
            followers = docsToAdd[tweetAuthor]["followers"]
            docsToAdd["ul::%s" % tweetAuthor]["userline"].insert(0,{"tweetid": tweetId, "body": tweetBody})
                    
            for follower in followers:
                docsToAdd["%s_%s" % (follower, tweetId)] = { "type" : "timeline", "username" : follower, "tweetid" : tweetId, "posted_by": tweetAuthor, "body": tweetBody}
        
        print("Phase 4: Import all")
        cb.set_multi(tweetsToAdd)
        cb.set_multi(docsToAdd)
        
        sqliteCursor.close()
        sqliteConn.close()
        print("COMPLETE!")
        
        # First built for View
        cb._view(s.TWEETS_DESIGN, s.VIEW_TIMELINE, params={"limit": "1", "stale":"false"})