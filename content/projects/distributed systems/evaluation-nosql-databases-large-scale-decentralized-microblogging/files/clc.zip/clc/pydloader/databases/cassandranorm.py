import subprocess
from .cassandra import CassandraDatabase
import os

cassandraStorage = "/media/ephemeral0/cassandra"

class CassandraNormDatabase(CassandraDatabase):
    def __init__(self, nodeInfo):
        super(CassandraNormDatabase,self).__init__(nodeInfo)
        self._type = "cassandranorm"
        
    def populate(self, datasetId, sqliteDatabase):
        """
        Populates the cassandra cluster from this node using the provided database.
        
        Args:
            datasetId (str) - An identifier for the dataset.
            sqliteDatabase (str) - Name of the database to use for populating this
                cassandra node (and thus the cluster).
        """
        
        if self._replicationFactors is None:
            raise Exception("Unknown replication factors! Database not setup?")
        
        # Setup a keyspace with triple replication per datacenter
        subprocess.call("echo -e \"CREATE KEYSPACE %s WITH PLACEMENT_STRATEGY = 'org.apache.cassandra.locator.NetworkTopologyStrategy' and STRATEGY_OPTIONS = %s;\\nexit;\" | cassandra-cli" % (datasetId, str(self._replicationFactors)), 
                        shell = True)
        # Populate with data
        subprocess.call("../%(id)s-data/sqlite2cassandranorm.py ../%(id)s-data/%(database)s" % {'id': datasetId, 'database': sqliteDatabase},
                        shell = True)