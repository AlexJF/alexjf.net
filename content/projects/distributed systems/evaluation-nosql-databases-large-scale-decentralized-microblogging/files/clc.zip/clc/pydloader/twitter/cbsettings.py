HOST = "localhost"
PORT = "8091"
ADM_USERNAME = "Admin"
ADM_PASSWORD = "password"

BUCKETS_API = "/pools/default/buckets"

BUCKET_NAME = "cbclc"
BUCKET_PORT = 11222
BUCKET_MIN_RAM = 100

LIMIT = 50

USERS_DESIGN = "user"
TWEETS_DESIGN = "tweet"
VIEW_USER = "username"
VIEW_USERLINE = "userline"
VIEW_TIMELINE = "timeline"

USERS_DOC = {"views":
                {"username":
                    {"map":
"function (doc, meta) {\n\
  if (meta.type == \"json\" && doc.type && doc.type == \"user\" && doc.username) {\n\
    emit(doc.username, null);\n\
  }\n\
}",
                    "reduce":"_count"}}, 
            "options": 
                {"updateInterval": 60000, "updateMinChanges": 20, "replicaUpdateMinChanges": 20}}

TWEETS_1_DOC = {"views":
                   {"userline":
                       {"map":
"function (doc, meta) {\n\
  if (meta.type == \"json\" && doc.type && doc.type == \"tweet\" && doc.username && doc.tweetid) {\n\
    emit([doc.username, doc.tweetid], null);\n\
  }\n\
}"},
                   "timeline":
                       {"map":
"function (doc, meta) {\n\
  if (meta.type == \"json\" && doc.type && doc.type == \"timeline\" && doc.username && doc.tweetid) {\n\
    emit([doc.username, doc.tweetid], null);\n\
  }\n\
}"}},               
                "options": 
                    {"updateInterval": 5000, "updateMinChanges": 10, "replicaUpdateMinChanges": 100}}
    
TWEETS_2_DOC = {"views":
                   {"userline":
                       {"map":
"function (doc, meta) {\n\
  if (meta.type == \"json\" && doc.type && doc.type == \"tweet\" && doc.username && doc.tweetid && doc.body) {\n\
    emit([doc.username, doc.tweetid], doc.body);\n\
  }\n\
}"},
                   "timeline":
                       {"map":
"function (doc, meta) {\n\
  if (meta.type == \"json\" && doc.type && doc.type == \"timeline\" && doc.username && doc.posted_by && doc.tweetid && doc.body) {\n\
    emit([doc.username, doc.tweetid], [doc.posted_by, doc.body]);\n\
  }\n\
}"}},               
                "options": 
                    {"updateInterval": 5000, "updateMinChanges": 10, "replicaUpdateMinChanges": 100}}
                    
TWEETS_3_DOC = {"views":
                   {"userline":
                       {"map":
"function (doc, meta) {\n\
  if (meta.type == \"json\" && doc.type && doc.type == \"tweet\" && doc.username && doc.tweetid && doc.body) {\n\
    emit([doc.username, doc.tweetid], doc.body);\n\
  }\n\
}"},
                   "timeline":
                       {"map":
"function (doc, meta) {\n\
  if (meta.type == \"json\" && doc.type && doc.type == \"tweet\" && doc.username && doc.followers && doc.tweetid && doc.body) {\n\
    for (i=0; i<doc.followers.length; i++) {\
      emit([doc.followers[i], doc.tweetid], [doc.username, doc.body]);\n\
    }\
  }\n\
}"}},               
                "options": 
                    {"updateInterval": 5000, "updateMinChanges": 10, "replicaUpdateMinChanges": 100}}
                    
TWEETS_4_DOC = {"views":
                   {"timeline":
                       {"map":
"function (doc, meta) {\n\
  if (meta.type == \"json\" && doc.type && doc.type == \"timeline\" && doc.username && doc.posted_by && doc.tweetid && doc.body) {\n\
    emit([doc.username, doc.tweetid], [doc.posted_by, doc.body]);\n\
  }\n\
}"}},               
                "options": 
                    {"updateInterval": 5000, "updateMinChanges": 10, "replicaUpdateMinChanges": 100}}
                    
            