from abc import ABCMeta, abstractmethod
import logging
import random
import os

def logResult(tag = ""):
    def logDecorator(fn):
        def log(self, *args, **kwargs):
            try:
                latency, result = fn(self, *args, **kwargs)
                #self.log(tag, "[%(latency)s] %(result)s", {'latency': latency,
                    #'result': result})
                self.log(tag, "[%(latency)s]", {'latency': latency})
                return (latency, result)
            except Exception:
                self.log(tag, "[ERROR]")
                raise

        return log

    return logDecorator

class TwitterClient(object):
    __metaclass__ = ABCMeta

    @property
    def user(self):
        return self._user

    def __init__(self, user, nodeInfo, cluster = []):
        self._user = user
        self._nodeInfo = nodeInfo
        self._endpoints = [n for n in cluster]
        # Randomize stuff a little bit
        random.shuffle(self._endpoints)
        # Ensure that nodes in the same zone are considered first, 
        # then in same region then in different regions
        self._endpoints.sort(key = self._nodeInfo.locationCompare, reverse = True)
        self._logger = None
        
    def setupLogger(self, experimentLogDir = ""):
        self._logger = logging.getLogger("twitter-%s" % self._user)
        
        handler = logging.FileHandler(os.path.join(experimentLogDir, self._user + ".log"))
        formatter = logging.Formatter("[%(tag)s] %(asctime)s => %(message)s")
        handler.setFormatter(formatter)
        self._logger.addHandler(handler)
        self._logger.setLevel(logging.INFO)
        self._logger.info(self._nodeInfo.zone, extra={"tag": "Location"})
        
    def iterEndpoints(self):
        return iter(self._endpoints)

    @logResult(tag = "tweet")
    def tweet(self, tweetId = None, msg = None):
        return self._tweet(tweetId, msg)

    @abstractmethod
    def _tweet(self, tweetId, msg):
        pass

    @logResult(tag = "userline")
    def getUserline(self, user):
        return self._getUserline(user)

    @abstractmethod
    def _getUserline(self, user):
        pass

    @logResult(tag = "timeline")
    def getTimeline(self):
        return self._getTimeline()

    @abstractmethod
    def _getTimeline(self):
        pass

    def tweetFound(self, tweetId):
        return self._tweetFound(tweetId)

    @abstractmethod
    def _tweetFound(self, tweetId):
        pass

    def getUsernames(self):
        return self._getUsernames()

    @abstractmethod
    def _getUsernames(self):
        pass

    def log(self, tag, msg, *args):
        if self._logger is None:
            return
        self._logger.info(msg, *args, extra={"tag": tag})
