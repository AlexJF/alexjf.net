import time, uuid, random, string, baseclient, pymongo
from pymongo.errors import AutoReconnect
from twitter.cassclient import CassandraTwitterClient

class MongoTwitterClient(baseclient.TwitterClient):
    def __init__(self, user, nodeInfo, endpoints, databaseName = 'twitter'):
        super(CassandraTwitterClient,self).__init__(user, nodeInfo)
        self._client = pymongo.MongoReplicaSetClient(endpoints, read_preference = pymongo.read_preferences.ReadPreference.SECONDARY)
        self._database = self._client[databaseName]

    def _tweet(self, tweetId = None, msg = None):
        name = str(self.user)
        
        def followersQuery(db):
            return db.Users.find({'_id': name}, {'followers': 1} )

        latency1, followers = self._queryDb(followersQuery)

        if tweetId is None:
            tweetId = uuid.uuid1()

        if msg is None:
            validChars = string.letters + string.digits + " "
            msg = "".join(
                [random.choice(validChars) for _ in range(random.randint(20, 140))])

        body = str(msg)

        def insertQuery(db):
            db.Tweets.insert( {'_id': tweetId, 'username': name, 'body': body} )
            db.Userline.insert( {'username': name, 'tweetid': tweetId, 'body': body} )
            db.Timeline.insert( [ {'username': follower, 'tweetid': tweetId, 'posted_by': name, 'body': body} 
                                 for follower in followers] )

            return None

        latency2, _ = self._queryDb(insertQuery)
        return (latency1 + latency2, (tweetId, msg, time.time()))

    def _getUserline(self, user):
        name = str(self.user)

        def userlineQuery(db):
            return db.Userline.find( {'username': name}, {'date': 1, 'body': 1} ).sort( {'tweetid': -1} ).limit(50)

        return self._queryDb(userlineQuery)

    def _getTimeline(self):
        name = str(self.user)

        def timelineQuery(db):
            return db.Timeline.find( {'username': name}, {'date': 1, 'posted_by': 1, 'body': 1} ).sort( {'tweetid': -1} ).limit(50)

        return self._queryDb(timelineQuery)

    def _tweetFound(self, tweetId):
        def tweetFoundQuery(db):
            return db.Tweets.find_one( {'_id': tweetId}, {'_id': 1} )

        _, result = self._queryDb(tweetFoundQuery)
        return bool(result)

    def _getUsernames(self):
        def usernamesQuery(db):
            return db.Users.find( { }, {'_id': 1} )

        _, result = self._queryDb(usernamesQuery)

        return [r[0] for r in result]

    def _queryDb(self, query):
        while True:
            try:
                time1 = time.time()
                result = query(self._database)
                time2 = time.time()

                return (time2 - time1, result)
            except AutoReconnect:
                pass

    def closeConnection(self):
        self._client.close()