from abc import ABCMeta, abstractmethod
import logging

def logResult(tag = ""):
    def logDecorator(fn):
        def log(self, *args, **kwargs):
            latency, result = fn(self, *args, **kwargs)
            self.log(tag, "[%(latency)s] %(result)s", {'latency': latency,
                'result': result})
            return result


        return log

class WikipediaClient(object):
    __metaclass__ = ABCMeta

    @property
    def user(self):
        return self._user

    def __init__(self, user, nodeInfo):
        self._user = user
        self._nodeInfo = nodeInfo
        self._logger = logging.getLogger("wikipedia-%s" % user)
        handler = logging.FileHandler("log/wikipedia/%s.log" % user)
        formatter = logging.Formatter("[%(tag)s] %(asctime)s => %(message)s")
        handler.setFormatter(formatter)
        self._logger.addHandler(handler)
        self._logger.setLevel(logging.INFO)

    @logResult(tag = "read")
    def read(self, articleId):
        return self._read(articleId)

    @abstractmethod
    def _read(self, articleId):
        pass

    @logResult(tag = "edit")
    def edit(self, articleId = None, body = None):
        return self._edit(articleId)

    @abstractmethod
    def _edit(self, articleId, body):
        pass
    
    def getArticleIds(self):
        return self._getArticleIds()

    @abstractmethod
    def _getArticleIds(self):
        pass

    def log(self, tag, msg, *args):
        self._logger.info(msg, *args, extra={"tag": tag})
