from couchbase import Couchbase
import random, uuid, string, time
import cbsettings as s

def measureTime(fn):
    def wrapper(self, *args, **kwargs):
        time1 = time.time()
        result = fn(self, *args, **kwargs)
        time2 = time.time()
        return (time2 - time1, result)
    
    return wrapper
        
class CouchbaseWikipediaClient(baseclient.WikipediaClient):
    def __init__(self, user, nodeInfo, cluster):
        super(CouchbaseWikipediaClient, self).__init__(user, nodeInfo)
        # Endpoints: copied from twitter
        self._endpoints = [n for n in cluster]
        random.shuffle(self._endpoints)
        self._endpoints.sort(key = self._nodeInfo.locationCompare, reverse = True)
        
        # Couchbase client
        self.cb = Couchbase.connect(host=_endpoints[0].publicIp, bucket=s.BUCKET_NAME)

    @measureTime
    def _read(self, articleId):
        articleId = self._getArticleId(articleId)
        result = self.cb.get(articleId, quiet=True)
        return (articleId, result.value)

    @measureTime
    def _edit(self, articleId = None, articleBody = None):
        articleId = self._getArticleId(articleId)

        allChars = string.letters + string.digits + " "
        if articleBody is None:
            articleBody = "".join(
                random.sample("%s%s%s" % (allChars, allChars, allChars),
                random.randint(20, 140)))
        
        self.cb.set(articleId, articleBody)
        
        return articleId

    @measureTime
    def _getArticleIds(self):
        articles = self.cb._view(s.WIKI_DESIGN, s.VIEW_ARTICLE, params={"stale":False, "reduce":False})
        if "rows" in articles.value:
            return [a["key"] for a in articles.value["rows"]]
        else:
            return []
        
    def _getArticleId(self, articleId=None):
        if articleId is None:
            articleId = uuid.uuid1()
            return "%0.16x-%0.4x-%0.12x" % (articleId.time, articleId.clock_seq, articleId.node)
        elif articleId isinstance(uuid.UUID):
            return "%0.16x-%0.4x-%0.12x" % (articleId.time, articleId.clock_seq, articleId.node)
        else:
            return articleId 
