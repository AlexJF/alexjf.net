from abc import ABCMeta, abstractmethod

class Database(object):
    __metaclass__ = ABCMeta
    
    def __init__(self, dbType, nodeInfo):
        self._type = dbType
        self._nodeInfo = nodeInfo
        
    @property
    def type(self):
        return self._type
    
    @property
    def nodeInfo(self):
        return self._nodeInfo
    
    @abstractmethod
    def setup(self):
        pass
    
    @abstractmethod
    def cleanup(self):
        pass
    
    @abstractmethod
    def start(self):
        pass
    
    @abstractmethod
    def stop(self):
        pass
    
    @abstractmethod
    def populate(self, datasetId, sqliteDatabase):
        pass
    
    @abstractmethod
    def crash(self):
        pass
    
    @abstractmethod
    def recover(self):
        pass