import subprocess
from .database import Database
import os

cassandraStorage = "/media/ephemeral0/cassandra"

class CassandraDatabase(Database):
    def __init__(self, nodeInfo):
        super(CassandraDatabase,self).__init__("cassandra", nodeInfo)
        self._replicationFactors = None
        
    def setup(self, seeds, replicationFactors):
        """
        Sets up configuration for a cassandra cluster on this node.
        
        Args:
            seeds (list of NodeInfo) - Endpoints of the seed nodes of the cassandra cluster.
            replicationFactors (dict) - Associations between datacenter names and number of 
                replicas in each datacenter. E.g: {'eu-west-1': 1, 'us-east-1': 2}
        """
        
        cassandraYamlTemplate = "cassandra/cassandra.yaml.template"
        cassandraYaml = "/etc/cassandra/conf/cassandra.yaml"
        
        with open(cassandraYamlTemplate) as template:
            templateStr = template.read()
            
        templateStr = templateStr.replace("<SEEDS>", ",".join(s.publicIp for s in seeds))
        templateStr = templateStr.replace("<PRIVATEIP>", self.nodeInfo.privateIp)
        templateStr = templateStr.replace("<PUBLICIP>", self.nodeInfo.publicIp)
        templateStr = templateStr.replace("<STORAGE>", cassandraStorage)
            
        with open(cassandraYaml, "w") as realYaml:
            realYaml.write(templateStr)
            
        if not os.path.isdir(cassandraStorage):
            os.makedirs(cassandraStorage)
            # Make it globally writable (this is just for testing anyway)
            os.chmod(cassandraStorage, 0777)
            
        self._replicationFactors = replicationFactors
        self._seeds = seeds
    
    def cleanup(self):
        """
        Cleanup stored data on local cassandra node.
        """
        self.stop()
        subprocess.call("rm -rf /media/ephemeral0/cassandra/{commitlog,saved_caches,data}/*", shell = True)
    
    def start(self):
        """
        Start the cassandra service using current configuration.
        """
        subprocess.call("service cassandra start", shell = True)
    
    def stop(self):
        """
        Stop the cassandra service.
        """
        subprocess.call("service cassandra stop", shell = True)
    
    def populate(self, datasetId, sqliteDatabase):
        """
        Populates the cassandra cluster from this node using the provided database.
        
        Args:
            datasetId (str) - An identifier for the dataset.
            sqliteDatabase (str) - Name of the database to use for populating this
                cassandra node (and thus the cluster).
        """
        
        if self._replicationFactors is None:
            raise Exception("Unknown replication factors! Database not setup?")
        
        # Setup a keyspace with triple replication per datacenter
        subprocess.call("echo -e \"CREATE KEYSPACE %s WITH PLACEMENT_STRATEGY = 'org.apache.cassandra.locator.NetworkTopologyStrategy' and STRATEGY_OPTIONS = %s;\\nexit;\" | cassandra-cli" % (datasetId, str(self._replicationFactors)), 
                        shell = True)
        # Populate with data
        subprocess.call("../%(id)s-data/sqlite2cassandra.py ../%(id)s-data/%(database)s" % {'id': datasetId, 'database': sqliteDatabase},
                        shell = True)
        
    def crash(self):
        """
        Crash (in an ugly way) this node of the Cassandra cluster.
        """
        
        subprocess.call("killall java", shell = True)
        
    def recover(self, nonCrashNodeInfos=None, last=False):
        """
        Recover from a crash. Same as start but clean up existing data first.
        """
        
        self.cleanup()
        self.setup([s for s in self._seeds if s.publicIp != self.nodeInfo.publicIp], self._replicationFactors)
        self.start()