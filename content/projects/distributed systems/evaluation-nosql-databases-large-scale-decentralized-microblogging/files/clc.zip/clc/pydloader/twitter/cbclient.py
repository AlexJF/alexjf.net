from couchbase import Couchbase
import cbsettings as s
import json, uuid, random, time, string, baseclient

class CouchbaseTwitterClient(baseclient.TwitterClient):
    def __init__(self, user, nodeInfo, cluster = None, type=1):
        super(CouchbaseTwitterClient, self).__init__(user, nodeInfo, cluster)
        dbNode = self._endpoints[0]
        self.cb = Couchbase.connect(host=dbNode.publicIp, bucket=s.BUCKET_NAME)
        self.type = type
    
    def _tweet(self, tweetId=None, msg=None):
        if tweetId is None:
            id = uuid.uuid1()
            tweetId = "%0.16x-%0.4x-%0.12x" % (id.time, id.clock_seq, id.node)
        elif isinstance(tweetId, uuid.UUID):
            tweetId = "%0.16x-%0.4x-%0.12x" % (tweetId.time, tweetId.clock_seq, tweetId.node)
            
        allChars = string.letters + string.digits + " "
        if msg is None:
            msg = "".join(
                random.sample("%s%s%s" % (allChars, allChars, allChars),
                random.randint(20, 140)))
         
        # get user's data (followers)
        latency1, userValue = self._get(self.user)
        if userValue.value is not None:
            followers = userValue.value["followers"]
        else:
            followers = []
               
        if self.type == 3:
            tweet = {"type": "tweet", "tweetid": tweetId, "username": self.user, "body": msg, "followers": followers}
            latency2 = self._add(tweetId, tweet)
        else:
            docsToAdd = {}
            # tweet to be added
            docsToAdd[tweetId] = { "type": "tweet", "tweetid": tweetId, "username": self.user, "body": msg }
            
            # followers' timelines: to be added
            for follower in followers:
                if self.type == 2:
                    newTL = { "type": "timeline", "username": follower, "tweetid": tweetId, "posted_by": self.user, "body": msg }
                else:
                    newTL = { "type": "timeline", "username": follower, "tweetid": tweetId }
                docsToAdd[follower + "_" + tweetId] = newTL
                
            # end
            latency2 = self._add_multi(docsToAdd)
        
        return (latency2 + latency1, (tweetId, msg, time.time()))
        
    def _getUserline(self, user=None):
        if user is None:
            user = self.user
            
        format = "[\"%s\",%s]"
        startkey = format % (user, "\"z\"")
        endkey = format % (user, "null")
        latency1, userline = self._query(s.TWEETS_DESIGN, s.VIEW_USERLINE, startkey=startkey, endkey=endkey, limit=s.LIMIT)
        latency2 = 0
        
        if self.type == 1:
            # Extract keys for get_multi
            if len(userline) > 0:
                keys = [val["id"] for val in userline]
                latency2, tweets = self._get_multi(keys)
            else:
                keys = []
        
            result = []
            for key in keys:
                tweet = tweets[key].value
                result.append((tweet["tweetid"].split("-")[0], tweet["body"]))
        else:
            result = [(tweet["id"].split("-")[0], tweet["value"]) for tweet in userline]
        
        return (latency2 + latency1, result)
        
    def _getTimeline(self):
        format = "[\"%s\",%s]"
        startkey = format % (self.user, "\"z\"")
        endkey = format % (self.user, "null")
        latency1, timeline = self._query(s.TWEETS_DESIGN, s.VIEW_TIMELINE, startkey=startkey, endkey=endkey, limit=s.LIMIT)
        #latency1, timeline = self._query(s.TWEETS_DESIGN, s.VIEW_TIMELINE, limit=s.LIMIT)
        latency2 = 0
        
        if self.type == 1:
            if len(timeline) > 0:
                # Extract keys for get_multi
                keys = [val["key"][1] for val in timeline]
                latency2, tweets = self._get_multi(keys)
            else:
                keys = []
        
            # Re-organize results
            result = []
            for key in keys:
                tweet = tweets[key].value
                result.append((tweet["tweetid"].split("-")[0], tweet["username"], tweet["body"]))
        else:
            result = [(tweet["key"][1].split("-")[0], tweet["value"][0], tweet["value"][1]) for tweet in timeline]
            
        return (latency2 + latency1, result)

    def _getUsernames(self):
        _, users = self._query(s.USERS_DESIGN, s.VIEW_USER, descending=False, stale="false")
        return [user["key"] for user in users]
    
    def _tweetFound(self, tweetId):
        if isinstance(tweetId, uuid.UUID):
            tweetId = "%0.16x-%0.4x-%0.12x" % (tweetId.time, tweetId.clock_seq, tweetId.node)
        _, result = self._get(tweetId)
        return result.rc == 0
       
    def _get(self, key):
        time1 = time.time()
        result = self.cb.get(key, quiet=True)
        time2 = time.time()
        return (time2 - time1, result)
         
    def _add(self, key, value):
        time1 = time.time()
        self.cb.add(key, value)
        time2 = time.time()
        return (time2 - time1)
        
    def _add_multi(self, keys):
        time1 = time.time()
        self.cb.add_multi(keys)
        time2 = time.time()
        return (time2 - time1)
        
    def _set(self, key, value):
        time1 = time.time()
        self.cb.set(key, value)
        time2 = time.time()
        return (time2 - time1)
        
    def _set_multi(self, keys):
        time1 = time.time()
        self.cb.set_multi(keys)
        time2 = time.time()
        return (time2 - time1)
        
    def _get_multi(self, keys):
        time1 = time.time()
        resp = self.cb.get_multi(keys, quiet=True)
        time2 = time.time()
        return (time2 - time1, resp)
         
    def _query(self, design_doc, view, key=None, startkey=None, endkey=None, limit=None, descending=True, reduce=False, stale="ok"):
        params = {"stale": stale}
        if descending is True:
            params["descending"] = "true"
        if reduce is False:
            params["reduce"] = "false"
            
        if limit is not None:
            params["limit"] = "%d" % limit
        if key is not None:
            params["key"] = key
        else:
            if startkey is not None:
                params["startkey"] = startkey
            if endkey is not None:
                params["endkey"] = endkey
                
        time1 = time.time()
        result = self.cb._view(design_doc, view, params=params).value
        time2 = time.time()
        
        if "rows" in result:
            result = result["rows"]
        else:
            result = []
        
        return (time2 - time1, result)
        
class CouchbaseTwitterClient1(CouchbaseTwitterClient):
    def __init__(self, user, nodeInfo, cluster = None):
        super(CouchbaseTwitterClient1, self).__init__(user, nodeInfo, cluster, type=1)
        
class CouchbaseTwitterClient2(CouchbaseTwitterClient):
    def __init__(self, user, nodeInfo, cluster = None):
        super(CouchbaseTwitterClient2, self).__init__(user, nodeInfo, cluster, type=2)
        
class CouchbaseTwitterClient3(CouchbaseTwitterClient):
    def __init__(self, user, nodeInfo, cluster = None):
        super(CouchbaseTwitterClient3, self).__init__(user, nodeInfo, cluster, type=3)
        
class CouchbaseTwitterClient4(CouchbaseTwitterClient):
    def __init__(self, user, nodeInfo, cluster = None):
        super(CouchbaseTwitterClient4, self).__init__(user, nodeInfo, cluster, type=4)
        
    def _tweet(self, tweetId=None, msg=None):
        if tweetId is None:
            id = uuid.uuid1()
            tweetId = "%0.16x-%0.4x-%0.12x" % (id.time, id.clock_seq, id.node)
        elif isinstance(tweetId, uuid.UUID):
            tweetId = "%0.16x-%0.4x-%0.12x" % (tweetId.time, tweetId.clock_seq, tweetId.node)
            
        allChars = string.letters + string.digits + " "
        if msg is None:
            msg = "".join(
                random.sample("%s%s%s" % (allChars, allChars, allChars),
                random.randint(20, 140)))
         
        # get user's data (followers)
        latency1, userValue = self._get(self.user)
        if userValue.value is not None:
            followers = userValue.value["followers"]
        else:
            followers = []
               
        
        # Modify userline
        latency2 = self._insertUserline("ul::%s" % self.user, { "type": "userline", "tweetid": tweetId, "body": msg })
        docsToAdd = {}
        # tweet to be added
        docsToAdd[tweetId] = { "type": "tweet", "tweetid": tweetId, "username": self.user, "body": msg }
            
        # followers' timelines: to be added
        for follower in followers:
            newTL = { "type": "timeline", "username": follower, "tweetid": tweetId, "posted_by": self.user, "body": msg }
            docsToAdd[follower + "_" + tweetId] = newTL
        
        # end
        latency3 = self._add_multi(docsToAdd)
        
        
        return (latency2 + latency1 + latency3, (tweetId, msg, time.time()))
        
    def _getUserline(self, user=None):
        if user is None:
            user = self.user
            
        latency , userline = self._get("ul::%s" % user)
        if userline.value is not None:
            result = userline.value["userline"][:50]
        else:
            result = []
        return (latency, result)

    def _insertUserline(self, key, value):
        time1 = time.time()
        userline = self.cb.get(key, quiet=True)
        if userline.value is not None:
            userline.value["userline"].insert(0, value)
            self.cb.set(key, userline.value)
        time2 = time.time()
        return time2 - time1
        