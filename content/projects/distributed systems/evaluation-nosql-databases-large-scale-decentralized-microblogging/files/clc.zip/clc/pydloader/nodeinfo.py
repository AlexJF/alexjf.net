class NodeInfo(object):
    def __init__(self, identifier, zone, publicIp, privateIp = None):
        self._id = identifier
        self._region = zone[:-1]
        self._zone = zone
        self._publicIp = publicIp
        self._privateIp = privateIp
        
    def __eq__(self, other):
        if type(other) is type(self):
            return self.__dict__ == other.__dict__
        return False
    
    def __ne__(self, other):
        return not self.__eq__(other)
    
    def __str__(self):
        return "Node %s (%s, %s, %s)" % \
            (self._id, self._zone, self._publicIp, "Unknown" if self._privateIp is None else self._privateIp)

    def _repr_pretty_(self, p, cycle):
        p.text(repr(self))

    def __repr__(self):
        return str(self)
    
    @property
    def id(self):
        return self._id
        
    @property
    def region(self):
        return self._region
        
    @property
    def zone(self):
        return self._zone
    
    @property
    def publicIp(self):
        return self._publicIp
    
    @property
    def privateIp(self):
        return self._privateIp
    
    def locationCompare(self, n):
        if n.zone == self.zone:
            return 2
        elif n.region == self.region:
            return 1
        else:
            return 0