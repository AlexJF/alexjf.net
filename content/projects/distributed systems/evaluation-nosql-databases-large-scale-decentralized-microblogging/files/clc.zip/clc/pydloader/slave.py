import rpyc, time, random, requests
from twitter.cassclient import CassandraTwitterClient
from twitter.cbclient import CouchbaseTwitterClient1, CouchbaseTwitterClient2, CouchbaseTwitterClient3, CouchbaseTwitterClient4
from wikipedia.dynamoclient import DynamoWikipediaClient
from multiprocessing import Process, Queue
import collections
from nodeinfo import NodeInfo
import nodeinfo
import copy
from databases.cassandra import CassandraDatabase
from databases.couchbaseDB import CouchbaseDatabase
from databases.mongoDB import MongoDatabase
import traceback
import os
from twitter.cassnormclient import CassandraNormTwitterClient
from databases.cassandranorm import CassandraNormDatabase

def avg(l):
    if len(l) == 0:
        return "N/A"
    return sum(l) / len(l)

class WorkloadSlave(rpyc.Service):
    def on_connect(self):
        self._bgsrv = rpyc.BgServingThread(self._conn)
        self.collectNodeInfo()

    def on_disconnect(self):
        self._bgsrv.stop()
    
    @property
    def exposed_nodeInfo(self):
        return self._nodeInfo
    
    @property
    def exposed_database(self):
        return self._database
    
    def collectNodeInfo(self):
        try:
            self._nodeInfo
        except Exception:
            pass
        else:
            return
        
        response = requests.get("http://169.254.169.254/latest/meta-data/instance-id")
        instanceId = response.text
        
        response = requests.get("http://instance-data/latest/meta-data/local-ipv4")
        privateIp = response.text
        
        response = requests.get("http://instance-data/latest/meta-data/public-ipv4")
        publicIp = response.text
        
        response = requests.get("http://instance-data/latest/meta-data/placement/availability-zone")
        zone = response.text
        
        self._nodeInfo = NodeInfo(instanceId, zone, publicIp, privateIp)
    
    def exposed_eval(self, command):
        """
        Evaluate a simple python expression (useful for testing connectivity).

        Args:
            command (str) - Python expression to evaluate.

        Returns:
            Result of python expression.
        """
        return eval(command)
    
    def exposed_chooseDatabase(self, databaseType, ramQuota=None, type=1):
        """
        Creates and associates with this slave a database instance of the 
        provided type.
        
        Args:
            databaseType (str) - String representation of the type of database.
        """
        
        try:
            if self._database is not None:
                self._database.stop()
        except Exception:
            pass
        
        if (databaseType == "cassandra"):
            self._database = CassandraDatabase(self._nodeInfo)
        if (databaseType == "cassandranorm"):
            self._database = CassandraNormDatabase(self._nodeInfo)
        elif databaseType == "couchbase":
            self._database = CouchbaseDatabase(self._nodeInfo, ramQuota, type)
        elif databaseType == "mongo":
            self._database = MongoDatabase(self._nodeInfo)
            
    def exposed_startTwitterExperiment(self, database, users, duration, experimentId):
        """
        Launches a normal twitter experiment (tweets, userlines and timelines),
        sending queries to the specified database and using one process for each
        specified user. Run the experiment for the specified duration.

        Args:
            database (dict) - See docstr of exposed_getTwitterClient.
            users (list) - List of usernames representing individual users.
            duration (int) - Duration of the experiment in seconds.
            experimentId (str) - Id of this experiment (used to structure the logs).

        Returns:
            Dict {"total experiment time", "list of results for each user"}
        """
        
        twitterLogDir = "logs/twitter"
        
        experimentLogDir = os.path.join(twitterLogDir, experimentId)
        
        if not os.path.isdir(experimentLogDir):
            os.makedirs(experimentLogDir)
        
        return self._launchExperiment(database, users,
                duration, self._twitterExperiment, experimentLogDir)
        
    def exposed_twitterWaitForTweet(self, database, tweetId):
        """
        Waits for a tweet with a matching id to be seen by a local client
        and returns both the waiting time and the local time at which the tweet 
        was seen.
        
        Args:
            database (dict) - See docstr of exposed_getTwitterClient.
            tweetId (str) - The id of a tweet formatted according to the ids used
                by the database.
        
        Returns:
            Tuple: (elapsedTime, localTime)
        """
        
        twitterClient = self.exposed_getTwitterClient(database, "Waiter")
        
        tweetId = copy.deepcopy(tweetId)
        startTime = time.time()
        found = False
        
        while not found:
            found = twitterClient.tweetFound(tweetId)
            
        endTime = time.time()
        
        return (endTime - startTime, endTime)

    def exposed_startWikiExperiment(self, database, users, duration, experimentId):
        """
        Launches a normal wiki experiment (read/writes of articles), sending
        queries to the specified database and using one process for each
        specified user. Run the experiment for the specified duration.

        Args:
            database (dict) - See docstr of exposed_getWikiClient.
            users (list) - List of usernames representing individual users.
            duration (int) - Duration of the experiment in seconds.
            experimentId (str) - String representing the experiment id (used
                to organize logs)

        Returns:
            Dict {"total experiment time", "list of results for each user"}
        """
        
        wikiLogDir = "logs/wiki"
        
        experimentLogDir = os.path.join(wikiLogDir, experimentId)
        
        if not os.path.isdir(experimentLogDir):
            os.makedirs(experimentLogDir)
            
        return self._launchExperiment(database, users, duration,
                self._wikiExperiment, experimentLogDir)
        
    def exposed_wikiWaitForArticle(self, database, articleId):
        """
        Waits for an article with a matching id to be seen by a local client
        and returns both the waiting time and the local time at which the article
        was seen.
        
        Args:
            database (dict) - See docstr of exposed_getWikiClient.
            tweetId (str) - The id of an article formatted according to the ids used
                by the database.
        
        Returns:
            Tuple: (elapsedTime, localTime)
        """
        
        wikiClient = self.exposed_getWikiClient(database, "Waiter")
        
        startTime = time.time()
        found = False
        
        while not found:
            found = wikiClient.tweetFound(articleId)
            
        endTime = time.time()
        
        return (endTime - startTime, endTime)

    def exposed_getTwitterClient(self, database, user):
        """
        Creates a twitter client to the specified database and for the specified
        user.

        Args:
            database (dict) - A dictionary containing information about the
                database. Only required key is "type" containing the type of the
                database (cassandra, dynamo, etc...). Extra key-value pairs will
                be passed to the initialization of the client (e.g: port numbers).
            user (str) - Username of the user associated with the client.
        
        Returns:
            A TwitterClient with connections to the specified database and
            associated with the specified user.
        """
            
        twitterClients = {"cassandra": CassandraTwitterClient, 
                          "cassandranorm": CassandraNormTwitterClient,
                          "couchbase1": CouchbaseTwitterClient1,
                          "couchbase2": CouchbaseTwitterClient2,
                          "couchbase3": CouchbaseTwitterClient3,
                          "couchbase4": CouchbaseTwitterClient4}

        databaseExtraArgs = dict(database)
        del databaseExtraArgs["type"]
        return twitterClients[database["type"]](user, self._nodeInfo, **databaseExtraArgs)

    def exposed_getWikiClient(self, database, user):
        """
        Creates a wiki client to the specified database and for the specified
        user.

        Args:
            database (dict) - A dictionary containing information about the
                database. Only required key is "type" containing the type of the
                database (cassandra, dynamo, etc...). Extra key-value pairs will
                be passed to the initialization of the client (e.g: port numbers).
            user (str) - Username of the user associated with the client.
        
        Returns:
            A WikipediaClient with connections to the specified database and
            associated with the specified user.
        """
            
        wikiClients = {"dynamo": DynamoWikipediaClient}

        databaseExtraArgs = dict(database)
        del databaseExtraArgs["type"]
        return wikiClients[database["type"]](user, self._nodeInfo, **databaseExtraArgs)

    def _launchExperiment(self, database, users, duration, fun, experimentLogDir):
        processes = []
        resultQueue = Queue()
        
        # Make deepcopies (using pickle) since database and users are remote references
        database = copy.deepcopy(database)
        users = copy.deepcopy(users)

        time1 = time.time()

        for user in users:
            p = Process(target = fun, args = (resultQueue, database, user, duration, experimentLogDir))
            processes.append(p)
            p.start()

        results = []

        for user in users:
            results.append(resultQueue.get())

        time2 = time.time()
        
        for p in processes:
            p.join()

        return {"experimentTime": time2 - time1, "results": results}

    def _twitterExperiment(self, resultQueue, database, user, duration, experimentLogDir):
        try:
            client = self.exposed_getTwitterClient(database, user)
            client.setupLogger(experimentLogDir)

            tweetLatencies = []
            tweetErrors = 0
            userlineLatencies = []
            userlineErrors = 0
            timelineLatencies = []
            timelineErrors = 0

            users = client.getUsernames()

            startTime = time.time()

            while time.time() - startTime < duration:
                opIndex = random.randrange(3)

                if opIndex == 0:
                    try:
                        latency, _ = client.tweet()
                        tweetLatencies.append(latency)
                    except Exception:
                        tweetErrors += 1
                elif opIndex == 1:
                    try:
                        latency, _ = client.getUserline(random.choice(users))
                        userlineLatencies.append(latency)
                    except Exception:
                        userlineErrors += 1
                elif opIndex == 2:
                    try:
                        latency, _ = client.getTimeline()
                        timelineLatencies.append(latency)
                    except Exception:
                        timelineErrors += 1
                        
                time.sleep(random.randint(1, 3))

            resultQueue.put({"status": "completed", 
                "numTweets": len(tweetLatencies),
                "numTweetErrors": tweetErrors,
                "numUserlines": len(userlineLatencies),
                "numUserlineErrors": userlineErrors,
                "numTimelines": len(timelineLatencies),
                "numTimelineErrors": timelineErrors,
                "avgTweetLatency": avg(tweetLatencies),
                "avgUserlineLatency": avg(userlineLatencies),
                "avgTimelineLatency": avg(timelineLatencies)})
        except Exception as e:
            resultQueue.put({"status": "aborted", "error": str(e) + "\n" + \
                             traceback.format_exc()})

    def _wikiExperiment(self, resultQueue, database, user, duration, experimentLogDir):
        try:
            client = self.exposed_getWikiClient(database, user)
            #client.setuplogger

            readLatencies = []
            readErrors = 0
            writeLatencies = []
            writeErrors = 0

            previouslyReadArticles = collections.deque(maxlen = 10)

            articleIds = client.getArticleIds()

            startTime = time.time()

            while time.time() - startTime < duration:
                opIndex = random.randint(0, 100)

                if opIndex <= 10 and len(previouslyReadArticles) > 0:
                    articleId, articleBody = random.choice(previouslyReadArticles)
                    charsToChange = random.sample(range(len(articleBody)),
                            random.randint(1, 1000))
                    for charIndex in charsToChange:
                        articleBody[charIndex] = articleBody[charIndex].swapcase()
                    try:
                        latency, result = client.edit(articleId, articleBody)
                        writeLatencies.append(latency)
                    except Exception:
                        writeErrors += 1
                else:
                    articleIdToRead = random.choice(articleIds)
                    try:
                        latency, result = client.read(articleIdToRead)
                        readLatencies.append(latency)
                        previouslyReadArticles.append(result)
                    except Exception:
                        readErrors += 1

            resultQueue.put({"status": "completed", 
                "numReads": len(readLatencies),
                "numReadErrors": readErrors,
                "numWrites": len(writeLatencies),
                "numWriteErrors": writeErrors,
                "avgReadLatency": avg(readLatencies),
                "avgWriteLatency": avg(writeLatencies)})
        except Exception as e:
            resultQueue.put({"status": "aborted", "error": str(e) + "\n" + \
                             traceback.format_exc()})


if __name__ == "__main__":
    from rpyc.utils.server import ThreadedServer
    t = ThreadedServer(WorkloadSlave, port = 25000, 
                       protocol_config = {"allow_all_attrs" : True,
                                          "allow_pickle" : True})
    t.start()
