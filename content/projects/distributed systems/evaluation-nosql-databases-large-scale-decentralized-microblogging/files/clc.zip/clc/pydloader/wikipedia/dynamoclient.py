import time
from boto import dynamodb
import random
import uuid
import string

def measureTime(fn):
    def wrapper(self, *args, **kwargs):
        time1 = time.time()
        result = fn(self, *args, **kwargs)
        time2 = time.time()
        return (time2 - time1, result)
    
    return wrapper

def DynamoWikipediaClient(WikipediaClient):
    def __init__(self, user, nodeInfo, region = "eu-west-1", articleTable = "articles"):
        self._region = region
        self._articleTableName = articleTable
        self._conn = dynamodb.connect_to_region(self._region)
        self._articleTable = self._conn.get_table(articleTable)
        super(DynamoWikipediaClient,self).__init__(user, nodeInfo)

    @measureTime
    def _read(self, articleId):
        return (articleId, self._articleTable.get_item(articleId)["body"])

    @measureTime
    def _edit(self, articleId = None, articleBody = None):
        if articleId is None:
            articleId = uuid.uuid1()

        if articleBody is None:
            articleBody = "".join(
                random.sample(string.letters + string.digits + " ", 
                random.randint(20, 140)))
            
        item = self._articleTable.new_item()
        item['id'] = articleId
        item['body'] = articleBody
        item.put()
        
        return articleId

    @measureTime
    def _getArticleIds(self):
        return list(self._articleTable.scan(attributes_to_get = ['id']))
