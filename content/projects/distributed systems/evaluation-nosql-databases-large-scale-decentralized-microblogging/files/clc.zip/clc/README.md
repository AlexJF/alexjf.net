Costs
=====
* https://docs.google.com/spreadsheet/ccc?key=0AodQKQjyQhGHdDlPeHB0UzZ1LUNaRVN2Y1hQTF80TEE#gid=1

CouchDB
=======
* CouchDB definitive guide - http://guide.couchdb.org/editions/1/en/index.html
* CouchApps 
    - http://guide.couchdb.org/draft/show.html
    - http://couchapp.org/page/what-is-couchapp

Python Distributed Loader (pydloader)
=====================================

Installation
------------
* Install python2 and virtualenv
    - Windows instructions if you happen to want to run it on your laptop Peter: 
      http://www.tylerbutler.com/2012/05/how-to-install-python-pip-and-virtualenv-on-windows-with-powershell/
* Run 'virtualenv ~/.pyenvs/clc' (or any other path, just make sure to remember it)
* Run 'source ~/.pyenvs/clc/bin/activate'
* Run 'pip install -r requirements.txt'

Running
-------
* Run 'source ~/.pyenvs/clc/bin/activate' (if needed)
* Run './launchWorkloadManager.sh'

Documentation
-------------
* Run 'help(manager)' in the shell obtained by running the previous step.

Tips
----
* virtualenvwrapper facilitates the whole creation and activation of the
  virtualenv.

Example session (with comments)
-------------------------------
    # Check running instances
    In [1]: manager.ec2_listInstances()
    |           ID |         Zone |        State |
    |   i-f6619bbb |   eu-west-1a |   terminated |

    # Launch new instances in the 1st region (Ireland) in 1 availability zone
    # and 1 instance per availability zone
    In [2]: dbsInfo = manager.ec2_launchInstances(manager.ec2Regions[0], 1, 1)

    # Check running instances to ensure that there's a new instance with state
    # running
    In [3]: manager.ec2_listInstances()
    |           ID |         Zone |        State |
    |   i-f6619bbb |   eu-west-1a |   terminated |
    |   i-74ae6b39 |   eu-west-1a |      running |

    # dbsInfo contains information about the endpoints of the instances. Create
    # slaves at each of those endpoints
    In [4]: dbs = manager.createSlaves(dbsInfo)

    # Since we created just one instance (and thus 1 slave), address it directly
    In [5]: db0 = dbs[0]

    # You can check info about the slave by simply asking for its representation
    In [6]: db0
    Out[6]: RemoteSlave@54.228.53.188 (DOWN)

    # You can launch the slave explicitly like so or just use it and if it is not
    # online it will be launched automatically
    In [7]: db0.launch()
    Updating remote code
    The authenticity of host '54.228.53.188 (54.228.53.188)' can't be established.
    RSA key fingerprint is f6:82:b7:9c:98:3e:93:0f:3f:05:6f:60:8f:d1:af:0f.
    Are you sure you want to continue connecting (yes/no)? yes
    Warning: Permanently added '54.228.53.188' (RSA) to the list of known hosts.
    sudo /home/ec2-user/clc/launchWorkloadSlave.sh
    exit status:  0
    nohup: appending output to `nohup.out'

    # Just making sure that slave is up and running by asking him to evaluate 'lol'
    In [8]: db0.eval("'lol'")
    Out[8]: 'lol'

    # Example of asking the server to set up Cassandra
    In [9]: db0.setupCassandra(dbInfo)

    (...)

    # In the end of the session, don't forget to terminate instances
    In [12]: manager.ec2_terminateInstances()

    In [13]: manager.ec2_listInstances()
    |           ID |         Zone |        State |
    |   i-74ae6b39 |   eu-west-1a | shutting-down |

    In [14]: manager.ec2_listInstances()
    |           ID |         Zone |        State |
    |   i-74ae6b39 |   eu-west-1a |   terminated |

Amazon Web Services (AWS)
=========================
* Login: https://clc.signin.aws.amazon.com/console
* AMIs w/ Cassandra, Couchbase, CouchDB and MongoDB:
    - Ireland: ami-9b1d0cef
    - N. Virginia: TO BE UPDATED
