#!/bin/sh

cd pydloader
ipython --ipython-dir="../.ipython" --profile="workload-manager"
