import sys

def avg(l):
    if len(l) == 0:
        return "N/A"
    return sum(l)/len(l)

if len(sys.argv) < 4:
    print("Usage: ./vmstat-aggregator.py <vmstat output file> <column name> <aggreg seconds>")

vmstatFile = sys.argv[1]
columnName = sys.argv[2]
columnIndex = 0
aggregationSeconds = int(sys.argv[3])
mode = 'normal'

if len(sys.argv) == 5:
    mode = sys.argv[4]

events = []

currentExperimentTime = 0

with open(vmstatFile) as f:
    header = f.readline()
    columns = f.readline().split()

    columnIndex = columns.index(columnName)

    for line in f:
        values = line.split()
        events.append((currentExperimentTime, int(values[columnIndex])))
        currentExperimentTime += 5

if mode != 'latex':
    print("Found %d matching events" % len(events))

for event in events:
    print("%d %d" % event)

if mode != 'latex':
    print(" ")
    print("Total average: %s" % str(avg([e[1] for e in events])))
