import matplotlib.pyplot as plt
from scipy.stats import rv_discrete
import numpy

numberPeople = 100000

powerlaw = lambda p, x: p[0] * (x+1) ** p[1]

xs = numpy.arange(numberPeople+1)
ys = powerlaw((4.47341022e+06,  -8.43865709e-01), xs)
ps = []

ySum = sum(ys)

for y in ys:
    ps.append(y / ySum)

pSum = sum(ps)

print("ySum = %f, pSum = %f" % (ySum, pSum))

followerDistribution = rv_discrete(name='follower', values=(xs, ps))

numFollowers = followerDistribution.rvs(size = numberPeople)

sums = [0] * (numberPeople + 1)

for num in numFollowers:
    sums[num] += 1

plt.figure()
plt.plot(xs, sums, 'b')
plt.show()
