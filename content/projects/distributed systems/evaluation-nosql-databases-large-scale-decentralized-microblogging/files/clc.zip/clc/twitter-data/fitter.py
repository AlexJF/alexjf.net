from scipy import optimize
import fileinput
import numpy

def residuals(f):
    def real_residuals(p, x, y):
        return y - f(p, x)
    return real_residuals

def fit(x, y, f, p_initial):
    p, cov, infodict, mesg, ier = optimize.leastsq(residuals(f),
            p_initial, args=(x, y), full_output = True)
    ss_err=(infodict['fvec']**2).sum()
    ss_tot=((y-y.mean())**2).sum()
    rsquared=1-(ss_err/ss_tot)

    return (p, rsquared)

xdata = []
ydata = []

for line in fileinput.input():
    try:
        x, y = line.split()

        if x == "0":
            continue

        xdata.append(float(x))
        ydata.append(int(y))
    except:
        pass

xdata = numpy.array(xdata)
ydata = numpy.array(ydata)

powerlaw = lambda p, x: p[0] * x ** p[1]
lognorm = lambda p, x: p[2] / (x * p[0] * numpy.sqrt(2 * numpy.pi)) * numpy.exp(-1/2*(numpy.log(x)/p[0])**2)
exponential = lambda p, x: p[0] * numpy.exp(p[1] * x)

print("Powerlaw")
print(str(fit(xdata, ydata, powerlaw, (1, -1))))

print("Lognorm")
print(str(fit(xdata, ydata, lognorm, (1, 0, 1))))

print("Exponential")
print(str(fit(xdata, ydata, exponential, (1, 0))))

