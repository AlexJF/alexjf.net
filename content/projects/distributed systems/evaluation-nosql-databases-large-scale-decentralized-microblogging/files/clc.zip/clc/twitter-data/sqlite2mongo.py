#! /usr/bin/env python

import pymongo
import sqlite3
import sys
import uuid

if (len(sys.argv) != 2):
    print("Usage: sqlite2mongo <path to sqlite database>")
    exit()

pathToSqliteDb = sys.argv[1]

mongoClient = pymongo.MongoClient('localhost', 27017)
mongoDB = mongoClient.created
sqliteConn = sqlite3.connect(pathToSqliteDb)
sqliteCursor = sqliteConn.cursor()

################
# Create users #
################

sqliteCursor.execute("SELECT username FROM Users")
users = [u[0] for u in sqliteCursor.fetchall()]
print("Phase 1. Migrating %d users" % len(users))

mongoDB.Users.insert( [{_id: user, followers: []} for user in users] )

####################
# Create followers #
####################

sqliteCursor.execute("SELECT username, following FROM Followers")
followRelationships = sqliteCursor.fetchall()
print("Phase 2. Migrating %d follower relationships" % len(followRelationships))

for relationship in followRelationships:
    follower, username = relationship[0:2]
    mongoDB.Users.update( {_id: username}, { $push: { followers: follower } } )

#################
# Create tweets #
#################

sqliteCursor.execute("SELECT COUNT(*) FROM Tweets");
print("Phase 3. Migrating %d tweets" % int(sqliteCursor.fetchone()[0]))

for user in mongoDB.Users:
    sqliteCursor.execute("SELECT tweetid, body FROM Tweets WHERE username = :username",
            dict(username = user._id))
    tweets = sqliteCursor.fetchall()

    for tweet in tweets:
        tweetId = uuid.UUID(tweet[0])
        tweetBody = tweet[1]

        mongoDB.Tweets.insert( { _id: tweetId, username: user._id, body: tweetBody } )
        mongoDB.Userline.insert( {username: user._id, tweetid: tweetId, body: tweetBody } )

        for follower in user.followers:
            mongoDB.Timeline.insert( { username: follower, tweetid: tweetId, posted_by: user._id, body: tweetBody } )

sqliteCursor.close()
sqliteConn.close()

print("Phase 4. Creating indices for Userline and Timeline" % int(sqliteCursor.fetchone()[0]))
mongoDB.Userline.ensure_index([('username', pymongo.ASCENDING), ('tweetid', pymongo.DESCENDING)])
mongoDB.Timeline.ensure_index([('username', pymongo.ASCENDING), ('tweetid', pymongo.DESCENDING)])

mongoClient.close()

print("COMPLETE!")
