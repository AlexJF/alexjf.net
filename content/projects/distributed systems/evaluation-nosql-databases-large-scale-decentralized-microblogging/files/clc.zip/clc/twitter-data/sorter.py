import fileinput

values = {}

for line in fileinput.input():
    if not line:
        continue

    x, y = line.split()
    try:
        x = int(x)
        y = int(y)
    except:
        print(line)
        continue
    values[x] = y

for x in sorted(values.keys()):
    print("%d %d" % (x, values[x]))
