import sys, re, datetime, os

def avg(l):
    if len(l) == 0:
        return "N/A"
    return sum(l)/len(l)

if len(sys.argv) < 4:
    print("Usage: ./log-aggregator.py <log folder> <tag name> <aggreg seconds>")

logFolder = sys.argv[1]
tagName = sys.argv[2]
aggregationSeconds = int(sys.argv[3])
mode = 'normal'

if len(sys.argv) == 5:
    mode = sys.argv[4]

events = []

eventRegex = re.compile("\[" + tagName + "\]\s+(.+)\s+=>\s+\[([^\]]+)\]")

if mode != 'latex':
    print("Average aggregation for tag '%s'" % tagName)

for logFile in os.listdir(logFolder):
    if not logFile.endswith(".log"):
        continue
    with open(os.path.join(logFolder, logFile)) as log:
        for line in log:
            match = eventRegex.match(line)

            if match:
                time = datetime.datetime.strptime(match.group(1), "%Y-%m-%d %H:%M:%S,%f")
                try: 
                    latency = float(match.group(2))
                    events.append((time, latency))
                except Exception:
                    events.append((time, "error"))

if mode != 'latex':
    print("Found %d matching events" % len(events))

events.sort(key=lambda x: x[0])

startingTime = events[0][0]
endingTime = events[-1][0]

if mode != 'latex':
    print("Starting time: %s" % str(startingTime))
    print("End time: %s" % str(endingTime))
    print("Total duration: %s seconds" % (endingTime - startingTime).total_seconds())
    print(" ")

subEvents = []
for event in events:
    if not subEvents:
        subEvents.append(event)
    else:
        firstEvent = subEvents[0]

        if (event[0] - firstEvent[0]).total_seconds() > aggregationSeconds:
            lastEvent = subEvents[-1]
            secondsSinceStart = (lastEvent[0] - startingTime).total_seconds()

            nonErrorEvents = [e for e in subEvents if type(e[1]) is float]
            averageLatency = str(avg([e[1] for e in nonErrorEvents]))
            numErrorsInSubEvents = len(subEvents) - len(nonErrorEvents)

            if mode != 'latex':
                print("%f %s (%d errors)" % (secondsSinceStart, averageLatency, numErrorsInSubEvents))
            else:
                print("%f %s" % (secondsSinceStart, averageLatency))

            subEvents = [event]
        else:
            subEvents.append(event)

nonErrorEvents = [e for e in events if type(e[1]) is float]
errorEvents = [e for e in events if type(e[1]) is str]

if mode != 'latex':
    print(" ")
    print("Total average: %s" % str(avg([e[1] for e in nonErrorEvents])))
    print("Total errors: %d" % len(errorEvents))
