from scipy.stats import rv_discrete
import numpy
import random
import sqlite3
import uuid
import textwrap
import sys

numberPeople = 1000

if len(sys.argv) > 1:
    numberPeople = int(sys.argv[1])

conn = sqlite3.connect("twitter-%d.db" % numberPeople)
cursor = conn.cursor()

#################
# Create tables #
#################
print("Phase 1. Creating tables")
cursor.execute("""
    CREATE TABLE Users (
        username text PRIMARY KEY
    );""")

cursor.execute("""
    CREATE TABLE Followers (
        username text,
        following text,
        PRIMARY KEY(username, following)
    );""")

cursor.execute("""
    CREATE TABLE Tweets (
        tweetid timeuuid PRIMARY KEY,
        username text,
        body text
    );""")

################
# Create users #
################
print("Phase 2. Creating %d users" % numberPeople)
print("Phase 2-1. Creating name fodder")
names = []
with open('census.names') as f:
    for line in f:
        if not line:
            continue

        names.append(line.split()[0].capitalize())

print("Phase 2-2. Creating actual users")
users = []
for i in range(numberPeople):
    username = ""

    while username in users or not username:
        username = "".join(random.sample(names, 2))

    users.append(username)
    cursor.execute("INSERT INTO Users (username) VALUES (:username)", 
            dict(username = username))


####################
# Create followers #
####################
print("Phase 3. Creating follower relationships")
powerlaw = lambda p, x: p[0] * (x+1) ** p[1]

xs = numpy.arange(numberPeople / 4)
ys = powerlaw((4.47341022e+06,  -8.43865709e-01), xs)
ps = []

ySum = sum(ys)

for y in ys:
    ps.append(y / ySum)

followerDistribution = rv_discrete(name='follower', values=(xs, ps))

numFollowersByUser = followerDistribution.rvs(size = numberPeople)
usersSortedByFollowers = sorted(users, 
        key=lambda user: numFollowersByUser[users.index(user)])

i = 0
for user in users:
    numFollowers = numFollowersByUser[i]
    followerIndexes = followerDistribution.rvs(size = numFollowers)
    possibleFollowers = list(usersSortedByFollowers)
    followers = [possibleFollowers.pop(j) for j in followerIndexes]

    for follower in followers:
        cursor.execute("INSERT INTO Followers (username, following) \
                VALUES (:username, :following)",
                dict(username = follower, following = user))
    i += 1

print("         Total relationships created: %d" % sum(numFollowersByUser))

#################
# Create tweets #
#################
print("Phase 4. Creating tweets")
print("Phase 4-1. Creating tweet fodder")
tweetFodder = []
currentParagraph = []

with open('dostoevsky.txt') as f:
    for line in f:
        line = line.strip()
        if not line:
            if currentParagraph:
                pieces = textwrap.wrap(" ".join(currentParagraph), 140)
                tweetFodder.extend([unicode(piece, 'utf-8') for piece in pieces])
            currentParagraph = []
        else:
            currentParagraph.append(line.strip())

print("Phase 4-2. Creating actual tweets")
i = 0
totalTweets = 0
for user in users:
    cursor.execute("SELECT COUNT(username) FROM Followers WHERE following = :username",
            dict(username = user))
    numFollowers = int(cursor.fetchone()[0])
    meanTweets = 2**numpy.log(numFollowers + 1)
    deviationTweets = numpy.log((numFollowers + 1)*10)
    numTweets = int(round(max(0, random.normalvariate(meanTweets, deviationTweets))))

    for i in range(numTweets):
        tweetId = uuid.uuid1()
        tweetBody = random.choice(tweetFodder)

        cursor.execute("INSERT INTO Tweets (tweetid, username, body) \
                VALUES (:tweetId, :username, :body)",
                dict(tweetId = unicode(tweetId), username = user, body = tweetBody))

    totalTweets += numTweets

print("         Total tweets created: %d" % totalTweets)

sums = [0] * numberPeople
for i in range(len(numFollowersByUser)):
    sums[numFollowersByUser[i]] += 1

with open('resulting-follower-distribution', 'w') as f:
    f.writelines(["%d %d\n" % (i, sums[i]) for i in range(len(sums))])

cursor.close()
conn.commit()
conn.close()

print("COMPLETE!")
