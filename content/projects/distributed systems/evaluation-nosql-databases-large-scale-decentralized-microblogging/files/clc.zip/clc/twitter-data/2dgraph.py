import matplotlib.pyplot as plt
import fileinput
#from scipy.stats import powerlaw
from scipy.stats import lognorm
import numpy

xLabel = ""
yLabel = ""
xData = []
yData = []

with fileinput.input() as input:
    xLabel, yLabel = input.readline().split()

    for line in input:
        if not line:
            continue
        x, y = line.split()
        xData.append(int(x))
        yData.append(int(y))

xData = numpy.array(xData)
yData = numpy.array(yData)

xMin = min(xData)
xMax = max(xData)
yMin = min(yData)
yMax = max(yData)

plt.figure()

plt.plot(xData, yData, 'b')

#powerlaw = lambda x, amp, index: amp * (x**index)
#powerLawXData = linspace(xMin, xMax, 10000)
#powerLawYData = powerlaw(powerLawXData, 28237387.748161, -1.721441)
#powerLawYData = powerlaw.pdf(powerLawXData, 1.0, loc=-919.31972291066336,
    #scale=1983.4724491461852)

#powerlaw = lambda p, x: p[0] * x ** p[1]
#powerlawY = powerlaw((4.47341022e+06,  -8.43865709e-01), xData)

#lognorm = lambda p, x: p[2] * numpy.divide(1, x * p[0] * numpy.sqrt(2 * numpy.pi)) * numpy.exp(-numpy.divide((numpy.log(x) - p[1])**2, 2 * p[0] **2))
#lognormalX = numpy.arange(xMin, xMax, 1)
#lognormalY = lognorm((6.30400081e-05,   0.00000000e+00,   6.43709957e+02), xData)

#plt.plot(powerLawXData, powerLawYData, 'r')
#plt.plot(xData, lognormalY, 'r')
#plt.plot(xData, powerlawY, 'g')

plt.xlim(xMin, xMax)
plt.ylim(yMin, yMax)

plt.xlabel(xLabel)
plt.ylabel(yLabel)
plt.show()
