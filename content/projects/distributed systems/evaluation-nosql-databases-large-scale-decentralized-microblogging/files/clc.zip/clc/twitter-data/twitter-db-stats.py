import sqlite3
import sys

numberPeople = int(sys.argv[1])

conn = sqlite3.connect("twitter-%d.db" % numberPeople)
cursor = conn.cursor()

result = cursor.execute("SELECT COUNT(*) FROM Followers")
numberFollowerRelationShips = result.fetchone()[0]

result = cursor.execute("SELECT COUNT(*) FROM Tweets")
numberTweets = result.fetchone()[0]

print("Num users: %d" % numberPeople)
print("Num follower relationships: %d" % numberFollowerRelationShips)
print("Num tweets: %d" % numberTweets)
