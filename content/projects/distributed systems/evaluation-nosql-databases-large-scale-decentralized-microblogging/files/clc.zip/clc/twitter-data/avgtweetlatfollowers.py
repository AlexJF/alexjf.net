import sys, re, datetime, os, sqlite3

def avg(l):
    if len(l) == 0:
        return "N/A"
    return sum(l)/len(l)

if len(sys.argv) < 3:
    print("Usage: ./avgtweetlatfollowers.py <log folder> <twitter sqlite database>")

logFolder = sys.argv[1]
twitterDatabase = sys.argv[2]
tagName = "tweet"
mode = 'normal'

if len(sys.argv) == 4:
    mode = sys.argv[3]

events = {}

eventRegex = re.compile("\[" + tagName + "\]\s+(.+)\s+=>\s+\[([^\]]+)\]")

if mode != 'latex':
    print("Average tweet latency per follower")

conn = sqlite3.connect(twitterDatabase)
cursor = conn.cursor()

for logFile in os.listdir(logFolder):
    with open(os.path.join(logFolder, logFile)) as log:
        username = logFile[:-4]
        cursor.execute("SELECT COUNT(*) FROM Followers WHERE following = :following", {'following': username})
        numFollowers = cursor.fetchone()[0]

        eventsList = events.get(numFollowers, [])

        if not eventsList:
            events[numFollowers] = eventsList

        for line in log:
            match = eventRegex.match(line)

            if match:
                time = datetime.datetime.strptime(match.group(1), "%Y-%m-%d %H:%M:%S,%f")
                try: 
                    latency = float(match.group(2))
                    eventsList.append((time, latency))
                except Exception:
                    eventsList.append((time, "error"))

if mode != 'latex':
    print("Found %d tweet events" % sum([len(eventsList) for eventsList in events.values()]))

orderedNumFollowers = sorted(events.keys())

for numFollowers in orderedNumFollowers:
    eventsList = events[numFollowers]
    averageLatency = avg([l for _, l in eventsList])

    print("%d %s" % (numFollowers, averageLatency))
