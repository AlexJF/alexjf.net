import fileinput, re, math

def avg(l):
    if len(l) == 0:
        return "N/A"
    return sum(l)/len(l)

floatLineRegex = re.compile(":\s+([\d.]+),")

values = []

with fileinput.input() as f:
    for line in f:
        match = floatLineRegex.search(line)

        if match is not None:
            values.append(float(match.group(1)))

mean = avg(values)
stdev = math.sqrt(sum((x-mean) ** 2 for x in values) / len(values))
print("Mean: %f" % mean)
print("Standard deviation: %f" % stdev)
