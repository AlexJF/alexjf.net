#! /usr/bin/env python

import cql
import sqlite3
import sys
import uuid

if (len(sys.argv) != 2):
    print("Usage: sqlite2cassandranorm <path to sqlite database>")
    exit()

pathToSqliteDb = sys.argv[1]

conn = cql.connect("localhost", 9160, "twitter", cql_version='3.0.0')
cursor = conn.cursor()
sqliteConn = sqlite3.connect(pathToSqliteDb)
sqliteCursor = sqliteConn.cursor()

#################
# Create tables #
#################
print("Phase 1. Creating tables")
cursor.execute("""
    CREATE TABLE Users (
        username text PRIMARY KEY
    );""")

cursor.execute("""
    CREATE TABLE Followers (
        username text,
        follower text,
        PRIMARY KEY(username, follower)
    );""")

cursor.execute("""
    CREATE TABLE Tweets (
        tweetid timeuuid PRIMARY KEY,
        username text,
        body text
    );""")

cursor.execute("""
    CREATE TABLE Userline (
        username text,
        tweetid timeuuid,
        PRIMARY KEY(username, tweetid)
    );""")

cursor.execute("""
    CREATE TABLE Timeline (
        username text,
        tweetid timeuuid,
        PRIMARY KEY(username, tweetid)
    );""")

################
# Create users #
################

sqliteCursor.execute("SELECT username FROM Users")
users = [u[0] for u in sqliteCursor.fetchall()]
print("Phase 2. Migrating %d users" % len(users))

for user in users:
    cursor.execute("INSERT INTO Users (username) VALUES (:username)", 
            dict(username = user))


####################
# Create followers #
####################
sqliteCursor.execute("SELECT username, following FROM Followers")
followRelationships = sqliteCursor.fetchall()
print("Phase 3. Migrating %d follower relationships" % len(followRelationships))

for relationship in followRelationships:
    cursor.execute("INSERT INTO Followers (username, follower) \
            VALUES (:username, :follower)",
            dict(follower=relationship[0], username=relationship[1]))

#################
# Create tweets #
#################
sqliteCursor.execute("SELECT COUNT(*) FROM Tweets");
print("Phase 4. Migrating %d tweets" % int(sqliteCursor.fetchone()[0]))

for user in users:
    sqliteCursor.execute("SELECT tweetid, body FROM Tweets WHERE username = :username",
            dict(username = user))
    tweets = sqliteCursor.fetchall()
    
    sqliteCursor.execute("SELECT username FROM Followers WHERE following = :username",
            dict(username = user))
    followers = [fl[0] for fl in sqliteCursor.fetchall()]

    for tweet in tweets:
        tweetId = uuid.UUID(tweet[0])
        tweetBody = tweet[1]

        cursor.execute("INSERT INTO Tweets (tweetid, username, body) \
                VALUES (:tweetId, :username, :body)",
                dict(tweetId = tweetId, username = user, body = tweetBody))

        cursor.execute("INSERT INTO Userline (username, tweetid) \
                VALUES (:username, :tweetId)",
                dict(tweetId = tweetId, username = user))

        for follower in followers:
            cursor.execute("INSERT INTO Timeline (username, tweetid) \
                    VALUES (:username, :tweetId)",
                dict(tweetId = tweetId, username = follower))

sqliteCursor.close()
sqliteConn.close()
cursor.close()
conn.close()

print("COMPLETE!")
