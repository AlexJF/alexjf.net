#!/bin/sh

#sudo su root
cd "$( dirname "${BASH_SOURCE[0]}" )"
source ../.pyenvs/clc/bin/activate
cd pydloader
nohup python slave.py &
sleep 5
