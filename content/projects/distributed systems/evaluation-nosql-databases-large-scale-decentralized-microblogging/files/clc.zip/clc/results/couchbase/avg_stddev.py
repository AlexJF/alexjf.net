import math, sys

def avg(l):
    return sum(l)/len(l)
    
def stddev(l):
    avg = sum(l)/len(l)
    tmp = [(v-avg)*(v-avg) for v in l]
    return math.sqrt(sum(tmp)/len(tmp))
    
def convertToRatio(l):
    s = sum(l)
    return [v/s for v in l]

filename = sys.argv[1]
ratio = False
if len(sys.argv) > 2 and sys.argv[2] == "ratio":
    ratio = True

list = []
with open(filename) as f:
    for line in f:
        line = line.strip()
        if len(line) < 1:
            if len(list) > 0:
                if ratio:
                    print "SUM=%f" % sum(convertToRatio(list))
                    print "AVG=%f" % avg(convertToRatio(list))
                    print "STDEV=%f" % stddev(convertToRatio(list))
                else:
                    print "SUM=%f" % sum(list)
                    print "AVG=%f" % avg(list)
                    print "STDEV=%f" % stddev(list)
        else:
            first = line.split()[0]
        
            if first == "-":
                print line.strip()
                list = []
            else:
                list.append(float(first))
