import manager
import slave

def reloadManager():
    global manager
    manager = reload(manager)

print(" ")
print(">>> Check help(manager) if you're lost.")
print(">>> Check help(slave) to see what you can order a slave to do.")
print("    (exposed_<function> may be called as <function> from a remote slave instance.")
print(">>> You can also just use tab-completion.")
print(" ")
print(">>> Don't forget to change manager.keyPair to the name of your")
print("    inter-region keypair created on the AWS console.")
