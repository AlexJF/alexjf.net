package pt.ist.anacom.replication;

class RemoteReplicatedServer extends RemoteApplicationServer {
	
	private ReplicationManager _replicationManager;
	
	@Override
	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException {
		
        ServiceFunction<CellPhoneSimpleDto, BalanceDto> serviceFunction = 
        		new ServiceFunction<CellPhoneSimpleDto, BalanceDto>() {
        	
            @Override
            public BalanceDto execute(Replica replica, CellPhoneSimpleDto dto) {
                return replica.getCellPhoneBalance(dto);
            }
        }

        return _replicationManager
        		.sendRequestToReplicas(
        				getOperatorNameFromPhoneNumber(dto.getNumber()), 
        				dto, 
        				serviceFunction);
	}
}

// All anacom exceptions subclasses must implement this method.
AnacomException {
    throwYourself() {
        throw this;
    }
}

public interface ServiceFunction<I, O> {
    public O execute(String location, I dto);
}

// Each replica represents a port type to a different location
class Replica extends RemoteApplicationServer {
    ...
}
