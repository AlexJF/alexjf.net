package pt.ist.anacom.replication;

import java.util.HashMap;
import java.util.Map;
import pt.ist.anacom.shared.stubs.OperatorService;
import pt.ist.anacom.shared.dto.*;
import java.util.Collections;
import java.util.concurrent.Semaphore

public class ReplicationManager {

	private OperatorService _service;
	private int _quorumSize;
	private Map<String, Integer> _timeStamps;

	ReplicationManager(OperatorService service, int quorumSize) {
		_service = service;
		_quorumSize = quorumSize;
		_timeStamps = new HashMap<String, Integer>();
	}

	protected Integer getTimestamp(String operatorName) {

		Integer timeStamp = _timeStamps.get(operatorName);

		if (timeStamp == null) {
			AnacomDto timestampDto = 
					sendRequestToReplicas(operatorName, new AnacomDto(), new TimestampServiceFunction());
			timeStamp = timestampDto.getTimestamp();
			_timeStamps.put(operatorName, timestampDto);
		}

		return timeStamp;
	}

	protected void setTimestamp(String operatorName, Integer timestamp) {
		_timeStamps.put(operatorName, timestamp);
	}

	private class TimestampServiceFunction implements
			ServiceFunction<Integer, Void> {

		@Override
        Integer execute(Replica replica,  Void notNeeded) {
            return replica.getTimestamp()
        }
	}

	protected Replica[] getReplicasForOperator(String operatorName) {
		// Instantiate replicas from UDDI cached info (or get cached replicas if
		// already created)
	}

	synchronized public <I extends AnacomDto, O extends AnacomDto> O sendRequestToReplicas(
			String operatorName, I dto, ServiceFunction<I, O> serviceFunction) {

		// Initiate semaphore and result/exception lists
		Semaphore _sem = new Semaphore(0);

		// List containing the results from each replica
		List<O> resultList = Collections.synchronizedList(new LinkedList<O>());

		// List containing the exceptions thrown by the replicas as result
		List<AnacomException> exceptionList = 
				Collections.synchronizedList(new LinkedList<AnacomException>());

		// Set the request dto timestamp to the current timestamp + 1
		dto.setTimestamp(getTimestamp(operatorName + 1));

		// Get an array of replicas for the specified operator name
		Replica[] replicas = getReplicasForOperator(operatorName);

		// Start threads to send requests to all replicas
		for (Replica replica : replicas) {

			Thread replicationThread = new ReplicationThread<I, O>(replica,
					dto, serviceFunction, resultList, exceptionList, _sem);
			replicationThread.start();
		}

		// Wait for a quorum
		_sem.acquire(_quorumSize);
		O finalResult = null;
		AnacomException finalException = null;
		int maxTimeStamp = 0;

		// Find dto associated with biggest timestamp
		for (O result : resultList) {
			Integer resultTimeStamp = result.getTimeStamp();
			
			if (resultTimeStamp > maxTimeStamp) {
				_finalResult = result;
				maxTimeStamp = resultTimeStamp;
			}
		}

		// Check if there's an exception with a bigger timestamp
		for (AnacomException exception : exceptionList) {
			Integer exceptionTimeStamp = exception.getTimeStamp();
			
			if (exception.getTimeStamp() > maxTimeStamp) {
				_finalException = exception;
				maxTimeStamp = exceptionTimeStamp;
			}
		}

		// If we found an exception with a bigger timestamp, throw it
		if (_finalException != null) {
			_finalException.throwYourself();
		}

		// Update our local timestamp
		setTimestamp(operatorName, maxTimeStamp);

		// Otherwise return result
		return _finalResult;
	}

	private static class ReplicationThread<I, O> extends Thread {
		
		Replica _replica;
		ServiceFunction<I, O> _serviceFunction;
		T _dto;
		List<O> _resultList;
		List<AnacomException> _exceptionList;
		Semaphore _sem;

		public ReplicationThread(Replica replica, I dto,
				ServiceFunction<I, O> serviceFunction, List<O> resultList,
				List<AnacomException> exceptionList, Semaphore sem) {
			
			_replica = replica;
			_dto = dto;
			_serviceFunction = serviceFunction;
			_resultList = resultList;
			_exceptionList = exceptionList;
			_sem = sem;
		}

		@Override
		public void run() {
			
			O result = null;
			AnacomException exception = null;
			
			try {
				try {
					result = _serviceFunction.execute(_replica, _dto);
				} catch (OperatorNotExistsException_Exception e) {
					throw ExceptionConverter.convertFromWebServiceException(e);
				} catch (CellPhoneAlreadyExistsException_Exception e) {
					throw ExceptionConverter.convertFromWebServiceException(e);
				} catch (InvalidCellPhonePrefixException_Exception e) {
					throw ExceptionConverter.convertFromWebServiceException(e);
				} catch (InvalidCellPhoneNumberException_Exception e) {
					throw ExceptionConverter.convertFromWebServiceException(e);
				} catch (HigherThanMaxBalanceException_Exception e) {
					throw ExceptionConverter.convertFromWebServiceException(e);
				}
			} catch (AnacomException e) {
				exception = e;
			} catch (Exception e) {
				// Print something but don't add it to the exception list.
				return;
			}

			// If the semaphore doesn't have queued threads, the caller already
			// obtained a quorum so just ignore the response (whatever that may
			// be).
			if (!_sem.hasQueuedThreads()) {
				return;
			} else if (exception != null) {
				_exceptionList.add(exception);
			} else {
				_resultList.add(result);
			}

			// If we got this far we added something to one of the lists so
			// signal the semaphore
			// that we got a succesful replica response
			_sem.release();
		}
	}
}
