package pt.ist.anacom.security.handlers.anacom;

import java.util.LinkedList;
import java.util.List;

import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Node;

import sun.security.x509.X509CertImpl;

/**
 * This handler grants the constraint that those using it will only receive
 * messages from Certification Authority or Presentation Server.
 */
public class OperatorCertificateHandler extends AnacomCertificateHandler {

	@Override
	protected boolean handleInboundMessage(SOAPMessage message) {
		System.out.println("Handling Inbound Message - Operator Certification Handler");

		try {
			SOAPHeader header = getHeader(getSoapEnvelope(message));
			Node certNode = getCertificateNode(header);
			X509CertImpl cert = null;

			List<String> unsecureOperations = new LinkedList<String>();
			String operationName = getOperationName(getSoapEnvelope(message));
			unsecureOperations.add("createCertificate");
			unsecureOperations.add("getBlackList");
			unsecureOperations.add("testCommand");
			if (operationName != null
					&& unsecureOperations.contains(operationName)) {
				return true;
			}

			if (certNode == null) {
				System.out.println("Cannot find certificate node");
				return false;
			}

			String certString = certNode.getTextContent();
			cert = new X509CertImpl(b64d.decodeBuffer(certString));

			String subjectDn = cert.getSubjectDN().toString();
			String subject = subjectDn.substring(subjectDn.indexOf('=') + 1,
					subjectDn.indexOf(','));

			if (!subject.equals("CA") && !subject.equals("PS")) {
				System.out.println("Unauthorized subject " + subject);
				return false;
			}

			return getParentResult(message);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	protected boolean getParentResult(SOAPMessage message) {
		return super.handleInboundMessage(message);
	}
}
