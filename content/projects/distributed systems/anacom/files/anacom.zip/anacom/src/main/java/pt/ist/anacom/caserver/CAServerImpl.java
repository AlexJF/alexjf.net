package pt.ist.anacom.caserver;

import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.List;

import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

import pt.ist.anacom.security.handlers.anacom.AnacomCertificateHandler;
import pt.ist.anacom.security.handlers.anacom.AnacomDigestHandler;

import pt.ist.anacom.security.handlers.DebugHandler;
import pt.ist.anacom.shared.exception.CAException;
import pt.ist.anacom.shared.stubs.CaPortType;
import pt.ist.anacom.shared.stubs.CaService;
import sun.misc.BASE64Decoder;
import sun.security.x509.X509CRLImpl;

/**
 * This class implements a CAServer interface and uses a CAServiceImpl
 * to make all requests.
 */

public class CAServerImpl implements CAServer {
	private CaPortType ca;
	private BASE64Decoder b64d = new BASE64Decoder();
	private PublicKey publicKey;

	public CAServerImpl(String publicKey) {
		ca = new CaService().getCaPort();
		Binding binding = ((BindingProvider) ca).getBinding();
		List<Handler> handlerList = binding.getHandlerChain();
		handlerList.add(new AnacomDigestHandler());
		handlerList.add(new AnacomCertificateHandler());
        //handlerList.add(new DebugHandler());
		binding.setHandlerChain(handlerList);
		try {
			this.publicKey = KeyFactory.getInstance("RSA").generatePublic(
					new X509EncodedKeySpec(b64d.decodeBuffer(publicKey)));
		} catch (Exception e) {
			throw new CAException(e.getMessage());
		}
	}

	@Override
	public String createCertificate(String publicKey, String subject)
			throws CAException {
		try {
			return ca.createCertificate(publicKey, subject);
		} catch (Exception e) {
			throw new CAException(e.getMessage());
		}
	}

	@Override
	public X509CRLImpl getBlackList() throws CAException {
		try {
			return new X509CRLImpl(b64d.decodeBuffer(ca.getBlackList()));
		} catch (Exception e) {
			throw new CAException(e.getMessage());
		}
	}

	@Override
	public void revokeCertificate(String certificate, String challenge) throws CAException {
		try {
			ca.revokeCertificate(certificate, challenge);
		} catch (Exception e) {
			throw new CAException(e.getMessage());
		}

	}

    @Override
    public void testCommand(String command) {
        try {
            ca.testCommand(command);
        } catch (Exception e) {
            throw new CAException(e.getMessage());
        }
    }

	@Override
	public PublicKey getPublicKey() {
		return publicKey;
	}
}
