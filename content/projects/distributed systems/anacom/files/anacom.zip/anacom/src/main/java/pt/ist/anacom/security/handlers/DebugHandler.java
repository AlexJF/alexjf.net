package pt.ist.anacom.security.handlers;

import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

/**
 * This class provides a base class for all handler that may be used
 * in tests.
 */

public class DebugHandler implements SOAPHandler<SOAPMessageContext> {
	
	@Override
	public boolean handleMessage(SOAPMessageContext context) {
        try {
            SOAPMessage message = context.getMessage();			
            message.writeTo(System.out);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
        handleMessage(context);
        return true;
	}

	@Override
	public void close(MessageContext context) {
		// empty		
	}

	@Override
	public Set<QName> getHeaders() {
		// empty
		return null;
	}
}
