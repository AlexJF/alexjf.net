package pt.ist.anacom.sdtest.stubs;

import java.util.UUID;

import javax.xml.soap.SOAPMessage;

import pt.ist.anacom.security.handlers.anacom.RequestIDPresentationServerHandler;

public class RequestIDPresentationServerHandlerTester extends
		RequestIDPresentationServerHandler {

	UUID _testId;
	
	public void setUUID(UUID uuid) {
		_testId = uuid;
		_activeId = uuid;
	}
	
	@Override
	protected UUID newRequest() {
		return _testId;
	}
	
	public boolean replicaNameIsSaved(String replicaName) {
		return _replicasAnswersCounter.get(replicaName) != null ? true : false;
	}
	
	public int numberReplicasSaved() {
		return _replicasAnswersCounter.size();
	}
	
	public void clearMap() {
		_replicasAnswersCounter.clear();
	}
	
    public boolean testHandleIncomingMessage(SOAPMessage message) {
        return handleInboundMessage(message);
    }

    public boolean testHandleOutgoingMessage(SOAPMessage message) {
        return handleOutboundMessage(message);
    }
	
}
