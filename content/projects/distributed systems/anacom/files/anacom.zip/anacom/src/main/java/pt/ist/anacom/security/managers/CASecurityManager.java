package pt.ist.anacom.security.managers;

import java.security.cert.CertificateExpiredException;
import java.security.cert.X509CRLEntry;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pt.ist.anacom.caserver.CertificateFactory;
import pt.ist.anacom.shared.exception.CAException;
import sun.security.x509.X500Name;
import sun.security.x509.X509CRLEntryImpl;
import sun.security.x509.X509CRLImpl;
import sun.security.x509.X509CertImpl;

/**
 * This security manager is detained by the Certification Authority.
 */
public class CASecurityManager extends AbstractSecurityManager {
	protected List<X509CRLEntry> _blacklist = new ArrayList<X509CRLEntry>();
    protected static CASecurityManager _instance = null;

    public static CASecurityManager getInstance() {
        if (_instance == null) {
            _instance = new CASecurityManager();
        }

        return _instance;
    }

    public static boolean isCreated() {
        return _instance != null;
    }
    
    /**
     * Initialize fields of the CA and creates a self signed certificate 
     * to allow all communication to be standard.
     */
	protected CASecurityManager() {
        super();
        setName("CA");
        _caPublicKey = getPublicKey();
		try {
			setCertificate(b64e.encode(CertificateFactory.createCertificate(getPublicKey(), getName(), getName(), getPrivateKey(), 0).getEncoded()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Creates a new black list with validity containing all
	 *  revoked certificates.
	 */
	public X509CRLImpl getBlackList() {
		Date lastDate = new Date();
		long validity = 720; // One Day
		lastDate.setTime(lastDate.getTime() + validity * 1000 /*1000L * 24L * 60L * 60L*/);

		X509CRLImpl crl;
		X509CRLEntry[] array = (X509CRLEntry[])_blacklist.toArray(new X509CRLEntry[_blacklist.size()]);

		try {
			crl = new X509CRLImpl(new X500Name("CA","Certification Authority","CA.anacom.pt","PT"), new Date(), lastDate,
					array);
			crl.sign(_ks, "SHA1withRSA" );
			return crl;
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return null;
	}
		
	/**
	 * Adds a new Certificate to the black list.
	 * @param cert Certificate to be added.
	 */
	public void addToBlackList(X509CertImpl cert) {
		_blacklist.add(new X509CRLEntryImpl(cert.getSerialNumber(),
				new Date()));
	}
	
	/**
	 * Eliminate all certificates from the black list.
	 */
    public void clearBlackList() {
        _blacklist.clear();
    }
    
    public String getCertificate() {
        try {
        	try { 
        		X509CertImpl cert = new X509CertImpl(b64d.decodeBuffer(_certificate));
        		cert.checkValidity();
            } catch (CertificateExpiredException e) {
    				setCertificate(b64e.encode(CertificateFactory.createCertificate(getPublicKey(), getName(), getName(), getPrivateKey(), 0).getEncoded()));
    		}
        } catch (Exception e) {
			throw new CAException(e.getMessage());
		}         
        return _certificate;
	}
}
