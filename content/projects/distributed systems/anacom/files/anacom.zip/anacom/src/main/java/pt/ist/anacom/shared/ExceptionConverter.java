package pt.ist.anacom.shared;

import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.BalanceChangeException;
import pt.ist.anacom.shared.exception.BusyStateException;
import pt.ist.anacom.shared.exception.CellPhoneAlreadyExistsException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.DestinationBusyException;
import pt.ist.anacom.shared.exception.DestinationOffException;
import pt.ist.anacom.shared.exception.DestinationSilenceException;
import pt.ist.anacom.shared.exception.HigherThanMaxBalanceException;
import pt.ist.anacom.shared.exception.IncomingCommunicationException;
import pt.ist.anacom.shared.exception.IncomingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.InvalidCellPhoneNumberException;
import pt.ist.anacom.shared.exception.InvalidCellPhonePrefixException;
import pt.ist.anacom.shared.exception.NegativeBalanceException;
import pt.ist.anacom.shared.exception.NotAStateException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;
import pt.ist.anacom.shared.exception.OutgoingCommunicationException;
import pt.ist.anacom.shared.exception.OutgoingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.SourceBusyException;
import pt.ist.anacom.shared.exception.SourceOffException;
import pt.ist.anacom.shared.exception.WrongTimestampException;
import pt.ist.anacom.shared.stubs.BalanceChangeException_Exception;
import pt.ist.anacom.shared.stubs.BusyStateException_Exception;
import pt.ist.anacom.shared.stubs.CellPhoneAlreadyExistsException_Exception;
import pt.ist.anacom.shared.stubs.CellPhoneNotExistsException_Exception;
import pt.ist.anacom.shared.stubs.HigherThanMaxBalanceException_Exception;
import pt.ist.anacom.shared.stubs.IncomingCommunicationNotSupportedException_Exception;
import pt.ist.anacom.shared.stubs.InvalidCellPhoneNumberException_Exception;
import pt.ist.anacom.shared.stubs.InvalidCellPhonePrefixException_Exception;
import pt.ist.anacom.shared.stubs.NegativeBalanceException_Exception;
import pt.ist.anacom.shared.stubs.NotAStateException_Exception;
import pt.ist.anacom.shared.stubs.OperatorNotExistsException_Exception;
import pt.ist.anacom.shared.stubs.OutgoingCommunicationNotSupportedException_Exception;
import pt.ist.anacom.shared.stubs.SourceBusyException_Exception;
import pt.ist.anacom.shared.stubs.SourceOffException_Exception;
import pt.ist.anacom.shared.stubs.DestinationOffException_Exception;
import pt.ist.anacom.shared.stubs.DestinationBusyException_Exception;
import pt.ist.anacom.shared.stubs.DestinationSilenceException_Exception;
import pt.ist.anacom.shared.stubs.WrongTimestampException_Exception;

/**
 * This class provides methods to convert from a local exception to a remote
 * exception or vice-versa.
 */
public class ExceptionConverter {
	/*
	 * ################################### # Local Exception -> WS Exception #
	 * ###################################
	 */
    protected static void convertToWebServiceException(pt.ist.anacom.shared.stubs.AnacomException wseinfo, AnacomException e) {
        wseinfo.setTimestamp(e.getTimestamp());
    }

	public static OperatorNotExistsException_Exception convertToWebServiceException(
			OperatorNotExistsException e) {
		pt.ist.anacom.shared.stubs.OperatorNotExistsException wse = new pt.ist.anacom.shared.stubs.OperatorNotExistsException();
		wse.setName(e.getName());
		wse.setPrefix(e.getPrefix());
        convertToWebServiceException(wse, e);
		return new OperatorNotExistsException_Exception(e.getMessage(), wse);
	}

	public static WrongTimestampException_Exception convertToWebServiceException(
			WrongTimestampException e) {
		pt.ist.anacom.shared.stubs.WrongTimestampException wse = new pt.ist.anacom.shared.stubs.WrongTimestampException();
		wse.setClientTimestamp(e.getClientTimestamp());
		wse.setTimestamp(e.getTimestamp());
        convertToWebServiceException(wse, e);
		return new WrongTimestampException_Exception(e.getMessage(), wse);
	}

	public static CellPhoneNotExistsException_Exception convertToWebServiceException(
			CellPhoneNotExistsException e) {
		pt.ist.anacom.shared.stubs.CellPhoneNotExistsException wse = new pt.ist.anacom.shared.stubs.CellPhoneNotExistsException();
		wse.setNumber(e.getNumber());
		wse.setOperatorName(e.getOperatorName());
        convertToWebServiceException(wse, e);
		return new CellPhoneNotExistsException_Exception(e.getMessage(), wse);
	}

	public static CellPhoneAlreadyExistsException_Exception convertToWebServiceException(
			CellPhoneAlreadyExistsException e) {
		pt.ist.anacom.shared.stubs.CellPhoneAlreadyExistsException wse = new pt.ist.anacom.shared.stubs.CellPhoneAlreadyExistsException();
		wse.setNumber(e.getNumber());
		wse.setOperatorName(e.getOperatorName());
        convertToWebServiceException(wse, e);
		return new CellPhoneAlreadyExistsException_Exception(e.getMessage(),
				wse);
	}

	public static InvalidCellPhoneNumberException_Exception convertToWebServiceException(
			InvalidCellPhoneNumberException e) {
		pt.ist.anacom.shared.stubs.InvalidCellPhoneNumberException wse = new pt.ist.anacom.shared.stubs.InvalidCellPhoneNumberException();
		wse.setNumber(e.getNumber());
		wse.setCauseMessage(e.getCauseMessage());
        convertToWebServiceException(wse, e);
		return new InvalidCellPhoneNumberException_Exception(e.getMessage(),
				wse);
	}

	public static InvalidCellPhonePrefixException_Exception convertToWebServiceException(
			InvalidCellPhonePrefixException e) {
		pt.ist.anacom.shared.stubs.InvalidCellPhonePrefixException wse = new pt.ist.anacom.shared.stubs.InvalidCellPhonePrefixException();
		wse.setPrefix(e.getPrefix());
		wse.setCauseMessage(e.getCauseMessage());
        convertToWebServiceException(wse, e);
		return new InvalidCellPhonePrefixException_Exception(e.getMessage(),
				wse);
	}

	public static HigherThanMaxBalanceException_Exception convertToWebServiceException(
			HigherThanMaxBalanceException e) {
		pt.ist.anacom.shared.stubs.HigherThanMaxBalanceException wse = new pt.ist.anacom.shared.stubs.HigherThanMaxBalanceException();
		wse.setBalance(e.getBalance());
		wse.setMaxBalance(e.getMaxBalance());
		wse.setPhoneNumber(e.getPhoneNumber());
        convertToWebServiceException(wse, e);
		return new HigherThanMaxBalanceException_Exception(e.getMessage(), wse);
	}

	public static NotAStateException_Exception convertToWebServiceException(
			NotAStateException e) {
		pt.ist.anacom.shared.stubs.NotAStateException wse = new pt.ist.anacom.shared.stubs.NotAStateException();
		wse.setPhoneNumber(e.getNumber());
		wse.setCauseMessage(e.getCauseMessage());
        convertToWebServiceException(wse, e);
		return new NotAStateException_Exception(e.getMessage(), wse);
	}

	public static BusyStateException_Exception convertToWebServiceException(
			BusyStateException e) {
		pt.ist.anacom.shared.stubs.BusyStateException wse = new pt.ist.anacom.shared.stubs.BusyStateException();
		wse.setPhoneNumber(e.getNumber());
        convertToWebServiceException(wse, e);
		return new BusyStateException_Exception(e.getMessage(), wse);
	}

	public static BalanceChangeException_Exception convertToWebServiceException(
			BalanceChangeException e) {
		pt.ist.anacom.shared.stubs.BalanceChangeException wse = new pt.ist.anacom.shared.stubs.BalanceChangeException();
		wse.setAmount(e.getAmount());
		wse.setCauseMessage(e.getCauseMessage());
        convertToWebServiceException(wse, e);
		return new BalanceChangeException_Exception(e.getMessage(), wse);
	}

    protected static <T extends pt.ist.anacom.shared.stubs.OutgoingCommunicationException> void convertToWebServiceException(T wseinfo, OutgoingCommunicationException e) {
        convertToWebServiceException((pt.ist.anacom.shared.stubs.AnacomException) wseinfo, e);
        wseinfo.setSourceNumber(e.getSourceNumber());
    }

    protected static <T extends pt.ist.anacom.shared.stubs.IncomingCommunicationException> void convertToWebServiceException(T wseinfo, IncomingCommunicationException e) {
        convertToWebServiceException((pt.ist.anacom.shared.stubs.AnacomException) wseinfo, e);
        wseinfo.setDestinationNumber(e.getDestinationNumber());
    }

	public static NegativeBalanceException_Exception convertToWebServiceException(
			NegativeBalanceException e) {
		pt.ist.anacom.shared.stubs.NegativeBalanceException wse = new pt.ist.anacom.shared.stubs.NegativeBalanceException();
		wse.setBalance(e.getBalance());
		wse.setSourceNumber(e.getSourceNumber());
        convertToWebServiceException(wse, e);
		return new NegativeBalanceException_Exception(e.getMessage(), wse);
	}

	public static OutgoingCommunicationNotSupportedException_Exception convertToWebServiceException(
			OutgoingCommunicationNotSupportedException e) {
		pt.ist.anacom.shared.stubs.OutgoingCommunicationNotSupportedException wse = new pt.ist.anacom.shared.stubs.OutgoingCommunicationNotSupportedException();
		wse.setCommType(e.getCommunicationType());
		wse.setPhoneType(e.getPhoneType());
		wse.setSourceNumber(e.getSourceNumber());
        convertToWebServiceException(wse, e);
		return new OutgoingCommunicationNotSupportedException_Exception(
				e.getMessage(), wse);
	}

	public static IncomingCommunicationNotSupportedException_Exception convertToWebServiceException(
			IncomingCommunicationNotSupportedException e) {
		pt.ist.anacom.shared.stubs.IncomingCommunicationNotSupportedException wse = new pt.ist.anacom.shared.stubs.IncomingCommunicationNotSupportedException();
		wse.setCommType(e.getCommunicationType());
		wse.setPhoneType(e.getPhoneType());
		wse.setDestinationNumber(e.getDestinationNumber());
        convertToWebServiceException(wse, e);
		return new IncomingCommunicationNotSupportedException_Exception(
				e.getMessage(), wse);
	}

	public static SourceOffException_Exception convertToWebServiceException(
			SourceOffException e) {
		pt.ist.anacom.shared.stubs.SourceOffException wse = new pt.ist.anacom.shared.stubs.SourceOffException();
		wse.setSourceNumber(e.getSourceNumber());
        convertToWebServiceException(wse, e);
		return new SourceOffException_Exception(e.getMessage(), wse);
	}

	public static SourceBusyException_Exception convertToWebServiceException(
			SourceBusyException e) {
		pt.ist.anacom.shared.stubs.SourceBusyException wse = new pt.ist.anacom.shared.stubs.SourceBusyException();
		wse.setSourceNumber(e.getSourceNumber());
        convertToWebServiceException(wse, e);
		return new SourceBusyException_Exception(e.getMessage(), wse);
	}

	
	public static DestinationOffException_Exception convertToWebServiceException(DestinationOffException e) {
		pt.ist.anacom.shared.stubs.DestinationOffException wse = new pt.ist.anacom.shared.stubs.DestinationOffException();
  		wse.setDestinationNumber(e.getDestinationNumber()); 
        convertToWebServiceException(wse, e);
  		return new DestinationOffException_Exception(e.getMessage(), wse); 
	}
	  
	public static DestinationBusyException_Exception convertToWebServiceException(DestinationBusyException e) {
		pt.ist.anacom.shared.stubs.DestinationBusyException wse = new pt.ist.anacom.shared.stubs.DestinationBusyException();
		wse.setDestinationNumber(e.getDestinationNumber()); 
        convertToWebServiceException(wse, e);
		return new DestinationBusyException_Exception(e.getMessage(), wse); 
	}
	  
	public static DestinationSilenceException_Exception convertToWebServiceException(DestinationSilenceException e) {
		pt.ist.anacom.shared.stubs.DestinationSilenceException wse = new pt.ist.anacom.shared.stubs.DestinationSilenceException();
		wse.setDestinationNumber(e.getDestinationNumber()); 
        convertToWebServiceException(wse, e);
		return new DestinationSilenceException_Exception(e.getMessage(), wse); 
	}
	
	/*
	 * ################################### # WS Exception -> Local Exception #
	 * ###################################
	 */
	protected static void convertFromWebServiceException(AnacomException e, pt.ist.anacom.shared.stubs.AnacomException wseinfo) {
        e.setTimestamp(wseinfo.getTimestamp());
    }
    
	public static OperatorNotExistsException convertFromWebServiceException(
			OperatorNotExistsException_Exception wse) {
		pt.ist.anacom.shared.stubs.OperatorNotExistsException info = wse
				.getFaultInfo();

        OperatorNotExistsException e;

		if (!info.getPrefix().equals("")) {
			e = new OperatorNotExistsException(info.getName(), info.getPrefix());
		} else {
			e = new OperatorNotExistsException(info.getName());
		}

        convertFromWebServiceException(e, info);
        return e;
	}

	public static WrongTimestampException convertFromWebServiceException(
			WrongTimestampException_Exception wse) {
		pt.ist.anacom.shared.stubs.WrongTimestampException info = wse
				.getFaultInfo();
		WrongTimestampException e = new WrongTimestampException(info.getClientTimestamp(), info.getServerTimestamp());
        convertFromWebServiceException(e, info);
        return e;
	}

	public static CellPhoneNotExistsException convertFromWebServiceException(
			CellPhoneNotExistsException_Exception wse) {
		pt.ist.anacom.shared.stubs.CellPhoneNotExistsException info = wse
				.getFaultInfo();
		CellPhoneNotExistsException e = new CellPhoneNotExistsException(info.getNumber());
        convertFromWebServiceException(e, info);
        return e;
	}

	public static CellPhoneAlreadyExistsException convertFromWebServiceException(
			CellPhoneAlreadyExistsException_Exception wse) {
		pt.ist.anacom.shared.stubs.CellPhoneAlreadyExistsException info = wse
				.getFaultInfo();
		CellPhoneAlreadyExistsException e = new CellPhoneAlreadyExistsException(info.getNumber(), info.getOperatorName());
        convertFromWebServiceException(e, info);
        return e;
	}

	public static InvalidCellPhoneNumberException convertFromWebServiceException(
			InvalidCellPhoneNumberException_Exception wse) {
		pt.ist.anacom.shared.stubs.InvalidCellPhoneNumberException info = wse
				.getFaultInfo();
		InvalidCellPhoneNumberException e = new InvalidCellPhoneNumberException(info.getNumber(),
				info.getCauseMessage());
        convertFromWebServiceException(e, info);
        return e;
	}

	public static InvalidCellPhonePrefixException convertFromWebServiceException(
			InvalidCellPhonePrefixException_Exception wse) {
		pt.ist.anacom.shared.stubs.InvalidCellPhonePrefixException info = wse
				.getFaultInfo();
		InvalidCellPhonePrefixException e = new InvalidCellPhonePrefixException(info.getPrefix(),
				info.getCauseMessage());
        convertFromWebServiceException(e, info);
        return e;
	}

	public static HigherThanMaxBalanceException convertFromWebServiceException(
			HigherThanMaxBalanceException_Exception wse) {
		pt.ist.anacom.shared.stubs.HigherThanMaxBalanceException info = wse
				.getFaultInfo();
		HigherThanMaxBalanceException e = new HigherThanMaxBalanceException(info.getPhoneNumber(),
				info.getBalance(), info.getMaxBalance());
        convertFromWebServiceException(e, info);
        return e;
	}

	public static BalanceChangeException convertFromWebServiceException(
			BalanceChangeException_Exception wse) {
		pt.ist.anacom.shared.stubs.BalanceChangeException info = wse
				.getFaultInfo();
		BalanceChangeException e = new BalanceChangeException(info.getAmount(),
				info.getCauseMessage());
        convertFromWebServiceException(e, info);
        return e;
	}

	public static NotAStateException convertFromWebServiceException(
			NotAStateException_Exception wse) {
		pt.ist.anacom.shared.stubs.NotAStateException info = wse.getFaultInfo();
		NotAStateException e = new NotAStateException(info.getPhoneNumber(),
				info.getCauseMessage());
        convertFromWebServiceException(e, info);
        return e;
	}

	public static BusyStateException convertFromWebServiceException(
			BusyStateException_Exception wse) {
		pt.ist.anacom.shared.stubs.BusyStateException info = wse.getFaultInfo();
		BusyStateException e = new BusyStateException(info.getPhoneNumber());
        convertFromWebServiceException(e, info);
        return e;
	}

	protected static void convertFromWebServiceException(OutgoingCommunicationException e, pt.ist.anacom.shared.stubs.OutgoingCommunicationException wseinfo) {
        convertFromWebServiceException((AnacomException) e, wseinfo);
        e.setSourceNumber(wseinfo.getSourceNumber());
    }

	public static NegativeBalanceException convertFromWebServiceException(
			NegativeBalanceException_Exception wse) {
		pt.ist.anacom.shared.stubs.NegativeBalanceException info = wse
				.getFaultInfo();
        NegativeBalanceException e = new NegativeBalanceException(info.getSourceNumber(), info.getBalance());
        convertFromWebServiceException((OutgoingCommunicationException) e, info);
		return e;
	}

	public static OutgoingCommunicationNotSupportedException convertFromWebServiceException(
			OutgoingCommunicationNotSupportedException_Exception wse) {
		pt.ist.anacom.shared.stubs.OutgoingCommunicationNotSupportedException info = wse
				.getFaultInfo();
		OutgoingCommunicationNotSupportedException e = new OutgoingCommunicationNotSupportedException(
				info.getSourceNumber(), info.getPhoneType(), info.getCommType());
        convertFromWebServiceException((OutgoingCommunicationException) e, info);
		return e;
	}

	protected static void convertFromWebServiceException(IncomingCommunicationException e, pt.ist.anacom.shared.stubs.IncomingCommunicationException wseinfo) {
        convertFromWebServiceException((AnacomException) e, wseinfo);
        e.setDestinationNumber(wseinfo.getDestinationNumber());
    }

	public static IncomingCommunicationNotSupportedException convertFromWebServiceException(
			IncomingCommunicationNotSupportedException_Exception wse) {
		pt.ist.anacom.shared.stubs.IncomingCommunicationNotSupportedException info = wse
				.getFaultInfo();
		IncomingCommunicationNotSupportedException e = new IncomingCommunicationNotSupportedException(
				info.getDestinationNumber(), info.getPhoneType(),
				info.getCommType());
        convertFromWebServiceException((IncomingCommunicationException) e, info);
		return e;
	}

	public static SourceOffException convertFromWebServiceException(
			SourceOffException_Exception wse) {
		pt.ist.anacom.shared.stubs.SourceOffException info = wse.getFaultInfo();
		SourceOffException e = new SourceOffException(info.getSourceNumber());
        convertFromWebServiceException((OutgoingCommunicationException) e, info);
		return e;
	}

	public static SourceBusyException convertFromWebServiceException(
			SourceBusyException_Exception wse) {
		pt.ist.anacom.shared.stubs.SourceBusyException info = wse.getFaultInfo();
		SourceBusyException e = new SourceBusyException(info.getSourceNumber());
        convertFromWebServiceException((OutgoingCommunicationException) e, info);
		return e;
	}

	
	public static DestinationOffException convertFromWebServiceException(DestinationOffException_Exception wse) {
		pt.ist.anacom.shared.stubs.DestinationOffException info = wse.getFaultInfo();
		DestinationOffException e = new DestinationOffException(info.getDestinationNumber()); 
        convertFromWebServiceException((IncomingCommunicationException) e, info);
		return e;
	}
  
	public static DestinationBusyException convertFromWebServiceException(DestinationBusyException_Exception wse) {
		pt.ist.anacom.shared.stubs.DestinationBusyException info = wse.getFaultInfo(); 
		DestinationBusyException e = new DestinationBusyException(info.getDestinationNumber()); 
        convertFromWebServiceException((IncomingCommunicationException) e, info);
		return e;
	}
  
	public static DestinationSilenceException convertFromWebServiceException(DestinationSilenceException_Exception wse) {
		pt.ist.anacom.shared.stubs.DestinationSilenceException info = wse.getFaultInfo(); 
		DestinationSilenceException e = new DestinationSilenceException(info.getDestinationNumber()); 
        convertFromWebServiceException((IncomingCommunicationException) e, info);
		return e;
	}
}
