package pt.ist.anacom.sdtest;

import static pt.ist.anacom.sdtest.mockactions.SleepAndReturn.sleepAndReturn;
import static pt.ist.anacom.sdtest.mockactions.SleepAndThrow.sleepAndThrow;

import org.jmock.Expectations;
import org.jmock.Mockery;

import pt.ist.anacom.replication.RemoteReplicatedServer;
import pt.ist.anacom.sdtest.stubs.PresentationReplicationManagerTester;
import pt.ist.anacom.service.bridge.RemoteOperator;
import pt.ist.anacom.shared.dto.AnacomDto;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;

public class PresentationReplicationTest extends ReplicationTestCase {
    Mockery context = new Mockery();

    private final String OPERATOR_NAME = "Vodafone";
    private final String CELL_NUMBER = "912495153";
    private final String CELL_NUMBER_BIZANTINE = "912495154";
    private final int QUORUM_SIZE = 4;

	public PresentationReplicationTest() {
	}

	@Override
	public void setUp() {
		super.setUp();
	}
	
	// Tests a case with no faults and the replicas return dtos
	// with the correct timestamp.
	// The presentation server know the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testNoReplicaFaultsReturnDtosKnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final BalanceDto returnDto = new BalanceDto(CELL_NUMBER, 100);
        returnDto.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
        }});

        // Act
        BalanceDto result = server.getCellPhoneBalance(cellPhoneDto);
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, returnDto);
	}

	// Tests a case with no faults and the replicas return exceptions
	// with the correct timestamp.
	// The presentation server know the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testNoReplicaFaultsThrowExceptionsKnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final CellPhoneNotExistsException resultException = new CellPhoneNotExistsException(CELL_NUMBER);
        resultException.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
        }});

        // Act
        try {
            server.getCellPhoneBalance(cellPhoneDto);
            fail("Execution should have thrown CellPhoneNotExistsException");
        } catch (CellPhoneNotExistsException e) {
            // All is well
        } catch (Exception e) {
            fail("Execution should have thrown CellPhoneNotExistsException");
        }
        
        // Assert
        context.assertIsSatisfied();
	}

	// Tests a case where one replica fails silently and all the other respond
	// with dtos with the correct timestamp.
	// The presentation server know the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testOneReplicaSilentFaultReturnDtosKnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final BalanceDto returnDto = new BalanceDto(CELL_NUMBER, 100);
        returnDto.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(50, null));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
        }});

        // Act
        BalanceDto result = server.getCellPhoneBalance(cellPhoneDto);
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, returnDto);
	}
	
	// Tests a case where one replica fails silently and all the other respond
	// with dtos with the correct timestamp.
	// The difference to the previous test is that this one tests the silent failure
	// of a different replica.
	// The presentation server know the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testOneReplicaSilentFaultReturnDifferentPositionDtosKnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final BalanceDto returnDto = new BalanceDto(CELL_NUMBER, 100);
        returnDto.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(50, null));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
        }});

        // Act
        BalanceDto result = server.getCellPhoneBalance(cellPhoneDto);
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, returnDto);
	}

	// Tests a case where one replica fails silently and all the other respond
	// with exceptions with the correct timestamp.
	// The presentation server know the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testOneReplicaSilentFaultThrowExceptionsKnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final CellPhoneNotExistsException resultException = new CellPhoneNotExistsException(CELL_NUMBER);
        resultException.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(50, null));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(sleepAndThrow(2, resultException));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(sleepAndThrow(2, resultException));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(sleepAndThrow(2, resultException));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(sleepAndThrow(2, resultException));
        }});

        // Act
        try {
            server.getCellPhoneBalance(cellPhoneDto);
            fail("Execution should have thrown CellPhoneNotExistsException");
        } catch (CellPhoneNotExistsException e) {
            // All is well
        } catch (Exception e) {
            fail("Execution should have thrown CellPhoneNotExistsException");
        }
        
        // Assert
        context.assertIsSatisfied();
	}
	
	// Tests a case where one replica fails silently and all the other respond
	// with exceptions with the correct timestamp.
	// The difference to the previous test is that this one tests the silent failure
	// of a different replica.
	// The presentation server know the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testOneReplicaSilentFaultDifferentPositionThrowExceptionsKnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final CellPhoneNotExistsException resultException = new CellPhoneNotExistsException(CELL_NUMBER);
        resultException.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(sleepAndThrow(2, resultException));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(50, null));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(sleepAndThrow(2, resultException));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(sleepAndThrow(2, resultException));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(sleepAndThrow(2, resultException));
        }});

        // Act
        try {
            server.getCellPhoneBalance(cellPhoneDto);
            fail("Execution should have thrown CellPhoneNotExistsException");
        } catch (CellPhoneNotExistsException e) {
            // All is well
        } catch (Exception e) {
            fail("Execution should have thrown CellPhoneNotExistsException");
        }
        
        // Assert
        context.assertIsSatisfied();
	}
	
	// Tests the invocation of two services, where no replica fails.
	// The presentation server doesn't know the timestamp so it
	// has to ask it to the replicas first.
	public void testTwoInvocationsNoFaultsUnknownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);

        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final AnacomDto timestampDto = new AnacomDto();
        timestampDto.setTimestamp(1);
        final ChangeCellPhoneBalanceDto changeBalanceDto = new ChangeCellPhoneBalanceDto(CELL_NUMBER, 200);
        final AnacomDto firstReturnDto = new AnacomDto();
        firstReturnDto.setTimestamp(2);
        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        final BalanceDto secondReturnDto = new BalanceDto(CELL_NUMBER, 100);
        secondReturnDto.setTimestamp(3);
        BalanceDto result = null;

        context.checking(new Expectations() {{
            oneOf (op1).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op2).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op3).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op4).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op5).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            atMost(1).of (op1).increaseCellPhoneBalance(changeBalanceDto); will(returnValue(firstReturnDto));
            atMost(1).of (op2).increaseCellPhoneBalance(changeBalanceDto); will(returnValue(firstReturnDto));
            atMost(1).of (op3).increaseCellPhoneBalance(changeBalanceDto); will(returnValue(firstReturnDto));
            atMost(1).of (op4).increaseCellPhoneBalance(changeBalanceDto); will(returnValue(firstReturnDto));
            atMost(1).of (op5).increaseCellPhoneBalance(changeBalanceDto); will(returnValue(firstReturnDto));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDto));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDto));
        }});

        // Act
        try {
            server.increaseCellPhoneBalance(changeBalanceDto);
            result = server.getCellPhoneBalance(cellPhoneDto);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception");
        }
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, secondReturnDto);
	}

	// Tests the invocation of two services, where one replica fails silently.
	// The presentation server doesn't know the timestamp so it
	// has to ask it to the replicas first.
	public void testTwoInvocationsOneFaultUnknownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);

        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final AnacomDto timestampDto = new AnacomDto();
        timestampDto.setTimestamp(1);
        final ChangeCellPhoneBalanceDto changeBalanceDto = new ChangeCellPhoneBalanceDto(CELL_NUMBER, 200);
        final AnacomDto firstReturnDto = new AnacomDto();
        firstReturnDto.setTimestamp(2);
        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        final BalanceDto secondReturnDto = new BalanceDto(CELL_NUMBER, 100);
        secondReturnDto.setTimestamp(3);
        BalanceDto result = null;

        context.checking(new Expectations() {{
            oneOf (op1).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op2).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op3).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op4).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op5).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            atMost(1).of (op1).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(50, null));
            atMost(1).of (op2).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(2, firstReturnDto));
            atMost(1).of (op3).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(2, firstReturnDto));
            atMost(1).of (op4).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(2, firstReturnDto));
            atMost(1).of (op5).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(2, firstReturnDto));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(50, null));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, secondReturnDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, secondReturnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, secondReturnDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, secondReturnDto));
        }});

        // Act
        try {
            server.increaseCellPhoneBalance(changeBalanceDto);
            result = server.getCellPhoneBalance(cellPhoneDto);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception");
        }
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, secondReturnDto);
	}

	// Tests the invocation of two services, where there is a delay in
	// one message.
	// The increase balance service call in operator 1 will arrive later
	// than the call to the get balance service. Because of that, operator 1
	// will return the previous balance. The quorum system wont accept that
	// answer.
	// The presentation server doesn't know the timestamp so it
	// has to ask it to the replicas first.
	public void testTwoInvocationsWriteDelayUnknownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);

        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final AnacomDto timestampDto = new AnacomDto();
        timestampDto.setTimestamp(1);
        final ChangeCellPhoneBalanceDto changeBalanceDto = new ChangeCellPhoneBalanceDto(CELL_NUMBER, 200);
        final AnacomDto firstReturnDto = new AnacomDto();
        firstReturnDto.setTimestamp(2);
        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        final BalanceDto secondReturnDto = new BalanceDto(CELL_NUMBER, 300);
        secondReturnDto.setTimestamp(3);
        final BalanceDto secondReturnDtoDelayed = new BalanceDto(CELL_NUMBER, 100);
        secondReturnDtoDelayed.setTimestamp(2);
        BalanceDto result = null;

        context.checking(new Expectations() {{
            oneOf (op1).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op2).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op3).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op4).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            oneOf (op5).getTimestamp(with(any(AnacomDto.class))); will(returnValue(timestampDto));
            atMost(1).of (op1).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(50, null));
            atMost(1).of (op2).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(2, firstReturnDto));
            atMost(1).of (op3).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(2, firstReturnDto));
            atMost(1).of (op4).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(2, firstReturnDto));
            atMost(1).of (op5).increaseCellPhoneBalance(changeBalanceDto); will(sleepAndReturn(2, firstReturnDto));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDtoDelayed));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(returnValue(secondReturnDto));
        }});

        // Act
        try {
            server.increaseCellPhoneBalance(changeBalanceDto);
            result = server.getCellPhoneBalance(cellPhoneDto);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception");
        }
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, secondReturnDto);
	}
	
	// ******************* BIZANTINE FAIL TESTS *******************************
	
	
	// Tests a case where one replica goes bizantine sending a dto with a
	// wrong timestamp.
	// The presentation server knows the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testOneReplicaBizantineFaultReturnDtosWrongTimestampKnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final BalanceDto returnDto = new BalanceDto(CELL_NUMBER, 100);
        returnDto.setTimestamp(1);
        final BalanceDto bizantineDto = new BalanceDto(CELL_NUMBER, 100);
        bizantineDto.setTimestamp(2);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(returnValue(bizantineDto));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
        }});

        // Act
        BalanceDto result = server.getCellPhoneBalance(cellPhoneDto);
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, returnDto);
	}
	
	// Tests a case where one replica goes bizantine sending a dto with the
	// correct timestamp but incorrect content.
	// The presentation server knows the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testOneReplicaBizantineFaultReturnDtosWrongContent1KnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final BalanceDto returnDto = new BalanceDto(CELL_NUMBER, 100);
        returnDto.setTimestamp(1);
        final BalanceDto bizantineDto = new BalanceDto(CELL_NUMBER_BIZANTINE, 100);
        bizantineDto.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(returnValue(bizantineDto));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
        }});

        // Act
        BalanceDto result = server.getCellPhoneBalance(cellPhoneDto);
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, returnDto);
	}
	
	// Tests a case where one replica goes bizantine sending a dto with the
	// correct timestamp but incorrect content.
	// The presentation server knows the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testOneReplicaBizantineFaultReturnDtosWrongContent2KnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final BalanceDto returnDto = new BalanceDto(CELL_NUMBER, 100);
        returnDto.setTimestamp(1);
        final BalanceDto bizantineDto = new BalanceDto(CELL_NUMBER, 200);
        bizantineDto.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(returnValue(bizantineDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
        }});

        // Act
        BalanceDto result = server.getCellPhoneBalance(cellPhoneDto);
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, returnDto);
	}
	
	// Tests a case where one replica goes bizantine sending a dto when it
	// should send an exception.
	// The presentation server knows the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testOneReplicaBizantineFaultReturnExceptionKnownTimestamp() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final CellPhoneNotExistsException resultException = new CellPhoneNotExistsException(CELL_NUMBER);
        resultException.setTimestamp(1);
        final BalanceDto returnDto = new BalanceDto(CELL_NUMBER, 100);
        returnDto.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
        }});
        
        // Act
        try {
        	BalanceDto dto = server.getCellPhoneBalance(cellPhoneDto);
        	if (dto != null) {
        		System.out.println("DTO!!");
        	}
            fail("Execution should have thrown CellPhoneNotExistsException");
        } catch (CellPhoneNotExistsException e) {
            // All is well
        } catch (Exception e) {
        	e.printStackTrace();
            fail("Execution should have thrown CellPhoneNotExistsException");
        }
        
        // Assert
        context.assertIsSatisfied();
	}
	
	// Tests a case where one replica goes bizantine sending a dto when it
	// should send an exception.
	// The difference between this test and the previous is the position
	// of the replica that is bizantine.
	// The presentation server knows the timestamp as well, so
	// there is no need for it to ask the replicas for it.
	public void testOneReplicaBizantineFaultReturnExceptionKnownTimestamp2() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        replicationManager.setTimestamp(OPERATOR_NAME, 0);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        cellPhoneDto.setTimestamp(0);
        final CellPhoneNotExistsException resultException = new CellPhoneNotExistsException(CELL_NUMBER);
        resultException.setTimestamp(1);
        final BalanceDto returnDto = new BalanceDto(CELL_NUMBER, 100);
        returnDto.setTimestamp(1);

        context.checking(new Expectations() {{
            never (op1).getTimestamp(with(any(AnacomDto.class)));
            never (op2).getTimestamp(with(any(AnacomDto.class)));
            never (op3).getTimestamp(with(any(AnacomDto.class)));
            never (op4).getTimestamp(with(any(AnacomDto.class)));
            never (op5).getTimestamp(with(any(AnacomDto.class)));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(returnValue(returnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(throwException(resultException));
        }});
        
        // Act
        try {
        	BalanceDto dto = server.getCellPhoneBalance(cellPhoneDto);
        	if (dto != null) {
        		System.out.println("DTO!!");
        	}
            fail("Execution should have thrown CellPhoneNotExistsException");
        } catch (CellPhoneNotExistsException e) {
            // All is well
        } catch (Exception e) {
        	e.printStackTrace();
            fail("Execution should have thrown CellPhoneNotExistsException");
        }
        
        // Assert
        context.assertIsSatisfied();
	}
	
	// In this test, the presentation server doesn't know the timestamp.
	// Because of that it will ask the replicas for it.
	// The situation that happens is:
	//  - One bizantine replica sends a wrong timestamp
	//  - Because of delays in the network, one replica sends a wrong timestamp
	//  - Two replicas send the correct timestamp.
	//  - One replica doesn't respond.
	// The presentation server should choose the timestamp according to the
	// distribution algorithm:
	//  - find the answers which were more received
	//  - inside those answers, chose the one with the biggest timestamp.
	public void testPresentationServerFailure() {
        // Arrange
        final RemoteOperator op1 = context.mock(RemoteOperator.class, "op1");
        final RemoteOperator op2 = context.mock(RemoteOperator.class, "op2");
        final RemoteOperator op3 = context.mock(RemoteOperator.class, "op3");
        final RemoteOperator op4 = context.mock(RemoteOperator.class, "op4");
        final RemoteOperator op5 = context.mock(RemoteOperator.class, "op5");

        RemoteOperator[] replicas = new RemoteOperator[5];

        replicas[0] = op1;
        replicas[1] = op2;
        replicas[2] = op3;
        replicas[3] = op4;
        replicas[4] = op5;

        final PresentationReplicationManagerTester replicationManager = new PresentationReplicationManagerTester(replicas, QUORUM_SIZE);
        RemoteReplicatedServer server = getRemoteReplicatedServer(replicationManager, OPERATOR_NAME);

        final CellPhoneSimpleDto cellPhoneDto = new CellPhoneSimpleDto(CELL_NUMBER);
        
        final AnacomDto timestampDto = new AnacomDto();
        timestampDto.setTimestamp(2);
        final AnacomDto bizantineTimestampDto = new AnacomDto();
        bizantineTimestampDto.setTimestamp(1);
        final AnacomDto networkDelayedTimestampDto = new AnacomDto();
        networkDelayedTimestampDto.setTimestamp(1);
        
        final BalanceDto returnDto = new BalanceDto(CELL_NUMBER, 100);
        returnDto.setTimestamp(3);
        final BalanceDto bizantineDto = new BalanceDto(CELL_NUMBER, 100);
        bizantineDto.setTimestamp(2);
        final BalanceDto delayedDto = new BalanceDto(CELL_NUMBER, 100);
        delayedDto.setTimestamp(2);
        

        context.checking(new Expectations() {{
            oneOf (op1).getTimestamp(with(any(AnacomDto.class))); will(sleepAndReturn(2, bizantineTimestampDto));
            oneOf (op2).getTimestamp(with(any(AnacomDto.class))); will(sleepAndReturn(2, networkDelayedTimestampDto));
            oneOf (op3).getTimestamp(with(any(AnacomDto.class))); will(sleepAndReturn(2, timestampDto));
            oneOf (op4).getTimestamp(with(any(AnacomDto.class))); will(sleepAndReturn(2, timestampDto));
            oneOf (op5).getTimestamp(with(any(AnacomDto.class))); will(sleepAndReturn(50, null));
            atMost(1).of (op1).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, bizantineDto));
            atMost(1).of (op2).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, delayedDto));
            atMost(1).of (op3).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
            atMost(1).of (op4).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(2, returnDto));
            atMost(1).of (op5).getCellPhoneBalance(cellPhoneDto); will(sleepAndReturn(50, null));
        }});

        // Act
        BalanceDto result = server.getCellPhoneBalance(cellPhoneDto);
        
        // Assert
        context.assertIsSatisfied();
        assertEquals(result, returnDto);
	}
}
