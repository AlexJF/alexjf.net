package pt.ist.anacom.domain;

/**
 * This class represents a 3G CellPhone. 
 * A 3G CellPhone can establish any type
 * of communication.
 */
public class CellPhone3G extends CellPhone3G_Base {

	public CellPhone3G(String number, int balance) {
		super();
		init(number, balance);
	}
}
