package pt.ist.anacom.security.exception;

/**
 * This class implements a base exception for all security issues.
 */

public abstract class AnacomSecurityException extends SecurityException {
	private static final long serialVersionUID = 1L;
	
	public AnacomSecurityException() {
		super();
	}
	
	AnacomSecurityException(String reason) {
		super(reason);
	}
	
}
