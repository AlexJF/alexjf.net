package pt.ist.anacom.security.handlers.ca;

import java.security.cert.X509CRL;

import java.util.LinkedList;
import java.util.List;

import javax.xml.soap.SOAPMessage;

import pt.ist.anacom.security.handlers.AbstractCertificateHandler;

import pt.ist.anacom.security.managers.CASecurityManager;

/**
 * This handler is used by Certification Authority
 */
public class CACertificateHandler extends AbstractCertificateHandler {
	@Override
	protected boolean handleInboundMessage(SOAPMessage message) {
        try {
            String operationName = getOperationName(getSoapEnvelope(message));
            System.out.println("Operation Name: " + operationName);
            List<String> unsecureOperations = new LinkedList<String>();
            unsecureOperations.add("createCertificate");
            unsecureOperations.add("getBlackList");
            unsecureOperations.add("testCommand");
            if (operationName != null && unsecureOperations.contains(operationName)) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

		return super.handleInboundMessage(message);
	}
	
	@Override
	protected X509CRL getBlackList() {
		return CASecurityManager.getInstance().getBlackList();
	}
	
    protected pt.ist.anacom.security.managers.AbstractSecurityManager getSecurityManager() {
        return CASecurityManager.getInstance();
    };
}
