package pt.ist.anacom.replication;

import pt.ist.anacom.service.bridge.RemoteOperator;

/**
 * This interface represents a presentation service function
 * which allows us to encapsulate an operation that should be
 * executed in a remote operator.
 *
 * @param <I> The type of Dto the service receives.
 * @param <O> The return type of Dto that the service returns.
 */
public interface PresentationServiceFunction<I, O> {
    public O execute(RemoteOperator operator, I dto);
}
