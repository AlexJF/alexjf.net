package pt.ist.anacom;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.Key;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;

import pt.ist.anacom.caserver.CAServer;
import pt.ist.anacom.security.managers.AnacomSecurityManager;
import pt.ist.anacom.service.bridge.RemoteOperator;
import pt.ist.anacom.shared.UDDIHelper;

public class AdministrationConsole {

	private static int CAOPT = 600;

	private static ArrayList<String> replicaCommand = new ArrayList<String>();
	private static ArrayList<String> caCommand = new ArrayList<String>();

	public static void main(String[] args) {

		replicaCommand.add("create");
		replicaCommand.add("revoke");
		replicaCommand.add("updateBL");
		replicaCommand.add("clear");

		caCommand.add("clear");
		caCommand.add("clearPS");
		caCommand.add("printBL");
		caCommand.add("printCL");
		
		System.out.println("*#*#*# Anacom Admin Console Application #*#*#*");
		UDDIHelper.getSingleton().startCacheManagement();
		UDDIHelper.getSingleton().printCacheInfo();

		int opChoice = 0;
		while (true) {
			ArrayList<String> operators = new ArrayList<String>(UDDIHelper
					.getSingleton().getAllOperators());
			opChoice = getOperatorFromUser(operators);
			if (opChoice == -1) {
				return;
			}
			if (opChoice == CAOPT) {
				useCA();
			} else {
				System.out.print('\f');
				useReplicas(operators.get(opChoice - 1));
			}
		}
	}

	private static void useCA() {
		while (true) {
			printCAMenu();
			int choice = getMenuOption();

			if (choice == 5) {
				return;
			}
			CAServer ca = UDDIHelper.getSingleton().getCA();
			AnacomSecurityManager.getInstance().setCA(ca);
			ca.testCommand(caCommand.get(choice - 1));

		}
	}

	private static void printCAMenu() {
		System.out.println("CA MENU\nChoose an option");
		System.out.println("1 - Clear");
		System.out.println("2 - Clear-PS");
		System.out.println("3 - Print current black list");
		System.out.println("4 - Print current certificate list");
		System.out.println("5 - Return");

	}

	private static void useReplicas(String operator) {
		List<RemoteOperator> remOpList = UDDIHelper.getSingleton()
				.getRemoteOperatorsFromOperatorName(operator);
		while (true) {
			int replicaChoice = chooseReplica(remOpList);
			if (replicaChoice == -1) {
				return;
			}
			RemoteOperator remOp = remOpList.get(replicaChoice - 1);
			specificReplica(remOp);
		}

	}

	private static void specificReplica(RemoteOperator remOp) {
		while (true) {
			printReplicaMenu();
			int choice = getMenuOption();
			if (choice == 5) {
				return;
			}
			try {

				remOp.testCommand(replicaCommand.get(choice - 1));
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}

	private static int getMenuOption() {
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		try {
			String s;
			s = br.readLine();
			return Integer.parseInt(s);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;
	}

	private static void printReplicaMenu() {
		System.out
				.println("On Replica Menu\nSelect the operation you want to preform");
		System.out.println("1 - Create Certificate");
		System.out.println("2 - Revoke current certificate");
		System.out.println("3 - Update blacklist");
		System.out.println("4 - Reset operator");
		System.out.println("5 - Return");
	}

	private static int chooseReplica(List<RemoteOperator> remOp) {
		System.out.println("Select the replica you want to use:");
		int i = 1;
		for (RemoteOperator remoteOperator : remOp) {
			System.out.println(i++ + "- " + remoteOperator.getName() + " - "
					+ remoteOperator.getReplicaNumber());
		}
		System.out.println(i + "- Return");
		int choice = getMenuOption();
		if (choice == i) {
			choice = -1;
		}
		return choice;
	}

	private static int getOperatorFromUser(ArrayList<String> operators) {
		System.out.println("Select the Operator you want to use:");
		int i = 1;
		for (String string : operators) {
			System.out.println(i++ + "- " + string);
		}
		System.out.println(i++ + "- CA");
		System.out.println(i + "- Exit");
		int choice = getMenuOption();
		if (choice == i) {
			choice = -1;
		} else if (choice == (i - 1)) {
			choice = CAOPT;
		}
		return choice;
	}

}
