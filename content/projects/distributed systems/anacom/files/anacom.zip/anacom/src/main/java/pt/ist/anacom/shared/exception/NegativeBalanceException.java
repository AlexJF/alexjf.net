package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to a cellphone with negative
 * balance attempting to make a communication.
 */
public class NegativeBalanceException extends OutgoingCommunicationException {
	private static final long serialVersionUID = 1L;

	private int _balance;

	public NegativeBalanceException() {
	}

	public NegativeBalanceException(String sourceNumber, int balance) {
		super(sourceNumber, "Source cellphone has negative balance: " + balance
				+ " cents.");
		_balance = balance;
	}

	public int getBalance() {
		return _balance;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of NegativeBalanceException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof NegativeBalanceException))
			return false;

		NegativeBalanceException exception = (NegativeBalanceException) obj;

		return getBalance() == exception.getBalance();
	}
}
