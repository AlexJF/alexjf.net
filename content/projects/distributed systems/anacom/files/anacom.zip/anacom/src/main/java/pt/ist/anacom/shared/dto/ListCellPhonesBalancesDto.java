package pt.ist.anacom.shared.dto;

import java.util.LinkedList;
import java.util.List;

/**
 * This Dto allows to transport a list of cell phones and
 * its balances.
*/
public class ListCellPhonesBalancesDto extends AnacomDto {
	
	static final long serialVersionUID = 1L;

	/** List of BalanceDto */
	private List<BalanceDto> _cellPhonesBalances;

	/**
	 * Creates a new instance of a ListCellPhonesBalancesDto.
	 */
	public ListCellPhonesBalancesDto() {
		_cellPhonesBalances = new LinkedList<BalanceDto>();
	}

	/**
	 * Adds a new phone balance to the list.
	 * 
	 * @param number
	 *            The number of the cellphone whose balance we are saving in the
	 *            list.
	 * @param balance
	 *            The balance of the aforementioned cellphone.
	 */
	public void addCellPhoneBalance(String number, int balance) {
		_cellPhonesBalances.add(new BalanceDto(number, balance));
	}

	/**
	 * Adds a new phone balance to the list.
	 * 
	 * @param balanceDto
	 *            A dto representing a cellphone balance.
	 */
	public void addCellPhoneBalance(BalanceDto balanceDto) {
		_cellPhonesBalances.add(balanceDto);
	}

	/**
	 * Retrieve balance information from the DTO.
	 * 
	 * @return List of BalanceDtos containing the stored balances.
	 */
	public List<BalanceDto> getCellPhonesBalances() {
		return _cellPhonesBalances;
	}
	
	/**
	 * Compares two instances of ListCellPhonesBalancesDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof ListCellPhonesBalancesDto))
			return false;

		ListCellPhonesBalancesDto dto = (ListCellPhonesBalancesDto) obj;

		return getCellPhonesBalances().equals(dto.getCellPhonesBalances());
	}
}
