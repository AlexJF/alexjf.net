package pt.ist.anacom.shared.exception;

public class CAException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public CAException() {
		super();
	}
	
	public CAException(String e) {
		super(e);
	}
}
