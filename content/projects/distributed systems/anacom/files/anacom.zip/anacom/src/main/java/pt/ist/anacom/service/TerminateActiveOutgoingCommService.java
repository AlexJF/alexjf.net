package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.fenixframework.FenixFramework;

public class TerminateActiveOutgoingCommService extends AnacomService{

	private CallWithDurationDto _dto;
	
	public TerminateActiveOutgoingCommService(CallWithDurationDto dto) {
		_dto = dto;
	}
	
	@Override
	public void dispatch() throws AnacomException {
		AnacomNetwork network = FenixFramework.getRoot();
		NetworkOperator op = network.getNetworkOperatorByCellPhoneNumberOrException(_dto
				.getSourceNumber());
		
		op.terminateActiveCommunication(_dto.getSourceNumber(), _dto.getDuration());
	}
}
