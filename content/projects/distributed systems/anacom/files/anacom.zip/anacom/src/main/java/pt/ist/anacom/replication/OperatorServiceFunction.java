package pt.ist.anacom.replication;

/**
 * This interface represents an operator service function
 * which allows us to encapsulate an operation that should be
 * executed in the operator.
 *
 * @param <I> The type of Dto the service receives.
 * @param <O> The return type of Dto that the service returns.
 */
public interface OperatorServiceFunction<I, O> {
    public O execute(I dto);
}
