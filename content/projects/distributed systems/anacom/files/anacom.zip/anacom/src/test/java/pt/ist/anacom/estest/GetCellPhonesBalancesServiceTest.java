package pt.ist.anacom.estest;

import java.math.BigDecimal;

import java.util.LinkedList;
import java.util.List;

import pt.ist.anacom.domain.NetworkOperator;

import pt.ist.anacom.service.GetCellPhonesBalancesService;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;

public class GetCellPhonesBalancesServiceTest extends AnacomTestCase {
	private static String HAVEPHONES_OPERATOR_NAME = "HAVEPHONES";
	private static String HAVEPHONES_OPERATOR_PREFIX = "12";
	private static int HAVEPHONES_OPERATOR_VOICE_COST = 20;
	private static int HAVEPHONES_VIDEO_COST = 40;
	private static int HAVEPHONES_SMS_COST = 5;
	private static BigDecimal HAVEPHONES_TAX = new BigDecimal(1.5);

	private static String NOPHONES_OPERATOR_NAME = "NOPHONES";
	private static String NOPHONES_OPERATOR_PREFIX = "21";
	private static int NOPHONES_OPERATOR_VOICE_COST = 20;
	private static int NOPHONES_OPERATOR_VIDEO_COST = 40;
	private static int NOPHONES_OPERATOR_SMS_COST = 5;
	private static BigDecimal NOPHONES_OPERATOR_TAX = new BigDecimal(1.5);

	private static String CELL1_HAVEPHONES_NUMBER = "123456700";
	private static int CELL1_HAVEPHONES_BALANCE = 100;
	private static String CELL2_HAVEPHONES_NUMBER = "123456701";
	private static int CELL2_HAVEPHONES_BALANCE = 50;

	private static NetworkOperator havePhones;

	public GetCellPhonesBalancesServiceTest(String msg) {
		super(msg);
	}

	public GetCellPhonesBalancesServiceTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();

		addOperator(HAVEPHONES_OPERATOR_NAME, HAVEPHONES_OPERATOR_PREFIX,
				HAVEPHONES_OPERATOR_VOICE_COST, HAVEPHONES_VIDEO_COST,
				HAVEPHONES_SMS_COST, HAVEPHONES_TAX);
		addOperator(NOPHONES_OPERATOR_NAME, NOPHONES_OPERATOR_PREFIX,
				NOPHONES_OPERATOR_VOICE_COST, NOPHONES_OPERATOR_VIDEO_COST,
				NOPHONES_OPERATOR_SMS_COST, NOPHONES_OPERATOR_TAX);

		havePhones = getOperatorByName(HAVEPHONES_OPERATOR_NAME);

		addCellPhone3G(havePhones, CELL1_HAVEPHONES_NUMBER,
				CELL1_HAVEPHONES_BALANCE);
		addCellPhone3G(havePhones, CELL2_HAVEPHONES_NUMBER,
				CELL2_HAVEPHONES_BALANCE);
	}

	public void testGetInfoFromOperatorWithNoPhones() {
		// Arrange
		NetworkOperatorSimpleDto _opDto = new NetworkOperatorSimpleDto(
				NOPHONES_OPERATOR_NAME);
		GetCellPhonesBalancesService service = new GetCellPhonesBalancesService(
				_opDto);
		List<BalanceDto> result = new LinkedList<BalanceDto>();

		// Act
		try {
			service.execute();
			result = service.getCellPhonesBalances().getCellPhonesBalances();
		} catch (AnacomException e) {
			fail("Test should not fail. Everything should go as expected");
		}

		// Assert
		assertEquals(
				"There shouldn't be any phones on the operator: "
						+ _opDto.getName(), 0, result.size());
	}

	public void testGetInfoFromOperatorWithPhones() {
		// Arrange
		NetworkOperatorSimpleDto _dto = new NetworkOperatorSimpleDto(
				HAVEPHONES_OPERATOR_NAME);
		GetCellPhonesBalancesService service = new GetCellPhonesBalancesService(
				_dto);
		List<BalanceDto> result = null;
		List<BalanceDto> expected = new LinkedList<BalanceDto>();
		expected.add(new BalanceDto(CELL1_HAVEPHONES_NUMBER,
				CELL1_HAVEPHONES_BALANCE));
		expected.add(new BalanceDto(CELL2_HAVEPHONES_NUMBER,
				CELL2_HAVEPHONES_BALANCE));

		// Act
		try {
			service.execute();
			result = service.getCellPhonesBalances().getCellPhonesBalances();
		} catch (AnacomException e) {
			fail("Test should not fail. Everything should go as expected");
		}

		// Assert
		assertEquals("Result was not what we were expecting", expected, result);
	}

	public void testGetInfoFromInexistentOperator() {
		// Arrange
		NetworkOperatorSimpleDto _dto = new NetworkOperatorSimpleDto(
				"DOESNTEXIST");
		GetCellPhonesBalancesService service = new GetCellPhonesBalancesService(
				_dto);

		List<BalanceDto> expected = new LinkedList<BalanceDto>();

		// Act
		try {
			service.execute();
			service.getCellPhonesBalances().getCellPhonesBalances();
			fail("OperatorNotExistsException wasn't thrown as expected");
		} catch (OperatorNotExistsException e) {
			// If we get here everything's fine
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw OperatorNotExistsException.");
		}

		// Assert
		assertEquals("The number of cell phones should be 0.", 0, service
				.getCellPhonesBalances().getCellPhonesBalances().size());

		assertEquals("Cell Phones Balances data is different.", expected,
				service.getCellPhonesBalances().getCellPhonesBalances());

	}
}
