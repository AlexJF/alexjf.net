package pt.ist.anacom.estest;

import java.math.BigDecimal;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.domain.Video;
import pt.ist.anacom.domain.Voice;

import pt.ist.anacom.service.TerminateActiveIncomingCommService;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;

public class TerminateActiveIncomingCommServiceTest extends AnacomTestCase {
	private static String OPERATOR_NAME = "ROFLCOPTER";
	private static String OPERATOR_PREFIX = "12";
	private static int OPERATOR_VOICE_COST = 20;
	private static int OPERATOR_VIDEO_COST = 40;
	private static int OPERATOR_SMS_COST = 5;
	private static BigDecimal OPERATOR_TAX = new BigDecimal(1.5);

    private static String CELL_SAME_OPER_NUMBER = "123456789";
	private static String CELL_NON_EXISTING_NUMBER = "123434343";

	private static String CELL_3G_ON_NUMBER = "123456710";

	private static int CELL_BALANCE = 1000;

    private static int VOICE_DURATION = 10;
    private static int VIDEO_DURATION = 10;

	private CellPhone cell3GOn;
	private NetworkOperator operator;

	public TerminateActiveIncomingCommServiceTest(String msg) {
		super(msg);
	}

	public TerminateActiveIncomingCommServiceTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();

		operator = addOperator(OPERATOR_NAME, OPERATOR_PREFIX,
				OPERATOR_VOICE_COST, OPERATOR_VIDEO_COST, OPERATOR_SMS_COST,
				OPERATOR_TAX);

		cell3GOn = addCellPhone3G(operator, CELL_3G_ON_NUMBER, CELL_BALANCE);
	}

	public void testTerminateActiveIncomingVideo() {
		// Arrange
        Video video = addIncomingVideo(cell3GOn, CELL_SAME_OPER_NUMBER);
		CallWithDurationDto dto = new CallWithDurationDto(CELL_SAME_OPER_NUMBER, CELL_3G_ON_NUMBER, VIDEO_DURATION);
		TerminateActiveIncomingCommService service = new TerminateActiveIncomingCommService(dto);

		// Act
		try {
			service.execute();
        } catch (AnacomException e) {
            fail("Incoming video communication termination should be successful.");
		}

		// Assert
		assertEquals("There should be no active communication after termination",
				getActiveCommunication(cell3GOn), null);
		assertEquals("Saved communication data should have the real duration of the communication",
				getCommunicationDuration(video), VIDEO_DURATION);
        assertTrue("Cellphone should be on after terminating the communication",
                isCellPhoneOn(cell3GOn));
	}

	public void testTerminateActiveIncomingVoice() {
		// Arrange
        Voice voice = addIncomingVoice(cell3GOn, CELL_SAME_OPER_NUMBER);
		CallWithDurationDto dto = new CallWithDurationDto(CELL_SAME_OPER_NUMBER, CELL_3G_ON_NUMBER, VOICE_DURATION);
		TerminateActiveIncomingCommService service = new TerminateActiveIncomingCommService(dto);

		// Act
		try {
			service.execute();
        } catch (AnacomException e) {
            fail("Incoming voice communication termination should be successful.");
		}

		// Assert
		assertEquals("There should be no active communication after termination",
				getActiveCommunication(cell3GOn), null);
		assertEquals("Saved communication data should have the real duration of the communication",
				getCommunicationDuration(voice), VOICE_DURATION);
        assertTrue("Cellphone should be on after terminating the communication",
                isCellPhoneOn(cell3GOn));
	}

	public void testTerminateActiveIncomingNonExistentActive() {
        // Arrange
		CallWithDurationDto dto = new CallWithDurationDto(CELL_SAME_OPER_NUMBER, CELL_3G_ON_NUMBER, VOICE_DURATION);
		TerminateActiveIncomingCommService service = new TerminateActiveIncomingCommService(dto);

		// Act
		try {
			service.execute();
        } catch (AnacomException e) {
            fail("Incoming video communication termination should be successful even when no such communication exists.");
		}
	}

	public void testTerminateActiveIncomingNonExistentCellPhone() {
        // Arrange
		CallWithDurationDto dto = new CallWithDurationDto(CELL_SAME_OPER_NUMBER, CELL_NON_EXISTING_NUMBER, VOICE_DURATION);
		TerminateActiveIncomingCommService service = new TerminateActiveIncomingCommService(dto);

		// Act
		try {
			service.execute();
        } catch (CellPhoneNotExistsException e) {
            // All is well
        } catch (AnacomException e) {
            fail("Wrong exception thrown. Should have thrown CellPhoneNotExistsException.");
		}
	}
}
