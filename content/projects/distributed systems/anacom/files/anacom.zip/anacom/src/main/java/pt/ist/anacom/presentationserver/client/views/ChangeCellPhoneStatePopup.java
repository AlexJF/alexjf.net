package pt.ist.anacom.presentationserver.client.views;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;

import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;

import pt.ist.anacom.presentationserver.client.Anacom;

import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto.CellPhoneStates;

public class ChangeCellPhoneStatePopup extends DialogBox {

	final private ListBox lstState = new ListBox();

	public ChangeCellPhoneStatePopup(final Anacom parent) {
		super();

		setGlassEnabled(true);
		setAnimationEnabled(true);

		setText("Change CellPhone State");

		HorizontalPanel horizontalPanel = new HorizontalPanel();
		setWidget(horizontalPanel);
		

		Label lblPhoneNumber = new Label("New State: ");
		horizontalPanel.add(lblPhoneNumber);

		horizontalPanel.add(lstState);

		for (CellPhoneWithStateDto.CellPhoneStates state : CellPhoneWithStateDto.CellPhoneStates
				.values()) {
			if (state.toString().equals(CellPhoneStates.Busy.toString())) {
				continue;
			}
			lstState.addItem(state.toString());
		}

		Button btnOk = new Button("OK", new ClickHandler() {
			public void onClick(ClickEvent event) {
				CellPhoneWithStateDto.CellPhoneStates state;
				String selectedStateName = lstState.getValue(lstState
						.getSelectedIndex());

				if (selectedStateName.equals("On")) {
					state = CellPhoneWithStateDto.CellPhoneStates.On;
				} else if (selectedStateName.equals("Silent")) {
					state = CellPhoneWithStateDto.CellPhoneStates.Silent;
				} else if (selectedStateName.equals("Off")) {
					state = CellPhoneWithStateDto.CellPhoneStates.Off;
				} else {
					return;
				}

				parent.setCurrentPhoneState(state);
				hide();
			}
		});
		horizontalPanel.add(btnOk);
	}

	@Override
	public void show() {
		lstState.setItemSelected(0, true);
		super.show();
	}
}
