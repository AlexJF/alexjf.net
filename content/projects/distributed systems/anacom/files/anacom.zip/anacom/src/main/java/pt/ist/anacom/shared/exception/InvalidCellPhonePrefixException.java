package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to an invalid cellphone prefix.
 */
public class InvalidCellPhonePrefixException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _prefix;
	private String _causeMessage;

	public InvalidCellPhonePrefixException() {
	}

	public InvalidCellPhonePrefixException(String prefix, String cause) {
		super("Specified cellphone prefix \"" + prefix + "\" is invalid: "
				+ cause);
		_prefix = prefix;
		_causeMessage = cause;
	}

	public String getPrefix() {
		return _prefix;
	}

	public String getCauseMessage() {
		return _causeMessage;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of InvalidCellPhonePrefixException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof InvalidCellPhonePrefixException))
			return false;

		InvalidCellPhonePrefixException exception = (InvalidCellPhonePrefixException) obj;

		return getPrefix().equals(exception.getPrefix())
				&& getCauseMessage().equals(exception.getCauseMessage());
	}
}
