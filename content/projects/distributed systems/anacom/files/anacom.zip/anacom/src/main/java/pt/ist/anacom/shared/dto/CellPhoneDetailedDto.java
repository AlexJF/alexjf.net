package pt.ist.anacom.shared.dto;

public class CellPhoneDetailedDto extends CellPhoneWithOperatorDto {
	
	static final long serialVersionUID = 1L;

	/**
	 * Enumerator with the possibles types of a CellPhone.
	 */
	public enum CellPhoneType {
		TwoG, ThreeG
	}

	/** Type of the CellPhone */
	private CellPhoneType _type;

	/** Balance of the CellPhone */
	private Integer _balance;

	public CellPhoneDetailedDto() {
		super();
	}

	/**
	 * Creates a new CellPhoneDetailedDto.
	 * 
	 * @param operatorName
	 *            The name of the operator where this phone resides.
	 * @param phoneNumber
	 *            The number of this cellphone.
	 * @param type
	 *            The type of the cellphone.
	 * @param balance
	 *            The balance of the cellphone in cents.
	 */
	public CellPhoneDetailedDto(String operatorName, String phoneNumber,
			CellPhoneType type, int balance) {
		super(operatorName, phoneNumber);
		_type = type;
		_balance = balance;
	}

	/**
	 * Creates a new CellPhoneDetailedDto.
	 * 
	 * Balance is initialized to 0.
	 * 
	 * @param operatorName
	 *            The name of the operator where this phone resides.
	 * @param phoneNumber
	 *            The number of this cellphone.
	 * @param type
	 *            The type of the cellphone.
	 */
	public CellPhoneDetailedDto(String operatorName, String phoneNumber,
			CellPhoneType type) {
		this(operatorName, phoneNumber, type, 0);
	}

	/**
	 * Retrieves the cellphone type.
	 * 
	 * @return The cellphone type.
	 */
	public CellPhoneType getType() {
		return _type;
	}

	/**
	 * Retrieves the cellphone's balance.
	 * 
	 * @return The cellphone's balance.
	 */
	public int getBalance() {
		return _balance;
	}
	
	/**
	 * Compares two instances of CellPhoneDetailedDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof CellPhoneDetailedDto))
			return false;

		CellPhoneDetailedDto dto = (CellPhoneDetailedDto) obj;

		return getType() == dto.getType()
				&& getBalance() == dto.getBalance();
	}
}
