package pt.ist.anacom.sdtest;

import pt.ist.anacom.replication.PresentationReplicationManager;
import pt.ist.anacom.replication.RemoteReplicatedServer;
import pt.ist.anacom.sdtest.stubs.PresentationReplicationManagerTester;
import junit.framework.TestCase;

public abstract class ReplicationTestCase extends TestCase {
	protected ReplicationTestCase(String msg) {
		super(msg);
	}

	protected ReplicationTestCase() {
		super();
	}

	protected void setUp() {
	}

	protected void tearDown() {
	}
	
	protected RemoteReplicatedServer getRemoteReplicatedServer(
			final PresentationReplicationManagerTester replicationManager, final String OPERATOR_NAME) {
		return new RemoteReplicatedServer() {
            @Override
            protected PresentationReplicationManager getReplicationManager() {
                return replicationManager;
            }

            @Override
            protected String getOperatorNameFromPhoneNumber(String number) {
                return OPERATOR_NAME;
            }
            
            @Override
            protected void initializeUDDI() {
            }

            @Override
            protected void initializeSecurity() {
            }
        };
	}
}
