package pt.ist.anacom.shared.exception;


/**
 * This class represents an exception related to an invalid balance change
 * operation.
 */
public class BalanceChangeException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private int _amount;
	private String _causeMessage;

	public BalanceChangeException() {
	}

	public BalanceChangeException(int amount, String cause) {
		super("Invalid balance change operation with amount \"" + amount
				+ "\": " + cause);
		_amount = amount;
		_causeMessage = cause;
	}

	public int getAmount() {
		return _amount;
	}

	public String getCauseMessage() {
		return _causeMessage;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of BalanceChangeException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof BalanceChangeException))
			return false;

		BalanceChangeException exception = (BalanceChangeException) obj;

		return getAmount() == exception.getAmount()
				&& getCauseMessage().equals(exception.getCauseMessage());
	}
}
