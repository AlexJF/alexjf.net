package pt.ist.anacom.presentationserver.client.views;

import pt.ist.anacom.presentationserver.client.Anacom;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto.CommunicationType;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;

public class GetLastCommunicationDetailsPopup extends DialogBox {
	private static final String UNKNOWNLABEL = "Unknown";
	final private Anacom parent;
	final Label lblCost = new Label(UNKNOWNLABEL);
	final Label lblDestinationNumber = new Label(UNKNOWNLABEL);
	final Label lblDuration = new Label(UNKNOWNLABEL);
	final Label lblType = new Label(UNKNOWNLABEL);
	final Label lblMessageSize = new Label(UNKNOWNLABEL);

	public GetLastCommunicationDetailsPopup(final Anacom parent) {
		super();
		this.parent = parent;

		FlexTable tbl = new FlexTable();

		setGlassEnabled(true);
		setAnimationEnabled(true);

		setText("Last Communication Details");

		HorizontalPanel horizontalPanel = new HorizontalPanel();
		setWidget(horizontalPanel);

		horizontalPanel.add(tbl);

		tbl.setHTML(1, 0, "Destination Number: ");
		tbl.setWidget(1, 1, lblDestinationNumber);

		tbl.setHTML(2, 0, "Cost: ");
		tbl.setWidget(2, 1, lblCost);

		tbl.setWidget(3, 0, lblDuration);
		tbl.setWidget(3, 1, lblMessageSize);

		tbl.setHTML(4, 0, "Communication Type: ");
		tbl.setWidget(4, 1, lblType);

		Button btnOk = new Button("Close", new ClickHandler() {
			public void onClick(ClickEvent event) {
				hide();
			}
		});
		tbl.setWidget(5, 2, btnOk);
	}

	public final void lastCommunicationDetails() {

		CellPhoneSimpleDto dto = new CellPhoneSimpleDto(
				parent.getCurrentPhoneNumber());
		parent.getRpcService().getLastCommunicationDetails(dto,
				new AsyncCallback<CommunicationDetailsDto>() {
					public void onSuccess(CommunicationDetailsDto response) {
						if (response.getType() == CommunicationType.UNKNOWN) {
							lblCost.setText(UNKNOWNLABEL);
							lblDestinationNumber.setText(UNKNOWNLABEL);
							lblType.setText(UNKNOWNLABEL);
							lblMessageSize.setText(UNKNOWNLABEL);
						} else {
							lblCost.setText(response.getCost() + "");
							lblDestinationNumber.setText(response
									.getDestinationNumber());
							lblType.setText(response.getType().toString());
							if (response.getType() == CommunicationType.SMS) {
								lblDuration.setText("Number of Characters: ");
							} else {
								lblDuration.setText("Duration: ");
							}
							lblMessageSize.setText(response.getSize() + "");
						}
					}

					public void onFailure(Throwable caught) {
						GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.getLastCommunicationDetails");
						GWT.log("-- Throwable: '" + caught.getClass().getName()
								+ "'");
						Window.alert("ERROR: Cannot getLastCommunicationDetails: "
								+ caught.getMessage());
					}
				});
	}

	@Override
	public void show() {
		lastCommunicationDetails();
		setText("Last Communication Details for "
				+ parent.getCurrentPhoneNumber());
		super.show();

	}

}
