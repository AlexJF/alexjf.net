package pt.ist.anacom.domain;

import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.DestinationSilenceException;

/**
 * This class represents a CellPhone's Silence State. When a CellPhone is in
 * Silence State it can make any type of communication but can only receive SMS
 * communication.
 */
public class CellPhoneSilenceState extends CellPhoneSilenceState_Base {

	public CellPhoneSilenceState() {
		super();
	}

	public void handleIncomingCommunication(Video commType)
			throws AnacomException {
		throw new DestinationSilenceException(getCellPhone().getNumber());
	}

	public void handleIncomingCommunication(SMS commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	public void handleIncomingCommunication(Voice commType)
			throws AnacomException {
		throw new DestinationSilenceException(getCellPhone().getNumber());
	}

	public void handleOutgoingCommunication(Video commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	public void handleOutgoingCommunication(SMS commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	public void handleOutgoingCommunication(Voice commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	public void turnOn() {
		this.getCellPhone().setCellPhoneState(new CellPhoneOnState());
	}

	public void turnOff() {
		this.getCellPhone().setCellPhoneState(new CellPhoneOffState());
	}

	public void turnSilence() {
		// Already in Silence State!
		// Nothing to do here.
	}

	public void turnBusy() {
		this.getCellPhone().setCellPhoneState(new CellPhoneBusyState());
	}

    @Override
    public String toString() {
        return "Silence";
    }
}
