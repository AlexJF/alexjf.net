package pt.ist.anacom.shared.exception;

public class WrongTimestampException extends AnacomException {
	private static final long serialVersionUID = 1L;

    private int _clientTimestamp;

	public WrongTimestampException() {
	}

	public WrongTimestampException(int clientTimestamp, int serverTimestamp) {
		super("Expected timestamp " + (serverTimestamp + 1) + ". Received " + clientTimestamp);
        _clientTimestamp = clientTimestamp;
        setTimestamp(serverTimestamp);

	}

	public int getClientTimestamp() {
		return _clientTimestamp;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of WrongTimestampException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof WrongTimestampException))
			return false;

		WrongTimestampException exception = (WrongTimestampException) obj;

		return getClientTimestamp() == exception.getClientTimestamp();
	}
}
