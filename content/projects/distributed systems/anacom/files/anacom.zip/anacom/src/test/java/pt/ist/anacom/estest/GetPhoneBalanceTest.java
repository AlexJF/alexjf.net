package pt.ist.anacom.estest;

import java.math.BigDecimal;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.service.GetCellPhoneBalanceService;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;

public class GetPhoneBalanceTest extends AnacomTestCase {

	private static String OPERATOR_NAME = "WOOW";
	private static String OPERATOR_PREFIX = "87";
	private static int OPERATOR_VOICE_COST = 10;
	private static int OPERATOR_VIDEO_COST = 30;
	private static int OPERATOR_SMS_COST = 6;
	private static BigDecimal OPERATOR_TAX = new BigDecimal(1.5);

	private static String CELL_NUMBER = "876711094";
	private static String NONEXISTING_CELL_NUMBER = "870000000";
	private static int CELL_BALANCE = 5;

	private CellPhone phone;

	public GetPhoneBalanceTest() {
	}

	@Override
	public void setUp() {
		super.setUp();

		NetworkOperator operator = addOperator(OPERATOR_NAME, OPERATOR_PREFIX,
				OPERATOR_VOICE_COST, OPERATOR_VIDEO_COST, OPERATOR_SMS_COST,
				OPERATOR_TAX);

		phone = addCellPhone2G(operator, CELL_NUMBER, CELL_BALANCE);
	}

	public void testBalanceCorrect() {
		// Arrange
		CellPhoneSimpleDto dto = new CellPhoneSimpleDto(CELL_NUMBER);
		GetCellPhoneBalanceService addService = new GetCellPhoneBalanceService(
				dto);
		int serviceBalance = 0;
		// Act
		try {
			addService.execute();
			serviceBalance = addService.getCellPhoneBalance().getBalance();
		} catch (AnacomException e) {
			fail("Balance retrieval should be successful.");
		}

		// Assert
		assertEquals("The balance returned by the service is wrong.",
				getCellPhoneBalance(phone), serviceBalance);
	}

	public void testBalanceWithAbsentPhone() {
		// Arrange
		CellPhoneSimpleDto dto = new CellPhoneSimpleDto(NONEXISTING_CELL_NUMBER);
		GetCellPhoneBalanceService addService = new GetCellPhoneBalanceService(
				dto);
		// Act
		try {
			addService.execute();
			fail("The phone number doesn't exist in the operator. It's supposed to throw a exception.");
		} catch (CellPhoneNotExistsException e) {
			// if we get this exception everything is fine!
		} catch (AnacomException e) {
			fail("We should only get a CellPhoneNotExistsException");
		}
	}
}
