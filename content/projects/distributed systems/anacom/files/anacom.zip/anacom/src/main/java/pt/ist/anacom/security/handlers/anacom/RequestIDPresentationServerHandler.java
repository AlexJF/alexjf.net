package pt.ist.anacom.security.handlers.anacom;

import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Node;

import pt.ist.anacom.security.handlers.AbstractHandler;
import sun.security.x509.X509CertImpl;

/**
 * This handler avoids that a bizantine replica/an attacker
 * is able to send response instead of the other replicas.
 */
public class RequestIDPresentationServerHandler extends AbstractHandler {

	/** The UUID for the active request */
	protected UUID _activeId;
	
	/** 
	 * Map that allows to verify if a given replica 
	 * already answered the request 
	 */
	protected Map<String, Boolean> _replicasAnswersCounter;
	
	public RequestIDPresentationServerHandler() {
		// Initially there are no requests!
		_activeId = null;
		_replicasAnswersCounter = new TreeMap<String, Boolean>();
	}

    @Override
    protected String getFaultString(boolean incoming) {
        if (incoming) {
            return "Incoming uuid not valid or duplicate response";
        } else {
            return "Unable to add uuid to outgoing message";
        }
    }
	
	/**
	 * This method indicates that the PresentationServer
	 * will make a new request.
	 * 
	 * @return the UUID of the request.
	 */
	protected UUID newRequest() {
		_activeId = UUID.randomUUID();
		_replicasAnswersCounter.clear();
		
		return _activeId;
	}
	
	/**
	 * Verifies if the new response coming from a given replica
	 * is valid or not.
	 * 
	 * @param replicaName The name of the replica who answered.
	 * @return true if the response is valid. false otherwise.
	 */
	protected boolean addResponse(String replicaName) {
		if (_replicasAnswersCounter.put(replicaName, true) == null) {
			return true;
		} else {
            System.out.println("Received duplicate response from " + replicaName);
			return false;
		}
	}

	@Override
	protected boolean handleInboundMessage(SOAPMessage message) {
        System.out.println("Handling Inbound Message - UUID Handler");
		try {
			
			Node uuidNode = getUUIDNode(getSoapEnvelope(message).getHeader());
			Node certificateNode = getCertificateNode(getSoapEnvelope(message).getHeader());

            if (uuidNode == null) {
                System.out.println("Null UUID node");
            }

            if (certificateNode == null) {
                System.out.println("Null Certificate node");
            }
			
			if ( ( uuidNode != null ) && ( certificateNode != null ) ) {
				String uuidString;
				uuidString = uuidNode.getTextContent();
				
				if (!uuidString.equals(_activeId.toString())) {
                    System.out.println("Active UUID: " + _activeId.toString());
                    System.out.println("Received UUID: " + uuidString);
					return false;
				}	
				
				String certString;
				certString = certificateNode.getTextContent();
				
				X509CertImpl cert = new X509CertImpl(b64d.decodeBuffer(certString));
				String replicaName = cert.getSubjectDN().getName();
				
				return addResponse(replicaName);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

        System.out.println("About to send false");
		
		// if the message doesn't have a certificate or a uuid ignore it
		return false;
	}

	@Override
	protected boolean handleOutboundMessage(SOAPMessage message) {
        System.out.println("Handling Outbound Message - UUID Handler");
		try {
			SOAPEnvelope soapEnvelope = getSoapEnvelope(message);
			SOAPHeader soapHeader = getHeader(soapEnvelope);
			Name name = soapEnvelope.createName("messageUUID", "anacom",
					"http://pt.ist.utl.anacom");
			SOAPElement element = soapHeader.addChildElement(name);
			element.addTextNode(newRequest().toString());
            System.out.println("Active UUID: " + _activeId.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return true;
	}	
}
