package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to a cellphone having more than
 * the maximum allowed balance.
 */
public class HigherThanMaxBalanceException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _phoneNumber;
	private int _balance;
	private int _maxBalance;

	public HigherThanMaxBalanceException() {
	}

	public HigherThanMaxBalanceException(String phoneNumber, int balance,
			int maxBalance) {
		super("Cellphone cannot have balance higher than \"" + maxBalance
				+ "\" cents. Had " + balance + " cents.");
		_phoneNumber = phoneNumber;
		_balance = balance;
		_maxBalance = maxBalance;
	}

	public String getPhoneNumber() {
		return _phoneNumber;
	}

	public int getBalance() {
		return _balance;
	}

	public int getMaxBalance() {
		return _maxBalance;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of HigherThanMaxBalanceException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof HigherThanMaxBalanceException))
			return false;

		HigherThanMaxBalanceException exception = (HigherThanMaxBalanceException) obj;

		return getPhoneNumber().equals(exception.getPhoneNumber())
				&& getBalance() == exception.getBalance()
				&& getMaxBalance() == exception.getMaxBalance();
	}
}
