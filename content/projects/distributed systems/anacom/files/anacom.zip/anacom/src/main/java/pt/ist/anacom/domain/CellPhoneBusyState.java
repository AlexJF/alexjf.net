package pt.ist.anacom.domain;

import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.DestinationBusyException;
import pt.ist.anacom.shared.exception.SourceBusyException;

/**
 * This class represents a CellPhone's Busy State.
 * 
 * When a CellPhone is in Busy State it's involved in a call with another
 * CellPhone and can only receive SMS communication while the active call
 * doesn't end.
 */
public class CellPhoneBusyState extends CellPhoneState {

    public CellPhoneBusyState() {
        super();
    }

    public void handleIncomingCommunication(Video commType)
            throws AnacomException {
        throw new DestinationBusyException(getCellPhone().getNumber());
    }

    public void handleIncomingCommunication(SMS commType)
            throws AnacomException {
        // We can make the communication!
        // Nothing to do here.
    }

    public void handleIncomingCommunication(Voice commType)
            throws AnacomException {
        throw new DestinationBusyException(getCellPhone().getNumber());
    }

    public void handleOutgoingCommunication(Video commType)
            throws AnacomException {
        throw new SourceBusyException(getCellPhone().getNumber());
    }

    public void handleOutgoingCommunication(SMS commType)
            throws AnacomException {
        throw new SourceBusyException(getCellPhone().getNumber());
    }

    public void handleOutgoingCommunication(Voice comm) throws AnacomException {
        throw new SourceBusyException(getCellPhone().getNumber());
    }

    public void turnOn() {
        this.getCellPhone().setCellPhoneState(new CellPhoneOnState());
    }

    public void turnOff() {
        this.getCellPhone().setCellPhoneState(new CellPhoneOffState());
    }

    public void turnSilence() {
        this.getCellPhone().setCellPhoneState(new CellPhoneSilenceState());
    }

    public void turnBusy() {
        // Already in Busy State!
        // Nothing to do here.
    }

    @Override
    public String toString() {
        return "Busy";
    }
}
