package pt.ist.anacom.estest;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.service.GetLastCommunicationDetailsService;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto.CommunicationType;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;

public class GetLastCommunicationDetailsServiceTest extends AnacomTestCase {

	private static final String MESSAGE1 = "beh";
	private static final String MESSAGE2 = "blah";
	private static String OPERATOR_NAME_BASE = "ZAZA";
	private static String OPERATOR_PREFIX_BASE = "87";

	private static String CELL_NUMBER1 = "876711094";
	private static String CELL_NUMBER2 = "876711095";
	private static int CELL_BALANCE = 200;
	private static int COST = 5;

	private CellPhone cell1;
	private CellPhone cell2;

	public GetLastCommunicationDetailsServiceTest() {
		super();
	}

	public GetLastCommunicationDetailsServiceTest(String msg) {
		super(msg);
	}

	@Override
	public void setUp() {
		super.setUp();
		addOperator(OPERATOR_NAME_BASE, OPERATOR_PREFIX_BASE);
		NetworkOperator op = getOperatorByName(OPERATOR_NAME_BASE);
		cell1 = addCellPhone2G(op, CELL_NUMBER1, CELL_BALANCE);
		cell2 = addCellPhone2G(op, CELL_NUMBER2, CELL_BALANCE);
	}

	public void testGetLastCommunicationWithOneComm() {
		// Arrange
		addIncomingSMS(cell2, CELL_NUMBER1, MESSAGE2);
		addOutgoingSMS(cell1, CELL_NUMBER2, MESSAGE2);
		CellPhoneSimpleDto dto = new CellPhoneSimpleDto(CELL_NUMBER1);
		GetLastCommunicationDetailsService service = new GetLastCommunicationDetailsService(
				dto);

		CommunicationDetailsDto expected = new CommunicationDetailsDto(
				CELL_NUMBER1, CELL_NUMBER2, COST, MESSAGE2.length(),
				CommunicationType.SMS);
		CommunicationDetailsDto result = null;

		// Act
		try {
			service.execute();
			result = service.getCommunicationDetails();
		} catch (CellPhoneNotExistsException e) {
			fail("Exception should not be sent: " + e.getMessage());
		}

		// Assert
		assertEquals("Communication details do not match", expected, result);
	}

	public void testGetLastCommunicationWithNoComms() {
		// Arrange
		CellPhoneSimpleDto dto = new CellPhoneSimpleDto(CELL_NUMBER1);
		GetLastCommunicationDetailsService service = new GetLastCommunicationDetailsService(
				dto);

		CommunicationDetailsDto result = null;

		// Act
		try {
			service.execute();
			result = service.getCommunicationDetails();
		} catch (CellPhoneNotExistsException e) {
			fail("Exception should not be sent: " + e.getMessage());
		}

		// Assert
		assertEquals("Communication found",
				CommunicationDetailsDto.NOPHONENUMBER, result.getDestinationNumber());
	}

	public void testGetLastCommunicationWithTwoComm() {
		// Arrange
		addIncomingSMS(cell2, CELL_NUMBER1, MESSAGE1);
		addOutgoingSMS(cell1, CELL_NUMBER2, MESSAGE1);
		addIncomingSMS(cell2, CELL_NUMBER1, MESSAGE2);
		addOutgoingSMS(cell1, CELL_NUMBER2, MESSAGE2);
		CellPhoneSimpleDto dto = new CellPhoneSimpleDto(CELL_NUMBER1);
		GetLastCommunicationDetailsService service = new GetLastCommunicationDetailsService(
				dto);

		CommunicationDetailsDto expected = new CommunicationDetailsDto(
				CELL_NUMBER1, CELL_NUMBER2, COST, MESSAGE2.length(),
				CommunicationType.SMS);
		CommunicationDetailsDto result = null;

		// Act
		try {
			service.execute();
			result = service.getCommunicationDetails();
		} catch (CellPhoneNotExistsException e) {
			fail("Exception should not be sent: " + e.getMessage());
		}

		// Assert
		assertEquals("Communication details do not match", expected, result);
	}
}
