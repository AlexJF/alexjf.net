package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to an incoming communication.
 */
public abstract class IncomingCommunicationException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _destinationNumber;

	public IncomingCommunicationException() {
	}

	public IncomingCommunicationException(String destinationNumber, String cause) {
		super("Cannot establish incoming communication to \""
				+ destinationNumber + "\": " + cause);
		_destinationNumber = destinationNumber;
	}

	public String getDestinationNumber() {
		return _destinationNumber;
	}

    public void setDestinationNumber(String number) {
        _destinationNumber = number;
    }
    
	/**
	 * Compares two instances of IncomingCommunicationException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof CellPhoneNotExistsException))
			return false;

		IncomingCommunicationException exception = (IncomingCommunicationException) obj;

		return getDestinationNumber().equals(exception.getDestinationNumber());
	}
}
