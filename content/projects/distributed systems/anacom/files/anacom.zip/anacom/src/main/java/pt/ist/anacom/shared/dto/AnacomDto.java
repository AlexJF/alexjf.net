package pt.ist.anacom.shared.dto;

import java.io.Serializable;

import pt.ist.anacom.shared.Timestamped;

/**
 * Class that represents a generic Dto.
 * The timestamp attribute is used by the distribution
 * algorithms.
 * All Dtos should inherit from this class!
 */
public class AnacomDto implements Serializable, Timestamped {

	private static final long serialVersionUID = 1L;

	/** Timestamp of the Dto */
	private Integer _timeStamp;
	
	/**
	 * Constructs a dto without a timestamp.
	 */
	public AnacomDto() {
		_timeStamp = null;
	}

	/**
	 * Constructs a Dto with a given timestamp.
	 * @param timeStamp of the Dto.
	 */
	public AnacomDto(Integer timeStamp) {
		_timeStamp = timeStamp;
	}
	
	/**
	 * Returns the timestamp of the Dto.
	 * @return the timestamp of the Dto.
	 */
	public Integer getTimestamp() {
		return _timeStamp;
	}
	
	/**
	 * Sets the timestamp of the Dto.
	 * @param timestamp to be set on the Dto.
	 */
	public void setTimestamp(Integer timestamp) {
		_timeStamp = timestamp;
	}
	
	/**
	 * Compares two instances of AnacomDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	if (obj == null)
    		return false;
		if (!(obj instanceof AnacomDto))
			return false;

		AnacomDto dto = (AnacomDto) obj;

		return getTimestamp() == null ? dto.getTimestamp() == null : getTimestamp().equals(dto.getTimestamp());
	}
}
