package pt.ist.anacom.domain;

import pt.ist.anacom.shared.exception.AnacomException;

/**
 * This class represents a CellPhone's On State. When a CellPhone is in On State
 * it can establish and receive any type of communication.
 */
public class CellPhoneOnState extends CellPhoneOnState_Base {

	public CellPhoneOnState() {
		super();
	}

	@Override
	public void handleIncomingCommunication(Video commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	@Override
	public void handleIncomingCommunication(SMS commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	@Override
	public void handleIncomingCommunication(Voice commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	@Override
	public void handleOutgoingCommunication(Video commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	@Override
	public void handleOutgoingCommunication(SMS commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	@Override
	public void handleOutgoingCommunication(Voice commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	public void turnOn() {
		// Already in On State.
		// Nothing to do here.
	}

	public void turnOff() {
		this.getCellPhone().setCellPhoneState(new CellPhoneOffState());
	}

	public void turnSilence() {
		this.getCellPhone().setCellPhoneState(new CellPhoneSilenceState());
	}

	public void turnBusy() {
		this.getCellPhone().setCellPhoneState(new CellPhoneBusyState());
	}

    @Override
    public String toString() {
        return "On";
    }
}
