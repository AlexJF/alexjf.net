package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.fenixframework.FenixFramework;

/**
 * This class implements the create network operator service.
 * 
 * This service allows creation of new network operators.
 */
public class CreateNetworkOperatorService extends AnacomService {
	NetworkOperatorDetailedDto _dto;

	/**
	 * Creates a new instance of this service with information about the
	 * operator to create.
	 * 
	 * @param dto
	 *            Element with information about a network operator.
	 */
	public CreateNetworkOperatorService(NetworkOperatorDetailedDto dto) {
		_dto = dto;
	}

	@Override
	public void dispatch() throws AnacomException {
		AnacomNetwork network = FenixFramework.getRoot();

		NetworkOperator operator = new NetworkOperator(_dto.getName(),
				_dto.getPrefix());

		operator.setCostSMS(_dto.getCostSMS());
		operator.setCostVideo(_dto.getCostVideo());
		operator.setCostVoice(_dto.getCostVoice());
		operator.setTax(_dto.getTax());
		operator.setBonus(_dto.getBonus());

		network.addNetworkOperator(operator);
	}
}
