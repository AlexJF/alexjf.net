package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to the source cellphone of a
 * communication being busy.
 */
public class SourceBusyException extends OutgoingCommunicationException {
	private static final long serialVersionUID = 1L;

	public SourceBusyException() {
	}

	public SourceBusyException(String sourceNumber) {
		super(sourceNumber, "Source cellphone is busy");
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of SourceBusyException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof SourceBusyException))
			return false;

		return true;
	}
}
