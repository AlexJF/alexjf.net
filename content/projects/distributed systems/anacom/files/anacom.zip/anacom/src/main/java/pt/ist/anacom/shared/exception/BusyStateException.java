package pt.ist.anacom.shared.exception;

public class BusyStateException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _phoneNumber;

	public BusyStateException() {
	}

	public BusyStateException(String phoneNumber) {
		super(
				"You tried to change "
						+ phoneNumber
						+ " state to Busy. You can only change to the following states: On, Off, Silent");
		_phoneNumber = phoneNumber;

	}

	public String getNumber() {
		return _phoneNumber;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of BusyStateException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof BusyStateException))
			return false;

		BusyStateException exception = (BusyStateException) obj;

		return getNumber().equals(exception.getNumber());
	}
}
