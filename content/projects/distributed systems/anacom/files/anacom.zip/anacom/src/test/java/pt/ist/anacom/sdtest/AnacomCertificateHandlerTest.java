package pt.ist.anacom.sdtest;

import java.security.KeyPair;
import java.security.cert.X509CRLEntry;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.soap.SOAPMessage;

import org.jmock.Expectations;
import org.jmock.Mockery;

import pt.ist.anacom.caserver.CAServer;
import pt.ist.anacom.sdtest.stubs.AnacomCertificateHandlerTester;
import pt.ist.anacom.security.managers.AnacomSecurityManager;
import sun.security.x509.X500Name;
import sun.security.x509.X509CRLEntryImpl;
import sun.security.x509.X509CRLImpl;
import sun.security.x509.X509CertImpl;

public class AnacomCertificateHandlerTest extends SecurityTestCase {
    Mockery context = new Mockery();
    
    KeyPair kPair = generateKeyPair();
    
    private AnacomCertificateHandlerTester handler;
    private AnacomSecurityManager Asm;
    
    public static final String SOAP_MESSAGE = 
            "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
            "<soap:Body><ns2:reset xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
            "</soap:Envelope>";
    
	public AnacomCertificateHandlerTest(String msg) {
		super(msg);
	}
    
    public AnacomCertificateHandlerTest() {
	}

	@Override
	public void setUp() {
		super.setUp();
		
		handler = new AnacomCertificateHandlerTester();
		
		System.out.println("---------------------------------------------");
	}
	
	private SOAPMessage prepareIncomingMessage(String message, KeyPair pair, X509CertImpl sourceCertificate) {
        SOAPMessage outgoingMessage = createSoapMessageFromString(message);
        
        addCertificateToSoapMessage(outgoingMessage, sourceCertificate);
        return outgoingMessage;
    }
	
    private SOAPMessage prepareValidIncomingMessage(String message, KeyPair pair) {
        X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", pair.getPrivate(), 1, 7);
        return prepareIncomingMessage(message, pair, sourceCertificate);
    }
    
    /* Receives a messages containing a certificate and ask for a blacklist
     * in order to verify if the received certificate is revoked or not.
     * 
     * Tests the amount of calls made to the CA (using a mock to CA Server).
     */
	public void testInboundNotOutOfDateBlacklistCalls() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		Asm = AnacomSecurityManager.getInstance();
		
		// Prepare a message with content equals SOAP_MESSAGE and adds a certificate
		// signed with kPairCA.privateKey
		SOAPMessage msg = prepareValidIncomingMessage(SOAP_MESSAGE, kPairCA);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Will ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Will ask for a blacklist (1 call)
			handler.testHandleIncomingMessage(msg);
			// Already have a valid blacklist - no additional call
			handler.testHandleIncomingMessage(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//Assert
		context.assertIsSatisfied();
	}
	
	/* Receives a messages containing a certificate and ask for a blacklist
     * in order to verify if the received certificate is revoked and valid.
     * 
     * Tests the result of such validation.
     */
	public void testInboundNotOutOfDateBlacklistResults() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		Boolean result = false;
		X509CRLEntry[] array = null;
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		Asm = AnacomSecurityManager.getInstance();
		
		// Prepare a message with content equals SOAP_MESSAGE and adds a certificate
		// signed with kPairCA.privateKey
		SOAPMessage msg = prepareValidIncomingMessage(SOAP_MESSAGE, kPairCA);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of(caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of(caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			Asm.setCA(caServer);
			
			// Will return true, since the certificate is valid and not revoked.
			result = handler.testHandleIncomingMessage(msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//Assert
		assertTrue("Message error", result);
	}

	/* Receives a messages containing a certificate and ask for a blacklist
     * in order to verify if the received certificate is revoked and valid.
     * After a time skip, the old blacklist goes invalid and new one (equal 
     * to the first one) is asked.
     * 
     * Tests the amount of calls made to the CA (using a mock to CA Server).
     */
	public void testInboundOutOfDateBlacklistCalls() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		
		Asm = AnacomSecurityManager.getInstance();
		
		// Prepare a message with content equals SOAP_MESSAGE and adds a certificate
		// signed with kPairCA.privateKey
		SOAPMessage msg = prepareValidIncomingMessage(SOAP_MESSAGE, kPairCA);
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDateFirst = new Date();
		lastDateFirst.setTime(lastDateFirst.getTime() + validity*3*1000);
		
		Date lastDateSecond = new Date();
		lastDateSecond.setTime(lastDateFirst.getTime() * 10*1000);
	
		try {
			final X509CRLImpl blackListFirst = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDateFirst, array);
			
			final X509CRLImpl blackListSecond = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDateSecond, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackListFirst));
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackListSecond));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Will ask for a blacklist (1 call)
			handler.testHandleIncomingMessage(msg);
			// Already have a valid blacklist - no additional call
			handler.testHandleIncomingMessage(msg);
			// Already have a valid blacklist - no additional call
			handler.testHandleIncomingMessage(msg);
			
			// Allows a time skip of 4 seconds
			Thread.sleep(4 * 1000);
			
			// Will ask for a blacklist (2 call) - previous one out of date
			handler.testHandleIncomingMessage(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        context.assertIsSatisfied();
	}
	
	/* Receives a messages containing a certificate and ask for a blacklist
     * in order to verify if the received certificate is revoked and valid.
     * After a time skip, the old blacklist goes invalid and new one (equal 
     * to the first one) is asked.
     * 
     * Tests the result of such validation.
     */
	public void testInboundOutOfDateBlacklistResults() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		Boolean resultFirst = false;
		Boolean resultSecond = false;
		X509CRLEntry[] array = null;
		
		Asm = AnacomSecurityManager.getInstance();
		
		// Prepare a message with content equals SOAP_MESSAGE and adds a certificate
		// signed with kPairCA.privateKey
		SOAPMessage msg = prepareValidIncomingMessage(SOAP_MESSAGE, kPairCA);
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity*500*1000);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(2).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			Asm.setCA(caServer);
	
			// Will return true, since the certificate is valid and not revoked.
			resultFirst = handler.testHandleIncomingMessage(msg);
			
			// Allows a time skip of 7 seconds
			Thread.sleep(4 * 1000);
			
			// Will return true, since the certificate is still valid and not revoked.
			resultSecond = handler.testHandleIncomingMessage(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Assert
        assertTrue("Message error", resultFirst);
        assertTrue("Message error", resultSecond);

	}
	
	/* Receives a messages containing a certificate that is out of date.
	 * Fails before asking for a blacklist, in order to verify if the received certificate 
	 * is revoked because validation test occurs first.
     * After a time skip, the old blacklist goes invalid.
     * 
     * Tests the amount of calls made to the CA (using a mock to CA Server).
     */
	public void testInboundOutOfDateCertificateCalls() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		Asm = AnacomSecurityManager.getInstance();
		
		// Prepare a message with content equals SOAP_MESSAGE and adds a certificate
		// signed with kPairCA.privateKey
		SOAPMessage msg = prepareValidIncomingMessage(SOAP_MESSAGE, kPairCA);
		 
		try {
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);

			// Allows a time skip of 8 seconds
			Thread.sleep(8*1000);
		
			// Tries to validated certificate and it fails. No verification about revoke
			// is made.
			handler.testHandleIncomingMessage(msg);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        context.assertIsSatisfied();
	}
	
	/* Receives a messages containing a certificate that is out of date.
	 * Fails before asking for a blacklist, in order to verify if the received certificate 
	 * is revoked because validation test occurs first.
     * After a time skip, the old blacklist goes invalid.
     * 
     * Tests the result of such validation.
     */
	public void testInboundOutOfDateCertificateResults() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		Boolean result = false;
		
		Asm = AnacomSecurityManager.getInstance();
		
		// Prepare a message with content equals SOAP_MESSAGE and adds a certificate
		// signed with kPairCA.privateKey
		SOAPMessage msg = prepareValidIncomingMessage(SOAP_MESSAGE, kPairCA);
		
		try {
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			Asm.setCA(caServer);

			// Allows a time skip of 16 seconds
			Thread.sleep(8*1000);
		
			// Will return false because it tries to validated certificate and it fails. 
			result = handler.testHandleIncomingMessage(msg);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
		assertFalse("Message error", result);
	}
	
	/* Receives a messages containing a certificate that is valid.
     * Asks for a blacklist to test if the certificate is revoked.
     * 
     * Tests the amount of calls made to the CA (using a mock to CA Server).
     */
	public void testInboundNoOutOfDateCertificateCalls() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;

		Asm = AnacomSecurityManager.getInstance();
		
		// Prepare a message with content equals SOAP_MESSAGE and adds a certificate
		// signed with kPairCA.privateKey
		SOAPMessage msg = prepareValidIncomingMessage(SOAP_MESSAGE, kPairCA);
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		try {
			
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Ask for blacklist to verify certificate (1 call)
			handler.testHandleIncomingMessage(msg);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
		context.assertIsSatisfied();
	}
	
	/* Receives a messages containing a certificate that is valid.
     * Asks for a blacklist to test if the certificate is revoked.
     * 
     * Tests the result of such validation.
     */
	public void testInboundNoOutOfDateCertificateResults() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		Boolean result = false;

		Asm = AnacomSecurityManager.getInstance();
		
		// Prepare a message with content equals SOAP_MESSAGE and adds a certificate
		// signed with kPairCA.privateKey
		SOAPMessage msg = prepareValidIncomingMessage(SOAP_MESSAGE, kPairCA);
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		try {
			
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			Asm.setCA(caServer);
			
			// Will return true since is everything fine with the certificate.
			result = handler.testHandleIncomingMessage(msg);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
	
	/* Sends a messages containing a certificate that is valid.
     * Asks for a blacklist to test if the certificate its own 
     * certificate is revoked.
     * 
     * Tests the result of such validation.
     */
	public void testOutboundNotOutOfDateCertificateResults(){
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		Boolean result = false;
		
		// Creates a simple certificate signed with kPairCA.privateKey, used by
		// sender.
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 1, 15);
		
		Asm = AnacomSecurityManager.getInstance();
		// Set sender's certificate
		Asm.setCertificate(certificateToBase64(sourceCertificate));
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			
			Asm.setCA(caServer);
			
			// Will return true, because everything is fine with the certificate.
			result = handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
	
	/* Sends a messages containing a certificate that is valid.
     * Asks for a blacklist to test if the certificate is revoked.
     * 
     * Tests the amount of calls made to the CA (using a mock to CA Server).
     */
	public void testOutboundNotOutOfDateCertificateCalls(){
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		
		// Creates a simple certificate signed with kPairCA.privateKey, used by
		// sender.
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 1, 15);
		
		Asm = AnacomSecurityManager.getInstance();
		// Set sender's certificate
		Asm.setCertificate(certificateToBase64(sourceCertificate));
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Will ask for blacklist (1 call)
			handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        context.assertIsSatisfied();
	}
	
	/* Sends a messages containing a certificate that is out of date.
     * Asks for a new certificate in order to send the message.
     * 
     * Tests the result of such validation.
     */
	public void testOutboundOutOfDateCertificateResults() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		Boolean resultFirst = false;
		Boolean resultSecond = false;
		
		Asm = AnacomSecurityManager.getInstance();
		// Set the name of the sender to EU
		Asm.setName("EU");
		
		// Create a valid certificate to be associated to the sender.
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 1);
		// Set the certificate to entity.
		Asm.setCertificate(certificateToBase64(sourceCertificate));
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			final X509CertImpl goodCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 40);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).createCertificate(with(any(String.class)),
														   with(any(String.class)));
														   will(returnValue(certificateToBase64(goodCertificate)));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			Asm.setCA(caServer);
			
			// Will return true, since the certificate is valid.
			resultFirst = handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));
			
			// Provides a time skip of 5 seconds (invalidating first certificate)
			Thread.sleep(5*1000);
			
			// Will return true, since it was able to fetch a new certificate.
			resultSecond = handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Should fail because certificate is out of date
        assertTrue("Message error", resultFirst);
        assertTrue("Message error", resultSecond);
	}
	
	/* Sends a messages containing a certificate that is out of date.
     * Asks for a new certificate in order to send the message.
     * 
     * Tests the amount of calls made to the CA (using a mock to CA Server).
     */
	public void testOutboundOutOfDateCertificateCalls() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
	
		Asm = AnacomSecurityManager.getInstance();
		// Set the name of the sender to EU
		Asm.setName("EU");
		
		// Create a valid certificate to be associated to the sender.
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 1);
		// Set the certificate to entity.
		Asm.setCertificate(certificateToBase64(sourceCertificate));
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			final X509CertImpl goodCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 40);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).createCertificate(with(any(String.class)),
														   with(any(String.class)));
														   will(returnValue(certificateToBase64(goodCertificate)));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Will ask for the blacklist (1 call)
			handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));
			
			// Provides a time skip of 5 seconds (invalidating first certificate)
			Thread.sleep(5*1000);
			
			// Will ask for a new certificate (1 call)
			handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Should fail because certificate is out of date
        context.assertIsSatisfied();
	}
	
	/* Sends a messages containing a certificate that is valid.
     * Asks for a blacklist to verify it.
     * 
     * Tests the amount of calls made to the CA (using a mock to CA Server).
     */
	public void testOutboundNotOutOfDateBlacklistCalls() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		
		Asm = AnacomSecurityManager.getInstance();
		// Set the name of the sender to EU
		Asm.setName("EU");
		
		// Create a valid certificate to be associated to the sender.
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 1);
		// Set the certificate to entity.
		Asm.setCertificate(certificateToBase64(sourceCertificate));
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Ask for blacklist (1 call)
			handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));
			// Already have valid blacklist (no call)
			handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        context.assertIsSatisfied();
	}
	
	/* Sends a messages containing a certificate that is valid.
     * Asks for a blacklist to verify it.
     * 
     * Tests the result of such validation.
     */
	public void testOutboundNotOutOfDateBlacklistResults() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		Boolean result = false;
		
		Asm = AnacomSecurityManager.getInstance();
		// Set the name of the sender to EU
		Asm.setName("EU");
		
		// Create a valid certificate to be associated to the sender.
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 1);
		// Set the certificate to entity.
		Asm.setCertificate(certificateToBase64(sourceCertificate));
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 5L*1000L * 24L * 60L * 60L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			Asm.setCA(caServer);
			
			// Will return true, since blacklist obtained is valid.
			result = handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
	
	
	/* Sends a messages containing a certificate that is valid.
     * Asks for a blacklist to verify it.
     * 
     * Tests the amount of calls made to the CA (using a mock to CA Server).
     */
	public void testOutboundOutOfDateBlacklistCalls() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		
		Asm = AnacomSecurityManager.getInstance();
		// Set the name of the sender to EU
		Asm.setName("EU");
		
		// Create a valid certificate to be associated to the sender.
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 5);
		// Set the certificate to entity.
		Asm.setCertificate(certificateToBase64(sourceCertificate));
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 1000L);
		
		try {
			
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(2).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Ask for blacklist (1 call)
			handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));	
			
			// Simulates a time skip of 2 seconds
			Thread.sleep(2000);
			
			// Ask for blacklist (2 call)
			handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        context.assertIsSatisfied();
	}
	
	/* Sends a messages containing a certificate that is valid.
     * Asks for a blacklist to verify it.
     * 
     * Tests the result of such validation.
     */
	public void testOutboundOutOfDateBlacklistResults() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		X509CRLEntry[] array = null;
		Boolean resultFirst = false;
		Boolean resultSecond = false;
		
		Asm = AnacomSecurityManager.getInstance();
		// Set the name of the sender to EU
		Asm.setName("EU");
		
		// Create a valid certificate to be associated to the sender.
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 5);
		// Set the certificate to entity.
		Asm.setCertificate(certificateToBase64(sourceCertificate));
		
		// Define validity to blacklist - 
		long validity = 1;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 1000L);
		
		try {
			
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(2).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Will return true because everything is well set.
			resultFirst = handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));	
			
			// Simulates a time skip of 7 seconds
			Thread.sleep(2000);
			
			// Will return true because blacklist obtained is out of date but it will fetch a new one.
			resultSecond = handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE));	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", resultFirst);
        assertTrue("Message error", resultSecond);
	}
	
	/* Receive a messages containing a revoked certificate.
     * Asks for a blacklist to verify it.
     * 
     * Tests the result of such validation.
     */
	public void testInboundRevokedCertificateResult() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		Boolean result = false;
		
		Asm = AnacomSecurityManager.getInstance();
		
		// List used to create a X509CRL
		ArrayList<X509CRLEntry> list = new ArrayList<X509CRLEntry>();
		
		// Certificated to be added to the blacklist
		final X509CertImpl badCertificate = 
				createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 2, 15);
		
		// Add certificate to blacklist
		list.add(new X509CRLEntryImpl(badCertificate.getSerialNumber(),new Date()));
		
		// Create an array from a list of revoked certificates.
		X509CRLEntry[] array = (X509CRLEntry[])list.toArray(new X509CRLEntry[list.size()]);
		
		// Create a message using the revoked certificate.
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE, kPairCA, badCertificate);
		
		// Define validity to blacklist - 
		long validity = 5;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 1000L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			Asm.setCA(caServer);
			
			// It will return false because a message from a revoked certificate is not
			// valid.
			result = handler.testHandleIncomingMessage(msg);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertFalse("Message error", result);
	}
	
	/* Receive a messages containing a revoked certificate.
     * Asks for a blacklist to verify it.
     * 
     * Tests the result of such validation.
     */
	public void testInboundRevokedCertificateCalls() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		Asm = AnacomSecurityManager.getInstance();
		
		// List used to create a X509CRL
		ArrayList<X509CRLEntry> list = new ArrayList<X509CRLEntry>();
		
		// Certificated to be added to the blacklist
		final X509CertImpl badCertificate = 
				createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 2, 15);
		
		// Add certificate to blacklist
		list.add(new X509CRLEntryImpl(badCertificate.getSerialNumber(),new Date()));
		
		// Create an array from a list of revoked certificates.
		X509CRLEntry[] array = (X509CRLEntry[])list.toArray(new X509CRLEntry[list.size()]);
		
		// Create a message using the revoked certificate.
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE, kPairCA, badCertificate);
		
		// Define validity to blacklist - 
		long validity = 5;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 1000L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Ask for a blacklist (1 call)
			handler.testHandleIncomingMessage(msg);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        context.assertIsSatisfied();
	}
	
	/* Send a messages containing a revoked certificate.
     * Asks for a blacklist to verify it.
     * 
     * Tests the result of such validation.
     */
	public void testOutboundRevokedCertificateResult() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		Boolean result = false;
		
		Asm = AnacomSecurityManager.getInstance();
		
		// List used to create a X509CRL
		ArrayList<X509CRLEntry> list = new ArrayList<X509CRLEntry>();
		
		// Certificated to be added to the blacklist
		final X509CertImpl badCertificate = 
				createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 2, 15);
		
		// Add certificate to blacklist
		list.add(new X509CRLEntryImpl(badCertificate.getSerialNumber(),new Date()));
		
		// Create an array from a list of revoked certificates.
		X509CRLEntry[] array = (X509CRLEntry[])list.toArray(new X509CRLEntry[list.size()]);
		
		// Create a message using the revoked certificate.
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE, kPairCA, badCertificate);
		
		// Define validity to blacklist - 
		long validity = 5;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 1000L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			final X509CertImpl goodCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 40);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).createCertificate(with(any(String.class)),
						   with(any(String.class)));
						   will(returnValue(certificateToBase64(goodCertificate)));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			Asm.setCA(caServer);
			
			// It will return true because it will fetch a new certificate.
			result = handler.testHandleOutgoingMessage(msg);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
	
	/* Send a messages containing a revoked certificate.
     * Asks for a blacklist to verify it.
     * 
     * Tests the result of such validation.
     */
	public void testOutboundRevokedCertificateCalls() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		final CAServer caServer = context.mock(CAServer.class, "CAServer");
		
		Asm = AnacomSecurityManager.getInstance();
		
		// List used to create a X509CRL
		ArrayList<X509CRLEntry> list = new ArrayList<X509CRLEntry>();
		
		// Certificated to be added to the blacklist
		final X509CertImpl badCertificate = 
				createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 2, 15);
		
		Asm.setCertificate(certificateToBase64(badCertificate));
		
		// Add certificate to blacklist
		list.add(new X509CRLEntryImpl(badCertificate.getSerialNumber(),new Date()));
		
		// Create an array from a list of revoked certificates.
		X509CRLEntry[] array = (X509CRLEntry[])list.toArray(new X509CRLEntry[list.size()]);
		
		// Create a message using the revoked certificate.
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE, kPairCA, badCertificate);
		
		// Define validity to blacklist - 
		long validity = 5;
		Date lastDate = new Date();
		lastDate.setTime(lastDate.getTime() + validity * 1000L);
		
		try {
			final X509CRLImpl blackList = new X509CRLImpl(
					new X500Name("CA","Certification Authority","CA.anacom.pt","PT"),
					new Date(), lastDate, array);
			
			final X509CertImpl goodCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 40);
			
			context.checking(new Expectations() {{
				exactly(1).of (caServer).getBlackList(); will(returnValue(blackList));
				exactly(1).of (caServer).createCertificate(with(any(String.class)),
						   with(any(String.class)));
						   will(returnValue(certificateToBase64(goodCertificate)));
				exactly(1).of (caServer).getPublicKey(); will(returnValue(kPairCA.getPublic()));
			}});
			
			// Ask for CA public key (1 call)
			Asm.setCA(caServer);
			
			// Ask for a blacklist (1 call)
			handler.testHandleOutgoingMessage(msg);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        context.assertIsSatisfied();
	}
}