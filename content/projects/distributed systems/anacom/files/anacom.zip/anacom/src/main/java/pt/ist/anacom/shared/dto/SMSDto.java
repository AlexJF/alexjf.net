package pt.ist.anacom.shared.dto;

public class SMSDto extends AnacomDto {
	
	static final long serialVersionUID = 1L;

	/** Number of the source cellphone. */
	private String _sourceNumber;
	/** Number of the destination cellphone. */
	private String _destinationNumber;
	/** Message of the SMS. */
	private String _message;

	public SMSDto() {
	}

	/**
	 * Creates a new instance of SMSDto.
	 * 
	 * @param sourceNumber
	 *            The number of the cellphone where the SMS originated from
	 * @param destinationNumber
	 *            The number of the cellphone to which the SMS is directed.
	 * @param message
	 *            The contents of the SMS message.
	 */
	public SMSDto(String sourceNumber, String destinationNumber, String message) {
		_sourceNumber = sourceNumber;
		_destinationNumber = destinationNumber;
		_message = message;
	}

	/**
	 * Get the number of the source CellPhone.
	 * 
	 * @return The number of the source CellPhone.
	 */
	public String getSourceNumber() {
		return _sourceNumber;
	}

	/**
	 * Get the number of the destination CellPhone.
	 * 
	 * @return The number of the destination CellPhone.
	 */
	public String getDestinationNumber() {
		return _destinationNumber;
	}

	/**
	 * Get the message of this SMS instance.
	 * 
	 * @return The message of this SMS instance.
	 */
	public String getMessage() {
		return _message;
	}
	
	/**
	 * Compares two instances of SMSDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof SMSDto))
			return false;

		SMSDto dto = (SMSDto) obj;

		return getSourceNumber().equals(dto.getSourceNumber())
				&& getDestinationNumber().equals(dto.getDestinationNumber())
				&& getMessage().equals(dto.getMessage());
	}
}
