package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to an invalid cellphone number.
 */
public class InvalidCellPhoneNumberException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _number;
	private String _causeMessage;

	public InvalidCellPhoneNumberException() {
	}

	public InvalidCellPhoneNumberException(String number, String cause) {
		super("Specified cellphone number \"" + number + "\" is invalid: "
				+ cause);
		_number = number;
		_causeMessage = cause;
	}

	public String getNumber() {
		return _number;
	}

	public String getCauseMessage() {
		return _causeMessage;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of InvalidCellPhoneNumberException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof InvalidCellPhoneNumberException))
			return false;

		InvalidCellPhoneNumberException exception = (InvalidCellPhoneNumberException) obj;

		return getNumber().equals(exception.getNumber())
				&& getCauseMessage().equals(exception.getCauseMessage());
	}
}
