package pt.ist.anacom.shared.dto;


/**
 * This class represents a Dto that has the necessary information for changing a
 * CellPhone's balance.
 */
public class ChangeCellPhoneBalanceDto extends AnacomDto {
	static final long serialVersionUID = 1L;

	/** The number of the CellPhone whose balance we want to change. */
	private String _cellPhoneNumber;

	/** The amount by which we want to change the CellPhone's balance.. */
	private int _amount;

	public ChangeCellPhoneBalanceDto() {
	}

	public ChangeCellPhoneBalanceDto(String phoneNumber, int amount) {
		_cellPhoneNumber = phoneNumber;
		_amount = amount;
	}

	/**
	 * Sets the number of the CellPhone whose balance we want to change.
	 * 
	 * @param phoneNumber
	 *            of the CellPhone whose balance we want to change.
	 */
	public void setPhoneNumber(String phoneNumber) {
		_cellPhoneNumber = phoneNumber;
	}

	/**
	 * Sets the amount by which we want to change the balance of the CellPhone.
	 * 
	 * @param amount
	 *            by which we want to change the CellPhone's balance in cents.
	 */
	public void setAmount(int amount) {
		_amount = amount;
	}

	/**
	 * Returns the number of the CellPhone whose balance we want to change.
	 * 
	 * @return Number of the CellPhone whose balance we want to change.
	 */
	public String getPhoneNumber() {
		return _cellPhoneNumber;
	}

	/**
	 * Returns the amount by which we want to change the balance of the
	 * CellPhone.
	 * 
	 * @return Amount by which we want to change the balance of the CellPhone in
	 *         cents.
	 */
	public int getAmount() {
		return _amount;
	}
	
	/**
	 * Compares two instances of ChangeCellPhoneBalanceDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof ChangeCellPhoneBalanceDto))
			return false;

		ChangeCellPhoneBalanceDto dto = (ChangeCellPhoneBalanceDto) obj;

		return getPhoneNumber().equals(dto.getPhoneNumber())
				&& getAmount() == dto.getAmount();
	}
}
