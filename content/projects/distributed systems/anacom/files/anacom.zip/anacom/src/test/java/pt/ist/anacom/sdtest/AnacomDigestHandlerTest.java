package pt.ist.anacom.sdtest;

import java.security.KeyPair;

import javax.xml.soap.SOAPMessage;

import org.jmock.Mockery;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import pt.ist.anacom.sdtest.stubs.AnacomDigestHandlerTester;
import pt.ist.anacom.security.managers.AnacomSecurityManager;
import sun.security.x509.X509CertImpl;

public class AnacomDigestHandlerTest extends SecurityTestCase {
	Mockery context = new Mockery();
	
	KeyPair caKeyPair = generateKeyPair();
	
	private AnacomDigestHandlerTester handler;
    private AnacomSecurityManager sm = AnacomSecurityManager.getInstance();
    
    public static final String SOAP_MESSAGE = 
            "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
            "<soap:Body><ns2:reset xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
            "</soap:Envelope>";

    private static final String GOOD_SOURCE_NAME = "ZE DAS COUVES";
    private static final String BAD_SOURCE_NAME = "NATACHA DAS CENOURAS";
    
    public AnacomDigestHandlerTest(String msg) {
		super(msg);
	}

	public AnacomDigestHandlerTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();
		
		handler = new AnacomDigestHandlerTester();
	}
	
	/* For a certain message, it signs its digest, using the privateKey of the pair provided, and then it appends
	 * its certificate.
	 */
	private SOAPMessage prepareIncomingMessage(String message, KeyPair pair, X509CertImpl sourceCertificate) {
        SOAPMessage incomingMessage = createSoapMessageFromString(message);
        handler.signXML(incomingMessage.getSOAPPart(), pair.getPrivate());
        addCertificateToSoapMessage(incomingMessage, sourceCertificate);
        return incomingMessage;
    }

    private SOAPMessage prepareValidIncomingMessage(String message, KeyPair pair) {
        X509CertImpl sourceCertificate = createCertificate(pair.getPublic(), GOOD_SOURCE_NAME, sm.getName(), caKeyPair.getPrivate(), 1);
        return prepareIncomingMessage(message, pair, sourceCertificate);
    }

    private SOAPMessage prepareInvalidIncomingMessage(String message, KeyPair pair) {
        KeyPair badPair = generateKeyPair();
        X509CertImpl sourceCertificate = createCertificate(badPair.getPublic(), BAD_SOURCE_NAME, sm.getName(), caKeyPair.getPrivate(), 1);
        return prepareIncomingMessage(message, pair, sourceCertificate);
    }
    
    /* This test pretends to test scenario where a given SOAPMessage is
     * digested, signed and appended to the certificate holding the publicKey that 
     * corresponds to the private key used to sign the message.
     * The message is then sent and should be a valid one.
     * This tests the validation of the digest used.
     */
    public void testAllowCorrectDigest() {
        // Arrange
        KeyPair pair = generateKeyPair();
        SOAPMessage message = prepareValidIncomingMessage(SOAP_MESSAGE, pair);
        Boolean result = false;

		try {
            result = handler.testHandleIncomingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Incoming message handling should not have failed");
        }
		
		// Assert
        assertTrue("Handler should have recognized the message as being valid", result);
	}
    
    /* Signs a the digest of the message with a wrong key and append a certificate
     * to another key.
     * This should fail since both digital signature does not match.
     */
    public void testBlockIncorrectPrivateKeyDigest() {
        // Arrange
        KeyPair pair = generateKeyPair();
        SOAPMessage message = prepareInvalidIncomingMessage(SOAP_MESSAGE, pair);
        Boolean result = false;
        
		try {
            result = handler.testHandleIncomingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Incoming message handling should not have failed");
        }
		
		// Assert
        assertFalse("Handler should have recognized the message as being invalid", result);
	}
    
    /* This test signs a message perfectly, but then it changes the signature
     * field of the message in order to obtain an error when trying to compare.
     */
    public void testBlockIncorrectDigest() {
        // Arrange
        KeyPair pair = generateKeyPair();
        SOAPMessage message = prepareValidIncomingMessage(SOAP_MESSAGE, pair);
        NodeList sigValues = message.getSOAPPart().getElementsByTagName("SignatureValue");
        Node sigValue = sigValues.item(0);
        sigValue.setTextContent(base64Encode("IAmMessingWithYourSignatureMWAHAHA".getBytes()));
        Boolean result = false;

		try {
            result = handler.testHandleIncomingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Incoming message handling should not have failed");
        }
		
		// Assert
        assertFalse("Handler should have recognized the message as being invalid", result);
	}
    
    /* This test shows that function used in handlers to sign the message
     * is working. The idea is to ask the handler to sign the message and
     * create a digital signature and the sign it by and comparing the 
     * results.
     */
    public void testCorrectDigestGeneration() {
        // Arrange
        SOAPMessage message = createSoapMessageFromString(SOAP_MESSAGE);
        SOAPMessage expectedMessage = createSoapMessageFromString(SOAP_MESSAGE);
        handler.signXML(expectedMessage.getSOAPPart(), sm.getPrivateKey());
        String expectedOutputString = getStringFromSoapMessage(expectedMessage);
        Boolean result = false;

		try {
            result = handler.testHandleOutgoingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Incoming message handling should not have failed");
        }

        String resultOutputString = getStringFromSoapMessage(message);
		
		// Assert
        assertTrue("Handler should have allowed the message to be sent", result);
        assertEquals("Generated message doesn't match expected message", resultOutputString, expectedOutputString);
    }
}
