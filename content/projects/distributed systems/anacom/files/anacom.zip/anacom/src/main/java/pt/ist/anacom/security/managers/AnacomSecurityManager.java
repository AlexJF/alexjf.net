package pt.ist.anacom.security.managers;

import java.security.KeyPair;
import java.security.cert.CertificateExpiredException;
import java.util.Date;

import pt.ist.anacom.caserver.CAServer;
import pt.ist.anacom.shared.exception.CAException;
import sun.security.x509.X509CRLImpl;
import sun.security.x509.X509CertImpl;

/**
 * This security manager is possessed by all entities of Anacom
 * domain.
 */
public class AnacomSecurityManager extends AbstractSecurityManager {
    private static AnacomSecurityManager _instance = null;
	private X509CRLImpl _blackList = null;
	private CAServer _ca = null;
	private boolean _isGettingBlackList = false;

    public static AnacomSecurityManager getInstance() {
        if (_instance == null) {
            _instance = new AnacomSecurityManager();
        }
        return _instance;
    }

    public static boolean isCreated() {
        return _instance != null;
    }

	private AnacomSecurityManager() {
        super();
	}

	public void setCA(CAServer ca) {
		_ca = ca;
        _caPublicKey = ca.getPublicKey();
        _blackList = null;
	}
	
	/**
	 * Obtains the black list if it is valid, otherwise
	 * it fetch a new one from the associated CA.
	 */
	public synchronized X509CRLImpl getBlackList() {
		_isGettingBlackList = true;
		System.out.println("Getting blackList");
		
		if (_blackList == null || (_blackList.getNextUpdate().before(new Date()) == true)) {
			_blackList = _ca.getBlackList();
		}
		_isGettingBlackList = false;
		return _blackList;
	}
	
	/**
	 * Ask for a new certificate to the associated CA.
	 * @throws CAException
	 */
	public void getNewCertificate() throws CAException{
		_certificate = _ca.createCertificate(b64e.encode(_kp.getEncoded()), name);
	}
	
	public synchronized String getCertificate() {
		if (_certificate == null) {
            return null;
        }
		System.out.println("Certificate not null");
        try {
			 X509CertImpl cert = new X509CertImpl(b64d.decodeBuffer(_certificate));
			 
			 cert.checkValidity();
			 System.out.println("Certificate is valid");
			 if (!_isGettingBlackList && getBlackList().isRevoked(cert)) {
				 System.out.println("Certificate is revoked so i'm getting a new one");
			     _certificate = null;
				 KeyPair pair = loadKeyPair();
				 _kp = pair.getPublic();
				 _ks = pair.getPrivate();
				 getNewCertificate();
			}
        } catch (CertificateExpiredException e) {
        	 System.out.println("Certificate expired so i'm getting a new one");
             _certificate = null;
			 getNewCertificate();
		} catch (Exception e) {
            e.printStackTrace();
         
			throw new CAException(e.getMessage());
		}
        return _certificate;
	}
}
