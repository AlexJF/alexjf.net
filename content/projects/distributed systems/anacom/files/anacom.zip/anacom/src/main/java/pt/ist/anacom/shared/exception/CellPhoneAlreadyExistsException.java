package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to an already existing cellphone.
 */
public class CellPhoneAlreadyExistsException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _number;
	private String _operatorName;

	public CellPhoneAlreadyExistsException() {
	}

	public CellPhoneAlreadyExistsException(String number, String operatorName) {
		super("A cellphone with the number \"" + number
				+ "\" already exists on the \"" + operatorName + "\" operator");
		_number = number;
		_operatorName = operatorName;
	}

	public String getNumber() {
		return _number;
	}

	public String getOperatorName() {
		return _operatorName;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of CellPhoneAlreadyExistsException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof CellPhoneAlreadyExistsException))
			return false;

		CellPhoneAlreadyExistsException exception = (CellPhoneAlreadyExistsException) obj;

		return getNumber().equals(exception.getNumber())
				&& getOperatorName().equals(exception.getOperatorName());
	}
}
