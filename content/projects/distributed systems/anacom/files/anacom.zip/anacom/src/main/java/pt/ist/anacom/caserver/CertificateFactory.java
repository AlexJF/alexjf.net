package pt.ist.anacom.caserver;

import java.io.IOException;

import java.security.cert.CertificateException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;

import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;

import sun.security.x509.AlgorithmId;
import sun.security.x509.CertificateAlgorithmId;
import sun.security.x509.CertificateIssuerName;
import sun.security.x509.CertificateSerialNumber;
import sun.security.x509.CertificateSubjectName;
import sun.security.x509.CertificateValidity;
import sun.security.x509.CertificateX509Key;
import sun.security.x509.X500Name;
import sun.security.x509.X500Signer;
import sun.security.x509.X509CertImpl;
import sun.security.x509.X509CertInfo;

/**
 * This class is a CA certificate factory. 
 */

public class CertificateFactory {
	public static X509CertImpl createCertificate(PublicKey publicKey, String app, String issuerName, PrivateKey issuerPrivateKey, int serialNumber)
			throws CertificateException, IOException, InvalidKeyException,
			NoSuchAlgorithmException, InvalidKeySpecException,
			NoSuchProviderException, SignatureException {
        return createCertificate(publicKey.getEncoded(), app, issuerName, issuerPrivateKey, serialNumber);
    }
	
	public static X509CertImpl createCertificate(PublicKey publicKey, String app, String issuerName, PrivateKey issuerPrivateKey, int serialNumber, long validity)
			throws CertificateException, IOException, InvalidKeyException,
			NoSuchAlgorithmException, InvalidKeySpecException,
			NoSuchProviderException, SignatureException {
        return createCertificate(publicKey.getEncoded(), app, issuerName, issuerPrivateKey, serialNumber, validity);
    }
	
	public static X509CertImpl createCertificate(byte[] pubKeyBytes, String app, String issuerName, PrivateKey issuerPrivateKey, int serialNumber) 
			throws InvalidKeyException, CertificateException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchProviderException, SignatureException, IOException {

	return createCertificate(pubKeyBytes, app, issuerName, issuerPrivateKey, serialNumber, 1800L);

	}
	
	public static X509CertImpl createCertificate(byte[] pubKeyBytes, String app, String issuerName, PrivateKey issuerPrivateKey, int serialNumber,
			long validity)
			throws CertificateException, IOException, InvalidKeyException,
			NoSuchAlgorithmException, InvalidKeySpecException,
			NoSuchProviderException, SignatureException {

			// Certificate info
			X509CertInfo certInfo = new X509CertInfo();

			// certificate validity
			Date firstDate = new Date();
			Date lastDate = new Date();
			lastDate.setTime(firstDate.getTime() + validity * 1000L);
			certInfo.set(X509CertInfo.VALIDITY, new CertificateValidity(
					firstDate, lastDate));

			// certificate serial number
			certInfo.set(X509CertInfo.SERIAL_NUMBER,
					new CertificateSerialNumber(serialNumber));

			// certificate X500 Subject
			X500Name appDN = new X500Name(app, "certificate", app
					+ ".anacom.pt", "PT");

			X500Name caDN = new X500Name(issuerName,
					"Certification Authority", "CA.anacom.pt", "PT");

			// certificate SIGNATURE
			Signature signature = Signature.getInstance("SHA1withRSA");
			signature.initSign(issuerPrivateKey);
			X500Signer issuer = new X500Signer(signature, caDN);

			certInfo.set(X509CertInfo.ISSUER,
					new CertificateIssuerName(issuer.getSigner()));

			// certificate Public key
			PublicKey pubKey = KeyFactory.getInstance("RSA").generatePublic(
					new X509EncodedKeySpec(pubKeyBytes));
			certInfo.set(X509CertInfo.KEY, new CertificateX509Key(pubKey));

			AlgorithmId algorithm = issuer.getAlgorithmId();
			certInfo.set(X509CertInfo.ALGORITHM_ID, new CertificateAlgorithmId(
					algorithm));

			CertificateSubjectName sub = new CertificateSubjectName(appDN);
			certInfo.set(X509CertInfo.SUBJECT, sub);

			X509CertImpl cert = new X509CertImpl(certInfo);

			cert.sign(issuerPrivateKey, signature.getAlgorithm());
			return cert;
	}
}
