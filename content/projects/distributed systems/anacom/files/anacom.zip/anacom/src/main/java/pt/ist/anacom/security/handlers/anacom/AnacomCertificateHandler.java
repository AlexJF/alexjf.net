package pt.ist.anacom.security.handlers.anacom;

import pt.ist.anacom.security.handlers.AbstractCertificateHandler;
import pt.ist.anacom.security.managers.AbstractSecurityManager;
import pt.ist.anacom.security.managers.AnacomSecurityManager;

/**
 * This handler is used by all entities from the Anacom domain,
 * and uses the Anacom Security Manager.
 */
public class AnacomCertificateHandler extends AbstractCertificateHandler {
    @Override
    protected AbstractSecurityManager getSecurityManager() {
        return AnacomSecurityManager.getInstance();
    }
}
