package pt.ist.anacom.security.handlers;

import java.io.StringWriter;
import java.security.PrivateKey;
import java.security.PublicKey;

import java.util.ArrayList;

import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;

import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;

import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;

import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import javax.xml.transform.dom.DOMSource;

import javax.xml.transform.OutputKeys;

import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.Source;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;

import pt.ist.anacom.security.managers.AbstractSecurityManager;

import sun.security.x509.X509CertImpl;

public abstract class AbstractDigestHandler extends AbstractHandler {

    @Override
	protected boolean handleInboundMessage(SOAPMessage message) {
        System.out.println("Handling Inbound Message - Digest Handler");
		try {
            SOAPPart part = message.getSOAPPart();
            SOAPEnvelope envelope = part.getEnvelope();
			SOAPHeader header = getHeader(envelope);
			X509CertImpl cert = new X509CertImpl();
			
			Node certNode = getCertificateNode(header);
			
            // If there's no certificate on the message,
            // let it pass since if this was an error the
            // CertificateHandler would have caught it.
			if (certNode == null) {
                return true;
			}

            String certString = certNode.getTextContent();
            cert = new X509CertImpl(b64d.decodeBuffer(certString));
            header.removeChild(certNode);
			
            //System.out.println(nodeToString(part));
            if (verifyXML(part, cert.getPublicKey())) {
                // Re add the certificate to the header since it is used by the UUID handler
                header.appendChild(certNode);
                return true;
            }
		} catch (Exception e) {
			e.printStackTrace();
		}
        return false;
	}

    @Override
	protected boolean handleOutboundMessage(SOAPMessage message) {
        System.out.println("Handling Outbound Message - Digest Handler");
		try {
            SOAPPart part = message.getSOAPPart();
            signXML(part, getSecurityManager().getPrivateKey());
            //System.out.println(nodeToString(part));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
    
    /**
     * Transform a node in xml to a string.
     * @param node Node to transform
     * @return String with the node.
     */
    public String nodeToString(Node node) {
        StringWriter sw = new StringWriter();
        try {
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            t.transform(new DOMSource(node), new StreamResult(sw));
        } catch (TransformerException te) {
            System.out.println("nodeToString Transformer Exception");
        }
        return sw.toString();
    }

    protected abstract AbstractSecurityManager getSecurityManager();
    
    /**
     * Returns the root node from a certain SOAP Part.
     * @param soapPart SOAP Part containing the node to extract.
     * @return The root node from the given SOAP Part.
     * @throws Exception
     */
    private Node getRootNode(SOAPPart soapPart) throws Exception {
        getHeader(soapPart.getEnvelope());
        Source source = soapPart.getContent();
        org.w3c.dom.Node root = null;

        if (source instanceof DOMSource) {
            root = ((DOMSource)source).getNode();
        } else if (source instanceof SAXSource) {
            InputSource inSource = ((SAXSource)source).getInputSource();
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            DocumentBuilder db = null;

            synchronized (dbf) {
            db = dbf.newDocumentBuilder();
            }

            Document doc = db.parse(inSource);
            root = (org.w3c.dom.Node) doc.getDocumentElement();
        } else {
            throw new Exception("Cannot convert SOAP message (" + source.getClass().getName() + ") into a W3C DOM tree");
        }

        return root;
    }
    
    /**
     * Signs a given SOAP Part, including all the xml, with the given 
     * private key.
     * @param soapPart SOAP Part to sign.
     * @param ks PrivateKey to sign.
     */
    public void signXML(SOAPPart soapPart, PrivateKey ks) {
        try {
            Node root = getRootNode(soapPart);
            Node envelope = root.getFirstChild();
            Node header = envelope.getFirstChild();
            
            // We assemble the different parts of the Signature element into an 
            // XMLSignature object
            XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");
            
            // We then invoke various factory methods to create the different
            // parts of the XMLSignature.
            
            // The DigestMethod (we use SHA1)
            DigestMethod digestMethod = fac.newDigestMethod(DigestMethod.SHA1, null);
            
            // The CanonicalizationMethod (we use inclusive and preserve comments)
            // to use a standard from on XML.
            CanonicalizationMethod cm = fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE_WITH_COMMENTS, (C14NMethodParameterSpec) null);
            
            // The SignatureMethod (we use RSA).
            SignatureMethod sm = fac.newSignatureMethod(SignatureMethod.RSA_SHA1, null);
            
            // A single Transform, the enveloped Transform, which is required for enveloped 
            // signatures so that the signature itself is removed before calculating the
            // signature value.
            ArrayList<Transform> transformList = new ArrayList<Transform>();
            TransformParameterSpec transformSpec = null;
            Transform exc14nTransform = fac.newTransform(Transform.ENVELOPED, transformSpec);
            transformList.add(exc14nTransform);
            
            Reference ref = fac.newReference("", digestMethod, transformList, null, null);
            ArrayList<Reference> refList = new ArrayList<Reference>();
            refList.add(ref);
            
            // KeyInfo object, which contains information that enables the recipient 
            // to find the key needed to validate the signature.
            SignedInfo signedInfo =fac.newSignedInfo(cm, sm, refList);
            
            // XMLSignContext contains input parameters for generating the signature
            DOMSignContext signContext = new DOMSignContext(ks, header);
            
            // Creates an object signature
            XMLSignature signature = fac.newXMLSignature(signedInfo, null);
            
            signature.sign(signContext);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
    }
    
    /**
     * Verifies if the signature contained in the SOAP Part is valid according to 
     * the SOAP Part and the public key provided.
     * @param soapPart SOAP Part to verify.
     * @param kp Public key to use in verification.
     * @return Returns the value of verification.
     */
    public boolean verifyXML(SOAPPart soapPart, PublicKey kp) {
        try {
            NodeList nl = soapPart.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
            if (nl.getLength() == 0) {
              throw new Exception("Cannot find Signature element");
            } 
            DOMValidateContext validationContext = new DOMValidateContext(kp, nl.item(0));
            XMLSignatureFactory signatureFactory = XMLSignatureFactory.getInstance("DOM");
            XMLSignature signature = signatureFactory.unmarshalXMLSignature(validationContext);
            boolean isValid = signature.validate(validationContext);
            if (isValid) {
                System.out.println("Digest passed with distinction");
            } else {
                System.out.println("Digest verification failed");
            }

            return isValid;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    protected String getFaultString(boolean incoming) {
        if (incoming) {
            return "Incoming digest not valid";
        } else {
            return "Unable to add digest to outgoing message";
        }
    }
}
