package pt.ist.anacom.security.handlers.anacom;

import pt.ist.anacom.security.handlers.AbstractDigestHandler;
import pt.ist.anacom.security.managers.AnacomSecurityManager;

/**
 * This handler is used by all entities from the Anacom domain,
 * and uses the Anacom Security Manager.
 */
public class AnacomDigestHandler extends AbstractDigestHandler {
    @Override
    protected pt.ist.anacom.security.managers.AbstractSecurityManager getSecurityManager() {
        return AnacomSecurityManager.getInstance();
    }
}
