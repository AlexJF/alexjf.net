package pt.ist.anacom.shared.dto;

/**
 * This Dto allows to transport simple information about
 * a network operator.
 */
public class NetworkOperatorSimpleDto extends AnacomDto {

	private static final long serialVersionUID = 1L;
	
	/** Name of the Operator */
	private String _name;

	/**
	 * Creates a new network operator with given information.
	 * 
	 * @param name
	 *            New network operator's name
	 */
	public NetworkOperatorSimpleDto(String name) {
		_name = name;
	}

	/**
	 * Obtain network operator's name.
	 * 
	 * @return A String with network operator's name.
	 */
	public String getName() {
		return _name;
	}
	
	/**
	 * Compares two instances of NetworkOperatorSimpleDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof NetworkOperatorSimpleDto))
			return false;

		NetworkOperatorSimpleDto dto = (NetworkOperatorSimpleDto) obj;

		return getName().equals(dto.getName());
	}

}
