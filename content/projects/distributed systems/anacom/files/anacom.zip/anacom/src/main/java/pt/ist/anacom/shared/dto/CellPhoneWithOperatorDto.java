package pt.ist.anacom.shared.dto;

public class CellPhoneWithOperatorDto extends CellPhoneSimpleDto {
	static final long serialVersionUID = 1L;

	/** Operator Name */
	private String _operatorName;

	/**
	 * Constructs a CellPhoneWithOperatorDto
	 */
	public CellPhoneWithOperatorDto() {
		super();
	}

	/**
	 * Creates a new CellPhoneWithOperatorDto.
	 * 
	 * @param operatorName
	 *            The name of the operator associated with this cellphone.
	 * @param phoneNumber
	 *            The number of the cellphone this dto represents.
	 */
	public CellPhoneWithOperatorDto(String operatorName, String phoneNumber) {
		super(phoneNumber);
		_operatorName = operatorName;
	}

	/**
	 * Retrieve the name of the operator associated with this cellphone.
	 * 
	 * @return Name of the operator associated with this cellphone.
	 */
	public String getOperatorName() {
		return _operatorName;
	}
	
	/**
	 * Compares two instances of CellPhoneWithOperatorDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof CallWithDurationDto))
			return false;

		CellPhoneWithOperatorDto dto = (CellPhoneWithOperatorDto) obj;

		return getOperatorName().equals(dto.getOperatorName());
	}
}
