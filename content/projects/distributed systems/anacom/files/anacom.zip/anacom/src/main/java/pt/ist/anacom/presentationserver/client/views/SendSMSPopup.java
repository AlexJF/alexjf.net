package pt.ist.anacom.presentationserver.client.views;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;

import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.TextArea;

import com.google.gwt.user.client.ui.TextBox;

import pt.ist.anacom.presentationserver.client.Anacom;

public class SendSMSPopup extends DialogBox {
	final TextBox txtDestinationNumber = new TextBox();
	final TextArea txtMessage = new TextArea();

	public SendSMSPopup(final Anacom parent) {
		super();

		setText("Send SMS");
		setGlassEnabled(true);
		setAnimationEnabled(true);

		txtMessage.setCharacterWidth(40);
		txtMessage.setVisibleLines(4);

		FlexTable dataTable = new FlexTable();

		setWidget(dataTable);

		dataTable.setHTML(0, 0, "Destination Number:");
		dataTable.setWidget(0, 1, txtDestinationNumber);

		dataTable.setHTML(1, 0, "Message:");
		dataTable.setWidget(1, 1, txtMessage);

		Button btnRegister = new Button("Send", new ClickHandler() {
			public void onClick(ClickEvent event) {
				parent.sendSMS(txtDestinationNumber.getText(),
						txtMessage.getText());
				hide();
			}
		});

		Button btnCancel = new Button("Cancel", new ClickHandler() {
			public void onClick(ClickEvent event) {
				hide();
			}
		});

		dataTable.setWidget(4, 0, btnRegister);
		dataTable.setWidget(4, 1, btnCancel);
	}

	@Override
	public void show() {
		txtDestinationNumber.setText("");
		txtMessage.setText("");
		super.show();
	}
}
