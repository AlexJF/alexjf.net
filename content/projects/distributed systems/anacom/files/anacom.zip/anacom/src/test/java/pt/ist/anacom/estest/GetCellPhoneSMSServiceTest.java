package pt.ist.anacom.estest;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.service.GetCellPhoneSMSService;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.dto.SMSDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;

public class GetCellPhoneSMSServiceTest extends AnacomTestCase {

	private static String OPERATOR_NAME = "WOW";
	private static String OPERATOR_PREFIX = "86";
	private static int OPERATOR_VOICE_COST = 10;
	private static int OPERATOR_VIDEO_COST = 30;
	private static int OPERATOR_SMS_COST = 6;
	private static BigDecimal OPERATOR_TAX = new BigDecimal(1.5);

	private static String CELL_NUMBER = "866711094";
	private static String CELL_NUMBER_NO_MESSAGE = "866711074";
	private static String NONEXISTING_CELL_NUMBER = "860000000";
	private static int CELL_BALANCE = 90;
	private static String CELL_NUMBER_OTHER = "863411094";

	private CellPhone phone;

	private static int NUMBER_OF_RECEIVED_SMS = 2;
	private static String SMALL_SMS_IN = "Hello! How are you doing?";
	private static String SMALL_SMS_IN2 = "Hello! Not bad!";
	private static String SMALL_SMS_OUT = "NICE!";

	public GetCellPhoneSMSServiceTest() {
	}

	@Override
	public void setUp() {
		super.setUp();

		NetworkOperator operator = addOperator(OPERATOR_NAME, OPERATOR_PREFIX,
				OPERATOR_VOICE_COST, OPERATOR_VIDEO_COST, OPERATOR_SMS_COST,
				OPERATOR_TAX);

		phone = addCellPhone2G(operator, CELL_NUMBER, CELL_BALANCE);
		addCellPhone2G(operator, CELL_NUMBER_OTHER, CELL_BALANCE);
		addCellPhone2G(operator, CELL_NUMBER_NO_MESSAGE, CELL_BALANCE);

		addIncomingSMS(phone, CELL_NUMBER_OTHER, SMALL_SMS_IN);
		addIncomingSMS(phone, CELL_NUMBER_OTHER, SMALL_SMS_IN2);
		addOutgoingSMS(phone, CELL_NUMBER_OTHER, SMALL_SMS_OUT);
	}

	public void testCorrectMessages() {
		// Arrange
		CellPhoneSimpleDto dto = new CellPhoneSimpleDto(CELL_NUMBER);
		GetCellPhoneSMSService service = new GetCellPhoneSMSService(dto);

		List<SMSDto> expected = new LinkedList<SMSDto>();
		expected.add(new SMSDto(CELL_NUMBER_OTHER, CELL_NUMBER, SMALL_SMS_IN));
		expected.add(new SMSDto(CELL_NUMBER_OTHER, CELL_NUMBER, SMALL_SMS_IN2));

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("List sms should be successful, all fields were correct");
		}

		// Assert
		ListCellPhoneSMSDto smsList = service.getCellPhonesSMS();

		assertEquals("The number of sms should be " + NUMBER_OF_RECEIVED_SMS
				+ ".", smsList.getCellPhonesSMS().size(),
				NUMBER_OF_RECEIVED_SMS);

		assertEquals("Messages data is different.", expected,
				smsList.getCellPhonesSMS());
	}

	public void testZeroMessages() {
		// Arrange
		CellPhoneSimpleDto dto = new CellPhoneSimpleDto(CELL_NUMBER_NO_MESSAGE);
		GetCellPhoneSMSService service = new GetCellPhoneSMSService(dto);

		List<SMSDto> expected = new LinkedList<SMSDto>();
		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("List sms should be successful, all fields were correct");
		}
		// Assert
		ListCellPhoneSMSDto smsList = service.getCellPhonesSMS();

		assertEquals("The number of sms should be " + NUMBER_OF_RECEIVED_SMS
				+ ".", smsList.getCellPhonesSMS().size(), 0);

		assertEquals("Messages data is different.", expected,
				smsList.getCellPhonesSMS());
	}

	public void testWithNonExistingCellPhone() {
		// Arrange
		CellPhoneSimpleDto dto = new CellPhoneSimpleDto(NONEXISTING_CELL_NUMBER);
		GetCellPhoneSMSService service = new GetCellPhoneSMSService(dto);

		List<SMSDto> expected = new LinkedList<SMSDto>();
		// Act
		try {
			service.execute();
			fail("List sms should be unsuccessful, cell phone does not exist.");
		} catch (CellPhoneNotExistsException e) {
			// if we get this exception everything is fine!
		} catch (AnacomException e) {
			fail("This kind of exception should not have been raised");
		}
		// Assert
		ListCellPhoneSMSDto smsList = service.getCellPhonesSMS();

		assertEquals("The number of sms should be " + 0 + ".", smsList
				.getCellPhonesSMS().size(), 0);

		assertEquals("Messages data is different.", expected,
				smsList.getCellPhonesSMS());
	}
}
