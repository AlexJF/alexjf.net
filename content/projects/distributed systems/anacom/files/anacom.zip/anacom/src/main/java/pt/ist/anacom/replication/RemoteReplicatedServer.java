package pt.ist.anacom.replication;

import pt.ist.anacom.caserver.CAServer;
import pt.ist.anacom.security.managers.AnacomSecurityManager;
import pt.ist.anacom.service.bridge.ApplicationServerBridge;
import pt.ist.anacom.service.bridge.RemoteOperator;
import pt.ist.anacom.shared.UDDIHelper;
import pt.ist.anacom.shared.dto.AnacomDto;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.dto.SMSDto;
import pt.ist.anacom.shared.exception.InvalidCellPhoneNumberException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;

public class RemoteReplicatedServer implements ApplicationServerBridge {
	
	private static int QUORUM_SIZE = 4;
	
	private PresentationReplicationManager _replicationManager;

    public RemoteReplicatedServer() {
        this(true);
    }

    public RemoteReplicatedServer(boolean activateSecurity) {
        if (activateSecurity) {
            initializeSecurity();
        }
        initializeUDDI();
        _replicationManager = getReplicationManager();
    }

	protected void initializeUDDI() {
        UDDIHelper uddi = UDDIHelper.getSingleton();
        uddi.startCacheManagement();
	}

    protected PresentationReplicationManager getReplicationManager() {
        return new PresentationReplicationManager(QUORUM_SIZE);
    }
	
	@Override
	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto) {
		
        PresentationServiceFunction<CellPhoneSimpleDto, BalanceDto> serviceFunction = 
        		new PresentationServiceFunction<CellPhoneSimpleDto, BalanceDto>() {
            @Override
            public BalanceDto execute(RemoteOperator operator, CellPhoneSimpleDto dto) {
                return operator.getCellPhoneBalance(dto);
            }
        };

        return _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getNumber()), 
        		dto, 
        		serviceFunction);
	}
	
	@Override
	public void registerCellPhone(CellPhoneDetailedDto dto) {
		
        PresentationServiceFunction<CellPhoneDetailedDto, AnacomDto> serviceFunction = 
        		new PresentationServiceFunction<CellPhoneDetailedDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, CellPhoneDetailedDto dto) {
                return operator.registerCellPhone(dto);
            }
        };

        _replicationManager.sendRequestToReplicas(
                dto.getOperatorName(), 
        		dto, 
        		serviceFunction);
	}

	@Override
	public void removeCellPhone(CellPhoneWithOperatorDto dto) {
		
        PresentationServiceFunction<CellPhoneWithOperatorDto, AnacomDto> serviceFunction = 
        		new PresentationServiceFunction<CellPhoneWithOperatorDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, CellPhoneWithOperatorDto dto) {
                return operator.removeCellPhone(dto);
            }
        };

        _replicationManager.sendRequestToReplicas(
                dto.getOperatorName(),
        		dto, 
        		serviceFunction);
	}

	@Override
	public void increaseCellPhoneBalance(ChangeCellPhoneBalanceDto dto) {
		
        PresentationServiceFunction<ChangeCellPhoneBalanceDto, AnacomDto> serviceFunction = 
        		new PresentationServiceFunction<ChangeCellPhoneBalanceDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, ChangeCellPhoneBalanceDto dto) {
                return operator.increaseCellPhoneBalance(dto);
            }
        };

        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getPhoneNumber()), 
        		dto, 
        		serviceFunction);
	}


	@Override
	public CellPhoneWithStateDto getCellPhoneState(CellPhoneSimpleDto dto) {
		
        PresentationServiceFunction<CellPhoneSimpleDto, CellPhoneWithStateDto> serviceFunction = 
        		new PresentationServiceFunction<CellPhoneSimpleDto, CellPhoneWithStateDto>() {
            @Override
            public CellPhoneWithStateDto execute(RemoteOperator operator, CellPhoneSimpleDto dto) {
                return operator.getCellPhoneState(dto);
            }
        };

        return _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getNumber()), 
        		dto, 
        		serviceFunction);
	}

	@Override
	public void sendSMS(SMSDto dto) {
        PresentationServiceFunction<SMSDto, AnacomDto> serviceFunction = 
        		new PresentationServiceFunction<SMSDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, SMSDto dto) {
                return operator.sendSMS(dto);
            }
        };

        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getSourceNumber()), 
        		dto, 
        		serviceFunction);

        PresentationServiceFunction<SMSDto, AnacomDto> serviceFunction2 = 
        		new PresentationServiceFunction<SMSDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, SMSDto dto) {
                return operator.receiveSMS(dto);
            }
        };

        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getDestinationNumber()), 
        		dto, 
        		serviceFunction2);
	}

	@Override
	public ListCellPhonesBalancesDto getCellPhonesBalances(
			NetworkOperatorSimpleDto dto) {
		
        PresentationServiceFunction<NetworkOperatorSimpleDto, ListCellPhonesBalancesDto> serviceFunction = 
        		new PresentationServiceFunction<NetworkOperatorSimpleDto, ListCellPhonesBalancesDto>() {
            @Override
            public ListCellPhonesBalancesDto execute(RemoteOperator operator, NetworkOperatorSimpleDto dto) {
                return operator.getCellPhonesBalances(dto);
            }
        };

        return _replicationManager.sendRequestToReplicas(
                dto.getName(), 
        		dto, 
        		serviceFunction);
	}

	@Override
	public ListCellPhoneSMSDto getCellPhoneSMS(CellPhoneSimpleDto dto) {
		
        PresentationServiceFunction<CellPhoneSimpleDto, ListCellPhoneSMSDto> serviceFunction = 
        		new PresentationServiceFunction<CellPhoneSimpleDto, ListCellPhoneSMSDto>() {
            @Override
            public ListCellPhoneSMSDto execute(RemoteOperator operator, CellPhoneSimpleDto dto) {
                return operator.getCellPhoneSMS(dto);
            }
        };

        return _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getNumber()), 
        		dto, 
        		serviceFunction);
	}

	@Override
	public void changeCellPhoneState(CellPhoneWithStateDto dto) {
		
        PresentationServiceFunction<CellPhoneWithStateDto, AnacomDto> serviceFunction = 
        		new PresentationServiceFunction<CellPhoneWithStateDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, CellPhoneWithStateDto dto) {
                return operator.changeCellPhoneState(dto);
            }
        };

        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getNumber()), 
        		dto, 
        		serviceFunction);
	}

	@Override
	public CommunicationDetailsDto getLastCommunicationDetails(
			CellPhoneSimpleDto dto) {
		
        PresentationServiceFunction<CellPhoneSimpleDto, CommunicationDetailsDto> serviceFunction = 
        		new PresentationServiceFunction<CellPhoneSimpleDto, CommunicationDetailsDto>() {
            @Override
            public CommunicationDetailsDto execute(RemoteOperator operator, CellPhoneSimpleDto dto) {
                return operator.getLastCommunicationDetails(dto);
            }
        };

        return _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getNumber()), 
        		dto, 
        		serviceFunction);

	}

	@Override
	public void establishVideoCall(CallDto dto) {
		
        PresentationServiceFunction<CallDto, AnacomDto> serviceFunctionEstablish = 
        		new PresentationServiceFunction<CallDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, CallDto dto) {
                return operator.establishVideoCommunication(dto);
            }
        };
		
        PresentationServiceFunction<CallDto, AnacomDto> serviceFunctionReceive = 
        		new PresentationServiceFunction<CallDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, CallDto dto) {
                return operator.receiveVideoCommunication(dto);
            }
        };
        
        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getDestinationNumber()), 
        		dto, 
        		serviceFunctionReceive);    
        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getSourceNumber()), 
        		dto, 
        		serviceFunctionEstablish);
	}

	@Override
	public void establishVoiceCall(CallDto dto) {
		
        PresentationServiceFunction<CallDto, AnacomDto> serviceFunctionEstablish = 
        		new PresentationServiceFunction<CallDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, CallDto dto) {
                return operator.establishVoiceCommunication(dto);
            }
        };
		
        PresentationServiceFunction<CallDto, AnacomDto> serviceFunctionReceive = 
        		new PresentationServiceFunction<CallDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, CallDto dto) {
                return operator.receiveVoiceCommunication(dto);
            }
        };

        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getDestinationNumber()), 
        		dto, 
        		serviceFunctionReceive);
        
        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getSourceNumber()), 
        		dto, 
        		serviceFunctionEstablish);
	}

	@Override
	public void terminateActiveCall(CallWithDurationDto dto) {
		
        PresentationServiceFunction<CallWithDurationDto, AnacomDto> serviceFunctionSource = 
        		new PresentationServiceFunction<CallWithDurationDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, CallWithDurationDto dto) {
                return operator.terminateActiveOutgoingCommunication(dto);
            }
        };
		
        PresentationServiceFunction<CallWithDurationDto, AnacomDto> serviceFunctionDestination = 
        		new PresentationServiceFunction<CallWithDurationDto, AnacomDto>() {
            @Override
            public AnacomDto execute(RemoteOperator operator, CallWithDurationDto dto) {
                return operator.terminateActiveIncomingCommunication(dto);
            }
        };
        
        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getSourceNumber()), 
        		dto, 
        		serviceFunctionSource);
        
        _replicationManager.sendRequestToReplicas(
                getOperatorNameFromPhoneNumber(dto.getDestinationNumber()), 
        		dto, 
        		serviceFunctionDestination);
	}

	@Override
	public void createNetworkOperator(NetworkOperatorDetailedDto dto) {
		throw new UnsupportedOperationException();
	}	

    public void testCommand(String operatorName, final String command) {
        _replicationManager.sendRequestToReplicas(operatorName, new AnacomDto(), 
            new PresentationServiceFunction<AnacomDto, AnacomDto>() {
                @Override
                public AnacomDto execute(RemoteOperator operator, AnacomDto dto) {
                    operator.testCommand(command);
                    AnacomDto resultdto = new AnacomDto();
                    resultdto.setTimestamp(0);
                    return resultdto;
                }
        });
    }

    protected String getOperatorNameFromPhoneNumber(String number) {
        if (number.length() < 2) {
			throw new InvalidCellPhoneNumberException(number,
					"Number has less than 2 digits. No prefix could be found");
        }

        String prefix = number.substring(0, 2);
        String operatorName = UDDIHelper.getSingleton().getOperatorNameFromPrefix(prefix);

        if (operatorName == null) {
            throw new OperatorNotExistsException("", prefix);
        }

        return operatorName;
    }
    
    protected void initializeSecurity() {
    	CAServer ca;
    	ca = UDDIHelper.getSingleton().getCA();
	    AnacomSecurityManager sm = AnacomSecurityManager.getInstance();
	    sm.setCA(ca);
		sm.setName("PS");
		sm.getNewCertificate();
    }
}
