package pt.ist.anacom.sdtest.stubs;

import javax.xml.soap.SOAPMessage;

import pt.ist.anacom.security.handlers.anacom.RequestIDOperatorServerHandler;

public class RequestIDOperatorServerHandlerTester extends
		RequestIDOperatorServerHandler {

    public boolean testHandleIncomingMessage(SOAPMessage message) {
        return handleInboundMessage(message);
    }

    public boolean testHandleOutgoingMessage(SOAPMessage message) {
        return handleOutboundMessage(message);
    }
}
