package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.Communication;
import pt.ist.anacom.domain.SMS;
import pt.ist.anacom.domain.Video;
import pt.ist.anacom.domain.Voice;
import pt.ist.anacom.shared.CommunicationVisitor;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto.CommunicationType;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.fenixframework.FenixFramework;

public class GetLastCommunicationDetailsService extends AnacomService {

	private CellPhoneSimpleDto _dto;
	private CommunicationDetailsDto _result;

	public GetLastCommunicationDetailsService(CellPhoneSimpleDto _dto) {
		this._dto = _dto;
	}

	@Override
	public void dispatch() throws CellPhoneNotExistsException {
		AnacomNetwork network = FenixFramework.getRoot();
		CellPhone cellPhone = network.getCellPhoneOrException(_dto.getNumber());
        LastCommVisitor visitor = this.new LastCommVisitor();

		Communication communication = cellPhone.getLastOutgoingCommunication();

		if (communication != null) {
			communication.accept(visitor);
		} else {
			_result = new CommunicationDetailsDto(
					CommunicationDetailsDto.NOPHONENUMBER,
					CommunicationDetailsDto.NOPHONENUMBER, 0, 0,
					CommunicationType.UNKNOWN);
		}
	}

	public final CommunicationDetailsDto getCommunicationDetails() {
		return _result;
	}

    private class LastCommVisitor extends CommunicationVisitor {
        /**
         * Implementation of the visit method for sms communication.
         */
        @Override
        public void visit(SMS sms) {
            _result = new CommunicationDetailsDto(sms.getSourceNumber(),
                    sms.getDestinationNumber(), sms.getCost(), sms.getData()
                            .length(), CommunicationType.SMS);
        }

        /**
         * Implementation of the visit method for voice communication.
         */
        @Override
        public void visit(Voice voice) {
            _result = new CommunicationDetailsDto(voice.getSourceNumber(),
                    voice.getDestinationNumber(), voice.getCost(),
                    voice.getDuration(), CommunicationType.VOICE);
        }

        /**
         * Implementation of the visit method for video communication.
         */
        @Override
        public void visit(Video video) {
            _result = new CommunicationDetailsDto(video.getSourceNumber(),
                    video.getDestinationNumber(), video.getCost(),
                    video.getDuration(), CommunicationType.VIDEO);
        }
    }
}
