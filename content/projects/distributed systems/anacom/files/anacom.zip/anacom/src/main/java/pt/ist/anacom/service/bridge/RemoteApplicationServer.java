package pt.ist.anacom.service.bridge;

import java.util.List;

import pt.ist.anacom.caserver.CAServer;
import pt.ist.anacom.security.managers.AnacomSecurityManager;
import pt.ist.anacom.shared.UDDIHelper;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.dto.SMSDto;
import pt.ist.anacom.shared.exception.InvalidCellPhoneNumberException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;

/**
 * This class implements an Application Server that only runs remotely.
 */
public class RemoteApplicationServer implements ApplicationServerBridge {
	/**
	 * The server of the operator registered in the Anacom Network.
	 */
	private RemoteOperator _operator = null;
    private Object _lock = new Object();

    public RemoteApplicationServer() {
        this(true);
    }
	
    /**
	 * Creates a new instance of a Remote Application Server for Anacom network.
	 */
	public RemoteApplicationServer(boolean initializeSecurity) {
        if (initializeSecurity) {
            initializeSecurity();
        }
        initializeUDDI();
	}

	@Override
	public void registerCellPhone(CellPhoneDetailedDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByName(dto.getOperatorName());
            _operator.registerCellPhone(dto);
        }
	}

	@Override
	public void removeCellPhone(CellPhoneWithOperatorDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByName(dto.getOperatorName());
            _operator.removeCellPhone(dto);
        }
	}

	@Override
	public void increaseCellPhoneBalance(ChangeCellPhoneBalanceDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getPhoneNumber());
            _operator.increaseCellPhoneBalance(dto);
        }
	}

	@Override
	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getNumber());
            return _operator.getCellPhoneBalance(dto);
        }
	}

	@Override
	public CellPhoneWithStateDto getCellPhoneState(CellPhoneSimpleDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getNumber());
            return _operator.getCellPhoneState(dto);
        }
	}

	@Override
	public void sendSMS(SMSDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getSourceNumber());
            _operator.sendSMS(dto);
            changeDestinationOperatorServerByPhoneNumber(dto
                    .getDestinationNumber());
            _operator.receiveSMS(dto);
        }
	}

	@Override
	public ListCellPhonesBalancesDto getCellPhonesBalances(NetworkOperatorSimpleDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByName(dto.getName());
            return _operator.getCellPhonesBalances(dto);
        }
	}

	@Override
	public ListCellPhoneSMSDto getCellPhoneSMS(CellPhoneSimpleDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getNumber());
            return _operator.getCellPhoneSMS(dto);
        }
	}

	@Override
	public void changeCellPhoneState(CellPhoneWithStateDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getNumber());
            _operator.changeCellPhoneState(dto);
        }
	}

	@Override
	public CommunicationDetailsDto getLastCommunicationDetails(CellPhoneSimpleDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getNumber());
            return _operator.getLastCommunicationDetails(dto);
        }
	}

	@Override
	public void establishVideoCall(CallDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getDestinationNumber());
            _operator.receiveVideoCommunication(dto);
            changeDestinationOperatorServerByPhoneNumber(dto.getSourceNumber());
            _operator.establishVideoCommunication(dto);
        }
	}

	@Override
	public void establishVoiceCall(CallDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getDestinationNumber());
            _operator.receiveVoiceCommunication(dto);
            changeDestinationOperatorServerByPhoneNumber(dto.getSourceNumber());
            _operator.establishVoiceCommunication(dto);
        }
	}

	@Override
	public void terminateActiveCall(CallWithDurationDto dto) {
        synchronized(_lock) {
            changeDestinationOperatorServerByPhoneNumber(dto.getSourceNumber());
            _operator.terminateActiveOutgoingCommunication(dto);
            changeDestinationOperatorServerByPhoneNumber(dto.getDestinationNumber());
            _operator.terminateActiveIncomingCommunication(dto);
        }
	}

	@Override
	public void createNetworkOperator(NetworkOperatorDetailedDto dto) {
		throw new UnsupportedOperationException();
	}

    public void testCommand(String command) {
        _operator.testCommand(command);
    }

	private void changeDestinationOperatorServerByName(String operatorName) {
        UDDIHelper uddi = UDDIHelper.getSingleton();
        List<RemoteOperator> operators = uddi.getRemoteOperatorsFromOperatorName(operatorName);

        if (operators == null || operators.size() == 0) {
            throw new OperatorNotExistsException(operatorName);
        }

        _operator = operators.get(0);
	}

	private void changeDestinationOperatorServerByPrefix(String operatorPrefix) {
        UDDIHelper uddi = UDDIHelper.getSingleton();
        String operatorName = uddi.getOperatorNameFromPrefix(operatorPrefix);

        if (operatorName == null) {
            throw new OperatorNotExistsException("", operatorPrefix);
        }

        System.out.println("Converted prefix '" + operatorPrefix + "' to operator name '" + operatorName + "'");

        changeDestinationOperatorServerByName(operatorName);
	}

	private void changeDestinationOperatorServerByPhoneNumber(String phoneNumber) {
		if (phoneNumber.length() < 2) {
			throw new InvalidCellPhoneNumberException(phoneNumber,
					"Number has less than 2 digits. No prefix could be found");
		}
		changeDestinationOperatorServerByPrefix(phoneNumber.substring(0, 2));
	}
	
	protected void initializeUDDI() {
        UDDIHelper uddi = UDDIHelper.getSingleton();
        uddi.startCacheManagement();
	}

    protected void initializeSecurity() {
    	CAServer ca;
	    AnacomSecurityManager sm = AnacomSecurityManager.getInstance();
    	ca = UDDIHelper.getSingleton().getCA();
	    sm.setCA(ca);
		sm.setName("PS");
		sm.getNewCertificate();
		System.out.println("Received new certificate");
    }
}
