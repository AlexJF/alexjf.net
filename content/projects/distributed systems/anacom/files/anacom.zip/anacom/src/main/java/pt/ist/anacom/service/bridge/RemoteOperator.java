package pt.ist.anacom.service.bridge;

import pt.ist.anacom.shared.dto.AnacomDto;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.dto.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.dto.SMSDto;

public interface RemoteOperator {
	public AnacomDto registerCellPhone(CellPhoneDetailedDto dto);
	public AnacomDto removeCellPhone(CellPhoneWithOperatorDto dto);
	public AnacomDto increaseCellPhoneBalance(ChangeCellPhoneBalanceDto dto);
	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto);
	public CellPhoneWithStateDto getCellPhoneState(CellPhoneSimpleDto dto);
	public AnacomDto sendSMS(SMSDto dto);
    public AnacomDto receiveSMS(SMSDto dto);
	public ListCellPhonesBalancesDto getCellPhonesBalances(NetworkOperatorSimpleDto dto);
	public ListCellPhoneSMSDto getCellPhoneSMS(CellPhoneSimpleDto dto);
	public AnacomDto changeCellPhoneState(CellPhoneWithStateDto dto);
	public CommunicationDetailsDto getLastCommunicationDetails(CellPhoneSimpleDto dto);
	public AnacomDto establishVideoCommunication(CallDto dto);
	public AnacomDto receiveVideoCommunication(CallDto dto);
	public AnacomDto establishVoiceCommunication(CallDto dto);
	public AnacomDto receiveVoiceCommunication(CallDto dto);
	public AnacomDto terminateActiveOutgoingCommunication(CallWithDurationDto dto);
	public AnacomDto terminateActiveIncomingCommunication(CallWithDurationDto dto);
    public AnacomDto getTimestamp(AnacomDto dto);
	public AnacomDto createNetworkOperator(NetworkOperatorDetailedDto dto);
    public void testCommand(String command);
    public String getName();
    public String getPrefix();
    public String getReplicaNumber();
    public String getUrl();
    public void setName(String name);
    public void setPrefix(String prefix);
    public void setReplicaNumber(String replicaNumber);
    public void setUrl(String url);
}

