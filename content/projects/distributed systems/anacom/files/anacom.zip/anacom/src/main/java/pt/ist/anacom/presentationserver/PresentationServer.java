package pt.ist.anacom.presentationserver;

import java.math.BigDecimal;

import pt.ist.anacom.replication.RemoteReplicatedServer;
import pt.ist.anacom.service.bridge.ApplicationServerBridge;
import pt.ist.anacom.service.bridge.LocalApplicationServer;
import pt.ist.anacom.service.bridge.RemoteApplicationServer;

import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.UDDIHelper;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto.CellPhoneStates;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.dto.SMSDto;

/**
 * This class implements the presentation server.
 */
public class PresentationServer {

	private static ApplicationServerBridge _serviceBridge = null;

	public static enum ProjectType {
		ES, ESSD, ESSDREP, ESSDSEC, ESSDREPSEC
	};

	public static void main(String[] args) {
		PresentationServer ps;
		if (args.length == 0 || args[0].equalsIgnoreCase("es")) {
			ps = new PresentationServer(ProjectType.ES);
			ps.createNetworkOperatorCommand("Vodafona", "91", 5, 20, 40,
					new BigDecimal("1.5"), new BigDecimal("0"));
		} 
        else if (args[0].equalsIgnoreCase("essd")) {
			ps = new PresentationServer(ProjectType.ESSD);
		} 
        else if (args[0].equalsIgnoreCase("essd-replicated")) {
            ps = new PresentationServer(ProjectType.ESSDREP);
        }
        else if (args[0].equalsIgnoreCase("essd-security")) {
            ps = new PresentationServer(ProjectType.ESSDSEC);
        } 
        else {
            ps = new PresentationServer(ProjectType.ESSDREPSEC);
        }

        System.out.println("\t1. Creating cellphone 912595153 in Vodafona");
        try {
		ps.createCellPhoneCommand("Vodafona", "912595153",
				CellPhoneDetailedDto.CellPhoneType.TwoG, 1000);
        } catch (AnacomException e) {
            System.out.println("\t" + e.getMessage());
        }
        System.out.println("\tCreation OK!");

        System.out.println("");

        System.out.println("\t2. Creating cellphone 912223344 in Void (does not exist!)");
        try {
            ps.createCellPhoneCommand("Void", "932223344", CellPhoneDetailedDto.CellPhoneType.TwoG, 1000);
        } catch (AnacomException e) {
            System.out.println("\t" + e.getMessage());
        }

        System.out.println("");

        System.out.println("\t3. Creating cellphone 912223344");
        try {
            ps.createCellPhoneCommand("Vodafona", "912223344", CellPhoneDetailedDto.CellPhoneType.TwoG, 1000);
        } catch (AnacomException e) {
            System.out.println("\t" + e.getMessage());
        }
        System.out.println("\tCreation OK!");

        System.out.println("");

        System.out.println("\t4. Setting state to ON in 912595153");
        try {
            ps.changeCellPhoneStateCommand("912595153", CellPhoneStates.On);
        } catch (AnacomException e) {
            System.out.println("\t" + e.getMessage());
        }
        System.out.println("\tSet OK!");

        System.out.println("");

        System.out.println("\t5. Setting state to ON in 912223344");
        try {
            ps.changeCellPhoneStateCommand("912223344", CellPhoneStates.On);
        } catch (AnacomException e) {
            System.out.println("\t" + e.getMessage());
        }
        System.out.println("\tSet OK!");
        
        System.out.println("");

        System.out.println("\t6. List cellphones in Vodafona");
        try {
            ps.listCellPhonesCommand("Vodafona");
        } catch (AnacomException e) {
            System.out.println("\t" + e.getMessage());
        }

        System.out.println("");
        System.out.println("");

        UDDIHelper.getSingleton().printCacheInfo();
	}

	public PresentationServer(ProjectType type) {
		if (type == ProjectType.ES) {
			_serviceBridge = new LocalApplicationServer();
		} 
        else if (type == ProjectType.ESSD) {
			_serviceBridge = new RemoteApplicationServer(false);
        } 
        else if (type == ProjectType.ESSDREP) {
			_serviceBridge = new RemoteReplicatedServer(false);
        } 
        else if (type == ProjectType.ESSDSEC) {
			_serviceBridge = new RemoteApplicationServer();
        } 
        else {
			_serviceBridge = new RemoteReplicatedServer();
		}
	}

	/**
	 * Command to create a network operator.
	 * 
	 * @param name
	 *            of the operator
	 * @param prefix
	 *            of the operator
	 * @param costSMS
	 *            cost of a sms
	 * @param costVoice
	 *            cost of a voice communication
	 * @param costVideo
	 *            cost of a video communication
	 * @param tax
	 *            to apply between different network operators
	 * @param bonus
	 * 			  applied on balance increase.           
	 */
	public void createNetworkOperatorCommand(String name, String prefix,
			int costSMS, int costVoice, int costVideo, BigDecimal tax, BigDecimal bonus) {
        NetworkOperatorDetailedDto dto = new NetworkOperatorDetailedDto(
                name, prefix, costSMS, costVoice, costVideo, tax, bonus);
        _serviceBridge.createNetworkOperator(dto);
	}

	/**
	 * Command to create a CellPhone.
	 * 
	 * @param operatorName
	 *            of the CellPhone
	 * @param number
	 *            of the CellPhone
	 * @param type
	 *            of the CellPhone
	 * @param balance
	 *            of the CellPhone
	 * @return
	 */
	public void createCellPhoneCommand(String operatorName, String number,
        CellPhoneDetailedDto.CellPhoneType type, int balance) {
        CellPhoneDetailedDto dto = new CellPhoneDetailedDto(operatorName,
                number, type, balance);

        _serviceBridge.registerCellPhone(dto);
	}

	/**
	 * Command to list all CellPhones of an operator.
	 * 
	 * @param operator
	 *            operator whose CellPhone we want to list
	 */
	public void listCellPhonesCommand(String operator) {
        NetworkOperatorSimpleDto operatorDto = new NetworkOperatorSimpleDto(
                operator);
        ListCellPhonesBalancesDto cellsBalances = _serviceBridge
                .getCellPhonesBalances(operatorDto);
        for (BalanceDto balance : cellsBalances.getCellPhonesBalances()) {
            System.out.println("\t" + balance.getPhoneNumber() + " ("
                    + balance.getBalance() + ")");
        }
	}

	/**
	 * Command to send an sms.
	 * 
	 * @param sourceCellPhoneNumber
	 *            Number of the source CellPhone
	 * @param destinationCellPhoneNumber
	 *            Number of the destination CellPhone
	 * @param message
	 *            to sent
	 */
	public void sendSMSCommand(String sourceCellPhoneNumber, String destinationCellPhoneNumber, String message) {
        SMSDto dto = new SMSDto(sourceCellPhoneNumber, destinationCellPhoneNumber,message);
        _serviceBridge.sendSMS(dto);
	}

	/**
	 * Command to get the balance of a CellPhone
	 * 
	 * @param number
	 *            of the CellPhone whose balance we want to get
	 * @return the balance of the CellPhone
	 */
	public int getCellPhoneBalanceCommand(String number) {
        CellPhoneSimpleDto dto = new CellPhoneSimpleDto(number);

        BalanceDto balanceDto = _serviceBridge.getCellPhoneBalance(dto);
        return balanceDto.getBalance();
	}

	/**
	 * Command to get the last communication details of a CellPhone
	 * 
	 * @param number
	 *            of the CellPhone whose last communication details we want to get
	 * @return the last communication details of the CellPhone
	 */
	public void CommunicationDetailsCommand(String number) {
        CellPhoneSimpleDto dto = new CellPhoneSimpleDto(number);

        CommunicationDetailsDto communicationDetailsDto = _serviceBridge.getLastCommunicationDetails(dto);
        System.out.println(communicationDetailsDto.getDestinationNumber() + " (" + communicationDetailsDto.getCost() + ", " + communicationDetailsDto.getSize());
	}
	/**
	 * Command to get the state of a CellPhone
	 * 
	 * @param number
	 *            of the CellPhone whose state we want to get
	 * @return the state of the CellPhone
	 */
	public CellPhoneStates getCellPhoneStateCommand(String number) {
        CellPhoneSimpleDto dto = new CellPhoneSimpleDto(number);

        CellPhoneWithStateDto stateDto = _serviceBridge
                .getCellPhoneState(dto);
        return stateDto.getState();
	}

	/**
	 * Command to change the state of a CellPhone
	 * 
	 * @param number
	 *            of the CellPhone whose state we want to get
	 * @param state
	 *            to which we want to change
	 */
	public void changeCellPhoneStateCommand(String number, CellPhoneStates state) {
		CellPhoneWithStateDto dto = new CellPhoneWithStateDto(number, state);
        _serviceBridge.changeCellPhoneState(dto);
	}

	/**
	 * Command to increase the balance of a CellPhone.
	 * 
	 * @param number
	 *            of the CellPhone we want to increase
	 * @param amount
	 *            by which we want to increase the balance of the CellPhone
	 */
	public void increaseCellPhoneBalanceCommand(String number, int amount) {
        ChangeCellPhoneBalanceDto dto = new ChangeCellPhoneBalanceDto(number, amount);
        _serviceBridge.increaseCellPhoneBalance(dto);
	}
}
