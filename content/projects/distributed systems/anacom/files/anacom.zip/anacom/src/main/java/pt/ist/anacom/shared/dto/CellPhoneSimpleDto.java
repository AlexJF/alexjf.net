package pt.ist.anacom.shared.dto;

public class CellPhoneSimpleDto extends AnacomDto {
	static final long serialVersionUID = 1L;

	/** The CellPhone's number */
	private String _number;

	public CellPhoneSimpleDto() {
	}

	/**
	 * Creates a new CellPhoneSimpleDto.
	 * 
	 * @param phoneNumber
	 *            The number of the cellphone.
	 */
	public CellPhoneSimpleDto(String phoneNumber) {
		_number = phoneNumber;
	}

	/**
	 * Retrieves the cellphone's number.
	 * 
	 * @return The cellphone's number.
	 */
	public String getNumber() {
		return _number;
	}

	/**
	 * Sets the cellphone's number.
	 * 
	 * @param number of the cellphone.
	 */
	public void setNumber(String number) {
		_number = number;
	}
	
	/**
	 * Compares two instances of CellPhoneSimpleDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof CellPhoneSimpleDto))
			return false;

		CellPhoneSimpleDto dto = (CellPhoneSimpleDto) obj;

		return getNumber().equals(dto.getNumber());
	}
}
