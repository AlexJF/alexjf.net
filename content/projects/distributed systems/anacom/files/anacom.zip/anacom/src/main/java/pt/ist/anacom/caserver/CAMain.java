package pt.ist.anacom.caserver;

import pt.ist.anacom.security.managers.AnacomSecurityManager;

import pt.ist.anacom.shared.UDDIHelper;

public class CAMain {
    public static void main(String[] args) {
        String command = "clear";

        if (args.length > 0) {
            command = args[0];
        }

        CAServer ca = UDDIHelper.getSingleton().getCA();

	    AnacomSecurityManager sm = AnacomSecurityManager.getInstance();
        sm.setName("PS");
	    sm.setCA(ca);
        
        ca.testCommand(command);
    }
}
