package pt.ist.anacom.domain;

import java.math.BigDecimal;

import java.util.List;
import java.util.ListIterator;

import pt.ist.anacom.shared.CommunicationVisitor;

import pt.ist.anacom.shared.exception.BalanceChangeException;
import pt.ist.anacom.shared.exception.HigherThanMaxBalanceException;
import pt.ist.anacom.shared.exception.InvalidCellPhoneNumberException;
import pt.ist.anacom.shared.exception.NegativeBalanceException;

/**
 * This class represents a generic CellPhone. A CellPhone belongs to a network
 * operator, has a 9 digit number and can receive and establish communications.
 */
public abstract class CellPhone extends CellPhone_Base {

    public static final int MAXBALANCE = 10000;

    /**
     * Initializes the cellphone's main attributes with the provided arguments.
     * 
     * This function should be used by all inheriting classes' constructors.
     * 
     * @param number
     *            The cellphone's number.
     * @param balance
     *            The cellphone's balance.
     * 
     * @throws InvalidCellPhoneNumberException
     *             If the number doesn't have exactly 9 digits.
     */
    protected void init(String number, int balance) {
        if (!number.matches("\\d{9}")) {
            throw new InvalidCellPhoneNumberException(number,
                    "Number doesn't have exactly 9 digits.");
        }

        setNumber(number);
        setCellPhoneState(new CellPhoneOffState());
        setBalance(balance);
    }

    /**
     * Returns the prefix associated with this cellphone's number.
     * 
     * @return A 2-digit prefix obtained from this cellphone's number.
     */
    public String getPrefix() {
        return getPrefixFromNumber(getNumber());
    }

    /**
     * Decreases the cellphone balance by cost.
     * 
     * @param cost
     *            The value (in cents) that the balance should be decreased.
     * 
     * @throws BalanceChangeException
     *             If the provided argument is negative.
     */
    public void decreaseBalance(int cost) {
        if (cost < 0) {
            throw new BalanceChangeException(cost,
                    "Cannot decrease balance by a negative value.");
        }
        setBalance(getBalance() - cost);
    }

    /**
     * Increases the cellphone balance by amount.
     * 
     * @param amount
     *            The value (in cents) that the balance should be increased.
     * 
     * @throws BalanceChangeException
     *             If the provided argument is negative.
     */
    public void increaseBalance(int amount) {
        if (amount < 0) {
            throw new BalanceChangeException(amount,
                    "Cannot increase balance by a negative value.");
        }
        setBalance(getBalance() + amount);
    }

    /**
     * Overriden to prevent direct calling.
     * 
     * Use on of: - addIncomingCommunication(SMS) -
     * addIncomingCommunication(Voice) - addIncomingCommunication(Video)
     * 
     * @throws UnsupportedOperationException
     *             always.
     */
    @Override
    public void addIncomingCommunication(Communication comm) {
        throw new UnsupportedOperationException();
    }

    /**
     * Adds an incoming sms communication to the incoming communication list.
     * 
     * @param comm
     *            The sms communication to add.
     * @throws IncomingCommunicationException
     *             If the cellphone cannot handle the given incoming
     *             communication.
     */
    public void addIncomingCommunication(SMS comm) {
        getCellPhoneState().handleIncomingCommunication(comm);
        super.addIncomingCommunication(comm);
    }

    /**
     * Adds an incoming voice communication to the incoming communication list.
     * 
     * @param comm
     *            The voice communication to add.
     * @throws IncomingCommunicationException
     *             If the cellphone cannot handle the given incoming
     *             communication.
     */
    public void addIncomingCommunication(Voice comm) {
        getCellPhoneState().handleIncomingCommunication(comm);
        setCellPhoneState(new CellPhoneBusyState());
        super.addIncomingCommunication(comm);
    }

    /**
     * Adds an incoming video communication to the incoming communication list.
     * 
     * @param comm
     *            The video communication to add.
     * @throws IncomingCommunicationException
     *             If the cellphone cannot handle the given incoming
     *             communication.
     */
    public void addIncomingCommunication(Video comm) {
        getCellPhoneState().handleIncomingCommunication(comm);
        setCellPhoneState(new CellPhoneBusyState());
        super.addIncomingCommunication(comm);
    }

    /**
     * Overriden to prevent direct calling.
     * 
     * Use on of: - addOutgoingCommunication(SMS) -
     * addOutgoingCommunication(Voice) - addOutgoingCommunication(Video)
     * 
     * @throws UnsupportedOperationException
     *             always.
     */
    @Override
    public void addOutgoingCommunication(Communication comm) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void setCellPhoneState(CellPhoneState cellPhoneState) {
        setPreviousCellPhoneState(getCellPhoneState());
        super.setCellPhoneState(cellPhoneState);
    }

    /**
     * Ensures that the cellphone has a positive balance.
     * 
     * @throws NegativeBalanceException
     *             if the cellphone has negative balance.
     */
    protected void ensurePositiveBalance() {
        if (getBalance() <= 0) {
            throw new NegativeBalanceException(getNumber(), getBalance());
        }
    }

    /**
     * Adds an outgoing sms communication to the outgoing communication list.
     * 
     * @param comm
     *            The sms communication to add.
     * @throws OutgoingCommunicationException
     *             If the cellphone cannot handle the given outgoing
     *             communication.
     */
    public void addOutgoingCommunication(SMS comm) {
        ensurePositiveBalance();
        getCellPhoneState().handleOutgoingCommunication(comm);
        setLastOutgoingCommunication(comm);
        super.addOutgoingCommunication(comm);
    }

    /**
     * Adds an outgoing voice communication to the outgoing communication list.
     * 
     * @param comm
     *            The voice communication to add.
     * @throws OutgoingCommunicationException
     *             If the cellphone cannot handle the given outgoing
     *             communication.
     */
    public void addOutgoingCommunication(Voice comm) {
        ensurePositiveBalance();
        getCellPhoneState().handleOutgoingCommunication(comm);
        setCellPhoneState(new CellPhoneBusyState());
        setLastOutgoingCommunication(comm);
        super.addOutgoingCommunication(comm);
    }

    /**
     * Adds an outgoing video communication to the outgoing communication list.
     * 
     * @param comm
     *            The video communication to add.
     * @throws OutgoingCommunicationException
     *             If the cellphone cannot handle the given outgoing
     *             communication.
     */
    public void addOutgoingCommunication(Video comm) {
        ensurePositiveBalance();
        getCellPhoneState().handleOutgoingCommunication(comm);
        setCellPhoneState(new CellPhoneBusyState());
        setLastOutgoingCommunication(comm);
        super.addOutgoingCommunication(comm);
    }

    /**
     * Gets the currently active communication.
     * @return An instance of Communication representing the communication currently active.
     */
    public NonImmediateCommunication getActiveCommunication() {
        List<Communication> outgoing = getOutgoingCommunication();
        List<Communication> incoming = getIncomingCommunication();
        ActiveCommunicationVisitor visitor = new ActiveCommunicationVisitor();

        ListIterator<Communication> iterator = outgoing.listIterator(outgoing.size());
        while (iterator.hasPrevious()) {
            Communication comm = iterator.previous();
            comm.accept(visitor);

            NonImmediateCommunication nonImmedComm = visitor.getActiveCommunication();
            if (nonImmedComm != null) {
                return nonImmedComm;
            }
        }

        iterator = incoming.listIterator(incoming.size());
        while (iterator.hasPrevious()) {
            Communication comm = iterator.previous();
            comm.accept(visitor);

            NonImmediateCommunication nonImmedComm = visitor.getActiveCommunication();
            if (nonImmedComm != null) {
                return nonImmedComm;
            }
        }

        return null;
    }
    
    /**
     * Sets the cellphone's balance.
     * 
     * @param balance
     *            the amount to set balance (in cents)
     * @throws HigherThanMaxBalanceException
     *             if the balance is higher than MAXBALANCE.
     */
    @Override
    public void setBalance(int balance) {
        if (balance > MAXBALANCE) {
            throw new HigherThanMaxBalanceException(getNumber(), balance,
                    MAXBALANCE);
        }

        super.setBalance(balance);
    }

    /**
     * Turn on the cellphone.
     */
    public void turnOn() {
        getCellPhoneState().turnOn();
    }

    /**
     * Turn busy the cellphone.
     */
    public void turnBusy() {
        getCellPhoneState().turnBusy();
    }

    /**
     * Turn silence the cellphone.
     */
    public void turnSilence() {
        getCellPhoneState().turnSilence();
    }

    /**
     * Turn off the cellphone.
     */
    public void turnOff() {
        getCellPhoneState().turnOff();
    }

    /**
     * Returns a textual representation of the cellphone.
     * 
     * @return Textual representation of the cellphone.
     */
    @Override
    public String toString() {
        return String.format("%s (Balance: %.2f euros)", getNumber(),
                new BigDecimal(getBalance()).divide(new BigDecimal(100)));
    }

    /**
     * Helper method for getting the prefix of a CellPhone number
     * 
     * @param cellPhoneNr
     *            the CellPhone number
     * @return the prefix for that CellPhone number
     */
    public static String getPrefixFromNumber(String cellPhoneNr) {
        if (cellPhoneNr.length() != 9) {
            throw new InvalidCellPhoneNumberException(cellPhoneNr,
                    "Number doesn't have 9 digits");
        }
        return cellPhoneNr.substring(0, 2);
    }

    private static class ActiveCommunicationVisitor extends CommunicationVisitor {
        NonImmediateCommunication activeComm;

        public ActiveCommunicationVisitor() {
            activeComm = null;
        }

        @Override
        public void visit(Voice voice) {
            visit((NonImmediateCommunication) voice);
        }

        @Override
        public void visit(Video video) {
            visit((NonImmediateCommunication) video);
        }

        public void visit(NonImmediateCommunication comm) {
            if (comm.getActive()) {
                activeComm = comm;
            }
        }

        public NonImmediateCommunication getActiveCommunication() {
            return activeComm;
        }
    }
}
