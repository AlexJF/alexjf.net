package pt.ist.anacom.replication;

import java.util.concurrent.PriorityBlockingQueue;

import pt.ist.anacom.shared.UDDIHelper;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.WrongTimestampException;
import pt.ist.anacom.shared.stubs.AnacomDto;
import java.util.concurrent.Semaphore;

/**
 * This class manages the requests made to the server.
 * It implements the server side of the distribution algorithm
 * developed.
 */
public class OperatorReplicationManager {

	/** The timestamp of the operator .*/
	private int _timestamp;
	
	/** 
	 * Queue of requests to handle later.
	 * This is needed to handle the case where the timestamp
	 * of the operator is behind the current timestamp of the
	 * client.
	 */
    private PriorityBlockingQueue<Request> _queuedRequests;
    
    /** Object merely used for synchronization motifs. */
    private Object _reqHandling = new Object();

    /**
     * Creates an instance of an OperatorReplicationManager.
     * @param timestamp First timestamp of the manager.
     */
    public OperatorReplicationManager(int timestamp) {
        _timestamp = timestamp;
        _queuedRequests = new PriorityBlockingQueue<Request>();
    }

    /**
     * Creates an instance of an OperatorReplicationManager.
     */
	public OperatorReplicationManager() {
        this(0);
	}

	/**
	 * Handles the requests by the client.
	 * Implements the functioning of the distribution
	 * algorithm developed.
	 * 
	 * @param dto with the information needed to execute the service.
	 * @param serviceFunction that contains information of what service to execute.
	 * @return the result of executing the service.
	 */
	public <I extends AnacomDto, O extends AnacomDto> O handleRequest(I dto, OperatorServiceFunction<I, O> serviceFunction) {
        
		if (dto.getTimestamp() == null) {
			// If enter here, one of the following is true:
			// - We are not in replication mode.
			// - We are in replication mode, and the client wanted to
			//   to know the timestamp.
            
			O result = serviceFunction.execute(dto);
            result.setTimestamp(_timestamp);
            return result;
        }
        else if (dto.getTimestamp() > _timestamp + 1) {
        	// If we enter here, there are some prior requests of the client
        	// that haven't reached the operator.
        	// Because of that, this request will be queued, and handled
        	// later, after the requests missing have been treated.
        	// This thread will be resumed after the request with
        	// timestamp: dto.getTimestamp() - 1 is executed.
        	
            Request req = new Request(dto.getTimestamp());
            _queuedRequests.add(req);
            try {
                req.acquire();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return null;
            }
        }
        else if (dto.getTimestamp() < _timestamp + 1) {
        	// If we enter here, the client has a wrong timestamp.
        	// Because of that we throw this exception.
        	
            throw new WrongTimestampException(dto.getTimestamp().intValue(), _timestamp);
        }

		//  _reqHandling is an object used purely for
		// synchronization purposes.
		// We only want one thread here at each moment!
        synchronized(_reqHandling) {
        	
            _timestamp++;
            // This variable will contain the non exception result 
            // provided by the operator.
            O result = null;
            // This variable will contain an exception if one
            // is provided by the operator.
            AnacomException finalException = null;

            try {
                result = serviceFunction.execute(dto);
            } catch (AnacomException e) {
                finalException = e;
            }

            // Got an exception?
            if (finalException != null) {
                finalException.setTimestamp(_timestamp);
                finalException.throwYourself();
            } else {
                result.setTimestamp(_timestamp);
            }

            // Check the lowest timestamp request queued.. 
            Request nextQueuedReq = _queuedRequests.peek();

            // If the lowest timestamp request queued has finally a timestamp
            // only one unit above the timestamp of the operator, then it can be executed!
            // Because of that we release the thread stopped in the condition:
            // (dto.getTimestamp() > _timestamp + 1)
            if (nextQueuedReq != null && nextQueuedReq.getTimestamp() == _timestamp + 1) {
                _queuedRequests.poll().release();
            }

            return result;
        }
	}

	/**
	 * The purpose of this class is to support the behavior of the
	 * (dto.getTimestamp() > _timestamp + 1) condition in 
	 * OperatorReplicationManager.  
	 * It serves as an element of the Priority Queue
	 * used by OperatorReplicationManager and contains the semaphore
	 * that locks the thread until its time to continue the execution of the
	 * request.
	 */
    private class Request implements Comparable<Request> {
    	
    	/** The timestamp of the request. */
        private Integer _timestamp;
        
        /** The semaphore to lock the thread. */
        private Semaphore _semaphore;

        /**
         * Creates an instance of a Request.
         * @param timestamp of the Request.
         */
        public Request(Integer timestamp) {
            _timestamp = timestamp;
            // the sempahore is initialized to 0, because
            // we don't any acquires to happen before the release.
            _semaphore = new Semaphore(0);
        }

        /**
         * Returns the timestamp of the Request.
         * @return the timestamp of the Request.
         */
        public Integer getTimestamp() {
            return _timestamp;
        }

        /**
         * Acquires the semaphore, locking until there is
         * a release.
         * @throws InterruptedException
         */
        public void acquire() throws InterruptedException {
            _semaphore.acquire();
        }

        /**
         * Releases the semaphore, unlocking the locked thread.
         */
        public void release() {
            _semaphore.release();
        }
        
        /**
         * Compares the request to a given one.
         * @param req The request to compare with
         * @returns < 0 if the timestamp is lower than the one of the given request.
         *           0 if the timestamp is equal to the one of the given request.
         *          > 0 if the timestamp is bigger to the one of the given request. 
         */
        public int compareTo(Request req) {
            return _timestamp.compareTo(req.getTimestamp());
        }
    }

	public void registerReplica(String operatorName, String prefix, String replicaNumber, String bindingUrl) {
		UDDIHelper.getSingleton().registerServer(operatorName, prefix, replicaNumber, bindingUrl);
	}

    public void resetTimestamp() {
        _timestamp = 0;
    }
}
