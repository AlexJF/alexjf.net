package pt.ist.anacom.security.handlers.anacom;

import java.util.UUID;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Node;

import pt.ist.anacom.security.handlers.AbstractHandler;

/**
 * This handler puts an uuid in each message sent. The uuid to send, is
 * received in the request.
 * This is needed to avoid that a bizantine replica/an attacker
 * is able to send response instead of the other replicas.
 */
public class RequestIDOperatorServerHandler extends AbstractHandler {

	/** The UUID for the active request */
	static protected UUID _activeId;
	
	public RequestIDOperatorServerHandler() {
		_activeId = null;
	}

    @Override
    protected String getFaultString(boolean incoming) {
        if (incoming) {
            return "Incoming uuid not valid";
        } else {
            return "Unable to add uuid to outgoing message";
        }
    }
	
	@Override
	protected boolean handleInboundMessage(SOAPMessage message) {
        System.out.println("Handling Inbound Message - UUID Handler");
		try {
			// testing if its the correct uuid
			Node uuidNode = getUUIDNode(getSoapEnvelope(message).getHeader());
			
			if (uuidNode != null) {
				String uuidString;
				uuidString = uuidNode.getTextContent();
				
				_activeId = UUID.fromString(uuidString);
			}
		} catch (SOAPException e) {
			e.printStackTrace();
		}
		
		return true;
	}

	@Override
	protected boolean handleOutboundMessage(SOAPMessage message) {
        System.out.println("Handling Outbound Message - UUID Handler");
		try {
			if (_activeId != null) {
                SOAPEnvelope soapEnvelope = getSoapEnvelope(message);
                SOAPHeader soapHeader = getHeader(soapEnvelope);
                Name name = soapEnvelope.createName("messageUUID", "anacom",
                        "http://pt.ist.utl.anacom");
                SOAPElement element = soapHeader.addChildElement(name);
				element.addTextNode(_activeId.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return true;
	}

}
