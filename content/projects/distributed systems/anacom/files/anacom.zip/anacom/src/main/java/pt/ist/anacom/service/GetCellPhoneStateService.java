package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.CellPhoneBusyState;
import pt.ist.anacom.domain.CellPhoneOnState;
import pt.ist.anacom.domain.CellPhoneSilenceState;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto.CellPhoneStates;
import pt.ist.fenixframework.FenixFramework;

public class GetCellPhoneStateService extends AnacomService {

	private CellPhoneSimpleDto _dto;

	private CellPhoneWithStateDto _state;

	public GetCellPhoneStateService() {
		super();
	}

	public GetCellPhoneStateService(CellPhoneSimpleDto StateDto) {
		_dto = StateDto;
	}

	@Override
	public void dispatch() throws CellPhoneNotExistsException {
		AnacomNetwork network = FenixFramework.getRoot();
		String cellPhoneNumber = _dto.getNumber();
		CellPhone cellPhone = network.getCellPhoneOrException(cellPhoneNumber);
		CellPhoneWithStateDto.CellPhoneStates phonestate = CellPhoneStates.Off;
		;

		if (cellPhone.getCellPhoneState() instanceof CellPhoneBusyState) {
			phonestate = CellPhoneStates.Busy;
		} else if (cellPhone.getCellPhoneState() instanceof CellPhoneSilenceState) {
			phonestate = CellPhoneStates.Silent;
		} else if (cellPhone.getCellPhoneState() instanceof CellPhoneOnState) {
			phonestate = CellPhoneStates.On;
		}

		_state = new CellPhoneWithStateDto(cellPhoneNumber, phonestate);
	}

	public final CellPhoneWithStateDto getCellPhoneState() {
		return _state;
	}

}
