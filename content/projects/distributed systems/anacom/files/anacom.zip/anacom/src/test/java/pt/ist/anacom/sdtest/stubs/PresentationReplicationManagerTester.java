package pt.ist.anacom.sdtest.stubs;

import java.util.Arrays;
import java.util.List;

import pt.ist.anacom.replication.PresentationReplicationManager;
import pt.ist.anacom.service.bridge.RemoteOperator;

public class PresentationReplicationManagerTester extends PresentationReplicationManager {
    private RemoteOperator[] _replicas;

    public PresentationReplicationManagerTester(RemoteOperator[] replicas, int quorumSize) {
        super(quorumSize);
        _replicas = replicas;
    }

    @Override
    protected List<RemoteOperator> getReplicasForOperator(String operatorName) {
        return Arrays.asList(_replicas);
    }

    public void setTimestamp(String operatorName, Integer timestamp) {
        super.setTimestamp(operatorName, timestamp);
    };
}
