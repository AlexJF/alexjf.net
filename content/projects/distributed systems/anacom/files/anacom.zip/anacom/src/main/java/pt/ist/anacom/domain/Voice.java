package pt.ist.anacom.domain;

import pt.ist.anacom.shared.CommunicationVisitor;

/**
 * This class represents a Voice communication type.
 */
public class Voice extends Voice_Base {

	/**
	 * Build an instance of a Voice communication type.
	 */
	public Voice(String sourceNumber, String destinationNumber) {
		super();
		init(sourceNumber, destinationNumber);
	}

	@Override
	public int calculateCost() {
		return getSourceCellPhone().getNetworkOperator().calculateCost(this);
	}

	@Override
	public void accept(CommunicationVisitor visitor) {
		visitor.visit(this);
	}
}
