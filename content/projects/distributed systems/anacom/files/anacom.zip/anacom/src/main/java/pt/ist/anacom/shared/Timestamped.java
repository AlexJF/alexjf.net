package pt.ist.anacom.shared;

/**
 * Interface that represents the objects that have a timestamp.
 */
public interface Timestamped {

	/**
	 * Returns the timestamp of the object.
	 * @return the timestamp of the object.
	 */
	public Integer getTimestamp();
}
