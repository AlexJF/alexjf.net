package pt.ist.anacom.estest;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.service.ChangeCellPhoneStateService;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto.CellPhoneStates;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;

public class ChangeCellPhoneStateSeviceTest extends AnacomTestCase {

	private static String OPERATOR_NAME_BASE = "ZAZA";
	private static String OPERATOR_PREFIX_BASE = "87";

	private static String CELL_NUMBER1 = "876711094";
	private static String CELL_NUMBER2 = "876711095";
	private static int CELL_BALANCE = 200;

	private static CellPhone cell;

	public ChangeCellPhoneStateSeviceTest() {
		super();
	}

	public ChangeCellPhoneStateSeviceTest(String msg) {
		super(msg);
	}

	@Override
	public void setUp() {
		super.setUp();
		addOperator(OPERATOR_NAME_BASE, OPERATOR_PREFIX_BASE);
		NetworkOperator op = getOperatorByName(OPERATOR_NAME_BASE);
		cell = addCellPhone2G(op, CELL_NUMBER1, CELL_BALANCE);
	}

	public void testChangeState() {
		// Arrange
		turnCellPhoneOff(cell);
		CellPhoneWithStateDto dto = new CellPhoneWithStateDto(CELL_NUMBER1,
				CellPhoneStates.On);
		ChangeCellPhoneStateService service = new ChangeCellPhoneStateService(
				dto);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("Should not throw an exception: " + e.getMessage());
		}

		// Assert
		assertEquals(CellPhoneStates.On, getCellPhoneState(cell));
	}

	public void testChangeNonExistent() {
		// Arrange
		turnCellPhoneOff(cell);
		CellPhoneWithStateDto dto = new CellPhoneWithStateDto(CELL_NUMBER2,
				CellPhoneStates.On);
		ChangeCellPhoneStateService service = new ChangeCellPhoneStateService(
				dto);

		// Act
		try {
			service.execute();
			fail("Should throw a CellPhoneNotExistsException");
		} catch (CellPhoneNotExistsException e) {
			// Everything is fine
		} catch (AnacomException e) {
			fail("Wrong exception thrown: " + e.getMessage());
		}
	}
}
