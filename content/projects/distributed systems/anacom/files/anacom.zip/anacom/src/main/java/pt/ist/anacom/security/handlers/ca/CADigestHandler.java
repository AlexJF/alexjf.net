package pt.ist.anacom.security.handlers.ca;

import pt.ist.anacom.security.handlers.AbstractDigestHandler;

import pt.ist.anacom.security.managers.CASecurityManager;

/**
 * This handler is used by Certification Authority
 */

public class CADigestHandler extends AbstractDigestHandler {
    @Override
    protected pt.ist.anacom.security.managers.AbstractSecurityManager getSecurityManager() {
        return CASecurityManager.getInstance();
    }
}
