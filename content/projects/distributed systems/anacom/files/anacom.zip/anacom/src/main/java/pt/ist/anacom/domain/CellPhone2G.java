package pt.ist.anacom.domain;

import pt.ist.anacom.shared.exception.IncomingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.OutgoingCommunicationNotSupportedException;

/**
 * This class represents a 2G CellPhone. A 2G CellPhone can't establish or
 * receive video communications.
 */
public class CellPhone2G extends CellPhone2G_Base {

	public CellPhone2G(String number, int balance) {
		super();
		init(number, balance);
	}

	@Override
	public void addIncomingCommunication(Video comm) {
		throw new IncomingCommunicationNotSupportedException(getNumber(),
				"2G CellPhone", "Video");
	}

	@Override
	public void addOutgoingCommunication(Video comm) {
		throw new OutgoingCommunicationNotSupportedException(getNumber(),
				"2G CellPhone", "Video");
	}
}
