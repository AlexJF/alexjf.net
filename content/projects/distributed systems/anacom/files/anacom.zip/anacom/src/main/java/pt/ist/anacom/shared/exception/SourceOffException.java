package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to the source cellphone of a
 * communication being off.
 */
public class SourceOffException extends OutgoingCommunicationException {
	private static final long serialVersionUID = 1L;

	public SourceOffException() {
	}

	public SourceOffException(String sourceNumber) {
		super(sourceNumber, "Source cellphone is off");
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of SourceOffException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof SourceOffException))
			return false;

		return true;
	}
}
