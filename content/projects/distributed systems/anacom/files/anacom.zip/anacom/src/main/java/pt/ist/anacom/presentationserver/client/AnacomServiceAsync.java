package pt.ist.anacom.presentationserver.client;

import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;

import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.SMSDto;

public interface AnacomServiceAsync {
	void initBridge(String serverType, AsyncCallback<Void> callback);

	public void registerCellPhone(CellPhoneDetailedDto dto,
			AsyncCallback<Void> callback);

	public void getCellPhoneBalance(CellPhoneSimpleDto dto,
			AsyncCallback<BalanceDto> callback);

	public void getCellPhoneState(CellPhoneSimpleDto dto,
			AsyncCallback<CellPhoneWithStateDto> callback);

	public void listSMS(CellPhoneSimpleDto dto,
			AsyncCallback<List<SMSDto>> callback);
	
	public void getLastCommunicationDetails(CellPhoneSimpleDto dto,
			AsyncCallback<CommunicationDetailsDto> callback);

	public void changeCellPhoneState(CellPhoneWithStateDto dto,
			AsyncCallback<Void> callback);

	public void increaseCellPhoneBalance(ChangeCellPhoneBalanceDto dto,
			AsyncCallback<Void> callback);

	public void sendSMS(SMSDto dto, AsyncCallback<Void> callback);

    public void establishVoiceCommunication(CallDto dto, AsyncCallback<Void> callback);

    public void establishVideoCommunication(CallDto dto, AsyncCallback<Void> callback);

    public void terminateActiveCommunication(CallWithDurationDto dto, AsyncCallback<Void> callback);
}
