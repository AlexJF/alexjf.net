package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.fenixframework.FenixFramework;

public class TerminateActiveIncomingCommService extends AnacomService{

	private CallWithDurationDto _dto;
	
	public TerminateActiveIncomingCommService(CallWithDurationDto dto) {
		_dto = dto;
	}
	
	@Override
	public void dispatch() throws AnacomException {
		AnacomNetwork network = FenixFramework.getRoot();
		NetworkOperator op = network.getNetworkOperatorByCellPhoneNumberOrException(_dto
				.getDestinationNumber());
		
		op.terminateActiveCommunication(_dto.getDestinationNumber(), _dto.getDuration());
	}
}
