package pt.ist.anacom.presentationserver.client.views;

import com.google.gwt.core.client.GWT;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;

import com.google.gwt.user.client.rpc.AsyncCallback;

import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlexTable;

import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;

import com.google.gwt.user.client.Window;

import pt.ist.anacom.presentationserver.client.Anacom;

import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;

public class RegisterCellPhonePopup extends DialogBox {
	final private Anacom parent;
	final TextBox txtOperator = new TextBox();
	final TextBox txtNumber = new TextBox();
	final ListBox lstType = new ListBox();
	final TextBox txtBalance = new TextBox();

	public RegisterCellPhonePopup(final Anacom parent) {
		super();

		this.parent = parent;

		setText("Add CellPhone");
		setGlassEnabled(true);
		setAnimationEnabled(true);

		FlexTable dataTable = new FlexTable();

		setWidget(dataTable);

		dataTable.setHTML(0, 0, "Operator Name:");
		dataTable.setWidget(0, 1, txtOperator);

		dataTable.setHTML(1, 0, "Number:");
		dataTable.setWidget(1, 1, txtNumber);

		dataTable.setHTML(2, 0, "Type:");
		dataTable.setWidget(2, 1, lstType);

		lstType.addItem("2G");
		lstType.addItem("3G");

		dataTable.setHTML(3, 0, "Balance:");
		dataTable.setWidget(3, 1, txtBalance);

		Button btnRegister = new Button("Register", new ClickHandler() {
			public void onClick(ClickEvent event) {
				registerCellPhone();
			}
		});

		Button btnCancel = new Button("Cancel", new ClickHandler() {
			public void onClick(ClickEvent event) {
				hide();
			}
		});

		dataTable.setWidget(4, 0, btnRegister);
		dataTable.setWidget(4, 1, btnCancel);
	}

	@Override
	public void show() {
		txtOperator.setText("");
		txtNumber.setText("");
		lstType.setItemSelected(0, true);
		txtBalance.setText("0");
		super.show();
	}

	public final void registerCellPhone() {
		CellPhoneDetailedDto.CellPhoneType type = CellPhoneDetailedDto.CellPhoneType.TwoG;

		if (lstType.getItemText(lstType.getSelectedIndex()).equals("3G")) {
			type = CellPhoneDetailedDto.CellPhoneType.ThreeG;
		}

		CellPhoneDetailedDto dto = new CellPhoneDetailedDto(
				txtOperator.getText(), txtNumber.getText(), type,
				Integer.parseInt(txtBalance.getText()));
		parent.getRpcService().registerCellPhone(dto,
				new AsyncCallback<Void>() {
					public void onSuccess(Void response) {
						hide();
					}

					public void onFailure(Throwable caught) {
						GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.registerCellPhone");
						GWT.log("-- Throwable: '" + caught.getClass().getName()
								+ "'");
						Window.alert("ERROR: Cannot register CellPhone: "
								+ caught.getMessage());
					}
				});
	}

}
