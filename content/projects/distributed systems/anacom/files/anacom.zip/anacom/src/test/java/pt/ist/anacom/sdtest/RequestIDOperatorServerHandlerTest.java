package pt.ist.anacom.sdtest;

import java.util.UUID;

import javax.xml.soap.SOAPMessage;

import pt.ist.anacom.sdtest.stubs.RequestIDOperatorServerHandlerTester;

public class RequestIDOperatorServerHandlerTest extends SecurityTestCase {

	private RequestIDOperatorServerHandlerTester handler;

    public static final String SOAP_MESSAGE = 
        "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
        "<soap:Body><ns2:reset xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
        "</soap:Envelope>";
	
	public RequestIDOperatorServerHandlerTest(String msg) {
		super(msg);
	}

	public RequestIDOperatorServerHandlerTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();
		
		handler = new RequestIDOperatorServerHandlerTester();
	}
	
	private SOAPMessage prepareIncomingMessage(String message, UUID uuid) {
        SOAPMessage outgoingMessage = createSoapMessageFromString(message);
        
        addUUIDToSoapMessage(outgoingMessage, uuid);
        return outgoingMessage;
    }

	// Tests if the handler accepts a correct message with an uuid
	public void testAllowCorrectMessageWithUUID() {
		
		UUID uuid = UUID.randomUUID();
        SOAPMessage message = prepareIncomingMessage(SOAP_MESSAGE, uuid);
        Boolean result = false;

		try {
            result = handler.testHandleIncomingMessage(message);
            
        } catch (Exception e) {
            e.printStackTrace();
            fail("Incoming message handling should not have failed");
        }
		
		// Assert
        assertTrue("Handler should have recognized the message as being valid", result);
	}
	
	// Tests if the handler accepts a correct message without an uuid
	public void testAllowCorrectMessageWithoutUUID() {
		
        SOAPMessage message = createSoapMessageFromString(SOAP_MESSAGE);
        Boolean result = false;

		try {
            result = handler.testHandleIncomingMessage(message);
            
        } catch (Exception e) {
            e.printStackTrace();
            fail("Incoming message handling should not have failed");
        }
		
		// Assert
        assertTrue("Handler should have recognized the message as being valid", result);
	}
	
	// Tests if the handler responds with the correct uuid
	public void testSendCorrectUUID() {
		
		UUID uuid = UUID.randomUUID();
        SOAPMessage message = prepareIncomingMessage(SOAP_MESSAGE, uuid);
        // the message passed to the outbound
        SOAPMessage outboundedMessage = createSoapMessageFromString(SOAP_MESSAGE);
        SOAPMessage expectedMessage = prepareIncomingMessage(SOAP_MESSAGE, uuid);
        String expectedOutputString = getStringFromSoapMessage(expectedMessage);
        Boolean result = false;

		try {
            handler.testHandleIncomingMessage(message);
            result = handler.testHandleOutgoingMessage(outboundedMessage);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Outgoing message handling should not have failed");
        }
		
		String resultOutputString = getStringFromSoapMessage(outboundedMessage);
		
		// Assert
        assertTrue("Handler should have allowed the message to be sent", result);
        assertEquals("Generated message doesn't match expected message", resultOutputString, expectedOutputString);
	}
}
