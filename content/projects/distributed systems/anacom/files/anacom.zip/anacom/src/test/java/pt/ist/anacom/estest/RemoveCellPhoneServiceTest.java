package pt.ist.anacom.estest;

import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.service.RemoveCellPhoneService;
import pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;

public class RemoveCellPhoneServiceTest extends AnacomTestCase {

	private final String OPNAME = "REMOVEOP";
	private final String OPPREFIX = "00";
	private final String CELLNR = "001231231";
	private final String NONEXISTING_CELLNR = "001231234";
	private final int CELLBAL = 50;

	private NetworkOperator operator;

	public RemoveCellPhoneServiceTest(String msg) {
		super(msg);
	}

	public RemoveCellPhoneServiceTest() {
		super();
	}

	@Override
	protected void setUp() {
		super.setUp();

		operator = addOperator(OPNAME, OPPREFIX);
		addCellPhone2G(operator, CELLNR, CELLBAL);
	}

	public void testRemoveInvalidCellPhone() {
		// Arrange
		CellPhoneWithOperatorDto dto = new CellPhoneWithOperatorDto(OPNAME,
				NONEXISTING_CELLNR);
		RemoveCellPhoneService svc = new RemoveCellPhoneService(dto);

		// Act
		try {
			svc.execute();
			fail("Expecting exception since cellphone doesn't exist");
		} catch (CellPhoneNotExistsException e) {
			// Expected exception
		}
	}

	public void testRemoveValidCellPhone() {
		// Arrange
		int cellNrBeforeRemove = getNumberOfCellPhones(operator);
		CellPhoneWithOperatorDto dto = new CellPhoneWithOperatorDto(OPNAME,
				CELLNR);

		RemoveCellPhoneService svc = new RemoveCellPhoneService(dto);

		// Act
		try {
			svc.execute();
		} catch (AnacomException e) {
			fail("Not expecting exception: " + e.getMessage());
		}

		// Assert
		assertEquals("Cellphone still in operator after remove", null,
				getCellPhoneByNumber(operator, CELLNR));
		assertEquals("More (or less) than 1 CellPhone was removed",
				cellNrBeforeRemove - 1, getNumberOfCellPhones(operator));
	}
}
