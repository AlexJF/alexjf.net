package pt.ist.anacom.domain;

import java.math.BigDecimal;

import pt.ist.anacom.shared.exception.BonusNotPositiveException;
import pt.ist.anacom.shared.exception.CellPhoneAlreadyExistsException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.InvalidCellPhonePrefixException;
import pt.ist.anacom.shared.exception.InvalidOperatorPrefixException;

/**
 * This class represents a network operator and maintains information about
 * cellphones and base communication costs.
 * 
 * Each cellphone registered with a NetworkOperator instance must have a prefix
 * matching the operator's prefix and must have an unique number.
 */
public class NetworkOperator extends NetworkOperator_Base {

	/**
	 * Build an instance of NetworkOperator.
	 * 
	 * @param name
	 *            The name of this network operator.
	 * @param prefix
	 *            The 2-digit prefix associated with this operator.
	 * 
	 * @throws InvalidOperatorPrefixException
	 *             If the provided prefix doesn't have exactly 2 digits.
	 */
	public NetworkOperator(String name, String prefix) {
		super();

		if (prefix.length() != 2) {
			throw new InvalidOperatorPrefixException(prefix,
					"Prefix doesn't have exactly 2 digits.");
		}

		setName(name);
		setPrefix(prefix);
		setCostSMS(5);
		setCostVoice(20);
		setCostVideo(40);
		setTax(new BigDecimal(1.5));
		setBonus(new BigDecimal(1));
	}

	/**
	 * Adds a new cellphone to this operator.
	 * 
	 * @param cellphone
	 *            The cellphone to add to the operator.
	 * @throws CellPhoneAlreadyExistsException
	 *             If this operator already has a cellphone with the same
	 *             number.
	 * @throws InvalidCellPhonePrefixException
	 *             If the phone's prefix doesn't match the operator's prefix.
	 */
	@Override
	public void addCellPhone(CellPhone cellphone) {
		if (!cellphone.getPrefix().equals(getPrefix())) {
			throw new InvalidCellPhonePrefixException(cellphone.getPrefix(),
					"Prefix doesn't match operator's prefix \"" + getPrefix()
							+ "\"");
		}

		for (CellPhone existingCell : getCellPhoneSet()) {
			if (existingCell.getNumber().equals(cellphone.getNumber())) {
				throw new CellPhoneAlreadyExistsException(
						cellphone.getNumber(), getName());
			}
		}

		super.addCellPhone(cellphone);
	}

	/**
	 * Retrieves a cellphone from this operator with the specified number.
	 * 
	 * @param number
	 *            The number of the cellphone to retrieve.
	 * @return An instance of the cellphone with the specified number or null if
	 *         no such cellphone exists on this operator.
	 */
	public CellPhone getCellPhone(String number) {
		if (number != null) {
			for (CellPhone cellPhone : getCellPhoneSet()) {
				if (cellPhone.getNumber().equals(number)) {
					return cellPhone;
				}
			}
		}

		return null;
	}

	/**
	 * Determines if a tax must be applied to a communication with the specified
	 * destination number and calculates the new cost.
	 * 
	 * Tax is only applied to numbers whose prefix doesn't match the operator
	 * prefix.
	 * 
	 * @param number
	 *            The destination number of the communication.
	 * @param cost
	 *            The base cost of the communication.
	 * 
	 * @return The provided cost with the tax applied or the same cost if no tax
	 *         is to be applied.
	 */
	protected int applyTax(String number, int cost) {
		if (!number.substring(0, 2).equals(getPrefix())) {
			BigDecimal decimalCost = getTax().multiply(new BigDecimal(cost));
			cost = decimalCost.intValue();
		}

		return cost;
	}

	/**
	 * Calculates the cost of the specified communication.
	 * 
	 * @param sms
	 *            The sms communication whose cost we wish to calculate.
	 * 
	 * @return The cost (in cents) of the communication.
	 */
	public int calculateCost(SMS sms) {
		int smsLength = sms.getData().length();
		return applyTax(sms.getDestinationNumber(), getCostSMS()
				* ((smsLength - 1) / 100 + 1));
	}

	/**
	 * Calculates the cost of the specified communication.
	 * 
	 * @param video
	 *            The video communication whose cost we wish to calculate.
	 * 
	 * @return The cost (in cents) of the communication.
	 */
	public int calculateCost(Video video) {
		return applyTax(video.getDestinationNumber(),
				getCostVideo() * video.getDuration());
	}

	/**
	 * Calculates the cost of the specified communication.
	 * 
	 * @param voice
	 *            The voice communication whose cost we wish to calculate.
	 * 
	 * @return The cost (in cents) of the communication.
	 */
	public int calculateCost(Voice voice) {
		return applyTax(voice.getDestinationNumber(),
				getCostVoice() * voice.getDuration());
	}

	/**
	 * Implements the logic for the sending of a SMS communication from a cellphone of this
     * network.
	 * 
	 * @param comm The communication to be received.
	 */
    public void establishCommunication(SMS comm) {
        CellPhone sourceCell = getCellPhoneOrException(comm.getSourceNumber());
		sourceCell.addOutgoingCommunication(comm);
        comm.end();
    }

	/**
	 * Implements the logic for the receival of a SMS communication by a cellphone of this
     * network.
	 * 
	 * @param comm The communication to be received.
	 */
    public void receiveCommunication(SMS comm) {
        CellPhone destinationCell = getCellPhoneOrException(comm.getDestinationNumber());
		destinationCell.addIncomingCommunication(comm);
        comm.end();
    }

	/**
	 * Implements the logic for the establishment of a voice communication from a cellphone of this
     * network.
	 * 
	 * @param comm The communication to be received.
	 */
    public void establishCommunication(Voice comm) {
        CellPhone sourceCell = getCellPhoneOrException(comm.getSourceNumber());
		sourceCell.addOutgoingCommunication(comm);
    }

	/**
	 * Implements the logic for the receival of a voice communication by a cellphone of this
     * network.
	 * 
	 * @param comm The communication to be received.
	 */
	public void receiveCommunication(Voice comm) {
        CellPhone destinationCell = getCellPhoneOrException(comm.getDestinationNumber());
		destinationCell.addIncomingCommunication(comm);
	}
	
	/**
	 * Implements the logic for the establishment of a video communication from a cellphone of this
     * network.
	 * 
	 * @param comm The communication to be received.
	 */
    public void establishCommunication(Video comm) {
        CellPhone sourceCell = getCellPhoneOrException(comm.getSourceNumber());
		sourceCell.addOutgoingCommunication(comm);
    }

	/**
	 * Implements the logic for the receival of a video communication by a cellphone of this
     * network.
	 * 
	 * @param comm The communication to be received.
	 */
	public void receiveCommunication(Video comm) {
        CellPhone destinationCell = getCellPhoneOrException(comm.getDestinationNumber());
		destinationCell.addIncomingCommunication(comm);
	}

    /**
     * Implements the logic for terminating an active communication on a 
     * cellphone of this network.
     *
     * @param comm The communication to be terminated.
     */
    public void terminateActiveCommunication(String phoneNumber, int duration) {
        CellPhone cell = getCellPhoneOrException(phoneNumber);
        NonImmediateCommunication comm = cell.getActiveCommunication();

        if (comm != null) {
            comm.end(duration);
            cell.setCellPhoneState(cell.getPreviousCellPhoneState());
        }
    }

    /**
     * Allows the retrieval of a CellPhone object registered with the network if
     * it exists or throws an exception otherwise.
     *
     * @param number The number associated with the desired cellphone.
     */
    public CellPhone getCellPhoneOrException(String number) {
		CellPhone cell = getCellPhone(number);
		
		if (cell == null) {
			throw new CellPhoneNotExistsException(number, getName());
        }

        return cell;
    }

	/**
	 * Increases the phone balance of a CellPhone, taking into account the bonus
	 * the operator offers.
	 * 
	 * @param cellPhoneNumber The number of the CellPhone whose balance we want
	 * 						  to increase.
	 * @param amount Amount by which we want to increase the balance of the
	 * 				 CellPhone.
	 */
	public void increaseCellPhoneBalance(String cellPhoneNumber, int amount) {
		CellPhone cellPhone = getCellPhone(cellPhoneNumber);

		if (cellPhone == null) {
			throw new CellPhoneNotExistsException(cellPhoneNumber, getName());
		}
		
		BigDecimal bonusedAmount = (getBonus().add(new BigDecimal(1))).multiply(new BigDecimal(amount));
		cellPhone.increaseBalance(bonusedAmount.intValue());
	}
	
	/**
	 * Sets the bonus of the network operator.
	 * 
	 * @param bonus The bonus of the network operator.
	 */
	@Override
	public void setBonus(BigDecimal bonus) {

		// if bonus is not positive
		if ( bonus.compareTo(new BigDecimal(0)) == -1 ) {
			throw new BonusNotPositiveException("The bonus must be positive");
		}
		
		super.setBonus(bonus);
	}
}
