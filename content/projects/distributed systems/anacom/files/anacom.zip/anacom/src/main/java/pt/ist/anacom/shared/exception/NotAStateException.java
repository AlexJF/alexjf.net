package pt.ist.anacom.shared.exception;

public class NotAStateException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _phoneNumber;
	private String _causeMessage;

	public NotAStateException() {
	}

	public NotAStateException(String phoneNumber, String cause) {
		super(
				"You cannot change cellphone "
						+ phoneNumber
						+ " to state: "
						+ cause
						+ ". You can only change to the following states: On, Off, Silent");
		_phoneNumber = phoneNumber;
		_causeMessage = cause;
	}

	public String getCauseMessage() {
		return _causeMessage;
	}

	public String getNumber() {
		return _phoneNumber;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of NotAStateException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof NotAStateException))
			return false;

		NotAStateException exception = (NotAStateException) obj;

		return getNumber().equals(exception.getNumber())
				&& getCauseMessage().equals(exception.getCauseMessage());
	}
}
