package pt.ist.anacom.sdtest;

import java.security.KeyPair;
import java.util.UUID;

import javax.xml.soap.SOAPMessage;

import pt.ist.anacom.sdtest.stubs.RequestIDPresentationServerHandlerTester;
import sun.security.x509.X509CertImpl;

public class RequestIDPresentationServerHandlerTest extends SecurityTestCase {
	
	private RequestIDPresentationServerHandlerTester handler;
	
	private KeyPair kPair = generateKeyPair();

    public static final String SOAP_MESSAGE = 
        "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
        "<soap:Body><ns2:reset xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
        "</soap:Envelope>";
	
	public RequestIDPresentationServerHandlerTest(String msg) {
		super(msg);
	}

	public RequestIDPresentationServerHandlerTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();
		
		handler = new RequestIDPresentationServerHandlerTester();
		handler.clearMap();
	}
	
	private SOAPMessage prepareIncomingMessage(String message, UUID uuid) {
        SOAPMessage outgoingMessage = createSoapMessageFromString(message);
        
        addUUIDToSoapMessage(outgoingMessage, uuid);
        return outgoingMessage;
    }
	
	private SOAPMessage prepareIncomingMessage(String message, KeyPair pair, X509CertImpl sourceCertificate) {
        SOAPMessage outgoingMessage = createSoapMessageFromString(message);
        
        addCertificateToSoapMessage(outgoingMessage, sourceCertificate);
        return outgoingMessage;
    }
	
	private SOAPMessage prepareIncomingMessage(String message, KeyPair pair, X509CertImpl sourceCertificate, UUID uuid) {
        SOAPMessage outgoingMessage = createSoapMessageFromString(message);
        
        addCertificateToSoapMessage(outgoingMessage, sourceCertificate);
        addUUIDToSoapMessage(outgoingMessage, uuid);
        return outgoingMessage;
    }
	
    private SOAPMessage prepareIncomingMessage(String message, KeyPair pair, UUID uuid) {
        X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", pair.getPrivate(), 1);
        return prepareIncomingMessage(message, pair, sourceCertificate, uuid);
    }
    
    private SOAPMessage prepareIncomingMessage(String message, KeyPair pair) {
        X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", pair.getPrivate(), 1);
        return prepareIncomingMessage(message, pair, sourceCertificate);
    }
	
	// Tests if the handler puts the correct uuid in the message
	public void testMessageSentWithUUDI() {

		UUID uuid = UUID.randomUUID();
        SOAPMessage message = createSoapMessageFromString(SOAP_MESSAGE);
        SOAPMessage expectedMessage = prepareIncomingMessage(SOAP_MESSAGE, uuid);
        String expectedOutputString = getStringFromSoapMessage(expectedMessage);
        Boolean result = false;

		try {
			handler.setUUID(uuid);
            result = handler.testHandleOutgoingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Outgoing message handling should not have failed");
        }
		
		String resultOutputString = getStringFromSoapMessage(message);
		
		// Assert
        assertTrue("Handler should have recognized the message as being valid", result);
        assertEquals("Generated message doesn't match expected message", resultOutputString, expectedOutputString);
	}
	
	// Tests if the handler accepts an answer with the right uuid from a replica
	// that hasn't send an answer yet.
	public void testAllowsValidAnswer() {
		
		UUID uuid = UUID.randomUUID();
        SOAPMessage message = prepareIncomingMessage(SOAP_MESSAGE, kPair, uuid);
        Boolean result = false;

		try {
			handler.setUUID(uuid);
            result = handler.testHandleIncomingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Outgoing message handling should not have failed");
        }
		
		String certString = getCertificateNode(message).getTextContent();
		String replicaName = getCertificateFromBase64(certString).getSubjectDN().getName(); 
		
		// Assert
        assertTrue("Handler should have allowed the message to be sent", result);
        assertTrue("Handler should have saved the replica name", handler.replicaNameIsSaved(replicaName));
        assertEquals("Handler should only have one replica saved", 1, handler.numberReplicasSaved());
        
	}
	
	// Tests if the handler rejects an answer with the wrong uuid from a replica
	// that hasn't send an answer yet.
	// This test assumes that it's really hard for two randomUUID have the same value.
	public void testRejectsWrongUUIDAnswer() {
		
		UUID uuid = UUID.randomUUID();
		UUID wronguuid = UUID.randomUUID();
        SOAPMessage message = prepareIncomingMessage(SOAP_MESSAGE, kPair, wronguuid);
        Boolean result = false;

		try {
			handler.setUUID(uuid);
            result = handler.testHandleIncomingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Outgoing message handling should not have failed");
        }
		
		String certString = getCertificateNode(message).getTextContent();
		String replicaName = getCertificateFromBase64(certString).getSubjectDN().getName(); 
		
		// Assert
        assertFalse("Handler shouldn't have allowed the message to be received", result);
        assertFalse("Handler shouldn't have saved the replica name", handler.replicaNameIsSaved(replicaName));
        assertEquals("Handler shouldn't save any replica", 0, handler.numberReplicasSaved());   
	}
	
	// Tests if the handler rejects an answer with the right uuid from a replica
	// that has already sent an answer.
	public void testRejectsReplicaSecondAnswer() {
		
		UUID uuid = UUID.randomUUID();
        SOAPMessage message = prepareIncomingMessage(SOAP_MESSAGE, kPair, uuid);
        Boolean result = false;

		try {
			handler.setUUID(uuid);
            handler.testHandleIncomingMessage(message);
            result = handler.testHandleIncomingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Outgoing message handling should not have failed");
        }
		
		String certString = getCertificateNode(message).getTextContent();
		String replicaName = getCertificateFromBase64(certString).getSubjectDN().getName(); 
		
		// Assert
        assertFalse("Handler shouldn't have allowed the message to be received", result);
        assertTrue("Handler should have saved the replica name the first time", handler.replicaNameIsSaved(replicaName));
        assertEquals("Handler shouldn't save the replica twice", 1, handler.numberReplicasSaved());
	}
	
	// Tests if the handler rejects an answer with the wrong uuid from a replica
	// that has already sent an answer.
	// This test assumes that it's really hard for two randomUUID have the same value.
	public void testRejectsWrongUUIDAndDuplicateAnswer() {
		
		UUID uuid = UUID.randomUUID();
		UUID wronguuid = UUID.randomUUID();
        SOAPMessage correctUUDIMessage = prepareIncomingMessage(SOAP_MESSAGE, kPair, uuid);
        SOAPMessage wrongUUDIMessage = prepareIncomingMessage(SOAP_MESSAGE, kPair, wronguuid);
        Boolean result = false;

		try {
			handler.setUUID(uuid);
			handler.testHandleIncomingMessage(correctUUDIMessage);
            result = handler.testHandleIncomingMessage(wrongUUDIMessage);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Outgoing message handling should not have failed");
        }
		
		String certString = getCertificateNode(wrongUUDIMessage).getTextContent();
		String replicaName = getCertificateFromBase64(certString).getSubjectDN().getName(); 
		
		// Assert
        assertFalse("Handler shouldn't have allowed the message to be received", result);
        assertTrue("Handler should have saved the replica name the first time", handler.replicaNameIsSaved(replicaName));
        assertEquals("Handler shouldn't save the replica twice", 1, handler.numberReplicasSaved());
	}
	
	// Tests if the handler rejects an answer with no uuid but with certificate.
	public void testRejectsNoUUID() {
		
		UUID uuid = UUID.randomUUID();
        SOAPMessage message = prepareIncomingMessage(SOAP_MESSAGE, kPair);

        Boolean result = false;

		try {
			handler.setUUID(uuid);
			result = handler.testHandleIncomingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Outgoing message handling should not have failed");
        }
		
		// Assert
        assertFalse("Handler shouldn't have allowed the message to be received", result);
	}
	
	// Tests if the handler rejects an answer with no certificate.
	public void testRejectsNoCertificate() {
		
		UUID uuid = UUID.randomUUID();
        SOAPMessage message = prepareIncomingMessage(SOAP_MESSAGE, uuid);
        Boolean result = false;

		try {
			handler.setUUID(uuid);
			result = handler.testHandleIncomingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Outgoing message handling should not have failed");
        }
		
		// Assert
        assertFalse("Handler shouldn't have allowed the message to be received", result);
	}
	
	// Tests if the handler rejects an answer without certificate and uuid
	public void testRejectsNoCertificateNoUUID() {
		
		UUID uuid = UUID.randomUUID();
        SOAPMessage message = createSoapMessageFromString(SOAP_MESSAGE);
        Boolean result = false;

		try {
			handler.setUUID(uuid);
			result = handler.testHandleIncomingMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Outgoing message handling should not have failed");
        }
		
		// Assert
        assertFalse("Handler shouldn't have allowed the message to be received", result);
	}
}
