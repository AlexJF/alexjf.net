package pt.ist.anacom.caserver;

import java.security.PublicKey;
import java.security.cert.CRLException;
import java.util.Map;
import java.util.TreeMap;

import javax.crypto.Cipher;

import pt.ist.anacom.security.managers.CASecurityManager;
import pt.ist.anacom.shared.exception.CAException;
import pt.ist.anacom.shared.stubs.CAException_Exception;
import pt.ist.anacom.shared.stubs.CaPortType;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import sun.security.x509.X509CRLImpl;
import sun.security.x509.X509CertImpl;


/**
 * This class implements a CAPortType. Therefore it implements all logic
 * related to the Certification Authority.
 */
@javax.jws.WebService(endpointInterface = "pt.ist.anacom.shared.stubs.CaPortType", wsdlLocation = "/ca.wsdl", name = "CaPortType", portName = "CaPort", targetNamespace = "http://ca.anacom.ist.pt/", serviceName = "CaService")
@javax.jws.HandlerChain(file = "handler-chain.xml")
public class CaServiceImpl implements CaPortType {

	private Map<String, X509CertImpl> _map = new TreeMap<String, X509CertImpl>();
	private int serialNumber;
	private BASE64Decoder b64d = new BASE64Decoder();
	private BASE64Encoder b64e = new BASE64Encoder();

	protected CASecurityManager getSecurityManager() {
		return CASecurityManager.getInstance();
	}

	public CaServiceImpl() {
		serialNumber = 1;
	}

	@Override
	public synchronized String createCertificate(String publicKey, String app)
			throws CAException_Exception {
		try {
			CASecurityManager sm = getSecurityManager();
            byte[] publicKeyBytes = b64d.decodeBuffer(publicKey);
			X509CertImpl cert = CertificateFactory.createCertificate(publicKeyBytes, app, sm.getName(), sm.getPrivateKey(), serialNumber++);

			_map.put(app, cert);

			return b64e.encode(cert.getEncoded());
		} catch (Exception e) {
            e.printStackTrace();
			throw new CAException_Exception(e.getMessage());
		}
	}

	@Override
	public synchronized void revokeCertificate(String certificate, String challenge)
			throws CAException_Exception {
		try {
			X509CertImpl toRevoke = new X509CertImpl(
					b64d.decodeBuffer(certificate));
			String dn = toRevoke.getSubjectDN().getName();
            PublicKey kp = toRevoke.getPublicKey();
			String subject = getCommonNameFromDN(dn);

			Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
			cipher.init(Cipher.DECRYPT_MODE, kp);

			String decipheredChallenge = new String(cipher.doFinal(b64d.decodeBuffer(challenge)));

            if (!decipheredChallenge.equals("ZOMG TEH LEGIT!!!")) {
                throw new Exception("You cannot revoke other people's certificates!");
            }
			
			if (_map.containsKey(subject)) {
				X509CertImpl cert = _map.get(subject);
				if (cert.getSerialNumber().equals(toRevoke.getSerialNumber())) {
					_map.remove(subject);
					getSecurityManager().addToBlackList(toRevoke);
				} else {
					throw new CAException("Could not find the provided certificate.");
				}
			} else {
				throw new Exception("The CA has no certificates associated with the subject of the provided certificate.");
			}
		} catch (Exception e) {
			throw new CAException_Exception(e.getMessage());
		}

	}

	@Override
	public synchronized String getBlackList() throws CAException_Exception {
		X509CRLImpl crl = getSecurityManager().getBlackList();
		try {
			return b64e.encode(crl.getEncoded());
		} catch (CRLException e) {
			throw new CAException_Exception(e.getMessage());
		}
	}

    @Override
    public void testCommand(String command) {
        System.out.println("Received test command: " + command);
        if (command.equals("clear")) {
            System.out.println("Clearing CA server");
            getSecurityManager().clearBlackList();
            _map.clear();
            serialNumber = 1;
        }
        else if (command.equals("clearPS")) {
            System.out.println("Clearing all entries of the PS on the CA server");
            _map.remove("PS");
        } else if (command.equals("printBL")) {
			System.out.println("Printing blacklist");
			System.out.println(getSecurityManager().getBlackList());
		} else if (command.equals("printCL")) {
			System.out.println("Printing certificate list");
			for (X509CertImpl cert : _map.values()) {
				System.out.println(cert);
			}
		}
    };
    
    
    /**
     * Retrieves the common name from a DN string.
     * @param dn The common name.
     * @return
     */
	private String getCommonNameFromDN(String dn) {
		String cn = dn.substring(dn.indexOf('=') + 1, dn.indexOf(','));
		return cn;
	}
}
