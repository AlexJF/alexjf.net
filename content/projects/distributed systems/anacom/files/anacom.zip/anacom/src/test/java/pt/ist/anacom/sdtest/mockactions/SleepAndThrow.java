package pt.ist.anacom.sdtest.mockactions;

import org.hamcrest.Description;

import org.jmock.api.Action;
import org.jmock.api.Invocation;

public class SleepAndThrow<T extends Exception> implements Action {
    private T throwValue;
    private int sleepTime;
    
    public SleepAndThrow(int sleepTime, T throwValue) {
        this.throwValue = throwValue;
        this.sleepTime = sleepTime;
    }
    
    public void describeTo(Description description) {
        description.appendText("sleeps for " + sleepTime + "seconds ")
                   .appendText(" and then returns the specified value");
    }
    
    public Object invoke(Invocation invocation) throws Throwable {
        Thread.sleep(sleepTime * 1000);
        throw throwValue;
    }

    public static <T extends Exception> Action sleepAndThrow(int sleepTime, T throwValue) {
        return new SleepAndThrow<T>(sleepTime, throwValue);
    }
}
