package pt.ist.anacom.estest;

import java.math.BigDecimal;

import java.util.Set;

import org.junit.AfterClass;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.CellPhone2G;
import pt.ist.anacom.domain.CellPhone3G;
import pt.ist.anacom.domain.CellPhoneBusyState;
import pt.ist.anacom.domain.CellPhoneOffState;
import pt.ist.anacom.domain.CellPhoneOnState;
import pt.ist.anacom.domain.CellPhoneSilenceState;
import pt.ist.anacom.domain.CellPhoneState;
import pt.ist.anacom.domain.Communication;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.domain.NonImmediateCommunication;
import pt.ist.anacom.domain.SMS;
import pt.ist.anacom.domain.Video;
import pt.ist.anacom.domain.Voice;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto.CellPhoneStates;

import pt.ist.fenixframework.Config;
import pt.ist.fenixframework.FenixFramework;

import pt.ist.fenixframework.pstm.repository.Repository;

import pt.ist.fenixframework.pstm.Transaction;

import junit.framework.TestCase;

public abstract class AnacomTestCase extends TestCase {
	static {
		if (FenixFramework.getConfig() == null) {
			FenixFramework.initialize(new Config() {
				{
					dbAlias = "test-db";
					domainModelPath = "src/main/dml/anacom.dml";
					repositoryType = RepositoryType.BERKELEYDB;
					rootClass = AnacomNetwork.class;
				}
			});
		}
	}

	protected AnacomTestCase(String msg) {
		super(msg);
	}

	protected AnacomTestCase() {
		super();
	}

	protected void setUp() {
		cleanNetwork();
	}

	protected void tearDown() {
		cleanNetwork();
	}

	protected void cleanNetwork() {
		boolean committed = false;
		try {
			Transaction.begin();
			AnacomNetwork network = FenixFramework.getRoot();
			Set<NetworkOperator> allOperators = network.getNetworkOperatorSet();
			allOperators.clear();
			Transaction.commit();
			committed = true;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not clean network");
			}

		}
	}

	@AfterClass
	public void closeDatabase() {
		Repository rep = Repository.getRepository();
		rep.closeRepository();
	}

	/*
	 * ################## # OPERATOR FUNCS # ##################
	 */
	protected NetworkOperator getOperatorByName(String operatorName) {
		boolean committed = false;
		NetworkOperator operator;

		try {
			Transaction.begin();
			AnacomNetwork network = FenixFramework.getRoot();
			operator = network.getNetworkOperatorByName(operatorName);
			Transaction.commit();
			committed = true;
			return operator;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not check operator existence");
			}
		}
	}

	protected NetworkOperator getOperatorByPrefix(String operatorPrefix) {
		boolean committed = false;
		NetworkOperator operator;

		try {
			Transaction.begin();
			AnacomNetwork network = FenixFramework.getRoot();
			operator = network.getNetworkOperatorByPrefix(operatorPrefix);
			Transaction.commit();
			committed = true;
			return operator;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not check operator existence");
			}
		}
	}

	protected boolean hasOperatorWithData(String operatorName,
			String operatorPrefix, int smsCost, int voiceCost, int videoCost,
			BigDecimal tax) {
		boolean committed = false;
		boolean result = false;

		try {
			Transaction.begin();
			AnacomNetwork network = FenixFramework.getRoot();
			for (NetworkOperator operator : network.getNetworkOperatorSet()) {
				if (operator.getName().equals(operatorName)
						&& operator.getPrefix().equals(operatorPrefix)
						&& operator.getCostSMS() == smsCost
						&& operator.getCostVoice() == voiceCost
						&& operator.getCostVideo() == videoCost
						&& operator.getTax().equals(tax)) {
					result = true;
				}
			}
			Transaction.commit();
			committed = true;
			return result;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not check operator existence");
			}
		}
	}

	protected NetworkOperator addOperator(String operatorName,
			String operatorPrefix) {
		boolean committed = false;
		NetworkOperator operator = null;

		try {
			Transaction.begin();
			AnacomNetwork network = FenixFramework.getRoot();
			operator = new NetworkOperator(operatorName, operatorPrefix);
			network.addNetworkOperator(operator);
			Transaction.commit();
			committed = true;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add new operator: " + operatorName + " ("
						+ operatorPrefix + ")");
			}
		}

		return operator;
	}

	protected NetworkOperator addOperator(String operatorName,
			String operatorPrefix, int voiceCost, int videoCost, int smsCost,
			BigDecimal tax) {
		boolean committed = false;
		NetworkOperator operator = null;

		try {
			Transaction.begin();
			AnacomNetwork network = FenixFramework.getRoot();
			operator = new NetworkOperator(operatorName, operatorPrefix);
			operator.setCostVoice(voiceCost);
			operator.setCostVideo(videoCost);
			operator.setCostSMS(smsCost);
			operator.setTax(tax);
			network.addNetworkOperator(operator);
			Transaction.commit();
			committed = true;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add new operator: " + operatorName + " ("
						+ operatorPrefix + ")");
			}
		}

		return operator;
	}

	protected NetworkOperator addOperator(String operatorName,
			String operatorPrefix, int voiceCost, int videoCost, int smsCost,
			BigDecimal tax, BigDecimal bonus) {
		boolean committed = false;
		NetworkOperator operator = null;

		try {
			Transaction.begin();
			AnacomNetwork network = FenixFramework.getRoot();
			operator = new NetworkOperator(operatorName, operatorPrefix);
			operator.setCostVoice(voiceCost);
			operator.setCostVideo(videoCost);
			operator.setCostSMS(smsCost);
			operator.setTax(tax);
			operator.setBonus(bonus);
			network.addNetworkOperator(operator);
			Transaction.commit();
			committed = true;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add new operator: " + operatorName + " ("
						+ operatorPrefix + ")");
			}
		}

		return operator;
	}

	protected int getNumberOfOperators() {
		boolean committed = false;
		int res;

		try {
			Transaction.begin();
			AnacomNetwork network = FenixFramework.getRoot();
			res = network.getNetworkOperatorCount();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not count operators on network");
			}
		}
	}

	protected int getOperatorCostSMS(NetworkOperator operator) {
		boolean committed = false;
		int res;

		try {
			Transaction.begin();
			res = operator.getCostSMS();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not get operator sms cost");
			}
		}
	}

	protected int getOperatorCostVideo(NetworkOperator operator) {
		boolean committed = false;
		int res;

		try {
			Transaction.begin();
			res = operator.getCostVideo();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not get operator video cost");
			}
		}
	}

	protected int getOperatorCostVoice(NetworkOperator operator) {
		boolean committed = false;
		int res;

		try {
			Transaction.begin();
			res = operator.getCostVoice();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not get operator voice cost");
			}
		}
	}

	protected BigDecimal getOperatorTax(NetworkOperator operator) {
		boolean committed = false;
		BigDecimal res;

		try {
			Transaction.begin();
			res = operator.getTax();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not get operator tax");
			}
		}
	}

	/*
	 * ############### # PHONE FUNCS # ###############
	 */
	protected CellPhone getCellPhoneByNumber(NetworkOperator operator,
			String number) {
		boolean committed = false;
		CellPhone phone;

		try {
			Transaction.begin();
			phone = operator.getCellPhone(number);
			Transaction.commit();
			committed = true;
			return phone;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not check cellphone existence");
			}
		}
	}

	protected CellPhone2G addCellPhone2G(NetworkOperator operator,
			String number, int balance) {
		boolean committed = false;
		CellPhone2G phone = null;
		try {
			Transaction.begin();
			phone = new CellPhone2G(number, balance);
			phone.setCellPhoneState(new CellPhoneOnState());
			operator.addCellPhone(phone);
			Transaction.commit();
			committed = true;
		} catch (Exception e) {
			System.out.println("Error: " + e.getLocalizedMessage());
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add new cellphone");
			}
		}

		return phone;
	}

	protected CellPhone3G addCellPhone3G(NetworkOperator operator,
			String number, int balance) {
		boolean committed = false;
		CellPhone3G phone = null;
		try {
			Transaction.begin();
			phone = new CellPhone3G(number, balance);
			phone.setCellPhoneState(new CellPhoneOnState());
			operator.addCellPhone(phone);
			Transaction.commit();
			committed = true;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add new cellphone: ");
			}
		}

		return phone;
	}

	protected void removeCellPhone(NetworkOperator operator, String number) {
		boolean committed = false;
		try {
			Transaction.begin();
			operator.removeCellPhone(operator.getCellPhone(number));
			Transaction.commit();
			committed = true;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not remove cellphone: " + number + " on operator: "
						+ operator);
			}
		}
	}

	protected int getNumberOfCellPhones(NetworkOperator operator) {
		boolean committed = false;
		int res;

		try {
			Transaction.begin();
			res = operator.getCellPhoneCount();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not count cellphones on operator");
			}
		}
	}

	protected int getCellPhoneBalance(CellPhone phone) {
		boolean committed = false;
		int res;

		try {
			Transaction.begin();
			res = phone.getBalance();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not determine cellphone balance");
			}
		}
	}

    protected boolean isCellPhoneOn(CellPhone phone) {
		boolean committed = false;
        boolean res = false;;

		try {
			Transaction.begin();
			res = phone.getCellPhoneState() instanceof CellPhoneOnState;
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not determine cellphone balance");
			}
		}
    }

	/*
	 * ############### # STATE FUNCS # ###############
	 */
	protected void turnCellPhoneSilent(CellPhone phone) {
		boolean committed = false;

		try {
			Transaction.begin();
			phone.turnSilence();
			Transaction.commit();
			committed = true;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not determine number of outgoing communications for cellphone");
			}
		}
	}

	protected void turnCellPhoneBusy(CellPhone phone) {
		boolean committed = false;

		try {
			Transaction.begin();
			phone.turnBusy();
			Transaction.commit();
			committed = true;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not determine number of outgoing communications for cellphone");
			}
		}
	}

	protected CellPhoneStates getCellPhoneState(CellPhone phone) {
		boolean committed = false;
		CellPhoneStates res;

		try {
			Transaction.begin();
			res = convertFromState(phone.getCellPhoneState());
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not determine cell phone state for cellphone");
			}
		}
	}

	private CellPhoneStates convertFromState(CellPhoneState state) {
		if (state instanceof CellPhoneOnState) {
			return CellPhoneStates.On;
		} else if (state instanceof CellPhoneOffState) {
			return CellPhoneStates.Off;
		} else if (state instanceof CellPhoneSilenceState) {
			return CellPhoneStates.Silent;
		} else if (state instanceof CellPhoneBusyState) {
			return CellPhoneStates.Busy;
		} else {
			return null;
		}
	}

	protected void turnCellPhoneOff(CellPhone phone) {
		boolean committed = false;

		try {
			Transaction.begin();
			phone.turnOff();
			Transaction.commit();
			committed = true;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not determine number of outgoing communications for cellphone");
			}
		}
	}

	/*
	 * ######################## # COMMUNICATIONS FUNCS #
	 * ########################
	 */
	protected int getNumberOfOutgoingCommunications(CellPhone phone) {
		boolean committed = false;
		int res;

		try {
			Transaction.begin();
			res = phone.getOutgoingCommunicationCount();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not determine number of outgoing communications for cellphone");
			}
		}
	}

	protected int getNumberOfIncomingCommunications(CellPhone phone) {
		boolean committed = false;
		int res;

		try {
			Transaction.begin();
			res = phone.getIncomingCommunicationCount();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not determine number of incoming communications for cellphone");
			}
		}
	}

	protected boolean checkHasIncomingCommunicationTo(CellPhone phone,
			String sourceNumber) {
		boolean committed = false;
		boolean res = false;

		try {
			Transaction.begin();
			for (Communication comm : phone.getIncomingCommunicationSet()) {
				if (comm.getSourceNumber().equals(sourceNumber)) {
					res = true;
					break;
				}
			}
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not check incoming communications of cellphone");
			}
		}
	}

	protected boolean checkHasOutgoingCommunicationTo(CellPhone phone,
			String destinationNumber) {
		boolean committed = false;
		boolean res = false;

		try {
			Transaction.begin();
			for (Communication comm : phone.getOutgoingCommunicationSet()) {
				if (comm.getDestinationNumber().equals(destinationNumber)) {
					res = true;
					break;
				}
			}
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not check outgoing communications of cellphone");
			}
		}
	}

    protected NonImmediateCommunication getActiveCommunication(CellPhone phone) {
		boolean committed = false;
		NonImmediateCommunication res = null;

		try {
			Transaction.begin();
            res = phone.getActiveCommunication();
			Transaction.commit();
			committed = true;
			return res;
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not check outgoing communications of cellphone");
			}
		}
    }

	protected SMS addIncomingSMS(CellPhone phone, String sourceNumber,
			String message) {
		boolean committed = false;
		SMS res = null;

		try {
			Transaction.begin();
			res = new SMS(sourceNumber, phone.getNumber(), message);
			phone.getNetworkOperator().receiveCommunication(res);
			Transaction.commit();
			committed = true;
			return res;
		} catch (Exception e) {
			System.out.println("Error: " + e.getLocalizedMessage());
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add incoming communication to cellphone");
			}
		}
		return res;
	}

	protected SMS addOutgoingSMS(CellPhone phone, String destinationNumber,
			String message) {
		boolean committed = false;
		SMS res = null;

		try {
			Transaction.begin();
			res = new SMS(phone.getNumber(), destinationNumber, message);
			phone.getNetworkOperator().establishCommunication(res);
			Transaction.commit();
			committed = true;
			return res;
		} catch (Exception e) {
			System.out.println("Error: " + e.getLocalizedMessage());
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add outgoing communication to cellphone");
			}
		}
		return res;
	}

	protected Voice addIncomingVoice(CellPhone phone, String sourceNumber) {
		boolean committed = false;
		Voice res = null;

		try {
			Transaction.begin();
			res = new Voice(sourceNumber, phone.getNumber());
			phone.getNetworkOperator().receiveCommunication(res);
			Transaction.commit();
			committed = true;
			return res;
		} catch (Exception e) {
			System.out.println("Error: " + e.getLocalizedMessage());
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add incoming communication to cellphone");
			}
		}
		return res;
	}

	protected Voice addOutgoingVoice(CellPhone phone, String destinationNumber) {
		boolean committed = false;
		Voice res = null;

		try {
			Transaction.begin();
			res = new Voice(phone.getNumber(), destinationNumber);
			phone.getNetworkOperator().establishCommunication(res);
			Transaction.commit();
			committed = true;
			return res;
		} catch (Exception e) {
			System.out.println("Error: " + e.getLocalizedMessage());
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add outgoing communication to cellphone");
			}
		}
		return res;
	}

	protected Video addIncomingVideo(CellPhone phone, String sourceNumber) {
		boolean committed = false;
		Video res = null;

		try {
			Transaction.begin();
			res = new Video(sourceNumber, phone.getNumber());
			phone.getNetworkOperator().receiveCommunication(res);
			Transaction.commit();
			committed = true;
			return res;
		} catch (Exception e) {
			System.out.println("Error: " + e.getLocalizedMessage());
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add incoming communication to cellphone");
			}
		}
		return res;
	}

	protected Video addOutgoingVideo(CellPhone phone, String destinationNumber) {
		boolean committed = false;
		Video res = null;

		try {
			Transaction.begin();
			res = new Video(phone.getNumber(), destinationNumber);
			phone.getNetworkOperator().establishCommunication(res);
			Transaction.commit();
			committed = true;
			return res;
		} catch (Exception e) {
			System.out.println("Error: " + e.getLocalizedMessage());
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not add outgoing communication to cellphone");
			}
		}
		return res;
	}

    protected int getCommunicationDuration(NonImmediateCommunication comm) {
		boolean committed = false;
		int res = 0;

		try {
			Transaction.begin();
			res = comm.getDuration();
			Transaction.commit();
			committed = true;
			return res;
		} catch (Exception e) {
			System.out.println("Error: " + e.getLocalizedMessage());
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not get communication duration");
			}
		}
		return res;
    }

    protected int getCommunicationCost(Communication comm) {
		boolean committed = false;
		int res = 0;

		try {
			Transaction.begin();
			res = comm.getCost();
			Transaction.commit();
			committed = true;
			return res;
		} catch (Exception e) {
			System.out.println("Error: " + e.getLocalizedMessage());
		} finally {
			if (!committed) {
				Transaction.abort();
				fail("Could not get communication duration");
			}
		}
		return res;
    }
}
