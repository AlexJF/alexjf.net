package pt.ist.anacom.replication;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import pt.ist.anacom.service.bridge.RemoteOperator;

import pt.ist.anacom.shared.exception.OperatorNotExistsException;

import pt.ist.anacom.shared.Timestamped;
import pt.ist.anacom.shared.UDDIHelper;
import pt.ist.anacom.shared.dto.AnacomDto;

import pt.ist.anacom.shared.exception.AnacomException;

import java.util.Collections;
import java.util.concurrent.Semaphore;

/**
 * This class manages the requests to be made to the server.
 * It implements the client side of the distribution algorithm
 * developed.
 * The class takes finds the replicas of the operator, sends them
 * the request and waits for an answer.
 */
public class PresentationReplicationManager {
	
	/** The quorum size we want to have. */
	private int _quorumSize;
	
	/** Map that associates an operator with a timestamp. */ 
	private Map<String, Integer> _timeStamps;

	/**
	 * Creates an instance of PresentationReplicationManager.
	 * 
	 * @param quorumSize size of the quorum we want.
	 */
	public PresentationReplicationManager(int quorumSize) {
		_quorumSize = quorumSize;
		_timeStamps = Collections.synchronizedMap(new HashMap<String, Integer>());
	}

	/**
	 * This method allows us to get the current timestamp of an operator.
	 * It asks every replica of the operator for its timestamp in order
	 * to get that information.
	 * 
	 * @param operatorName Name of the operator whose timestamp we want to know.
	 * @return The timestamp of the given operator.
	 */
	protected Integer getTimestamp(String operatorName) {

		Integer timestamp = _timeStamps.get(operatorName);

		if (timestamp == null) {
			AnacomDto timestampDto = 
					internalSendRequestToReplicas(operatorName, 
							new AnacomDto(), 
							new TimestampServiceFunction());
			timestamp = timestampDto.getTimestamp();
			_timeStamps.put(operatorName, timestamp);
		}

		return timestamp;
	}

	/**
	 * Sets the timestamp of a given operator.
	 * 
	 * @param operatorName Name of the operator whose timestamp
	 * 					   we are going to set.
	 * @param timestamp The timestamp of the operator.
	 */
	protected void setTimestamp(String operatorName, Integer timestamp) {
		_timeStamps.put(operatorName, timestamp);
	}

	/**
	 * This class represents a service function that asks an operator for its
	 * timestamp.
	 */
	private class TimestampServiceFunction implements PresentationServiceFunction<AnacomDto, AnacomDto> {
		@Override
        public AnacomDto execute(RemoteOperator operator,  AnacomDto dto) {
            return operator.getTimestamp(dto);
        }
	}

	/**
	 * Returns the replicas of a given operator, using the UDDI server.
	 * 
	 * @param operatorName Name of the operator whose replicas we want to get.
	 * @return The replicas of a given operator.
	 */
	protected List<RemoteOperator> getReplicasForOperator(String operatorName) {
        return UDDIHelper.getSingleton().getRemoteOperatorsFromOperatorName(operatorName);
	}

	/**
	 * Sends a request to all the replicas of a given operator and waits
	 * for a quorum to decide the answer.
	 * 
	 * @param operatorName Name of the operator.
	 * @param dto containing the information needed by the service to be executed.
	 * @param serviceFunction containing the information about the service to be executed.
	 * @return the result of executing the service.
	 */
	public synchronized <I extends AnacomDto, O extends AnacomDto> O sendRequestToReplicas(
			String operatorName, I dto, PresentationServiceFunction<I, O> serviceFunction) {
	
		// Set the request dto timestamp to the current timestamp + 1
		dto.setTimestamp(getTimestamp(operatorName) + 1);
	
	    return internalSendRequestToReplicas(operatorName, dto, serviceFunction);
	}

	/**
	 * Sends a request to all the replicas of a given operator and waits
	 * for a quorum to decide the answer.
	 * 
	 * @param operatorName Name of the operator.
	 * @param dto containing the information needed by the service to be executed.
	 * @param serviceFunction containing the information about the service to be executed.
	 * @return the result of executing the service.
	 */
	protected <I extends AnacomDto, O extends AnacomDto> O internalSendRequestToReplicas(
			String operatorName, I dto, PresentationServiceFunction<I, O> serviceFunction) {
		
		// Initiate semaphore and result/exception lists
		Semaphore sem = new Semaphore(0);

		// List containing the results from each replica
		List<O> resultList = Collections.synchronizedList(new LinkedList<O>());

		// List containing the exceptions thrown by the replicas as result
		List<AnacomException> exceptionList = 
				Collections.synchronizedList(new LinkedList<AnacomException>());

        // Get an array of replicas for the specified operator name
        List<RemoteOperator> replicas = getReplicasForOperator(operatorName);

        if (replicas == null || replicas.size() < _quorumSize) {
            throw new OperatorNotExistsException(operatorName);
        }

        // Used by the threads to terminate
        Boolean foundQuorum = false;

        // Start threads to send requests to all replicas
        for (RemoteOperator replica : replicas) {
            Thread replicationThread = new ReplicationThread<I, O>(replica,
                    dto, serviceFunction, resultList, exceptionList, sem, foundQuorum);
            replicationThread.start();
        }

        try {
            // Wait for a quorum
            sem.acquire(_quorumSize);
            synchronized(foundQuorum) {
                foundQuorum = true;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        }
        
        return analyseQuorumResponses(resultList, exceptionList, operatorName);
    }

	/**
	 * Analyses the quorum responses.
	 * Throws a runtime exception if the final answer is an exception
	 * or returns an AnacomDto if the final answer is a dto.
	 * 
	 * @param resultList
	 * @param exceptionList
	 * @param operatorName
	 * @return
	 */
	private <O extends AnacomDto> O analyseQuorumResponses(
			List<O> resultList, List<AnacomException> exceptionList, String operatorName) {
				
        // Used to store the frequency of each non exception result
        Map<O, Integer> resultsFrequency = new HashMap<O, Integer>();
        
        // Used to store the frequency of each exception caught
        Map<AnacomException, Integer> exceptionsFrequency = new HashMap<AnacomException, Integer>();
        
        // Used to store the dtos and its frequency received in an ordered manner
        List<Map.Entry<O, Integer>> orderedResults;
        
        // Used to store the exceptions and its frequency received in an ordered manner
        List<Map.Entry<AnacomException, Integer>> orderedExceptions;
		
        // This variable is used if the final answer is a Dto
        O finalResult = null;
        
        resultsFrequency = calculateFrequencies(resultList);
        exceptionsFrequency = calculateFrequencies(exceptionList);
        
        orderedResults = getOrderedFrequencyList(resultsFrequency);
		orderedExceptions = getOrderedFrequencyList(exceptionsFrequency);
		
		finalResult = findAnswer(orderedResults, orderedExceptions, operatorName);
        
        return finalResult;
	}
	
	/**
	 * Returns an ordered list of timestamped objects.
	 * The ordination takes in account the timestamp of the object
	 * and their frequency.
	 * 
	 * @param timestampedFrequencies Map with the frequecies of the timestamped objects.
	 * @return A list with the orderd timestamped objects.
	 */
	private <O extends Timestamped> List<Map.Entry<O, Integer>> getOrderedFrequencyList(Map<O, Integer> timestampedFrequencies) {
	    Set<Map.Entry<O, Integer>> timestampedsSet = timestampedFrequencies.entrySet();
	    List<Map.Entry<O, Integer>> orderedTimestampeds = 
	    		new LinkedList<Map.Entry<O, Integer>>(timestampedsSet);
	    
	    Collections.sort(orderedTimestampeds, new Comparator<Map.Entry<O, Integer>>() {
	
			@Override
			public int compare(Entry<O, Integer> arg0,
					Entry<O, Integer> arg1) {
				
				if (arg0.getValue().equals(arg1.getValue())) {
					return -1 * arg0.getKey().getTimestamp().compareTo(arg1.getKey().getTimestamp());
				} else {
					return -1 * arg0.getValue().compareTo(arg1.getValue());
				}
			}
	    });
	
	    return orderedTimestampeds;
	}

	/**
	 * Calculates the frequencies of a given object
	 * in a given list.
	 * 
	 * @param resultList The list with the objects whose frequency we want to calculate.
	 * @return A map with each object associated with its frequency.
	 */
	private <I> Map<I, Integer> calculateFrequencies(List<I> resultList) {
		
		Map<I, Integer> frequencies = new HashMap<I, Integer>();
		
	    synchronized(resultList) {
	        // Find dto associated with biggest timestamp
	        for (I result : resultList) {
	         
	            Integer mapResultFrequency = (Integer) frequencies.get(result);
	            if (mapResultFrequency == null) {
	            	// if we enter here this dto isnt in the map yet
	            	frequencies.put(result, 1);
	            } else {
	            	// if we enter here, this dto is already in the map.
	            	// because of that we just need to increase its key.
	            	frequencies.put(result, mapResultFrequency + 1);
	            }
	        }
	    }
	    
	    return frequencies;
	}

	/**
	 * Calculates the final answer that the client should consider.
	 * Takes in account the distribution algorithm calculated.
	 * It throws an run time exception if the final answer is an exception
	 * or returns a dto if the final answer is a dto.
	 * 
	 * @param orderedResults An ordered list of the Dtos received.
	 * @param orderedExceptions An ordered list of the Exceptions received.
	 * @param operatorName The name of the operator whose replicas we are receiving answers.
	 * @return A dto if the final answer is a dto.
	 */
	private <O extends AnacomDto> O findAnswer(List<Map.Entry<O, Integer>> orderedResults, 
			List<Map.Entry<AnacomException, Integer>> orderedExceptions, String operatorName) {
		
        O finalResult = null;
        AnacomException finalException = null;
        int maxTimeStamp = 0;
		
		if (orderedResults.isEmpty()) {
        	// If we enter here, we are sure that the majority of the responses
        	// were an exception!
        	
        	finalException = orderedExceptions.get(0).getKey();
        	maxTimeStamp = orderedExceptions.get(0).getKey().getTimestamp();
        } else if (orderedExceptions.isEmpty()) {
        	// If we enter here, we are sure that the majority of the responses
        	// were a dto!
        	
        	finalResult = orderedResults.get(0).getKey();
        	maxTimeStamp = orderedResults.get(0).getKey().getTimestamp();
        } else { 
        
        	O mostFrequentDto = orderedResults.get(0).getKey();
        	Integer mostFrequentDtoFrequency = orderedResults.get(0).getValue();
        	AnacomException mostFrequentException = orderedExceptions.get(0).getKey();
        	Integer mostFrequentExceptionFrequency = orderedExceptions.get(0).getValue();
        	
	        if (mostFrequentDtoFrequency > mostFrequentExceptionFrequency) {
	        	finalResult = mostFrequentDto;
	        	maxTimeStamp = mostFrequentDto.getTimestamp();
	        } else if (mostFrequentDtoFrequency < mostFrequentExceptionFrequency) {
	        	finalException = mostFrequentException;
	        	maxTimeStamp = mostFrequentException.getTimestamp();
	        } else if (mostFrequentDto.getTimestamp().equals(mostFrequentException.getTimestamp()))
	        {
	        	// throw ARSENINEEXCEPTION()
	        } else if (mostFrequentDto.getTimestamp() > mostFrequentException.getTimestamp()) {
	        	finalResult = mostFrequentDto;
	        	maxTimeStamp = mostFrequentDto.getTimestamp();
	        } else {
	        	finalException = mostFrequentException;
	        	maxTimeStamp = mostFrequentException.getTimestamp();
	        }
        }
		
        // Update our local timestamp
        setTimestamp(operatorName, maxTimeStamp);
        
        // If we found an exception with a bigger timestamp, throw it
        if (finalException != null) {
            finalException.throwYourself();
        }
        
        return finalResult;
	}
	
	/**
	 * This class is used by the send request to replicas mechanism of the
	 * distribution algorithm.
	 * Each threads makes the request to a replica and waits for an answer,
	 * returning as soon as they get one.
	 *
	 * @param <I> The type of Dto the service receives.
	 * @param <O> The return type of Dto that the service returns.
	 */
	private static class ReplicationThread<I, O> extends Thread {
		
		/** The replica to which the thread will make the request. */
		RemoteOperator _replica;
		
		/** 
		 * Service function containing the information of the service
		 * to be executed.
		 */
		PresentationServiceFunction<I, O> _serviceFunction;
		
		/**
		 * The Dto containing information needed by the service to be
		 * executed.
		 */
		I _dto;
		
		/** List where to put the result (if any). */
		List<O> _resultList;
		/** List where to put the exception caught (if any) */
		List<AnacomException> _exceptionList;
		Semaphore _sem;
        Boolean _foundQuorum;

		public ReplicationThread(RemoteOperator replica, I dto,
				PresentationServiceFunction<I, O> serviceFunction, List<O> resultList,
				List<AnacomException> exceptionList, Semaphore sem, Boolean foundQuorum) {
			_replica = replica;
			_dto = dto;
			_serviceFunction = serviceFunction;
			_resultList = resultList;
			_exceptionList = exceptionList;
			_sem = sem;
            _foundQuorum = foundQuorum;
		}

		@Override
		public void run() {
			O result = null;
			AnacomException exception = null;
			
			try {
                result = _serviceFunction.execute(_replica, _dto);
			} catch (AnacomException e) {
				exception = e;
			} catch (Exception e) {
				// Print something but don't add it to the exception list.
                System.out.println(e.getMessage());
				return;
			}

            // If we already found a quorum, just quit
            synchronized(_foundQuorum) {
                if (_foundQuorum) {
                    return;
                }
            }

            if (exception != null) {
				_exceptionList.add(exception);
			} else {
				_resultList.add(result);
			}

			// If we got this far we added something to one of the lists so
			// signal the semaphore
			// that we got a succesful replica response
			_sem.release();
		}
	}
}
