package pt.ist.anacom.domain;

import pt.ist.anacom.shared.CommunicationVisitor;

/**
 * This class represents a SMS communication type.
 */
public class SMS extends SMS_Base {

	/**
	 * Build an instance of a SMS communication type.
	 */
	public SMS(String sourceNumber, String destinationNumber, String message) {
		super();
		init(sourceNumber, destinationNumber);
		setData(message);
	}

	@Override
	public int calculateCost() {
		return getSourceCellPhone().getNetworkOperator().calculateCost(this);
	}

	@Override
	public void accept(CommunicationVisitor visitor) {
		visitor.visit(this);
	}
}
