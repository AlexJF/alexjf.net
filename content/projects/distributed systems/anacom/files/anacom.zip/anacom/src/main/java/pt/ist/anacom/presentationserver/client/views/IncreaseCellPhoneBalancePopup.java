package pt.ist.anacom.presentationserver.client.views;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;

import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;

import pt.ist.anacom.presentationserver.client.Anacom;

public class IncreaseCellPhoneBalancePopup extends DialogBox {

	final private TextBox txtIncreaseAmount = new TextBox();

	public IncreaseCellPhoneBalancePopup(final Anacom parent) {
		super();

		setGlassEnabled(true);
		setAnimationEnabled(true);

		setText("Increase CellPhone Balance");

		HorizontalPanel horizontalPanel = new HorizontalPanel();
		setWidget(horizontalPanel);

		Label lblIncreaseAmount = new Label("Increase Amount (cents): ");
		horizontalPanel.add(lblIncreaseAmount);

		horizontalPanel.add(txtIncreaseAmount);

		Button btnOk = new Button("OK", new ClickHandler() {
			public void onClick(ClickEvent event) {
				parent.increasePhoneBalance(Integer.parseInt(txtIncreaseAmount
						.getText()));
				hide();
			}
		});
		horizontalPanel.add(btnOk);
	}

	@Override
	public void show() {
		txtIncreaseAmount.setText("0");
		super.show();
	}
}
