package pt.ist.anacom.integrationtest;

import java.util.List;

import pt.ist.anacom.estest.AnacomTestCase;

import junit.framework.TestCase;
import pt.ist.anacom.replication.RemoteReplicatedServer;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto.CellPhoneStates;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto.CommunicationType;
import pt.ist.anacom.shared.dto.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.dto.SMSDto;

import pt.ist.anacom.shared.UDDIHelper;

public class IntegrationTest extends TestCase {
	RemoteReplicatedServer rrs = new RemoteReplicatedServer();

	private static String OPERATOR_NAME_BASE = "Vodafona";

	private static String CELL_NUMBER1 = "911234567";
	private static String CELL_NUMBER2 = "912345678";
	private static int CELL_BALANCE = 200;
	private static int CELL_BALANCE_INCREASE = 50;
	private static int CALL_DURATION = 2;
    private static int OPERATOR_BONUS = 1;
	
	public IntegrationTest() {
		super();
	}

	public IntegrationTest(String msg) {
		super(msg);
	}

	protected void setUp() {
        UDDIHelper.getSingleton().getCA().testCommand("clear");
		rrs.testCommand(OPERATOR_NAME_BASE, "clear");
        try {
            Thread.sleep(3);
        } catch (Exception e) {
        }
	}
	
	public void testTheFinalTest() {
		// used in: get cell phone balance
		CellPhoneSimpleDto cellPhone1SimpleDto = new CellPhoneSimpleDto(CELL_NUMBER1);
		CellPhoneSimpleDto cellPhone2SimpleDto = new CellPhoneSimpleDto(CELL_NUMBER2);
		
		// used in: registration
		CellPhoneDetailedDto cellPhone1DetailedDto = new CellPhoneDetailedDto(OPERATOR_NAME_BASE, 
				CELL_NUMBER1, 
				CellPhoneDetailedDto.CellPhoneType.ThreeG,CELL_BALANCE);
		
		CellPhoneDetailedDto cellPhone2DetailedDto = new CellPhoneDetailedDto(OPERATOR_NAME_BASE, 
				CELL_NUMBER2, 
				CellPhoneDetailedDto.CellPhoneType.ThreeG,CELL_BALANCE);
		
		// used in: removal
		CellPhoneWithOperatorDto cellPhone1WithOperatorDto = new CellPhoneWithOperatorDto(OPERATOR_NAME_BASE, CELL_NUMBER1);
		
		// used in: get cell phone balance
		BalanceDto getCellPhoneBalanceBalanceDto;
		
		// used in: increase cell phone balance
		ChangeCellPhoneBalanceDto changeCellPhoneBalance;
		
		// used in: get cell phone state
		CellPhoneWithStateDto cellPhone1StateDto;
		CellPhoneWithStateDto cellPhone2StateDto;
		
		// used in: get cell phones balances
		NetworkOperatorSimpleDto VodafonaSimpleDto = new NetworkOperatorSimpleDto(OPERATOR_NAME_BASE);
		
		// used in: send sms
		SMSDto smsCell1ToCell2Dto = new SMSDto(CELL_NUMBER1, CELL_NUMBER2, "Hello");
		
		ListCellPhoneSMSDto cell2SMSListDto;
		
		CommunicationDetailsDto commDetailsDto;
		
		// used in: make voice call
		CallDto callCell1ToCell2Dto = new CallDto(CELL_NUMBER1, CELL_NUMBER2);
		
		// used in: make voice call, make video call
		CallWithDurationDto durationDto = new CallWithDurationDto(CELL_NUMBER1, CELL_NUMBER2, CALL_DURATION);
		
		// registration
		rrs.registerCellPhone(cellPhone1DetailedDto);
		try {
			rrs.registerCellPhone(cellPhone1DetailedDto);
			fail("Double cell phone registration! Exception should have been thrown.");
		} catch (Exception e) {
			// If we get here everything is fine!
		}

        System.out.println("ZEZE");
		
		rrs.registerCellPhone(cellPhone2DetailedDto);
		
		// remove cellphone
		rrs.removeCellPhone(cellPhone1WithOperatorDto);
        System.out.println("ZIZI");
		rrs.registerCellPhone(cellPhone1DetailedDto);
        System.out.println("ZUZU");
		
		// get cellphone balance
		getCellPhoneBalanceBalanceDto = rrs.getCellPhoneBalance(cellPhone1SimpleDto);
		assertEquals(CELL_BALANCE, getCellPhoneBalanceBalanceDto.getBalance());
		
		// increase cellphone balance
		changeCellPhoneBalance = 
				new ChangeCellPhoneBalanceDto(CELL_NUMBER1, CELL_BALANCE_INCREASE);
		rrs.increaseCellPhoneBalance(changeCellPhoneBalance);
		getCellPhoneBalanceBalanceDto = rrs.getCellPhoneBalance(cellPhone1SimpleDto);
		assertEquals(CELL_BALANCE + CELL_BALANCE_INCREASE * (1 + OPERATOR_BONUS), getCellPhoneBalanceBalanceDto.getBalance());
		
		// get cell phone state
		cellPhone1StateDto = rrs.getCellPhoneState(cellPhone1SimpleDto);
		assertEquals(CellPhoneWithStateDto.CellPhoneStates.Off, cellPhone1StateDto.getState());
		
		// set cell phone state
		cellPhone2StateDto = new CellPhoneWithStateDto(CELL_NUMBER2, CellPhoneStates.On);
		cellPhone1StateDto = new CellPhoneWithStateDto(CELL_NUMBER1, CellPhoneStates.On);
		rrs.changeCellPhoneState(cellPhone1StateDto);
		rrs.changeCellPhoneState(cellPhone2StateDto);
		
		assertEquals(rrs.getCellPhoneState(cellPhone1SimpleDto).getState(), CellPhoneStates.On);
		assertEquals(rrs.getCellPhoneState(cellPhone2SimpleDto).getState(), CellPhoneStates.On);
		
		// get Cell Phones Balances
		ListCellPhonesBalancesDto balancesDto = rrs.getCellPhonesBalances(VodafonaSimpleDto);
		assertEquals(2, balancesDto.getCellPhonesBalances().size());
        List<BalanceDto> balanceList = balancesDto.getCellPhonesBalances();

        for (BalanceDto balance : balanceList) {
            if (balance.getPhoneNumber().equals(CELL_NUMBER1)) {
                assertEquals(CELL_BALANCE + CELL_BALANCE_INCREASE * (1 + OPERATOR_BONUS), balance.getBalance());
            } else {
                assertEquals(CELL_BALANCE, balance.getBalance());
            }
        }
		
		// send sms
		rrs.sendSMS(smsCell1ToCell2Dto);
		cell2SMSListDto = rrs.getCellPhoneSMS(cellPhone2SimpleDto);
		commDetailsDto = rrs.getLastCommunicationDetails(cellPhone1SimpleDto);
		
		assertEquals(1, cell2SMSListDto.getCellPhonesSMS().size());
        SMSDto smsdto = cell2SMSListDto.getCellPhonesSMS().get(0);
        smsCell1ToCell2Dto.setTimestamp(smsdto.getTimestamp());
		assertEquals(smsCell1ToCell2Dto, smsdto);
		assertEquals(commDetailsDto.getType(), CommunicationType.SMS);
		
		// voice call
		rrs.establishVoiceCall(callCell1ToCell2Dto);
		rrs.terminateActiveCall(durationDto);
		commDetailsDto = rrs.getLastCommunicationDetails(cellPhone1SimpleDto);
		
		assertEquals("Source number is not the correct one", commDetailsDto.getSourceNumber(), CELL_NUMBER1);
		assertEquals("Destination numbers is not the correct one", commDetailsDto.getDestinationNumber(), CELL_NUMBER2);
		assertEquals("Communication type is not the correct one", commDetailsDto.getType(), CommunicationType.VOICE);
		assertEquals("Cost was deducted on wrong cell phone", CELL_BALANCE, rrs.getCellPhoneBalance(cellPhone2SimpleDto).getBalance());
		
		// video call
		rrs.establishVideoCall(callCell1ToCell2Dto);
		rrs.terminateActiveCall(durationDto);
		commDetailsDto = rrs.getLastCommunicationDetails(cellPhone1SimpleDto);
		
		assertEquals("Source number is not the correct one", commDetailsDto.getSourceNumber(), CELL_NUMBER1);
		assertEquals("Destination numbers is not the correct one", commDetailsDto.getDestinationNumber(), CELL_NUMBER2);
		assertEquals("Communication type is not the correct one", commDetailsDto.getType(), CommunicationType.VIDEO);
		assertEquals("Cost was deducted on wrong cell phone", CELL_BALANCE, rrs.getCellPhoneBalance(cellPhone2SimpleDto).getBalance());
		
	}	
}
