package pt.ist.anacom.shared;

import pt.ist.anacom.domain.SMS;
import pt.ist.anacom.domain.Voice;
import pt.ist.anacom.domain.Video;

/**
 * This abstract class defines a general interface for Communication Visitors.
 */
public abstract class CommunicationVisitor {
	public void visit(SMS sms) {
    }

	public void visit(Voice voice) {
    }

	public void visit(Video video) {
    }
}
