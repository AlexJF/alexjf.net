package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.fenixframework.FenixFramework;

/**
 * This class implements the get cell phone balance service.
 */
public class GetCellPhoneBalanceService extends AnacomService {

	/** The service Dto */
	private CellPhoneSimpleDto _dto;
	/** The value to return */
	private BalanceDto _balance;

	/**
	 * Creates a new instance of this service with information about the
	 * cellphone.
	 * 
	 * @param dto
	 *            Element with information about the cellphone whose balance we
	 *            wish to obtain.
	 */
	public GetCellPhoneBalanceService(CellPhoneSimpleDto dto) {
		_dto = dto;
	}

	@Override
	public void dispatch() throws CellPhoneNotExistsException {
		AnacomNetwork network = FenixFramework.getRoot();
		String cellPhoneNumber = _dto.getNumber();
		CellPhone cellPhone = network.getCellPhoneOrException(cellPhoneNumber);

		_balance = new BalanceDto(cellPhoneNumber, cellPhone.getBalance());
	}

	/**
	 * Get the dto containing the cell phone balance retrieved by the service.
	 * 
	 * @return Cell phone balance DTO.
	 */
	public final BalanceDto getCellPhoneBalance() {
		return _balance;
	}

}
