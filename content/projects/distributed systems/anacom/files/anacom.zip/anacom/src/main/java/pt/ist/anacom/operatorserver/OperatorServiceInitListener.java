package pt.ist.anacom.operatorserver;

import java.io.File;
import java.math.BigDecimal;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.replication.OperatorReplicationManager;
import pt.ist.anacom.security.managers.AnacomSecurityManager;
import pt.ist.anacom.service.CreateNetworkOperatorService;
import pt.ist.anacom.shared.UDDIHelper;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.exception.OperatorAlreadyExistsException;
import pt.ist.fenixframework.Config;
import pt.ist.fenixframework.FenixFramework;
import pt.ist.fenixframework.pstm.repository.Repository;

public class OperatorServiceInitListener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// codigo a executar antes de parar (undeploy) a aplicacao
		// oportunidade de libertar recursos se necessario
        pt.ist.fenixframework.pstm.TransactionChangeLogs.finalizeTransactionSystem();
		Repository rep = Repository.getRepository();
		rep.closeRepository();
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		try {
			ServletContext servletContext = arg0.getServletContext();
			final String dmlFilePath = servletContext.getRealPath("anacom.dml");
			String operatorName = servletContext
					.getInitParameter("operatorName");
			String operatorPrefix = servletContext
					.getInitParameter("operatorPrefix");
			String replicaNumber = servletContext
					.getInitParameter("replicaNumber");
			String bindingUrl = servletContext
					.getInitParameter("bindingUrl");
			int operatorSMSCost = Integer.parseInt(servletContext
					.getInitParameter("operatorSMSCost"));
			int operatorVoiceCost = Integer.parseInt(servletContext
					.getInitParameter("operatorVoiceCost"));
			int operatorVideoCost = Integer.parseInt(servletContext
					.getInitParameter("operatorVideoCost"));
			BigDecimal operatorTax = new BigDecimal(
					servletContext.getInitParameter("operatorTax"));
			BigDecimal operatorBonus = new BigDecimal(
					servletContext.getInitParameter("operatorBonus"));
            boolean activateSecurity = servletContext.getInitParameter("activateSecurity").equals("yes");

			String replicaName = operatorName + "-" + replicaNumber;

			String tmpDir = System.getProperty("java.io.tmpdir");
			// final File dbFile = new File(tmpDir,
			// UUID.randomUUID().toString());
			final File dbFile = new File(tmpDir, replicaName);
			dbFile.mkdir();

			Config config = new Config() {
				{
					domainModelPath = dmlFilePath;
					dbAlias = dbFile.getPath();
					rootClass = AnacomNetwork.class;
					repositoryType = RepositoryType.BERKELEYDB;
				}
			};

			FenixFramework.initialize(config);

            OperatorReplicationManager replicationManager = new OperatorReplicationManager();
            replicationManager.registerReplica(operatorName, operatorPrefix, replicaNumber, bindingUrl);
            
            servletContext.setAttribute("replicationManager", replicationManager);

			NetworkOperatorDetailedDto dto = new NetworkOperatorDetailedDto(
					operatorName, operatorPrefix, operatorSMSCost,
					operatorVoiceCost, operatorVideoCost, operatorTax, operatorBonus);

            if (activateSecurity) {
                AnacomSecurityManager securityManager = AnacomSecurityManager.getInstance();
                securityManager.setName(replicaName);
                securityManager.setCA(UDDIHelper.getSingleton().getCA());
                securityManager.getNewCertificate();
            }

			CreateNetworkOperatorService service = new CreateNetworkOperatorService(
					dto);
			
            try {
                service.execute();
            } catch (OperatorAlreadyExistsException e) {
                System.out.println("Server already initialized");
            }
		} catch (Exception e) {
			System.out.println("Error starting up the webapp: \n");
			e.printStackTrace();
		}
	}
}
