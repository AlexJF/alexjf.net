package pt.ist.anacom.estest;

import java.math.BigDecimal;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.service.EstablishVideoCommunicationService;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.NegativeBalanceException;
import pt.ist.anacom.shared.exception.OutgoingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.SourceBusyException;
import pt.ist.anacom.shared.exception.SourceOffException;

public class EstablishVideoCommunicationServiceTest extends AnacomTestCase{
	private static String OPERATOR_NAME = "ROFLCOPTER";
	private static String OPERATOR_PREFIX = "12";
	private static int OPERATOR_VOICE_COST = 20;
	private static int OPERATOR_VIDEO_COST = 40;
	private static int OPERATOR_SMS_COST = 5;
	private static BigDecimal OPERATOR_TAX = new BigDecimal(1.5);

	private static String CELL_NON_EXISTING_NUMBER = "123434343";

	private static String CELL_2G_ON_NUMBER = "123456700";
	private static String CELL_2G_SILENT_NUMBER = "123456701";
	private static String CELL_2G_BUSY_NUMBER = "123456702";
	private static String CELL_2G_OFF_NUMBER = "123456703";

	private static String CELL_3G_ON_NUMBER = "123456710";
	private static String CELL_3G_SILENT_NUMBER = "123456711";
	private static String CELL_3G_BUSY_NUMBER = "123456712";
	private static String CELL_3G_OFF_NUMBER = "123456713";

	private static String CELL_NEGATIVE_BALANCE_NUMBER = "123456720";

	private static String CELL_DEST_DIFFOPER_NUMBER = "912122121";
	private static String CELL_DEST_SAMEOPER_NUMBER = "123456789";
	
	private static int CELL_BALANCE = 100;
	private static int CELL_NEGATIVE_BALANCE = -100;

	private CellPhone cell2GOn;
	private CellPhone cell2GSilent;
	private CellPhone cell2GBusy;
	private CellPhone cell2GOff;
	private CellPhone cell3GOn;
	private CellPhone cell3GSilent;
	private CellPhone cell3GBusy;
	private CellPhone cell3GOff;
	private CellPhone cellNegativeBalance;
	private NetworkOperator operator;
	
	public EstablishVideoCommunicationServiceTest(String msg) {
		super(msg);
	}
	
	public EstablishVideoCommunicationServiceTest() {
		
	}
	
	@Override
	public void setUp() {
		super.setUp();

		operator = addOperator(OPERATOR_NAME, OPERATOR_PREFIX,
				OPERATOR_VOICE_COST, OPERATOR_VIDEO_COST, OPERATOR_SMS_COST,
				OPERATOR_TAX);

		cell2GOn = addCellPhone2G(operator, CELL_2G_ON_NUMBER, CELL_BALANCE);
		cell2GSilent = addCellPhone2G(operator, CELL_2G_SILENT_NUMBER,
				CELL_BALANCE);
		turnCellPhoneSilent(cell2GSilent);
		cell2GBusy = addCellPhone2G(operator, CELL_2G_BUSY_NUMBER, CELL_BALANCE);
		turnCellPhoneBusy(cell2GBusy);
		cell2GOff = addCellPhone2G(operator, CELL_2G_OFF_NUMBER, CELL_BALANCE);
		turnCellPhoneOff(cell2GOff);

		cell3GOn = addCellPhone3G(operator, CELL_3G_ON_NUMBER, CELL_BALANCE);
		cell3GSilent = addCellPhone3G(operator, CELL_3G_SILENT_NUMBER,
				CELL_BALANCE);
		turnCellPhoneSilent(cell3GSilent);
		cell3GBusy = addCellPhone3G(operator, CELL_3G_BUSY_NUMBER, CELL_BALANCE);
		turnCellPhoneBusy(cell3GBusy);
		cell3GOff = addCellPhone3G(operator, CELL_3G_OFF_NUMBER, CELL_BALANCE);
		turnCellPhoneOff(cell3GOff);

		cellNegativeBalance = addCellPhone3G(operator,
				CELL_NEGATIVE_BALANCE_NUMBER, CELL_NEGATIVE_BALANCE);
	}
	
	public void testEstablishVideoFrom3GOn() {
		// Arrange
		CallDto dto = new CallDto(CELL_3G_ON_NUMBER, CELL_DEST_SAMEOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);
		int initialSentCommunicationCount = getNumberOfOutgoingCommunications(cell3GOn);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			System.out.println(e.toString());
			fail("CellPhone exists and is on. Video call sending should be successful");
		}

		// Assert
		assertTrue(
				"Last communication should have been made to "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasOutgoingCommunicationTo(cell3GOn,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of outgoing communications should be increased by one.",
				initialSentCommunicationCount + 1,
				getNumberOfOutgoingCommunications(cell3GOn));
		
		assertNotNull("There should be one active communication", getActiveCommunication(cell3GOn));
	}
	
	public void testEstablishVideoFrom3GOff() {
		// Arrange
		CallDto dto = new CallDto(CELL_3G_OFF_NUMBER, CELL_DEST_SAMEOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);
		int initialSentCommunicationCount = getNumberOfOutgoingCommunications(cell3GOff);

		// Act
		try {
			service.execute();
			fail("CellPhone exists and is off. Video call should fail");
		} catch (SourceOffException e) {
			// Everything is fine
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw SourceOffException.");
		}

		// Assert
		assertFalse(
				"There should be no outgoing communication to "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasOutgoingCommunicationTo(cell3GOff,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of outgoing communications should be exactly the same.",
				initialSentCommunicationCount,
				getNumberOfOutgoingCommunications(cell3GOff));
		
		assertNull("There should be zero active communication", getActiveCommunication(cell3GOn));
		
	}
	
	public void testEstablishVideoFrom3GBusy() {
		// Arrange
		CallDto dto = new CallDto(CELL_3G_BUSY_NUMBER, CELL_DEST_SAMEOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);
		int initialSentCommunicationCount = getNumberOfOutgoingCommunications(cell3GBusy);

		// Act
		try {
			service.execute();
			fail("CellPhone exists and is busy. Video call should fail");
		} catch (SourceBusyException e) {
			// Everything is fine
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw SourceBusyException.");
		}

		// Assert
		assertFalse(
				"There should be no outgoing communication to "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasOutgoingCommunicationTo(cell3GBusy,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of outgoing communications should be exactly the same.",
				initialSentCommunicationCount,
				getNumberOfOutgoingCommunications(cell3GBusy));
		
		assertNull("There should be zero active communication", getActiveCommunication(cell3GOff));
	}
	
	public void testEstablishVideoFrom3GSilence() {
		// Arrange
		CallDto dto = new CallDto(CELL_3G_SILENT_NUMBER,CELL_DEST_SAMEOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);
		int initialSentCommunicationCount = getNumberOfOutgoingCommunications(cell3GSilent);
	
		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is silent. Video call should be successful");
		}

		// Assert
		assertTrue(
				"Last communication should have been made to "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasOutgoingCommunicationTo(cell3GSilent,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of outgoing communications should be increased by one.",
				initialSentCommunicationCount + 1,
				getNumberOfOutgoingCommunications(cell3GSilent));
		
		assertNotNull("There should be one active communication", getActiveCommunication(cell3GSilent));
	}
	
	public void testEstablishVideoFrom2GOn() {
		CallDto dto = new CallDto(CELL_2G_ON_NUMBER, CELL_DEST_SAMEOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);
		int initialSentCommunicationCount = getNumberOfOutgoingCommunications(cell2GOn);

		// Act
		try {
			service.execute();
			fail("CellPhone exists and is on but is 2G. Video call should fail");
		} catch (OutgoingCommunicationNotSupportedException e) {
			// Everything is fine
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw OutgoingCommunicationNotSupportedException.");
		}

		// Assert
		assertFalse(
				"There should be no outgoing communication to "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasOutgoingCommunicationTo(cell2GOn,
						CELL_DEST_SAMEOPER_NUMBER));
		
		assertEquals(
				"The number of outgoing communications should be the same.",
				initialSentCommunicationCount,
				getNumberOfOutgoingCommunications(cell2GOn));
		
		assertNull("There should be zero active communication", getActiveCommunication(cell2GOn));
	}
	
	public void testEstablishVideoFrom2GOff() {
		CallDto dto = new CallDto(CELL_2G_OFF_NUMBER, CELL_DEST_SAMEOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);
		int initialSentCommunicationCount = getNumberOfOutgoingCommunications(cell2GOff);

		// Act
		try {
			service.execute();
			fail("CellPhone exists but is off and 2G. Video call should fail");
		} catch (OutgoingCommunicationNotSupportedException e) {
			// Everything is fine
		} catch (SourceOffException e) {
			// Everything is fine
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw OutgoingCommunicationNotSupportedException" +
				 "or SourceOffException");
		}

		// Assert
		assertFalse(
				"There should be no outgoing communication to "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasOutgoingCommunicationTo(cell2GOff,
						CELL_DEST_SAMEOPER_NUMBER));
		
		assertEquals(
				"The number of outgoing communications should be the same.",
				initialSentCommunicationCount,
				getNumberOfOutgoingCommunications(cell2GOff));
		
		assertNull("There should be zero active communication", getActiveCommunication(cell2GOff));
	}
	
	public void testEstablishVideoFrom2GBusy() {
		CallDto dto = new CallDto(CELL_2G_BUSY_NUMBER, CELL_DEST_SAMEOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);
		int initialSentCommunicationCount = getNumberOfOutgoingCommunications(cell2GBusy);

		// Act
		try {
			service.execute();
			fail("CellPhone exists but is busy and is 2G. Video call should fail");
		} catch (OutgoingCommunicationNotSupportedException e) {
			// Everything is fine
		} catch (SourceBusyException e) {
			// Everything is fine
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw OutgoingCommunicationNotSupportedException " +
				 "or SourceBusyException.");
		}

		// Assert
		assertFalse(
				"There should be no outgoing communication to "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasOutgoingCommunicationTo(cell2GBusy,
						CELL_DEST_SAMEOPER_NUMBER));
		
		assertEquals(
				"The number of outgoing communications should be the same.",
				initialSentCommunicationCount,
				getNumberOfOutgoingCommunications(cell2GBusy));
		
		assertNull("There should be zero active communication", getActiveCommunication(cell2GBusy));
	}
	
	public void testEstablishVideoFrom2GSilente() {
		CallDto dto = new CallDto(CELL_2G_SILENT_NUMBER, CELL_DEST_SAMEOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);
		int initialSentCommunicationCount = getNumberOfOutgoingCommunications(cell2GSilent);

		// Act
		try {
			service.execute();
			fail("CellPhone exists and is on but is 2G. Video call should fail");
		} catch (OutgoingCommunicationNotSupportedException e) {
			// Everything is fine
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw OutgoingCommunicationNotSupportedException.");
		}

		// Assert
		assertFalse(
				"There should be no outgoing communication to "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasOutgoingCommunicationTo(cell2GSilent,
						CELL_DEST_SAMEOPER_NUMBER));
		
		assertEquals(
				"The number of outgoing communications should be the same.",
				initialSentCommunicationCount,
				getNumberOfOutgoingCommunications(cell2GSilent));
		
		assertNull("There should be zero active communication", getActiveCommunication(cell2GSilent));
	}
	
	public void testEstablishVideoFromNonExisting() {
		CallDto dto = new CallDto(CELL_NON_EXISTING_NUMBER, CELL_DEST_DIFFOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);

		// Act
		try {
			service.execute();
			fail("CellPhone does not exist. Video callshould fail.");
		} catch (CellPhoneNotExistsException e) {
			// if we get this exception everything is fine!
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw CellPhoneNotExistsException.");
		}
	}
	
	public void testEstablishVideoFromNegativeBalance() {
		CallDto dto = new CallDto(CELL_NEGATIVE_BALANCE_NUMBER,CELL_DEST_SAMEOPER_NUMBER);
		EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(dto);
		int initialSentCommunicationCount = getNumberOfOutgoingCommunications(cellNegativeBalance);

		// Act
		try {
			service.execute();
			fail("CellPhone exists and is on but has negative balance. Video call should fail");
		} catch (NegativeBalanceException e) {
			// Everything is fine
		} catch (AnacomException e) {
			System.out.println(e.toString());
			fail("Wrong exception thrown. It should throw NegativeBalanceException.");
		}

		// Assert
		assertEquals(
				"The number of outgoing communications should be exactly the same.",
				initialSentCommunicationCount,
				getNumberOfOutgoingCommunications(cellNegativeBalance));
	}
}
