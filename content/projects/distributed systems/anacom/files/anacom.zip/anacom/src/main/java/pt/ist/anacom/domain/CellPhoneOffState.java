package pt.ist.anacom.domain;

import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.DestinationOffException;
import pt.ist.anacom.shared.exception.SourceOffException;

/**
 * This class represents a CellPhone's Off State. When a CellPhone is in Off
 * State it can't establish or receive calls nor send SMSs. It can only send
 * SMSs.
 */
public class CellPhoneOffState extends CellPhoneState {

	public CellPhoneOffState() {
		super();
	}

	public void handleIncomingCommunication(Video commType)
			throws AnacomException {
		throw new DestinationOffException(getCellPhone().getNumber());
	}

	public void handleIncomingCommunication(SMS commType)
			throws AnacomException {
		// We can make the communication!
		// Nothing to do here.
	}

	public void handleIncomingCommunication(Voice commType)
			throws AnacomException {
		throw new DestinationOffException(getCellPhone().getNumber());
	}

	public void handleOutgoingCommunication(Video commType)
			throws AnacomException {
		throw new SourceOffException(getCellPhone().getNumber());
	}

	public void handleOutgoingCommunication(SMS commType)
			throws AnacomException {
		throw new SourceOffException(getCellPhone().getNumber());
	}

	public void handleOutgoingCommunication(Voice commType)
			throws AnacomException {
		throw new SourceOffException(getCellPhone().getNumber());
	}

	public void turnOn() {
		this.getCellPhone().setCellPhoneState(new CellPhoneOnState());
	}

	public void turnOff() {
		// Already in Off State.
		// Nothing to do here.
	}

	public void turnSilence() {
		this.getCellPhone().setCellPhoneState(new CellPhoneSilenceState());
	}

	public void turnBusy() {
		this.getCellPhone().setCellPhoneState(new CellPhoneBusyState());
	}

    @Override
    public String toString() {
        return "Off";
    }
}
