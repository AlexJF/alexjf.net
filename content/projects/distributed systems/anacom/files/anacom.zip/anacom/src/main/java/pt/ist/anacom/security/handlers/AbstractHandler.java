package pt.ist.anacom.security.handlers;

import java.util.Iterator;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.w3c.dom.Node;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * This is the base class for all security handlers.
 * It declares some utilitarian functions and an interface that
 * must be followed by all handlers that extends this one.
 */

public abstract class AbstractHandler implements SOAPHandler<SOAPMessageContext> {
	protected BASE64Decoder b64d = new BASE64Decoder();
	protected BASE64Encoder b64e = new BASE64Encoder();
	
	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		Boolean outboundProperty = (Boolean) context
				.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        Boolean result;
		if (outboundProperty) {
			result =  handleOutboundMessage(context.getMessage());
		} else {
			result =  handleInboundMessage(context.getMessage());
		}

        if (!result) {
            replaceWithFault(context.getMessage(), !outboundProperty);
        }

        return result;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		Boolean outboundProperty = (Boolean) context
				.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        Boolean result;
		if (outboundProperty) {
			result =  handleOutboundMessage(context.getMessage());
		} else {
			result =  handleInboundMessage(context.getMessage());
		}

        if (!result) {
            replaceWithFault(context.getMessage(), !outboundProperty);
        }

        return result;
	}

    protected void replaceWithFault(SOAPMessage message, boolean incoming) {
        try {
            message.getSOAPBody().removeContents();
            SOAPFault fault = message.getSOAPBody().addFault();
            fault.setFaultString(getFaultString(incoming));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected abstract String getFaultString(boolean incoming);

	@Override
	public void close(MessageContext context) {
		// empty		
	}

	@Override
	public Set<QName> getHeaders() {
		// empty
		return null;
	}
	
	/**
	 * Retrieves the SOAP envelope from a given SOAP message context.
	 * @param context SOAP message context from a message.
	 * @return Returns SOAPEnvelop from the given SOAP message context.
	 * @throws SOAPException
	 */
	protected SOAPEnvelope getSoapEnvelope(SOAPMessage message)
			throws SOAPException {
		SOAPPart soapPart = message.getSOAPPart();
		SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
		return soapEnvelope;
	}
	
	/**
	 * Retrieves the header from a given SOAP Envelope
	 * @param soapEnvelope SOAP Envelope from a SOAP message.
	 * @return Return the header of the SOAP Message.
	 * @throws SOAPException
	 */
	protected SOAPHeader getHeader(SOAPEnvelope soapEnvelope)
			throws SOAPException {
		SOAPHeader soapHeader = soapEnvelope.getHeader();
		if (soapHeader == null) {
			soapHeader = soapEnvelope.addHeader();
		}
		return soapHeader;
	}
	
	
	/**
	 * Retrieves the body from a given SOAP envelope.
	 * @param soapEnvelope SOAP Envelope from a SOAP message.
	 * @return Returns the body of the SOAP Message.
	 * @throws SOAPException
	 */
	protected SOAPBody getBody(SOAPEnvelope soapEnvelope)
			throws SOAPException {
		SOAPBody soapBody = soapEnvelope.getBody();
		return soapBody;
	}

	/**
	 * Given a SOAP Header retrieves the head node with the name equal
	 * to the string provided.
	 * 
	 * @param h SOAP Header from a message.
	 * @param nodeName Name of the header node that we are looking for.
	 * @return Returns an header node.
	 */
    protected Node getHeaderNode(SOAPHeader h, String nodeName) {
    	
    	if (h == null) {
    		return null;
    	}
    	
		 Iterator iterator = h.examineAllHeaderElements();
	     while (iterator.hasNext()) {
	    	 SOAPHeaderElement el = (SOAPHeaderElement) iterator.next();
	    	 if (el.getNodeName().equals(nodeName))
	    		 return (Node)el;
	     }
	     
	     return null;
    }
	
	protected Node getCertificateNode(SOAPHeader h) {
        return getHeaderNode(h, "anacom:certificate");
	}
	
	protected Node getDigestNode(SOAPHeader h) {
        return getHeaderNode(h, "anacom:messageDigest");
	}

	protected Node getUUIDNode(SOAPHeader h) {
        return getHeaderNode(h, "anacom:messageUUID");
	}
	
	/**
	 * Returns the name of the operation that will be invoked.
	 * @param soapEnvelope SOAP Envelop of the message.
	 * @return
	 */
    protected String getOperationName(SOAPEnvelope soapEnvelope) {
        try {
            SOAPBody body = getBody(soapEnvelope);
            Node firstChild = body.getFirstChild();

            return firstChild.getLocalName();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
	
	/**
	 * This function must be implemented by all that extend this class
	 * in order to provided the proper behavior for incoming messages
	 * for each specific handler.
	 * @param context SOAP Message context.
	 * @return Returns a boolean that will be used to decide if the message shall
	 * 		   or not pass.
	 */
	protected abstract boolean handleInboundMessage(SOAPMessage message);
	
	/**
     * This function must be implemented by all that extend this class
     * in order to provided the proper behavior for ougoing messages
     * for each specific handler.
     * @param context SOAP Message context.
     * @return Returns a boolean that will be used to decide if the message shall
     * 		   or not pass.
     */
	protected abstract boolean handleOutboundMessage(SOAPMessage message);

}
