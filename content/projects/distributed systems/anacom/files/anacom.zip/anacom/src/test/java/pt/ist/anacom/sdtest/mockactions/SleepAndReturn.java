package pt.ist.anacom.sdtest.mockactions;

import org.hamcrest.Description;

import org.jmock.api.Action;
import org.jmock.api.Invocation;

public class SleepAndReturn<T> implements Action {
    private T returnValue;
    private int sleepTime;
    
    public SleepAndReturn(int sleepTime, T returnValue) {
        this.returnValue = returnValue;
        this.sleepTime = sleepTime;
    }
    
    public void describeTo(Description description) {
        description.appendText("sleeps for " + sleepTime + "seconds ")
                   .appendText(" and then returns the specified value");
    }
    
    public Object invoke(Invocation invocation) throws Throwable {
        Thread.sleep(sleepTime * 1000);
        return returnValue;
    }

    public static <T> Action sleepAndReturn(int sleepTime, T returnValue) {
        return new SleepAndReturn<T>(sleepTime, returnValue);
    }
}
