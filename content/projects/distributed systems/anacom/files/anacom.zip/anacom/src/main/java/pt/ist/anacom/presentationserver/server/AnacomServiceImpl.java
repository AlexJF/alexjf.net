package pt.ist.anacom.presentationserver.server;

import java.math.BigDecimal;

import java.util.List;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

import pt.ist.anacom.presentationserver.client.AnacomService;

import pt.ist.anacom.replication.RemoteReplicatedServer;

import pt.ist.anacom.service.bridge.ApplicationServerBridge;
import pt.ist.anacom.service.bridge.LocalApplicationServer;
import pt.ist.anacom.service.bridge.RemoteApplicationServer;

import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.dto.SMSDto;

import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.BalanceChangeException;
import pt.ist.anacom.shared.exception.BusyStateException;
import pt.ist.anacom.shared.exception.CellPhoneAlreadyExistsException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.DestinationBusyException;
import pt.ist.anacom.shared.exception.DestinationOffException;
import pt.ist.anacom.shared.exception.DestinationSilenceException;
import pt.ist.anacom.shared.exception.HigherThanMaxBalanceException;
import pt.ist.anacom.shared.exception.IncomingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.InvalidCellPhoneNumberException;
import pt.ist.anacom.shared.exception.InvalidCellPhonePrefixException;
import pt.ist.anacom.shared.exception.NegativeBalanceException;
import pt.ist.anacom.shared.exception.NotAStateException;
import pt.ist.anacom.shared.exception.OperatorAlreadyExistsException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;
import pt.ist.anacom.shared.exception.OutgoingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.SourceBusyException;
import pt.ist.anacom.shared.exception.SourceOffException;

public class AnacomServiceImpl extends RemoteServiceServlet implements
		AnacomService {

	private static final long serialVersionUID = 1L;

	private static ApplicationServerBridge bridge = null;

	public void initBridge(String serverType) throws AnacomException {
        if (bridge != null) {
            return;
        }

        if (serverType.equals("essd")) {
            bridge = new RemoteApplicationServer(false);
            System.out.println("Initiated normal sd: " + bridge);
        } 
        else if (serverType.equals("essd-security")) {
            bridge = new RemoteApplicationServer();
            System.out.println("Initiated security: " + bridge);
        }
        else if (serverType.equals("essd-replicated")) {
            bridge = new RemoteReplicatedServer(false);
            System.out.println("Initiated replicated: " + bridge);
        }
        else if (serverType.equals("essd-replicated-security")) {
            bridge = new RemoteReplicatedServer();
            System.out.println("Initiated replicated with security: " + bridge);
        }
        else {
            bridge = new LocalApplicationServer();
            NetworkOperatorDetailedDto opdto = new NetworkOperatorDetailedDto(
                    "SDES", "98", 5, 20, 40, new BigDecimal("1.5"), new BigDecimal("0"));
            System.out.println("Initiated es: " + bridge);
            try {
                bridge.createNetworkOperator(opdto);
            } catch (OperatorAlreadyExistsException e) {
                // we do nothing here
            }
        }
	}

	@Override
	public void registerCellPhone(CellPhoneDetailedDto dto)
			throws OperatorNotExistsException, CellPhoneAlreadyExistsException,
			InvalidCellPhoneNumberException, InvalidCellPhonePrefixException,
			HigherThanMaxBalanceException {
        bridge.registerCellPhone(dto);
	}

	@Override
	public CommunicationDetailsDto getLastCommunicationDetails(
			CellPhoneSimpleDto dto) throws CellPhoneNotExistsException {
		return bridge.getLastCommunicationDetails(dto);
	}
	
	@Override
	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto)
			throws InvalidCellPhoneNumberException, OperatorNotExistsException,
			CellPhoneNotExistsException {
        return bridge.getCellPhoneBalance(dto);
	}

	@Override
	public CellPhoneWithStateDto getCellPhoneState(CellPhoneSimpleDto dto)
			throws InvalidCellPhoneNumberException, OperatorNotExistsException,
			CellPhoneNotExistsException {
		return bridge.getCellPhoneState(dto);
	}

	@Override
	public List<SMSDto> listSMS(CellPhoneSimpleDto dto)
			throws InvalidCellPhoneNumberException, OperatorNotExistsException,
			CellPhoneNotExistsException {
		return bridge.getCellPhoneSMS(dto).getCellPhonesSMS();
	}

	@Override
	public void changeCellPhoneState(CellPhoneWithStateDto dto)
			throws InvalidCellPhoneNumberException, NotAStateException,
			BusyStateException, CellPhoneNotExistsException {
		bridge.changeCellPhoneState(dto);
	}

	@Override
	public void increaseCellPhoneBalance(ChangeCellPhoneBalanceDto dto)
			throws InvalidCellPhoneNumberException, BalanceChangeException,
			HigherThanMaxBalanceException, CellPhoneNotExistsException {
		bridge.increaseCellPhoneBalance(dto);
	}

	@Override
	public void sendSMS(SMSDto dto) throws CellPhoneNotExistsException,
			OutgoingCommunicationNotSupportedException,
			NegativeBalanceException, SourceOffException, SourceBusyException,
			InvalidCellPhoneNumberException {
		bridge.sendSMS(dto);
	}

    @Override
    public void establishVoiceCommunication(CallDto dto) throws 
           CellPhoneNotExistsException,
           OutgoingCommunicationNotSupportedException,
           IncomingCommunicationNotSupportedException,
           SourceOffException, SourceBusyException,
           DestinationOffException, DestinationSilenceException,
           DestinationBusyException, NegativeBalanceException,
           InvalidCellPhoneNumberException {
        bridge.establishVoiceCall(dto);
    }

    @Override
    public void establishVideoCommunication(CallDto dto) throws 
           CellPhoneNotExistsException,
           OutgoingCommunicationNotSupportedException,
           IncomingCommunicationNotSupportedException,
           SourceOffException, SourceBusyException,
           DestinationOffException, DestinationSilenceException,
           DestinationBusyException, NegativeBalanceException,
           InvalidCellPhoneNumberException {
        bridge.establishVideoCall(dto);
    }

    @Override
    public void terminateActiveCommunication(CallWithDurationDto dto)
           throws CellPhoneNotExistsException,
                  InvalidCellPhoneNumberException {
        bridge.terminateActiveCall(dto);
    }
}
