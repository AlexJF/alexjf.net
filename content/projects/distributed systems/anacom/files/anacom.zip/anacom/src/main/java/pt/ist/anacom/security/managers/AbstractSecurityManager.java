package pt.ist.anacom.security.managers;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import sun.security.x509.X509CRLImpl;

/**
 * This is the base class for all security managers.
 */
public abstract class AbstractSecurityManager {
	protected PublicKey _kp;
	protected PrivateKey _ks;
    protected PublicKey _caPublicKey;
	protected String _certificate = null;
	protected BASE64Decoder b64d = new BASE64Decoder();
	protected BASE64Encoder b64e = new BASE64Encoder();
	protected String name;

    public AbstractSecurityManager() {
        KeyPair pair = loadKeyPair();
        _kp = pair.getPublic();
        _ks = pair.getPrivate();
    }

	public PublicKey getPublicKey() {
		return _kp;
	}

	public PrivateKey getPrivateKey() {
		return _ks;
	}

	public PublicKey getCAPublicKey() {
		return _caPublicKey;
	}

	public abstract X509CRLImpl getBlackList();

	public String getCertificate() {
        return _certificate;
    }

	public void setCertificate(String _certificate) {
		this._certificate = _certificate;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	/**
	 * Generate a new Key pair for the entity in possesion.
	 * of the security manager.
	 * @return the key pair generated
	 */
	protected KeyPair loadKeyPair() {
		KeyPairGenerator keygen = null;
		try {
			keygen = KeyPairGenerator.getInstance("RSA");
			keygen.initialize(1024);
            return keygen.generateKeyPair();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
            return null;
		}
	}
}
