package pt.ist.anacom.estest;

import java.math.BigDecimal;

import pt.ist.anacom.service.CreateNetworkOperatorService;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.InvalidOperatorPrefixException;
import pt.ist.anacom.shared.exception.OperatorAlreadyExistsException;

public class CreateNetworkOperatorServiceTest extends AnacomTestCase {
	private static String OPERATOR_NAME = "ROFLCOPTER";
	private static String OPERATOR_PREFIX = "12";
	private static int OPERATOR_VOICE_COST = 20;
	private static int OPERATOR_VIDEO_COST = 40;
	private static int OPERATOR_SMS_COST = 5;
	private static BigDecimal OPERATOR_TAX = new BigDecimal(1.5);
	private static BigDecimal OPERATOR_BONUS = new BigDecimal(0);

	private static String OPERATOR_NAME_BASE = "ZAZA";
	private static String OPERATOR_PREFIX_BASE = "15";
	private static int OPERATOR_VOICE_COST_BASE = 30;
	private static int OPERATOR_VIDEO_COST_BASE = 10;
	private static int OPERATOR_SMS_COST_BASE = 7;
	private static BigDecimal OPERATOR_TAX_BASE = new BigDecimal(1.5);

	private static String OPERATOR_WRONG_PREFIX1 = "2";
	private static String OPERATOR_WRONG_PREFIX3 = "122";

	public CreateNetworkOperatorServiceTest(String msg) {
		super(msg);
	}

	public CreateNetworkOperatorServiceTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();
		addOperator(OPERATOR_NAME_BASE, OPERATOR_PREFIX_BASE,
				OPERATOR_VOICE_COST_BASE, OPERATOR_VIDEO_COST_BASE,
				OPERATOR_SMS_COST_BASE, OPERATOR_TAX_BASE, OPERATOR_BONUS);
	}

	public void testNewOperatorCreation() {
		// Arrange
		NetworkOperatorDetailedDto dto = new NetworkOperatorDetailedDto(
				OPERATOR_NAME, OPERATOR_PREFIX, OPERATOR_SMS_COST,
				OPERATOR_VOICE_COST, OPERATOR_VIDEO_COST, OPERATOR_TAX, OPERATOR_BONUS);

		CreateNetworkOperatorService service = new CreateNetworkOperatorService(
				dto);
		int initialNumberOfOperators = getNumberOfOperators();

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("Operator creation should be successful, all fields were correct");
		}

		// Assert
		assertEquals("The number of operators should be increased by one.",
				initialNumberOfOperators + 1, getNumberOfOperators());
		assertTrue(
				"Operator with specified data should exist.",
				hasOperatorWithData(OPERATOR_NAME, OPERATOR_PREFIX,
						OPERATOR_SMS_COST, OPERATOR_VOICE_COST,
						OPERATOR_VIDEO_COST, OPERATOR_TAX));
	}

	public void testNewOperatorCreationWithMoreThanTwoDigitsPrefix() {
		// Arrange
		NetworkOperatorDetailedDto dto = new NetworkOperatorDetailedDto(
				OPERATOR_NAME, OPERATOR_WRONG_PREFIX3, OPERATOR_SMS_COST,
				OPERATOR_VIDEO_COST, OPERATOR_VOICE_COST, OPERATOR_TAX, OPERATOR_BONUS);

		CreateNetworkOperatorService service = new CreateNetworkOperatorService(
				dto);
		int initialNumberOfOperators = getNumberOfOperators();

		// Act
		try {
			service.execute();
			fail("Prefix with more than 2 digits. Operator creation should fail.");
		} catch (InvalidOperatorPrefixException e) {
			// if we get this exception everything is fine!
		} catch (AnacomException e) {
			fail("This kind if of exception should not have been raise");
		}

		// Assert
		assertEquals("The number of operators should be exactly the same.",
				initialNumberOfOperators, getNumberOfOperators());
	}

	public void testNewOperatorCreationWithLessThanTwoDigitsPrefix() {
		// Arrange
		NetworkOperatorDetailedDto dto = new NetworkOperatorDetailedDto(
				OPERATOR_NAME, OPERATOR_WRONG_PREFIX1, OPERATOR_SMS_COST,
				OPERATOR_VIDEO_COST, OPERATOR_VOICE_COST, OPERATOR_TAX, OPERATOR_BONUS);

		CreateNetworkOperatorService service = new CreateNetworkOperatorService(
				dto);
		int initialNumberOfOperators = getNumberOfOperators();

		// Act
		try {
			service.execute();
			fail("Prefix with less than 2 digits. Operator creation should fail.");
		} catch (InvalidOperatorPrefixException e) {
			// if we get this exception everything is fine!
		} catch (AnacomException e) {
			fail("This kind if of exception should not have been raise");
		}

		// Assert
		assertEquals("The number of operators should be exactly the same.",
				initialNumberOfOperators, getNumberOfOperators());
	}

	public void testNewOperatorCreationWithExistingName() {
		// Arrange
		NetworkOperatorDetailedDto dto = new NetworkOperatorDetailedDto(
				OPERATOR_NAME_BASE, OPERATOR_PREFIX, OPERATOR_SMS_COST,
				OPERATOR_VIDEO_COST, OPERATOR_VOICE_COST, OPERATOR_TAX, OPERATOR_BONUS);

		CreateNetworkOperatorService service = new CreateNetworkOperatorService(
				dto);
		int initialNumberOfOperators = getNumberOfOperators();

		// Act
		try {
			service.execute();
			fail("Name already exists. Operator creation should fail.");
		} catch (OperatorAlreadyExistsException e) {
			// if we get this exception everything is fine!
		} catch (AnacomException e) {
			fail("This kind if of exception should not have been raise");
		}

		// Assert
		assertEquals("The number of operators should be exactly the same.",
				initialNumberOfOperators, getNumberOfOperators());
	}

	public void testNewOperatorCreationWithExistingPrefix() {
		// Arrange
		NetworkOperatorDetailedDto dto = new NetworkOperatorDetailedDto(
				OPERATOR_NAME, OPERATOR_PREFIX_BASE, OPERATOR_SMS_COST,
				OPERATOR_VIDEO_COST, OPERATOR_VOICE_COST, OPERATOR_TAX, OPERATOR_BONUS);

		CreateNetworkOperatorService service = new CreateNetworkOperatorService(
				dto);
		int initialNumberOfOperators = getNumberOfOperators();

		// Act
		try {
			service.execute();
			fail("Prefix already exists. Operator creation should fail.");
		} catch (OperatorAlreadyExistsException e) {
			// if we get this exception everything is fine!
		} catch (AnacomException e) {
			fail("This kind if of exception should not have been raise");
		}

		// Assert
		assertEquals("The number of operators should be exactly the same.",
				initialNumberOfOperators, getNumberOfOperators());
	}
}
