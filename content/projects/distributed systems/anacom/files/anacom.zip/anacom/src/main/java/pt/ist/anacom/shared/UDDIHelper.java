package pt.ist.anacom.shared;

import java.net.PasswordAuthentication;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import javax.xml.registry.BulkResponse;
import javax.xml.registry.BusinessLifeCycleManager;
import javax.xml.registry.BusinessQueryManager;
import javax.xml.registry.Connection;
import javax.xml.registry.ConnectionFactory;
import javax.xml.registry.FindQualifier;
import javax.xml.registry.JAXRException;
import javax.xml.registry.RegistryService;
import javax.xml.registry.infomodel.Organization;
import javax.xml.registry.infomodel.Service;
import javax.xml.registry.infomodel.ServiceBinding;

import org.apache.ws.scout.registry.ConnectionFactoryImpl;

import org.joda.time.DateTime;
import org.joda.time.Seconds;

import pt.ist.anacom.caserver.CAServer;
import pt.ist.anacom.caserver.CAServerImpl;
import pt.ist.anacom.service.bridge.RemoteOperator;
import pt.ist.anacom.service.bridge.RemoteOperatorImpl;

public class UDDIHelper {
	private static UDDIHelper _instance = null;
	private Connection _connection = null;
	private BusinessQueryManager _queryManager = null;
	private BusinessLifeCycleManager _lifeManager = null;
	private Map<String, List<RemoteOperator>> _operatorsCache;
	private Map<String, String> _prefixToNameCache;
	private Map<RemoteOperator, CacheUpdateInfo> _cacheUpdateInfo;
	private Timer _updateTimer;

	private static final String serviceName = "Anacom operator";

	// Each time block has 1 second
	private final int TIMEBLOCK_SECONDS = 5;
	private final int UPDATE_INTERVAL_MILI = 5000 * 60;

	private UDDIHelper() {
		_operatorsCache = Collections
				.synchronizedMap(new HashMap<String, List<RemoteOperator>>());
		_prefixToNameCache = Collections
				.synchronizedMap(new HashMap<String, String>());
		_cacheUpdateInfo = Collections
				.synchronizedMap(new HashMap<RemoteOperator, CacheUpdateInfo>());
	}

	public static UDDIHelper getSingleton() {
		if (_instance == null) {
			_instance = new UDDIHelper();
			_instance.createConnection();
		}
		return _instance;
	}

	public void startCacheManagement() {
		_updateTimer = new Timer(true);
		updateRemoteOperators();
		_updateTimer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				System.out.println("Updating UDDI cache");
				updateRemoteOperators();
			}
		}, UPDATE_INTERVAL_MILI, UPDATE_INTERVAL_MILI);
	}

	private void createConnection() {
		if (_connection == null) {
			try {
				ConnectionFactory connFactory = ConnectionFactoryImpl
						.newInstance();
				Properties props = new Properties();

				props.setProperty("scout.juddi.client.config.file", "uddi.xml");
				props.setProperty("javax.xml.registry.queryManagerURL",
						"http://localhost:8081/juddiv3/services/inquiry");
				props.setProperty("javax.xml.registry.lifeCycleManagerURL",
						"http://localhost:8081/juddiv3/services/publish");
				props.setProperty("javax.xml.registry.securityManagerURL",
						"http://localhost:8081/juddiv3/services/security");
				props.setProperty("scout.proxy.uddiVersion", "3.0");
				props.setProperty("scout.proxy.transportClass",
						"org.apache.juddi.v3.client.transport.JAXWSTransport");

				connFactory.setProperties(props);
				_connection = connFactory.createConnection();

				PasswordAuthentication passwdAuth = new PasswordAuthentication(
						"userName", "password".toCharArray());

				Set<PasswordAuthentication> creds = new HashSet<PasswordAuthentication>();
				creds.add(passwdAuth);
				_connection.setCredentials(creds);
				RegistryService rs = _connection.getRegistryService();
				_queryManager = rs.getBusinessQueryManager();
				_lifeManager = rs.getBusinessLifeCycleManager();

			} catch (JAXRException e) {
				System.err.println("Error trying to contact UDDI.");
				e.printStackTrace();
			}
		}
	}
	
	public Set<String> getAllOperators() {
		return _operatorsCache.keySet();
	}

	protected Collection<Organization> findOrganizations(String searchPattern) {
		try {
			Collection<String> namePatterns = new ArrayList<String>();
			namePatterns.add(searchPattern);

			Collection<String> findQualifiers = new ArrayList<String>();
			findQualifiers.add(FindQualifier.SORT_BY_NAME_DESC);

			BulkResponse res = _queryManager.findOrganizations(findQualifiers,
					namePatterns, null, null, null, null);
			@SuppressWarnings("unchecked")
			Collection<Organization> orgs = res.getCollection();
			return orgs;
		} catch (JAXRException e) {
			System.err.println("couldn't get query manager");
			e.printStackTrace();
			return Collections.emptyList();
		}
	}

	public Boolean registerCA(String bindingURI, String publicKey) {
		String serviceOrgName = "Anacom CA";
		Boolean retV = false;
		try {

			Collection<Organization> orgs = findOrganizations("Anacom CA");

			Organization org;

			Iterator<Organization> it = orgs.iterator();

			if (!it.hasNext()) {
				org = _lifeManager.createOrganization(serviceOrgName);
			} else {
				org = it.next();
			}

			org.setDescription(_lifeManager
					.createInternationalString(publicKey));

			@SuppressWarnings("unchecked")
			Collection<Service> services = org.getServices();
			Service service = null;
			boolean newService = true;

			for (Service svc : services) {
				if (svc.getName().getValue().equals("Anacom CA")) {
					newService = false;
					service = svc;
					break;
				}
			}
			
			if (service == null) {
				service = _lifeManager.createService(serviceOrgName);
			}

			@SuppressWarnings("unchecked")
			Collection<ServiceBinding> bindings = service.getServiceBindings();

			if (bindings.size() == 0) {
				ServiceBinding binding = _lifeManager.createServiceBinding();
				binding.setValidateURI(false);
				binding.setAccessURI(bindingURI);
				service.addServiceBinding(binding);
			} else {
				ServiceBinding binding = bindings.iterator().next();
				binding.setAccessURI(bindingURI);
			}

			if (newService) {
				org.addService(service);
			}

			Collection<Organization> orgs2 = new ArrayList<Organization>();
			orgs2.add(org);

			BulkResponse br = _lifeManager.saveOrganizations(orgs2);
			if (br.getStatus() == JAXRException.STATUS_SUCCESS) {
				retV = true;
			} else {
				@SuppressWarnings("unchecked")
				Collection<Exception> exceptions = br.getExceptions();
				for (Exception e : exceptions) {
					e.printStackTrace();
				}
			}
		} catch (JAXRException e) {
			System.err.println("couldn't get life manager");
			e.printStackTrace();
		}
		return retV;
	}

	public Boolean registerServer(String operatorName, String prefix,
			String replicaNumber, String bindingURI) {
		Boolean retV = false;
		try {
			Collection<Organization> orgs = findOrganizations(prefix + "-"
					+ operatorName);

			Organization org;

			Iterator<Organization> it = orgs.iterator();

			if (!it.hasNext()) {
				org = _lifeManager.createOrganization(prefix + "-"
						+ operatorName);
			} else {
				org = it.next();
			}

			@SuppressWarnings("unchecked")
			Collection<Service> services = org.getServices();
			Service service = null;
			boolean newService = true;

			for (Service svc : services) {
				if (svc.getName().getValue().equals(serviceName)) {
					newService = false;
					service = svc;
					break;
				}
			}

			if (service == null) {
				service = _lifeManager.createService(serviceName);
			}
			@SuppressWarnings("unchecked")
			Collection<ServiceBinding> bindings = service.getServiceBindings();
			ServiceBinding binding = null;
			for (ServiceBinding serviceBinding : bindings) {
				if (serviceBinding.getDescription().getValue().equalsIgnoreCase("Replica " + replicaNumber)) {
					binding = serviceBinding;
					binding.setAccessURI(bindingURI);
				}
			}

			if (binding == null) {
				binding = _lifeManager.createServiceBinding();
				binding.setDescription(_lifeManager
						.createInternationalString("Replica " + replicaNumber));
				binding.setValidateURI(false);
				binding.setAccessURI(bindingURI);
				service.addServiceBinding(binding);
			}

			if (newService) {
				org.addService(service);
			}

			Collection<Organization> orgs2 = new ArrayList<Organization>();
			orgs2.add(org);

			BulkResponse br = _lifeManager.saveOrganizations(orgs2);

			if (br.getStatus() == JAXRException.STATUS_SUCCESS) {
				retV = true;
			} else {
				@SuppressWarnings("unchecked")
				Collection<Exception> exceptions = br.getExceptions();

				for (Exception e : exceptions) {
					e.printStackTrace();
				}
			}
		} catch (JAXRException e) {
			System.err.println("couldn't get life manager");
			e.printStackTrace();
		}
		return retV;
	}

	protected void updateRemoteOperators() {
		_operatorsCache.clear();
		_prefixToNameCache.clear();
		_cacheUpdateInfo.clear();

		Collection<Organization> orgs = findOrganizations("%-%");

		for (Organization org : orgs) {
			try {
				String orgName = org.getName().getValue();
				if (orgName.equalsIgnoreCase("Anacom CA") || orgName.equalsIgnoreCase("null")) {
					continue;
				}
				String[] orgNameParts = orgName.split("-", 2);
				String operatorPrefix = orgNameParts[0];
				String operatorName = orgNameParts[1];
				DateTime now = new DateTime();

				List<RemoteOperator> results = new LinkedList<RemoteOperator>();

				_operatorsCache.put(operatorName, results);
				_prefixToNameCache.put(operatorPrefix, operatorName);

				@SuppressWarnings("unchecked")
				Collection<Service> services = org.getServices();

				for (Service svc : services) {
					@SuppressWarnings("unchecked")
					Collection<ServiceBinding> binds = svc.getServiceBindings();
					if (svc.getName() == null) {
						continue;
					}
					if (svc.getName().getValue()
							.equalsIgnoreCase(serviceName)) {
						for (ServiceBinding bindings : binds) {
							String replicaNumber = bindings.getDescription().getValue().split(" ")[1];
							RemoteOperator replica = new RemoteOperatorImpl(
									operatorName, operatorPrefix,
									replicaNumber, bindings.getAccessURI());
							results.add(replica);
							_cacheUpdateInfo.put(replica, new CacheUpdateInfo(
									now));
						}
					}
				}
			} catch (JAXRException e) {
				e.printStackTrace();
			}
		}
	}

	protected RemoteOperator getOperatorReplica(String operatorName,
			String replicaNumber) {
		List<RemoteOperator> replicas = _operatorsCache.get(operatorName);

		if (replicas != null) {
			for (RemoteOperator op : replicas) {
				if (op.getReplicaNumber().equals(replicaNumber)) {
					return op;
				}
			}
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	public CAServer getCA() {
		try {
			Collection<Organization> orgs = findOrganizations("Anacom CA");
			Organization org = orgs.iterator().next();
			Collection<Service> services;
			services = org.getServices();
			for (Service svc : services) {
				Collection<ServiceBinding> binds = svc.getServiceBindings();
				if (binds != null) {
					String key = org.getDescription().getValue();
					CAServer ca = new CAServerImpl(key);
					return ca;
				}
				return null;
			}
		} catch (JAXRException e) {
			e.printStackTrace();
		}

		return null;
	}



	protected boolean updateRemoteOperator(String operatorName,
			String replicaNumber) {
		Collection<Organization> orgs = findOrganizations("%-" + operatorName);
		Iterator<Organization> it = orgs.iterator();

		if (it.hasNext()) {
			try {
				Organization org = it.next();

				RemoteOperator replica = getOperatorReplica(operatorName,
						replicaNumber);

				if (replica == null) {
					return false;
				}

				CacheUpdateInfo info = _cacheUpdateInfo.get(replica);

				@SuppressWarnings("unchecked")
				Collection<Service> services = org.getServices();

				for (Service svc : services) {
					@SuppressWarnings("unchecked")
					Collection<ServiceBinding> binds = svc.getServiceBindings();
					String svcName = svc.getName().getValue();

					if (svcName.equals(serviceName)) {
						for (ServiceBinding serviceBinding : binds) {
							String bindingName = serviceBinding.getDescription().getValue();
							if (bindingName.equals("Replica " + replicaNumber)) {
								String newUrl = serviceBinding.getAccessURI();
								if (!newUrl.equals(replica.getUrl())) {
									info.setLastUpdate(new DateTime());
									info.setWaitTimeBlocks(1);
									replica.setUrl(newUrl);
									return true;
								}
							}
						}
					}
				}
			} catch (JAXRException e) {
				e.printStackTrace();
			}
		}

		return false;
	}

	public void notifyRemoteOperatorFailed(String operatorName,
			String replicaNumber) {
		RemoteOperator replica = getOperatorReplica(operatorName, replicaNumber);
		CacheUpdateInfo info = null;

		info = _cacheUpdateInfo.get(replica);

		if (info == null) {
			return;
		}

		DateTime lastUpdate = info.getLastUpdate();
		int waitBlocks = info.getWaitTimeBlocks();

		if (Seconds.secondsBetween(new DateTime(), lastUpdate).getSeconds() > waitBlocks
				* TIMEBLOCK_SECONDS) {
			if (!updateRemoteOperator(operatorName, replicaNumber)) {
				info.setWaitTimeBlocks(2 * info.getWaitTimeBlocks());
			}
		}
	}

	public List<RemoteOperator> getRemoteOperatorsFromOperatorName(
			String operatorName) {
		return _operatorsCache.get(operatorName);
	}

	public List<RemoteOperator> getRemoteOperatorsFromOperatorPrefix(
			String prefix) {
		return _operatorsCache.get(getOperatorNameFromPrefix(prefix));
	}

	public String getOperatorNameFromPrefix(String prefix) {
		return _prefixToNameCache.get(prefix);
	}

	public void printCacheInfo() {
		System.out.println("Operator's cache:");
		for (Map.Entry<String, List<RemoteOperator>> entry : _operatorsCache
				.entrySet()) {
			System.out.println("* " + entry.getKey() + " replicas:");

			for (RemoteOperator op : entry.getValue()) {
				System.out.println("\t" + op.toString());
			}
		}

		System.out.println("Prefix to Name cache:");
		for (Map.Entry<String, String> entry : _prefixToNameCache.entrySet()) {
			System.out.println(entry.getKey() + " - " + entry.getValue());
		}
	}

	public static void main(String[] args) {
		UDDIHelper uddi = UDDIHelper.getSingleton();

		Collection<Organization> orgs = uddi.findOrganizations("%");

		for (Organization org : orgs) {
			try {
				System.out.println(org.getName().getValue());

				if (org.getDescription() != null) {
					System.out.println(org.getDescription().getValue());
				}
				@SuppressWarnings("unchecked")
				Collection<Service> services = org.getServices();
				for (Service service : services) {
					System.out.println("\t" + service.getName().getValue());
					try {
						@SuppressWarnings("unchecked")
						Collection<ServiceBinding> bindings = service
								.getServiceBindings();

						for (ServiceBinding binding : bindings) {
							System.out.println("\t\t" + binding.getDescription().getValue() + " - " + binding.getAccessURI());
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private class CacheUpdateInfo {
		private DateTime _lastUpdate;
		private int _waitTimeBlocks;

		public CacheUpdateInfo(DateTime lastUpdate, int waitTimeBlocks) {
			_lastUpdate = lastUpdate;
			_waitTimeBlocks = waitTimeBlocks;
		}

		public CacheUpdateInfo(DateTime lastUpdate) {
			this(lastUpdate, 1);
		}

		public DateTime getLastUpdate() {
			return _lastUpdate;
		}

		public int getWaitTimeBlocks() {
			return _waitTimeBlocks;
		}

		public void setLastUpdate(DateTime lastUpdate) {
			_lastUpdate = lastUpdate;
		}

		public void setWaitTimeBlocks(int waitTimeBlocks) {
			_waitTimeBlocks = waitTimeBlocks;
		}
	}
}
