package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;

import pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;
import pt.ist.fenixframework.FenixFramework;

/**
 * This class implements the get cell phone info service.
 * 
 * This service gets all the cell phones and their balances from a specific
 * operator
 */
public class GetCellPhonesBalancesService extends AnacomService {

	/** The result to return */
	private ListCellPhonesBalancesDto _result;
	/** The service Dto */
	private NetworkOperatorSimpleDto _operator;

	/**
	 * Creates a new instance of this service with information about the
	 * operator.
	 * 
	 * @param dto
	 *            Element with information about the operator from which we want
	 *            to retrieve a list of cellphones and their balances.
	 */
	public GetCellPhonesBalancesService(NetworkOperatorSimpleDto operator) {
		_operator = operator;
		_result = new ListCellPhonesBalancesDto();
	}

	@Override
	public void dispatch() throws OperatorNotExistsException {
		AnacomNetwork an = FenixFramework.getRoot();
		NetworkOperator op = an.getNetworkOperatorByName(_operator.getName());

		if (op == null) {
			throw new OperatorNotExistsException(_operator.getName());
		}

		for (CellPhone phone : op.getCellPhoneSet()) {
			_result.addCellPhoneBalance(phone.getNumber(), phone.getBalance());
		}
	}

	/**
	 * Retrieve a dto containing a list of cellphone balances.
	 * 
	 * @return A DTO containing a list of cellphone balances retrieved by the
	 *         service.
	 */
	public final ListCellPhonesBalancesDto getCellPhonesBalances() {
		return _result;
	}

}
