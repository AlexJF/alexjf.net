package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to an already existing operator.
 */
public class OperatorAlreadyExistsException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _name;
	private String _prefix;

	public OperatorAlreadyExistsException() {
	}

	public OperatorAlreadyExistsException(String name) {
		super("An operator with the name \"" + name
				+ "\" already exists on the network");
		_name = name;
		_prefix = "";
	}

	public OperatorAlreadyExistsException(String name, String prefix) {
		super("An operator with the prefix \"" + prefix
				+ "\" already exists on the network");
		_name = name;
		_prefix = prefix;
	}

	public String getName() {
		return _name;
	}

	public String getPrefix() {
		return _prefix;
	}

    public void throwYourself() {
        throw this;
    }
}
