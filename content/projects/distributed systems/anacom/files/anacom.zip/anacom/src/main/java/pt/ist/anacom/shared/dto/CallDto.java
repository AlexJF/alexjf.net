package pt.ist.anacom.shared.dto;

/**
 * This dto allows the transport the information needed
 * of a call.
 */
public class CallDto extends AnacomDto {
	
	static final long serialVersionUID = 1L;

	/** The source number of the call */
	private String _sourceNumber;
	/** The destination number of the call */
	private String _destinationNumber;

	/**
	 * Constructs a call dto.
	 */
	public CallDto() {
	}

	/**
	 * Creates a new instance of VoiceDto.
	 * 
	 * @param sourceNumber
	 *            The number of the cellphone where the call originated from.
	 * @param destinationNumber
	 *            The number of the cellphone to which the call is directed.
	 */
	public CallDto(String sourceNumber, String destinationNumber) {
		_sourceNumber = sourceNumber;
		_destinationNumber = destinationNumber;
	}

	/**
	 * Get the number of the source CellPhone.
	 * 
	 * @return The number of the source CellPhone.
	 */
	public String getSourceNumber() {
		return _sourceNumber;
	}

	/**
	 * Get the number of the destination CellPhone.
	 * 
	 * @return The number of the destination CellPhone.
	 */
	public String getDestinationNumber() {
		return _destinationNumber;
	}
	
	/**
	 * Compares two instances of CallDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof CallDto))
			return false;

		CallDto dto = (CallDto) obj;

		return getSourceNumber().equals(dto.getSourceNumber())
				&& getDestinationNumber().equals(dto.getDestinationNumber());
	}
}
