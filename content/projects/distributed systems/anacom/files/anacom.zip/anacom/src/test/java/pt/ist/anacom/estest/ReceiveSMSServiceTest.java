package pt.ist.anacom.estest;

import java.math.BigDecimal;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;

import pt.ist.anacom.service.ReceiveSMSService;
import pt.ist.anacom.shared.dto.SMSDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;

public class ReceiveSMSServiceTest extends AnacomTestCase {
	private static String OPERATOR_NAME = "ROFLCOPTER";
	private static String OPERATOR_PREFIX = "12";
	private static int OPERATOR_VOICE_COST = 20;
	private static int OPERATOR_VIDEO_COST = 40;
	private static int OPERATOR_SMS_COST = 5;
	private static BigDecimal OPERATOR_TAX = new BigDecimal(1.5);

	private static String CELL_NON_EXISTING_NUMBER = "123434343";

	private static String CELL_2G_ON_NUMBER = "123456700";
	private static String CELL_2G_SILENT_NUMBER = "123456701";
	private static String CELL_2G_BUSY_NUMBER = "123456702";
	private static String CELL_2G_OFF_NUMBER = "123456703";

	private static String CELL_3G_ON_NUMBER = "123456710";
	private static String CELL_3G_SILENT_NUMBER = "123456711";
	private static String CELL_3G_BUSY_NUMBER = "123456712";
	private static String CELL_3G_OFF_NUMBER = "123456713";

	private static String CELL_DEST_DIFFOPER_NUMBER = "912122121";
	private static String CELL_DEST_SAMEOPER_NUMBER = "123456789";

	private static String SMALL_SMS = "Hello! How are you doing?";

	private static int CELL_BALANCE = 100;

	private CellPhone cell2GOn;
	private CellPhone cell2GSilent;
	private CellPhone cell2GBusy;
	private CellPhone cell2GOff;
	private CellPhone cell3GOn;
	private CellPhone cell3GSilent;
	private CellPhone cell3GBusy;
	private CellPhone cell3GOff;
	private NetworkOperator operator;

	public ReceiveSMSServiceTest(String msg) {
		super(msg);
	}

	public ReceiveSMSServiceTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();

		operator = addOperator(OPERATOR_NAME, OPERATOR_PREFIX,
				OPERATOR_VOICE_COST, OPERATOR_VIDEO_COST, OPERATOR_SMS_COST,
				OPERATOR_TAX);

		cell2GOn = addCellPhone2G(operator, CELL_2G_ON_NUMBER, CELL_BALANCE);
		cell2GSilent = addCellPhone2G(operator, CELL_2G_SILENT_NUMBER,
				CELL_BALANCE);
		turnCellPhoneSilent(cell2GSilent);
		cell2GBusy = addCellPhone2G(operator, CELL_2G_BUSY_NUMBER, CELL_BALANCE);
		turnCellPhoneBusy(cell2GBusy);
		cell2GOff = addCellPhone2G(operator, CELL_2G_OFF_NUMBER, CELL_BALANCE);
		turnCellPhoneOff(cell2GOff);

		cell3GOn = addCellPhone3G(operator, CELL_3G_ON_NUMBER, CELL_BALANCE);
		cell3GSilent = addCellPhone3G(operator, CELL_3G_SILENT_NUMBER,
				CELL_BALANCE);
		turnCellPhoneSilent(cell3GSilent);
		cell3GBusy = addCellPhone3G(operator, CELL_3G_BUSY_NUMBER, CELL_BALANCE);
		turnCellPhoneBusy(cell3GBusy);
		cell3GOff = addCellPhone3G(operator, CELL_3G_OFF_NUMBER, CELL_BALANCE);
		turnCellPhoneOff(cell3GOff);
	}

	public void testReceiveSMSInNonExisting() {
		// Arrange
		SMSDto dto = new SMSDto(CELL_DEST_DIFFOPER_NUMBER,
				CELL_NON_EXISTING_NUMBER, SMALL_SMS);
		ReceiveSMSService service = new ReceiveSMSService(dto);

		// Act
		try {
			service.execute();
			fail("CellPhone does not exist. SMS receival should fail");
		} catch (CellPhoneNotExistsException e) {
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw CellPhoneNotExistsException.");
		}
	}

	public void testReceiveSMSOn2GOn() {
		// Arrange
		SMSDto dto = new SMSDto(CELL_DEST_SAMEOPER_NUMBER, CELL_2G_ON_NUMBER,
				SMALL_SMS);
		ReceiveSMSService service = new ReceiveSMSService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell2GOn);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is on. SMS receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell2GOn,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell2GOn));
	}

	public void testReceiveSMSOn2GSilent() {
		// Arrange
		SMSDto dto = new SMSDto(CELL_DEST_SAMEOPER_NUMBER,
				CELL_2G_SILENT_NUMBER, SMALL_SMS);
		ReceiveSMSService service = new ReceiveSMSService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell2GSilent);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is silent. SMS receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell2GSilent,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell2GSilent));
	}

	public void testReceiveSMSOn2GBusy() {
		// Arrange
		SMSDto dto = new SMSDto(CELL_DEST_SAMEOPER_NUMBER, CELL_2G_BUSY_NUMBER,
				SMALL_SMS);
		ReceiveSMSService service = new ReceiveSMSService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell2GBusy);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is busy. SMS receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell2GBusy,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell2GBusy));
	}

	public void testReceiveSMSOn2GOff() {
		// Arrange
		SMSDto dto = new SMSDto(CELL_DEST_SAMEOPER_NUMBER, CELL_2G_OFF_NUMBER,
				SMALL_SMS);
		ReceiveSMSService service = new ReceiveSMSService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell2GOff);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
            e.printStackTrace();
			fail("CellPhone exists and is off. SMS receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell2GOff,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell2GOff));
	}

	public void testReceiveSMSOn3GOn() {
		// Arrange
		SMSDto dto = new SMSDto(CELL_DEST_SAMEOPER_NUMBER, CELL_3G_ON_NUMBER,
				SMALL_SMS);
		ReceiveSMSService service = new ReceiveSMSService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell3GOn);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is on. SMS receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell3GOn,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell3GOn));
	}

	public void testReceiveSMSOn3GSilent() {
		// Arrange
		SMSDto dto = new SMSDto(CELL_DEST_SAMEOPER_NUMBER,
				CELL_3G_SILENT_NUMBER, SMALL_SMS);
		ReceiveSMSService service = new ReceiveSMSService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell3GSilent);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is silent. SMS receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell3GSilent,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell3GSilent));
	}

	public void testReceiveSMSOn3GBusy() {
		// Arrange
		SMSDto dto = new SMSDto(CELL_DEST_SAMEOPER_NUMBER, CELL_3G_BUSY_NUMBER,
				SMALL_SMS);
		ReceiveSMSService service = new ReceiveSMSService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell3GBusy);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is busy. SMS receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell3GBusy,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell3GBusy));
	}

	public void testReceiveSMSOn3GOff() {
		// Arrange
		SMSDto dto = new SMSDto(CELL_DEST_SAMEOPER_NUMBER, CELL_3G_OFF_NUMBER,
				SMALL_SMS);
		ReceiveSMSService service = new ReceiveSMSService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell3GOff);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is off. SMS receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell3GOff,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell3GOff));
	}
}
