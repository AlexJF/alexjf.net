package pt.ist.anacom.presentationserver.client;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.SMSDto;

import pt.ist.anacom.shared.exception.BalanceChangeException;
import pt.ist.anacom.shared.exception.BusyStateException;
import pt.ist.anacom.shared.exception.CellPhoneAlreadyExistsException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.DestinationBusyException;
import pt.ist.anacom.shared.exception.DestinationOffException;
import pt.ist.anacom.shared.exception.DestinationSilenceException;
import pt.ist.anacom.shared.exception.HigherThanMaxBalanceException;
import pt.ist.anacom.shared.exception.IncomingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.InvalidCellPhoneNumberException;
import pt.ist.anacom.shared.exception.InvalidCellPhonePrefixException;
import pt.ist.anacom.shared.exception.NegativeBalanceException;
import pt.ist.anacom.shared.exception.NotAStateException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;
import pt.ist.anacom.shared.exception.OutgoingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.SourceBusyException;
import pt.ist.anacom.shared.exception.SourceOffException;

@RemoteServiceRelativePath("service")
public interface AnacomService extends RemoteService {
	public void initBridge(String serverType);

	public void registerCellPhone(CellPhoneDetailedDto dto)
			throws OperatorNotExistsException, CellPhoneAlreadyExistsException,
			InvalidCellPhoneNumberException, InvalidCellPhonePrefixException,
			HigherThanMaxBalanceException;

	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto)
			throws InvalidCellPhoneNumberException, OperatorNotExistsException,
			CellPhoneNotExistsException;

	public CellPhoneWithStateDto getCellPhoneState(CellPhoneSimpleDto dto)
			throws InvalidCellPhoneNumberException, OperatorNotExistsException,
			CellPhoneNotExistsException;

	public List<SMSDto> listSMS(CellPhoneSimpleDto dto)
			throws InvalidCellPhoneNumberException, OperatorNotExistsException,
			CellPhoneNotExistsException;
	
	public CommunicationDetailsDto getLastCommunicationDetails(CellPhoneSimpleDto dto)
			throws InvalidCellPhoneNumberException, CellPhoneNotExistsException;

	public void changeCellPhoneState(CellPhoneWithStateDto dto)
			throws InvalidCellPhoneNumberException, NotAStateException,
			BusyStateException, CellPhoneNotExistsException;

	public void increaseCellPhoneBalance(ChangeCellPhoneBalanceDto dto)
			throws InvalidCellPhoneNumberException, BalanceChangeException,
			HigherThanMaxBalanceException, CellPhoneNotExistsException;

	public void sendSMS(SMSDto dto) throws CellPhoneNotExistsException,
			OutgoingCommunicationNotSupportedException,
			NegativeBalanceException, SourceOffException, SourceBusyException,
			InvalidCellPhoneNumberException;

    public void establishVoiceCommunication(CallDto dto) throws 
           CellPhoneNotExistsException,
           OutgoingCommunicationNotSupportedException,
           IncomingCommunicationNotSupportedException,
           SourceOffException, SourceBusyException,
           DestinationOffException, DestinationSilenceException,
           DestinationBusyException, NegativeBalanceException,
           InvalidCellPhoneNumberException;

    public void establishVideoCommunication(CallDto dto) throws 
           CellPhoneNotExistsException,
           OutgoingCommunicationNotSupportedException,
           IncomingCommunicationNotSupportedException,
           SourceOffException, SourceBusyException,
           DestinationOffException, DestinationSilenceException,
           DestinationBusyException, NegativeBalanceException,
           InvalidCellPhoneNumberException;

    public void terminateActiveCommunication(CallWithDurationDto dto)
           throws CellPhoneNotExistsException,
                  InvalidCellPhoneNumberException;
}
