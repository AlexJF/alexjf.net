package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.CellPhoneOffState;
import pt.ist.anacom.domain.CellPhoneOnState;
import pt.ist.anacom.domain.CellPhoneSilenceState;
import pt.ist.anacom.domain.CellPhoneState;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.exception.BusyStateException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.NotAStateException;
import pt.ist.fenixframework.FenixFramework;

/**
 * This class implements the change cell phone state info service.
 * 
 * This service changes the state of the cell phone whose number was passed on
 * the dto.
 */
public class ChangeCellPhoneStateService extends AnacomService {

	/** The service dto */
	CellPhoneWithStateDto _dto;

	public ChangeCellPhoneStateService(CellPhoneWithStateDto dto) {
		_dto = dto;
	}

	@Override
	public void dispatch() throws BusyStateException, NotAStateException,
			CellPhoneNotExistsException {
		AnacomNetwork n = FenixFramework.getRoot();
		CellPhone p = n.getCellPhoneOrException(_dto.getNumber());

		CellPhoneState s = null;
		switch (_dto.getState()) {
		case On:
			s = new CellPhoneOnState();
			break;
		case Silent:
			s = new CellPhoneSilenceState();
			break;
		case Off:
			s = new CellPhoneOffState();
			break;
		case Busy:
			throw new BusyStateException(_dto.getNumber());
		default:
			throw new NotAStateException(_dto.getNumber(), _dto.getState()
					.name());
		}
		p.setCellPhoneState(s);
	}

}
