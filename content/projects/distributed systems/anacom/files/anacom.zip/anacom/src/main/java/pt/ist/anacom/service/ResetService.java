package pt.ist.anacom.service;

import java.util.Set;
import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.fenixframework.FenixFramework;

/**
 * This class resets the entire network to a blank state
 */
public class ResetService extends AnacomService {
	@Override
	public void dispatch() {
        AnacomNetwork network = FenixFramework.getRoot();
        Set<NetworkOperator> allOperators = network.getNetworkOperatorSet();
        for (NetworkOperator op : allOperators) {
            op.getCellPhoneSet().clear();
        }
	}
}
