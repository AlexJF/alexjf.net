package pt.ist.anacom.sdtest;

import java.security.KeyPair;

import pt.ist.anacom.caserver.CaServiceImpl;

import pt.ist.anacom.sdtest.stubs.CASecurityManagerTester;

import pt.ist.anacom.shared.stubs.CAException_Exception;
import sun.security.x509.X509CRLImpl;
import sun.security.x509.X509CertImpl;

public class CAServiceTest extends SecurityTestCase {
    private CaServiceImpl ca;
	private String publicKey1String;
    private KeyPair keyPair1;
	private String publicKey2String;
    private KeyPair keyPair2;
	private final String SUBJECT = "TESTEAPP";
    private final String CHALLENGE = "ZOMG TEH LEGIT!!!";
    private final CASecurityManagerTester sm = new CASecurityManagerTester();
	
	public CAServiceTest(String msg) {
		super(msg);
	}

	public CAServiceTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();

        sm.clearBlacklist();
		
        keyPair1 = generateKeyPair();
        keyPair2 = generateKeyPair();
        publicKey1String = base64Encode(keyPair1.getPublic().getEncoded());
        publicKey2String = base64Encode(keyPair2.getPublic().getEncoded());

        ca = new CaServiceImpl() {
            protected pt.ist.anacom.security.managers.CASecurityManager getSecurityManager() {
                return sm;
            };            
        };
	}
	
	@Override
	public void tearDown() {
	}
	
	/* Crates a certificate from a give CA, signing a give
	 * public key to a certain subject.
	 */
	public void testCreateCertificate() {
		// Arrange
		X509CertImpl cert = null;
		
		// Act
		try {
            cert = getCertificateFromCA(ca, publicKey1String, SUBJECT);
		} catch (Exception e) {
            System.out.println(e.getMessage());
			e.printStackTrace();
            fail("Certificate creation should not fail");
		}
		
		// Assert
		assertEquals("The public key in the certificate should be the same as the one provided.", 
				base64Encode(cert.getPublicKey().getEncoded()), publicKey1String);
		
		assertEquals("The issuer name should be that of the CA.", 
				"CN=CA, OU=Certification Authority, O=CA.anacom.pt, C=PT",
				cert.getIssuerX500Principal().toString());
		
		assertEquals("The subject name should be that of the provided APP.", 
				"CN="+SUBJECT+", OU=certificate, O="+SUBJECT+".anacom.pt, C=PT",
				cert.getSubjectDN().toString());
	}
	
	/* Create a certificate from a given CA and ask to revoke the same
	 * certificate providing a certain wrong challenge.
	 * The main idea is to see if CA checks that the challenge is wrong
	 * and also does not performs the revoke. Also, it checks if the 
	 * certificate is not on the blacklist retrieved from CA.
	 */
	public void testRevokeCertificateNotLegit() {
        // Arrange
		X509CertImpl cert = null;
		X509CRLImpl blackListBeforeRevoke = null;
		X509CRLImpl blackListAfterRevoke = null;
        String challenge = base64Encode(encryptData(CHALLENGE.getBytes(), keyPair2.getPrivate()));

		// Act
		try {
            cert = getCertificateFromCA(ca, publicKey1String, SUBJECT);
			blackListBeforeRevoke = getBlacklistFromCA(ca);
			ca.revokeCertificate(base64Encode(cert.getEncoded()), challenge);
			blackListAfterRevoke = getBlacklistFromCA(ca);
			fail("Certificate revocation should fail since the caller failed the challenge (encrypted with wrong private key)");
		} catch (CAException_Exception e) {
            // All is well
		} catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            fail("Exception should be of type CAException_Exception.");
        }

        try {
			blackListAfterRevoke = getBlacklistFromCA(ca);
        } catch (Exception e) {
			e.printStackTrace();
            System.out.println(e.getMessage());
            fail("Blacklist request should not fail");
        }
		
		// Assert
		assertFalse("The certificate should not be on the blacklist before revokal", 
			blackListBeforeRevoke.isRevoked(cert));
		assertFalse("The certificate should not be on the blacklist after revokal", 
            blackListAfterRevoke.isRevoked(cert));
	}
	
	/* Create a certificate from a given CA and ask to revoke the same
	 * certificate providing a certain correct challenge.
	 * The main idea is to see if CA checks that the challenge is correct
	 * and also performs the revoke. Also, it checks if the 
	 * certificate is on the blacklist retrieved from CA.
	 */
	public void testRevokeCertificateLegit() {
        // Arrange
		X509CertImpl cert = null;
		X509CRLImpl blackListBeforeRevoke = null;
		X509CRLImpl blackListAfterRevoke = null;
        String challenge = base64Encode(encryptData(CHALLENGE.getBytes(), keyPair1.getPrivate()));

		// Act
		try {
            cert = getCertificateFromCA(ca, publicKey1String, SUBJECT);
			blackListBeforeRevoke = getBlacklistFromCA(ca);
			ca.revokeCertificate(base64Encode(cert.getEncoded()), challenge);
			blackListAfterRevoke = getBlacklistFromCA(ca);
		} catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
			fail("Certificate revocation should not have failed");
		}
		
		// Assert
		assertFalse("The certificate should not be on the blacklist before revokal", 
			blackListBeforeRevoke.isRevoked(cert));
		assertTrue("The certificate should be on the blacklist after revokal", 
				blackListAfterRevoke.isRevoked(cert));
	}
	
	/* If a certain certificate is already revoked then it should not be possible
	 * to revoke it again. This test tests that by waiting for an exception that
	 * CA should throw. Also the certificate should be on the blacklist retrived
	 * by CA.
	 */
	public void testRevokeSameCertificateTwice() {
        // Arrange
		X509CertImpl cert = null;
		X509CRLImpl blackListBeforeRevoke = null;
		X509CRLImpl blackListAfterRevoke = null;
        String challenge = base64Encode(encryptData(CHALLENGE.getBytes(), keyPair1.getPrivate()));
		
		// Act
		try {
            cert = getCertificateFromCA(ca, publicKey1String, SUBJECT);
			blackListBeforeRevoke = getBlacklistFromCA(ca);
			ca.revokeCertificate(base64Encode(cert.getEncoded()), challenge);
            // This one should throw CAException_Exception
			ca.revokeCertificate(base64Encode(cert.getEncoded()), challenge);
		} catch (CAException_Exception e) {
			//Everything is fine
		} catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
			fail("Wrong exception thrown. It should throw CAException_Exception.");
		}

        try {
			blackListAfterRevoke = getBlacklistFromCA(ca);
        } catch (Exception e) {
            e.printStackTrace();
			System.out.println(e.getMessage());
			fail("Blacklist request should not fail");
        }

		// Assert
		assertFalse("The certificate should not be on the blacklist before revokal", 
			blackListBeforeRevoke.isRevoked(cert));
		assertTrue("The certificate should be on the blacklist after revokal", 
				blackListAfterRevoke.isRevoked(cert));
	}
	
	/* This test creates and revokes a certificate for someone. And then
	 * repeat the process. The idea is to see if CA can handle different
	 * certificates for the same key from the same person in different 
	 * instances of time.
	 */
	public void testRevokeCertificatesFromSameSubjectTwice() {
        // Arrange
		X509CertImpl certFirst = null;
		X509CertImpl certSecond = null;
		X509CRLImpl blackListBeforeRevokeFirstCertificate = null;
		X509CRLImpl blackListAfterRevokeFirstCertificate = null;
		X509CRLImpl blackListBeforeRevokeSecondCertificate = null;
		X509CRLImpl blackListAfterRevokeSecondCertificate = null;
        String challenge = base64Encode(encryptData(CHALLENGE.getBytes(), keyPair1.getPrivate()));
		
		// Act
		try {
			certFirst = getCertificateFromCA(ca, publicKey1String, SUBJECT);
			blackListBeforeRevokeFirstCertificate = getBlacklistFromCA(ca);
			ca.revokeCertificate(base64Encode(certFirst.getEncoded()), challenge);
			blackListAfterRevokeFirstCertificate = getBlacklistFromCA(ca);

			certSecond = getCertificateFromCA(ca, publicKey1String, SUBJECT);
			blackListBeforeRevokeSecondCertificate = getBlacklistFromCA(ca);
			ca.revokeCertificate(base64Encode(certSecond.getEncoded()), challenge);
			blackListAfterRevokeSecondCertificate = getBlacklistFromCA(ca);
		} catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
			fail("Revokal should not fail");
		}
		
		// Assert
		assertFalse("The first certificate should not be revoked before revocation", 
				blackListBeforeRevokeFirstCertificate.isRevoked(certFirst));
		assertFalse("The second certificate should not be revoked before revocation", 
				blackListBeforeRevokeSecondCertificate.isRevoked(certSecond));
		assertTrue("The first certificate should be revoked after recovation", 
				blackListAfterRevokeFirstCertificate.isRevoked(certFirst));
		assertTrue("The second certificate should be revoked after revocation", 
				blackListAfterRevokeSecondCertificate.isRevoked(certSecond));
	}
	
	/* This test creates and revokes a certificate for someone. And then
	 * repeat the process. The idea is to see if CA can handle different
	 * certificates for the DIFFERENT key from the same person in different 
	 * instances of time.
	 */
	public void testRevokeCertificatesFromSameSubjectDifferentKeys() {
        // Arrange
		X509CertImpl certFirst = null;
		X509CertImpl certSecond = null;
		X509CRLImpl blackListBeforeRevokeFirstCertificate = null;
		X509CRLImpl blackListAfterRevokeFirstCertificate = null;
		X509CRLImpl blackListBeforeRevokeSecondCertificate = null;
		X509CRLImpl blackListAfterRevokeSecondCertificate = null;
        String challenge1 = base64Encode(encryptData(CHALLENGE.getBytes(), keyPair1.getPrivate()));
        String challenge2 = base64Encode(encryptData(CHALLENGE.getBytes(), keyPair2.getPrivate()));
		
		// Act
		try {
			certFirst = getCertificateFromCA(ca, publicKey1String, SUBJECT);
			blackListBeforeRevokeFirstCertificate = getBlacklistFromCA(ca);
			ca.revokeCertificate(base64Encode(certFirst.getEncoded()), challenge1);
			blackListAfterRevokeFirstCertificate = getBlacklistFromCA(ca);

			certSecond = getCertificateFromCA(ca, publicKey2String, SUBJECT);
			blackListBeforeRevokeSecondCertificate = getBlacklistFromCA(ca);
			ca.revokeCertificate(base64Encode(certSecond.getEncoded()), challenge2);
			blackListAfterRevokeSecondCertificate = getBlacklistFromCA(ca);
		} catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
			fail("Revokal should not fail");
		}
		
		// Assert
		assertFalse("The first certificate should not be revoked before revocation", 
				blackListBeforeRevokeFirstCertificate.isRevoked(certFirst));
		assertFalse("The second certificate should not be revoked before revocation", 
				blackListBeforeRevokeSecondCertificate.isRevoked(certSecond));
		assertTrue("The first certificate should be revoked after recovation", 
				blackListAfterRevokeFirstCertificate.isRevoked(certFirst));
		assertTrue("The second certificate should be revoked after revocation", 
				blackListAfterRevokeSecondCertificate.isRevoked(certSecond));
	}
	
}
