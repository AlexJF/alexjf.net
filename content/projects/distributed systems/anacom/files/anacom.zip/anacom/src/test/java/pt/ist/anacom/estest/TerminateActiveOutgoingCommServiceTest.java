package pt.ist.anacom.estest;

import java.math.BigDecimal;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.domain.Video;
import pt.ist.anacom.domain.Voice;

import pt.ist.anacom.service.TerminateActiveOutgoingCommService;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;

public class TerminateActiveOutgoingCommServiceTest extends AnacomTestCase {
	private static String OPERATOR_NAME = "ROFLCOPTER";
	private static String OPERATOR_PREFIX = "12";
	private static int OPERATOR_VOICE_COST = 20;
	private static int OPERATOR_VIDEO_COST = 40;
	private static int OPERATOR_SMS_COST = 5;
	private static BigDecimal OPERATOR_TAX = new BigDecimal(1.5);

    private static String CELL_SAME_OPER_NUMBER = "123456789";
    private static String CELL_DIFF_OPER_NUMBER = "912223344";
	private static String CELL_NON_EXISTING_NUMBER = "123434343";

	private static String CELL_3G_ON_NUMBER = "123456710";

	private static int CELL_BALANCE = 1000;

    private static int VOICE_DURATION = 10;
    private static int VIDEO_DURATION = 10;

	private CellPhone cell3GOn;
	private NetworkOperator operator;

	public TerminateActiveOutgoingCommServiceTest(String msg) {
		super(msg);
	}

	public TerminateActiveOutgoingCommServiceTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();

		operator = addOperator(OPERATOR_NAME, OPERATOR_PREFIX,
				OPERATOR_VOICE_COST, OPERATOR_VIDEO_COST, OPERATOR_SMS_COST,
				OPERATOR_TAX);

		cell3GOn = addCellPhone3G(operator, CELL_3G_ON_NUMBER, CELL_BALANCE);
	}

	public void testTerminateActiveOutgoingVideoSameOper() {
		// Arrange
        Video video = addOutgoingVideo(cell3GOn, CELL_SAME_OPER_NUMBER);
		CallWithDurationDto dto = new CallWithDurationDto(CELL_3G_ON_NUMBER, CELL_SAME_OPER_NUMBER, VIDEO_DURATION);
		TerminateActiveOutgoingCommService service = new TerminateActiveOutgoingCommService(dto);
        int initialBalance = getCellPhoneBalance(cell3GOn);
		int expectedCost = calculateVideoCost(operator, VIDEO_DURATION, false);
		int expectedBalance = initialBalance - expectedCost;

		// Act
		try {
			service.execute();
        } catch (AnacomException e) {
            fail("Outgoing video communication termination should be successful.");
		}

		// Assert
		assertEquals("The balance after the outgoing voice comm termination should be reduced",
				expectedBalance, getCellPhoneBalance(cell3GOn));
		assertEquals("There should be no active communication after termination",
				getActiveCommunication(cell3GOn), null);
		assertEquals("Saved communication data should have the real duration of the communication",
				getCommunicationDuration(video), VIDEO_DURATION);
		assertEquals("Saved communication data should have the real cost of the communication",
				getCommunicationCost(video), expectedCost);
        assertTrue("Cellphone should be on after terminating the communication",
                isCellPhoneOn(cell3GOn));
	}

	public void testTerminateActiveOutgoingVoiceDiffOper() {
		// Arrange
        Voice voice = addOutgoingVoice(cell3GOn, CELL_DIFF_OPER_NUMBER);
		CallWithDurationDto dto = new CallWithDurationDto(CELL_3G_ON_NUMBER, CELL_DIFF_OPER_NUMBER, VOICE_DURATION);
		TerminateActiveOutgoingCommService service = new TerminateActiveOutgoingCommService(dto);
        int initialBalance = getCellPhoneBalance(cell3GOn);
		int expectedCost = calculateVoiceCost(operator, VOICE_DURATION, true);
		int expectedBalance = initialBalance - expectedCost;

		// Act
		try {
			service.execute();
        } catch (AnacomException e) {
            fail("Outgoing voice communication termination should be successful.");
		}

		// Assert
		assertEquals("The balance after the outgoing voice comm termination should be reduced",
				expectedBalance, getCellPhoneBalance(cell3GOn));
		assertEquals("There should be no active communication after termination",
				getActiveCommunication(cell3GOn), null);
		assertEquals("Saved communication data should have the real duration of the communication",
				getCommunicationDuration(voice), VOICE_DURATION);
		assertEquals("Saved communication data should have the real cost of the communication",
				getCommunicationCost(voice), expectedCost);
        assertTrue("Cellphone should be on after terminating the communication",
                isCellPhoneOn(cell3GOn));
	}

	public void testTerminateActiveOutgoingVideoDiffOper() {
		// Arrange
        Video video = addOutgoingVideo(cell3GOn, CELL_DIFF_OPER_NUMBER);
		CallWithDurationDto dto = new CallWithDurationDto(CELL_3G_ON_NUMBER, CELL_DIFF_OPER_NUMBER, VIDEO_DURATION);
		TerminateActiveOutgoingCommService service = new TerminateActiveOutgoingCommService(dto);
        int initialBalance = getCellPhoneBalance(cell3GOn);
		int expectedCost = calculateVideoCost(operator, VIDEO_DURATION, true);
		int expectedBalance = initialBalance - expectedCost;

		// Act
		try {
			service.execute();
        } catch (AnacomException e) {
            fail("Outgoing video communication termination should be successful.");
		}

		// Assert
		assertEquals("The balance after the outgoing voice comm termination should be reduced",
				expectedBalance, getCellPhoneBalance(cell3GOn));
		assertEquals("There should be no active communication after termination",
				getActiveCommunication(cell3GOn), null);
		assertEquals("Saved communication data should have the real duration of the communication",
				getCommunicationDuration(video), VIDEO_DURATION);
		assertEquals("Saved communication data should have the real cost of the communication",
				getCommunicationCost(video), expectedCost);
        assertTrue("Cellphone should be on after terminating the communication",
                isCellPhoneOn(cell3GOn));
	}

	public void testTerminateActiveOutgoingVoiceSameOper() {
		// Arrange
        Voice voice = addOutgoingVoice(cell3GOn, CELL_SAME_OPER_NUMBER);
		CallWithDurationDto dto = new CallWithDurationDto(CELL_3G_ON_NUMBER, CELL_SAME_OPER_NUMBER, VOICE_DURATION);
		TerminateActiveOutgoingCommService service = new TerminateActiveOutgoingCommService(dto);
        int initialBalance = getCellPhoneBalance(cell3GOn);
		int expectedCost = calculateVoiceCost(operator, VOICE_DURATION, false);
		int expectedBalance = initialBalance - expectedCost;

		// Act
		try {
			service.execute();
        } catch (AnacomException e) {
            fail("Outgoing voice communication termination should be successful.");
		}

		// Assert
		assertEquals("The balance after the outgoing voice comm termination should be reduced",
				expectedBalance, getCellPhoneBalance(cell3GOn));
		assertEquals("There should be no active communication after termination",
				getActiveCommunication(cell3GOn), null);
		assertEquals("Saved communication data should have the real duration of the communication",
				getCommunicationDuration(voice), VOICE_DURATION);
		assertEquals("Saved communication data should have the real cost of the communication",
				getCommunicationCost(voice), expectedCost);
        assertTrue("Cellphone should be on after terminating the communication",
                isCellPhoneOn(cell3GOn));
	}

	public void testTerminateActiveOutgoingNonExistentActive() {
        // Arrange
		CallWithDurationDto dto = new CallWithDurationDto(CELL_3G_ON_NUMBER, CELL_SAME_OPER_NUMBER, VOICE_DURATION);
		TerminateActiveOutgoingCommService service = new TerminateActiveOutgoingCommService(dto);

		// Act
		try {
			service.execute();
        } catch (AnacomException e) {
            fail("Outgoing video communication termination should be successful even when no such communication exists.");
		}
	}

	public void testTerminateActiveOutgoingNonExistentCellPhone() {
        // Arrange
		CallWithDurationDto dto = new CallWithDurationDto(CELL_NON_EXISTING_NUMBER, CELL_SAME_OPER_NUMBER, VOICE_DURATION);
		TerminateActiveOutgoingCommService service = new TerminateActiveOutgoingCommService(dto);

		// Act
		try {
			service.execute();
        } catch (CellPhoneNotExistsException e) {
            // All is well
        } catch (AnacomException e) {
            fail("Wrong exception thrown. Should have thrown CellPhoneNotExistsException.");
		}
	}

	private int calculateVideoCost(NetworkOperator operator, int duration,
			boolean diffOperator) {
		int cost = getOperatorCostVideo(operator) * duration;

		if (diffOperator) {
			cost = getOperatorTax(operator).multiply(new BigDecimal(cost))
					.intValue();
		}

		return cost;
	}

	private int calculateVoiceCost(NetworkOperator operator, int duration,
			boolean diffOperator) {
		int cost = getOperatorCostVoice(operator) * duration;

		if (diffOperator) {
			cost = getOperatorTax(operator).multiply(new BigDecimal(cost))
					.intValue();
		}

		return cost;
	}
}
