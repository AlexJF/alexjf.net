package pt.ist.anacom.sdtest;

import java.security.KeyPair;
import java.util.Date;

import javax.xml.soap.SOAPMessage;

import pt.ist.anacom.sdtest.stubs.CACertificateHandlerTester;
import pt.ist.anacom.security.managers.CASecurityManager;
import sun.security.x509.X509CertImpl;

public class CACertificateHandlerTest extends SecurityTestCase {
    KeyPair kPair = generateKeyPair();
    
    private CACertificateHandlerTester handler;
    
    public static final String SOAP_MESSAGE_REVOKE = 
            "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
            "<soap:Body><ns2:revoke xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
            "</soap:Envelope>";
    
    public static final String SOAP_MESSAGE_CREATE = 
            "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
            "<soap:Body><ns2:createCertificate xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
            "</soap:Envelope>";
    
    public static final String SOAP_MESSAGE_GETBLACKLIST = 
            "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
            "<soap:Body><ns2:createCertificate xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
            "</soap:Envelope>";
    
    public CACertificateHandlerTest() {
	}

	@Override
	public void setUp() {
		super.setUp();
		handler = new CACertificateHandlerTester();
	}
	
	private SOAPMessage prepareIncomingMessage(String message, X509CertImpl sourceCertificate) {
        SOAPMessage outgoingMessage = createSoapMessageFromString(message);
        
        addCertificateToSoapMessage(outgoingMessage, sourceCertificate);
        return outgoingMessage;
    }
	
    private SOAPMessage prepareValidIncomingMessage(String message) {
        X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", CASecurityManager.getInstance().getPrivateKey(), 15);
        
        return prepareIncomingMessage(message, sourceCertificate);
    }
    
	/* This test simulates a situation where the CA receives a message
	 * and is blacklist is valid.
	 */
	public void testInboundNotOutOfDateBlacklist() {
		//Arrange
		Boolean result = false;
		
		SOAPMessage msg = prepareValidIncomingMessage(SOAP_MESSAGE_REVOKE);
		try {
			// Will return true because everything is fine
			result = handler.testHandleIncomingMessage(msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
	
	
	public void testInboundOutOfDateCertificate() {
		//Arrange
		final KeyPair kPairCA = generateKeyPair();
		Boolean result = false;
		
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", kPairCA.getPrivate(), 4, 1);
			
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_REVOKE, sourceCertificate);
				
		try {
			// Wait two second (certificate expires)
			Thread.sleep(2*1000);
		
			// Will return false because certificate received is no longer valid
			result = handler.testHandleIncomingMessage(msg);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertFalse("Message error", result);
	}
	
	public void testInboundNoOutOfDateCertificate() {
		//Arrange
		Boolean result = false;
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", CASecurityManager.getInstance().getPrivateKey(), 4, 15);
			
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_REVOKE, sourceCertificate);
		
		try {
			// Will return true because everything is valid
			result = handler.testHandleIncomingMessage(msg);	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
	
	public void testInboundRevokedCertificate() {
		//Arrange
		X509CertImpl badCertificate = createCertificate(kPair.getPublic(), "EU", "CA", CASecurityManager.getInstance().getPrivateKey(), 2, 15);
        
        CASecurityManager.getInstance().addToBlackList(badCertificate);
        
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_REVOKE, badCertificate);
	
		Boolean result = false;
		
		try {
			// Will return false because certificate is revoked
	        result = handler.testHandleIncomingMessage(msg);	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertFalse("Message error", result);
	}
	
	public void testInboundCreateCertificate() {
		// Arrange
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", CASecurityManager.getInstance().getPrivateKey(), 4);
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_CREATE, sourceCertificate);
	
		Boolean result = false;
	
		try {
			// Will return true because everything is fine
			result = handler.testHandleIncomingMessage(msg);	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
	
	public void testInboundGetBlackList() {
		// Arrange
		X509CertImpl sourceCertificate = createCertificate(kPair.getPublic(), "EU", "CA", CASecurityManager.getInstance().getPrivateKey(), 4, 15);
			
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_GETBLACKLIST, sourceCertificate);
	
		Boolean result = false;
		try {
		   // Will return true because everything is fine
	       result = handler.testHandleIncomingMessage(msg);	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
	
	public void testOutboundNotOutOfDateCertificate() {
		// Arrange
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
				"CA", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15);

		CASecurityManager.getInstance().setCertificate(certificateToBase64(sourceCertificate));
		
		Boolean result = false;
		try {
			// Will return true because everything is fine
			result = handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE_CREATE));	
		} catch (Exception e) {
			e.printStackTrace();
		}
		// Assert
        assertTrue("Message error", result);
	}
	
	public void testOutboundOutOfDateCertificate() {
		// Arrange
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
				"CA", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 1);

		CASecurityManager.getInstance().setCertificate(certificateToBase64(sourceCertificate));
		
		Boolean result = false;
		
		try {
			Thread.sleep(3*1000);
			// Will return true because it will create a new certificate before sending
			result = handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE_CREATE));	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
	
	public void testOutboundNotOutOfDateBlacklist() {
		// Arrange
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
				"CA", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15);

		CASecurityManager.getInstance().setCertificate(certificateToBase64(sourceCertificate));
		CASecurityManager.getInstance().addToBlackList(sourceCertificate);
		
		Boolean result = false;
		try {
			// Will return true because everything is fine
			result = handler.testHandleOutgoingMessage(createSoapMessageFromString(SOAP_MESSAGE_CREATE));	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Assert
        assertTrue("Message error", result);
	}
}
