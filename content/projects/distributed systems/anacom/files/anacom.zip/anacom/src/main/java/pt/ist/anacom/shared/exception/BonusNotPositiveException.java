package pt.ist.anacom.shared.exception;

public class BonusNotPositiveException extends AnacomException {

	private static final long serialVersionUID = 1L;

	public BonusNotPositiveException() { 
		super();
	}
	
	public BonusNotPositiveException(String msg) {
		super(msg);
	}
	
	@Override
	public void throwYourself() {
		throw this;
	}

}
