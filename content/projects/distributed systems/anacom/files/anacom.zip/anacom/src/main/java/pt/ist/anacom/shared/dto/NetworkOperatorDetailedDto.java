package pt.ist.anacom.shared.dto;

import java.math.BigDecimal;

/**
 * This dto allows to transport detailed information
 * about a network operator.
 */
public class NetworkOperatorDetailedDto extends NetworkOperatorSimpleDto {

	private static final long serialVersionUID = 1L;

	/** Prefix of the operator */
	private String _prefix;

	/** Cost of a sms of the operator */
	private Integer _costSMS;

	/** Cost of a voice communication of the operator */
	private Integer _costVoice;

	/** Cost of a video communication of the operator */
	private Integer _costVideo;

	/** Tax of the operator */
	private BigDecimal _tax;
	
	/** Bonus given by the operator on increase balance */
	private BigDecimal _bonus;

	/**
	 * Creates a new network operator with given information.
	 * 
	 * @param name
	 *            New network operator's name.
	 * @param prefix
	 *            New network operator's prefix.
	 * @param costSMS
	 *            New network operator's SMS cost in cents.
	 * @param costVoice
	 *            New network operator's voice cost in cents.
	 * @param costVideo
	 *            New network operator's video cost in cents.
	 * @param tax
	 *            New network operator's applied tax.
	 * @param bonus
	 * 			  New network operator's bonus tax on balance increase.           
	 */
	public NetworkOperatorDetailedDto(String name, String prefix, int costSMS,
			int costVoice, int costVideo, BigDecimal tax, BigDecimal bonus) {
		super(name);
		_prefix = prefix;
		_costSMS = costSMS;
		_costVoice = costVoice;
		_costVideo = costVideo;
		_tax = tax;
		_bonus = bonus;
	}

	/**
	 * Obtain network operator's prefix.
	 * 
	 * @return A String with network operator's prefix.
	 */
	public String getPrefix() {
		return _prefix;
	}

	/**
	 * Obtain network operator's SMS cost.
	 * 
	 * @return An integer with network operator's SMS cost in cents.
	 */
	public int getCostSMS() {
		return _costSMS;
	}

	/**
	 * Obtain network operator's voice cost.
	 * 
	 * @return An integer with network operator's voice cost in cents.
	 */
	public int getCostVoice() {
		return _costVoice;
	}

	/**
	 * Obtain network operator's video cost.
	 * 
	 * @return An integer with network operator's video cost in cents.
	 */
	public int getCostVideo() {
		return _costVideo;
	}

	/**
	 * Obtain network operator's applied tax.
	 * 
	 * @return Network operator's applied tax.
	 */
	public BigDecimal getTax() {
		return _tax;
	}
	
	/**
	 * Obtain network operator's bonus tax.
	 * 
	 * @return Network operator's applied bonus tax. 
	 */
	public BigDecimal getBonus() {
		return _bonus;
	}
	
	/**
	 * Compares two instances of NetworkOperatorDetailedDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof NetworkOperatorDetailedDto))
			return false;

		NetworkOperatorDetailedDto dto = (NetworkOperatorDetailedDto) obj;

		return getPrefix().equals(dto.getPrefix())
				&& getCostSMS() == dto.getCostSMS()
				&& getCostVoice() == dto.getCostVoice()
				&& getCostVideo() == dto.getCostVideo()
				&& getTax().equals(dto.getTax())
				&& getBonus().equals(dto.getBonus());
	}
}
