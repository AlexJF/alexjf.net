package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.fenixframework.FenixFramework;

/**
 * This class represents a service that allows to increase the balance of a
 * CellPhone.
 */
public class IncreaseCellPhoneBalanceService extends AnacomService {

	/** The Dto received by the service */
	private ChangeCellPhoneBalanceDto _dto;

	/**
	 * Build an instance of IncreaseCellPhoneBalanceService.
	 * 
	 * @param dto
	 *            that the service will use.
	 */
	public IncreaseCellPhoneBalanceService(ChangeCellPhoneBalanceDto dto) {
		_dto = dto;
	}

	@Override
	public void dispatch() throws AnacomException {
		AnacomNetwork network = FenixFramework.getRoot();
		String cellPhoneNumber = _dto.getPhoneNumber();
		int amount = _dto.getAmount();
		NetworkOperator op = network.getNetworkOperatorByCellPhoneNumberOrException(cellPhoneNumber);

		op.increaseCellPhoneBalance(cellPhoneNumber, amount);
	}

}
