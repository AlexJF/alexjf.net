package pt.ist.anacom.service.bridge;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.dto.SMSDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;

/**
 * Interface that provides all the possible operations on Anacom.
 */
public interface ApplicationServerBridge {
	/**
	 * Creates a new operator in the Anacom network.
	 * 
	 * @param dto
	 *            The dto with information regarding the {@link NetworkOperator}
	 *            we want to create.
	 * @throws AnacomException
	 *             if an error occurred during the creation of the operator.
	 */
	public void createNetworkOperator(NetworkOperatorDetailedDto dto)
			throws AnacomException;

	/**
	 * Registers a new cell phone in the correct operator provided that exists a
	 * operator within the Anacom Network that uses the desired prefix.
	 * 
	 * @param dto
	 *            The dto with information regarding the {@link CellPhone} we
	 *            want to register.
	 * @throws AnacomException
	 *             if an error occurred registering the cell phone.
	 */
	public void registerCellPhone(CellPhoneDetailedDto dto)
			throws AnacomException;

	/**
	 * Removes a cell phone from the correct operator provided that the operator
	 * exists on Anacom network.
	 * 
	 * @param dto
	 *            The dto with information regarding the {@link CellPhone} we
	 *            want to remove.
	 * @throws AnacomException
	 *             if an error occurred removing the cell phone.
	 */
	public void removeCellPhone(CellPhoneWithOperatorDto dto)
			throws AnacomException;

	/**
	 * Gets the balance of the cell phone provided as argument.
	 * 
	 * @param dto
	 *            The dto with information regarding the cell phone we want to
	 *            get the balance.
	 * @return A dto with information about the balance of the cell phone.
	 * @throws AnacomException
	 *             if an error occurred when getting the cell phone balance.
	 */
	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException;

	/**
	 * Gets the last communication details of the cell phone provided as argument.
	 * 
	 * @param dto
	 *            The dto with information regarding the cell phone we want to
	 *            get the last communication details.
	 * @return A dto with information about the last communication details of the cell phone.
	 * @throws AnacomException
	 *             if an error occurred when getting the cell phone last communication details.
	 */
	public CommunicationDetailsDto getLastCommunicationDetails(CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException;
	
	/**
	 * Gets the state of the cell phone provided as argument.
	 * 
	 * @param dto
	 *            The dto with information regarding the cell phone we want to
	 *            get the balance.
	 * @return A dto with information about the state of the cell phone.
	 * @throws AnacomException
	 *             if an error occurred when getting the cell phone balance.
	 */
	public CellPhoneWithStateDto getCellPhoneState(CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException;

	/**
	 * Increases the balance of a cell phone in a determined amount.
	 * 
	 * @param dto
	 *            The dto with information about the cell phone we want to
	 *            increase balance and about the amount we want to increase.
	 * @throws AnacomException
	 *             if an error occurred when increasing balance.
	 */
	public void increaseCellPhoneBalance(ChangeCellPhoneBalanceDto dto)
			throws AnacomException;

	/**
	 * Gets the cell phones and their balances of a specific operator.
	 * 
	 * @param operator
	 *            The dto with information about the operator we want to get the
	 *            cell phones' numbers and balances.
	 * @return A dto with a list of {@link CellPhoneSimpleDto} containing
	 *         information about each cell phone of the operator.
	 * @throws AnacomException
	 *             if an error occurred when getting the information.
	 */
	public ListCellPhonesBalancesDto getCellPhonesBalances(
			NetworkOperatorSimpleDto operator) throws AnacomException;

	/**
	 * Gets the cell phone incoming SMS.
	 * 
	 * @param Cell
	 *            phone The dto with information about the cell phone.
	 * @return A dto with a list of {@link SMSDto} containing information about
	 *         all incoming SMS.
	 * @throws AnacomException
	 *             if an error occurred when getting the information.
	 */
	public ListCellPhoneSMSDto getCellPhoneSMS(CellPhoneSimpleDto cellPhone)
			throws AnacomException;

	/**
	 * Manages all the process of sending SMS message. Takes care of both sender
	 * and receiver sides.
	 * 
	 * @param dto
	 *            The dto with information about the sender phone number, the
	 *            destination phone number and the message itself.
	 * @throws AnacomException
	 *             if an error occurred during the sending/receiving processes.
	 */
	public void sendSMS(SMSDto dto) throws AnacomException;
	
	/**
	 * Changes the CellPhone state to the one specified on the dto.
	 * 
	 * @param dto
	 *            The dto with the information about the phone number we want to
	 *            change the state and the state we want to change it to
	 * @throws AnacomException
	 *             if an error occured when changing the state of the mobile
	 */
	public void changeCellPhoneState(CellPhoneWithStateDto dto)
			throws AnacomException;

	/**
	 * Manages all the process of making a video call. 
     * Takes care of both sender and receiver sides.
	 * 
	 * @param dto
	 *            The dto with information about the sender phone number, the
	 *            destination phone number and the message itself.
	 * @throws AnacomException
	 *             if an error occurred during the sending/receiving processes.
	 */
	public void establishVideoCall(CallDto dto) throws AnacomException;
	
	/**
	 * Manages all the process of making a voice call. 
     * Takes care of both sender and receiver sides.
	 * 
	 * @param dto
	 *            The dto with information about the sender phone number, the
	 *            destination phone number and the message itself.
	 * @throws AnacomException
	 *             if an error occurred during the sending/receiving processes.
	 */
	public void establishVoiceCall(CallDto dto) throws AnacomException;

    /**
     * Manages the termination of an active call between 2 cell phones.
     * Takes care of both sender and receiver sides.
     *
     * @param dto The dto with information about the call to be terminated.
     * @throws AnacomException if an error occurred during sending/receiving processes.
     */
    public void terminateActiveCall(CallWithDurationDto dto) throws AnacomException;
}
