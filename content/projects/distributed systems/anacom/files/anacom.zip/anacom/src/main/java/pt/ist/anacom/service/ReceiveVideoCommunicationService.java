package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.domain.Video;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.fenixframework.FenixFramework;

public class ReceiveVideoCommunicationService extends AnacomService{

	private CallDto _dto;
	
	public ReceiveVideoCommunicationService(CallDto dto) {
		_dto = dto;
	}
	
	@Override
	public void dispatch() throws AnacomException {
		AnacomNetwork network = FenixFramework.getRoot();
		NetworkOperator op = network.getNetworkOperatorByCellPhoneNumberOrException(_dto
				.getDestinationNumber());
		
		Video video = new Video(_dto.getSourceNumber(), _dto.getDestinationNumber());
		
		op.receiveCommunication(video);
	}

}
