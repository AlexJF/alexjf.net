package pt.ist.anacom.shared.dto;

public class CellPhoneWithStateDto extends CellPhoneSimpleDto {

	private static final long serialVersionUID = 1L;

	// NOTE: CellPhoneStates done on purpose.
	/**
	 * Do not switch with CellPhoneState class
	 */
	public enum CellPhoneStates {
		On, Silent, Busy, Off;
	}

	/** CellPhone state */
	private CellPhoneStates _state;

	/**
	 * Creates a new CellPhoneWithStateDto.
	 * 
	 * @param phoneNumber
	 *            The number of the cellphone this dto represents.
	 * @param state
	 *            The state associated with this cellphone.
	 */
	public CellPhoneWithStateDto(String phoneNumber, CellPhoneStates state) {
		super(phoneNumber);
		_state = state;
	}

	public CellPhoneWithStateDto() {
	}

	/**
	 * Retrieve the state associated with this cellphone.
	 * 
	 * @return State associated with this cellphone.
	 */
	public CellPhoneStates getState() {
		return _state;
	}

	/**
	 * Sets the state of the CellPhone
	 * 
	 * @param state
	 *            we want to set
	 */
	public void setState(CellPhoneStates state) {
		_state = state;
	}

	/**
	 * Compares two instances of CellPhoneWithStateDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof CellPhoneWithStateDto))
			return false;

		CellPhoneWithStateDto dto = (CellPhoneWithStateDto) obj;

		return getState() == dto.getState();
	}
}
