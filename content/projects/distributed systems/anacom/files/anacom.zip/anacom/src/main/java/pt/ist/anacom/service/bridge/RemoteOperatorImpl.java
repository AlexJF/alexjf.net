package pt.ist.anacom.service.bridge;

import java.util.List;

import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.handler.Handler;

import pt.ist.anacom.security.handlers.anacom.AnacomCertificateHandler;
import pt.ist.anacom.security.handlers.anacom.AnacomDigestHandler;
import pt.ist.anacom.security.handlers.anacom.RequestIDPresentationServerHandler;

import pt.ist.anacom.security.handlers.DebugHandler;

import pt.ist.anacom.security.managers.AnacomSecurityManager;
import pt.ist.anacom.shared.DtoConverter;
import pt.ist.anacom.shared.ExceptionConverter;
import pt.ist.anacom.shared.UDDIHelper;
import pt.ist.anacom.shared.dto.AnacomDto;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.dto.SMSDto;
import pt.ist.anacom.shared.stubs.BalanceChangeException_Exception;
import pt.ist.anacom.shared.stubs.BusyStateException_Exception;
import pt.ist.anacom.shared.stubs.CellPhoneAlreadyExistsException_Exception;
import pt.ist.anacom.shared.stubs.CellPhoneNotExistsException_Exception;
import pt.ist.anacom.shared.stubs.DestinationBusyException_Exception;
import pt.ist.anacom.shared.stubs.DestinationOffException_Exception;
import pt.ist.anacom.shared.stubs.DestinationSilenceException_Exception;
import pt.ist.anacom.shared.stubs.HigherThanMaxBalanceException_Exception;
import pt.ist.anacom.shared.stubs.IncomingCommunicationNotSupportedException_Exception;
import pt.ist.anacom.shared.stubs.InvalidCellPhoneNumberException_Exception;
import pt.ist.anacom.shared.stubs.InvalidCellPhonePrefixException_Exception;
import pt.ist.anacom.shared.stubs.NegativeBalanceException_Exception;
import pt.ist.anacom.shared.stubs.NotAStateException_Exception;
import pt.ist.anacom.shared.stubs.OperatorNotExistsException_Exception;
import pt.ist.anacom.shared.stubs.OperatorPortType;
import pt.ist.anacom.shared.stubs.OperatorService;
import pt.ist.anacom.shared.stubs.OutgoingCommunicationNotSupportedException_Exception;
import pt.ist.anacom.shared.stubs.SourceBusyException_Exception;
import pt.ist.anacom.shared.stubs.SourceOffException_Exception;
import pt.ist.anacom.shared.stubs.WrongTimestampException_Exception;

public class RemoteOperatorImpl implements RemoteOperator {
    private OperatorPortType _port;

    private String _name;
    private String _prefix;
    private String _replicaNumber;
    private String _url;

    protected void notifyUDDIOfFailure(WebServiceException e) {
        System.err.println("Communication error with " + _url);
        UDDIHelper.getSingleton().notifyRemoteOperatorFailed(_name, _replicaNumber);
    }

    public RemoteOperatorImpl() {
		OperatorService service = new OperatorService();
		_port = service.getOperatorPort();
        addSecurityHandlers();
    }

    public RemoteOperatorImpl(String name, String prefix, String replicaNumber, String url) {
        this();
        setName(name);
        setPrefix(prefix);
        setReplicaNumber(replicaNumber);
        setUrl(url);
    }

	public AnacomDto registerCellPhone(CellPhoneDetailedDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.registerCellPhone(DtoConverter
					.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (OperatorNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneAlreadyExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (InvalidCellPhonePrefixException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (HigherThanMaxBalanceException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}
	
	public AnacomDto removeCellPhone(CellPhoneWithOperatorDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.removeCellPhone(DtoConverter.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (OperatorNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}
	
	public AnacomDto increaseCellPhoneBalance(ChangeCellPhoneBalanceDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.increaseCellPhoneBalance(DtoConverter
					.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (BalanceChangeException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (HigherThanMaxBalanceException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}
	
	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port
					.getCellPhoneBalance(DtoConverter
							.convertToWebServiceDto(dto)));

        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}
	
	public CellPhoneWithStateDto getCellPhoneState(CellPhoneSimpleDto dto) {
		try {
			return DtoConverter
					.convertFromWebServiceDto(_port
							.getCellPhoneState(DtoConverter
									.convertToWebServiceDto(dto)));

        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}

	public AnacomDto sendSMS(SMSDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.sendSMS(DtoConverter.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (OutgoingCommunicationNotSupportedException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (NegativeBalanceException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (SourceOffException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (SourceBusyException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}

    public AnacomDto receiveSMS(SMSDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.receiveSMS(DtoConverter.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (IncomingCommunicationNotSupportedException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
    }

	public ListCellPhonesBalancesDto getCellPhonesBalances(NetworkOperatorSimpleDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port
					.getCellPhonesBalances(DtoConverter
							.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (OperatorNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}
	
	public ListCellPhoneSMSDto getCellPhoneSMS(CellPhoneSimpleDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port
					.getCellPhoneSMS(DtoConverter.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}

	public AnacomDto changeCellPhoneState(CellPhoneWithStateDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.changeCellPhoneState(DtoConverter
					.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (BusyStateException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (NotAStateException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}
	
	public CommunicationDetailsDto getLastCommunicationDetails(CellPhoneSimpleDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.getLastCommunicationDetails(DtoConverter.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}
	
	public AnacomDto establishVideoCommunication(CallDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.establishVideoCommunication(DtoConverter
					.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (OutgoingCommunicationNotSupportedException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (NegativeBalanceException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (SourceOffException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (SourceBusyException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}

	public AnacomDto receiveVideoCommunication(CallDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.receiveVideoCommunication(DtoConverter
					.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (IncomingCommunicationNotSupportedException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (DestinationBusyException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (DestinationOffException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (DestinationSilenceException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}

	public AnacomDto establishVoiceCommunication(CallDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.establishVoiceCommunication(DtoConverter
					.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (OutgoingCommunicationNotSupportedException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (NegativeBalanceException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (SourceOffException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (SourceBusyException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}

	public AnacomDto receiveVoiceCommunication(CallDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.receiveVoiceCommunication(DtoConverter
					.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (IncomingCommunicationNotSupportedException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (DestinationBusyException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (DestinationOffException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (DestinationSilenceException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}
	
	public AnacomDto terminateActiveOutgoingCommunication(CallWithDurationDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.terminateActiveOutgoingCommunication(DtoConverter.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}

	public AnacomDto terminateActiveIncomingCommunication(CallWithDurationDto dto) {
		try {
			return DtoConverter.convertFromWebServiceDto(_port.terminateActiveIncomingCommunication(DtoConverter.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
		} catch (InvalidCellPhoneNumberException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		} catch (CellPhoneNotExistsException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
        } catch (WrongTimestampException_Exception e) {
			throw ExceptionConverter.convertFromWebServiceException(e);
		}
	}

    public AnacomDto getTimestamp(AnacomDto dto) {
        try {
            return DtoConverter.convertFromWebServiceDto(_port.getTimestamp(DtoConverter.convertToWebServiceDto(dto)));
        } catch (WebServiceException e) {
            notifyUDDIOfFailure(e);
            throw e;
        }
    }

	public AnacomDto createNetworkOperator(NetworkOperatorDetailedDto dto) {
		throw new UnsupportedOperationException();
	}

    public void testCommand(String command) {
        _port.testCommand(command);
    }

    public String getName() {
        return _name;
    }

    public String getPrefix() {
        return _prefix;
    }

    public String getReplicaNumber() {
        return _replicaNumber;
    }

    public String getUrl() {
        return _url;
    }

    public void setName(String name) {
        _name = name;
    }

    public void setPrefix(String prefix) {
        _prefix = prefix;
    }

    public void setReplicaNumber(String replicaNumber) {
        _replicaNumber = replicaNumber;
    }

    public void setUrl(String url) {
        _url = url;
		BindingProvider bp = (BindingProvider) _port;
		bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, url);
    }

    public String toString() {
        return _prefix + " - " + _name + " - " + _replicaNumber + " (" + _url + ")";
    }

    protected void addSecurityHandlers() {
        if (!AnacomSecurityManager.isCreated()) {
            return;
        }
		Binding binding = ((BindingProvider) _port).getBinding();
        List<Handler> handlerList = binding.getHandlerChain();
		handlerList.add(new RequestIDPresentationServerHandler());
		handlerList.add(new AnacomDigestHandler());
		handlerList.add(new AnacomCertificateHandler());
        //handlerList.add(new DebugHandler());
		binding.setHandlerChain(handlerList);
    }
}

