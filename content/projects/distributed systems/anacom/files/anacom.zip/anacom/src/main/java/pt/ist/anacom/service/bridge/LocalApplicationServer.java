package pt.ist.anacom.service.bridge;

import jvstm.Atomic;
import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.service.ChangeCellPhoneStateService;
import pt.ist.anacom.service.CreateNetworkOperatorService;
import pt.ist.anacom.service.EstablishVideoCommunicationService;
import pt.ist.anacom.service.EstablishVoiceCommunicationService;
import pt.ist.anacom.service.GetCellPhoneBalanceService;
import pt.ist.anacom.service.GetCellPhoneSMSService;
import pt.ist.anacom.service.GetCellPhoneStateService;
import pt.ist.anacom.service.GetCellPhonesBalancesService;
import pt.ist.anacom.service.GetLastCommunicationDetailsService;
import pt.ist.anacom.service.IncreaseCellPhoneBalanceService;
import pt.ist.anacom.service.ReceiveSMSService;
import pt.ist.anacom.service.ReceiveVideoCommunicationService;
import pt.ist.anacom.service.ReceiveVoiceCommunicationService;
import pt.ist.anacom.service.RegisterCellPhoneService;
import pt.ist.anacom.service.RemoveCellPhoneService;
import pt.ist.anacom.service.SendSMSService;
import pt.ist.anacom.service.TerminateActiveIncomingCommService;
import pt.ist.anacom.service.TerminateActiveOutgoingCommService;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.CommunicationDetailsDto;
import pt.ist.anacom.shared.dto.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.dto.NetworkOperatorDetailedDto;
import pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.dto.SMSDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.fenixframework.Config;
import pt.ist.fenixframework.FenixFramework;

/**
 * This class implements an Application Server that only runs locally.
 */
public class LocalApplicationServer implements ApplicationServerBridge {

	/**
	 * Creates a new instance of a Local Application Server for Anacom network.
	 */
	public LocalApplicationServer() {
		Config config = new Config() {
			{
				domainModelPath = "src/main/dml/anacom.dml";
				dbAlias = "db";
				rootClass = AnacomNetwork.class;
				repositoryType = RepositoryType.BERKELEYDB;
			}
		};

		FenixFramework.initialize(config);
	}

	@Override
	public void registerCellPhone(CellPhoneDetailedDto dto)
			throws AnacomException {
		RegisterCellPhoneService service = new RegisterCellPhoneService(dto);
		service.execute();
	}

	@Override
	public void removeCellPhone(CellPhoneWithOperatorDto dto)
			throws AnacomException {
		RemoveCellPhoneService service = new RemoveCellPhoneService(dto);
		service.execute();
	}

	@Override
	public void increaseCellPhoneBalance(ChangeCellPhoneBalanceDto dto)
			throws AnacomException {
		IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
				dto);
		service.execute();
	}

	@Override
	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException {
		GetCellPhoneBalanceService service = new GetCellPhoneBalanceService(dto);
		service.execute();
		return service.getCellPhoneBalance();
	}
	
	@Override
	public CellPhoneWithStateDto getCellPhoneState(CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException {
		GetCellPhoneStateService service = new GetCellPhoneStateService(dto);
		service.execute();
		return service.getCellPhoneState();
	}

	@Override
	@Atomic
	public void sendSMS(SMSDto dto) throws AnacomException {
		SendSMSService sendService = new SendSMSService(dto);
		ReceiveSMSService receiveService = new ReceiveSMSService(dto);

		sendService.dispatch();
		receiveService.dispatch();
	}

	@Override
	@Atomic
	public void establishVideoCall(CallDto dto) throws AnacomException {
		EstablishVideoCommunicationService videoEstablishService = new
												EstablishVideoCommunicationService(dto);
		ReceiveVideoCommunicationService videoReceiveService = new
												ReceiveVideoCommunicationService(dto);
		
		videoEstablishService.dispatch();
		videoReceiveService.dispatch();
	}
	
	@Override
	@Atomic
	public void establishVoiceCall(CallDto dto) throws AnacomException {
		EstablishVoiceCommunicationService voiceEstablishService = new
												EstablishVoiceCommunicationService(dto);
		ReceiveVoiceCommunicationService voiceReceiveService = new
												ReceiveVoiceCommunicationService(dto);
		
		voiceEstablishService.dispatch();
		voiceReceiveService.dispatch();
	}

    @Override
    @Atomic
    public void terminateActiveCall(CallWithDurationDto dto) throws AnacomException {
        TerminateActiveIncomingCommService terminateIncomingService = new TerminateActiveIncomingCommService(dto);
        TerminateActiveOutgoingCommService terminateOutgoingService = new TerminateActiveOutgoingCommService(dto);

        terminateIncomingService.dispatch();
        terminateOutgoingService.dispatch();
    }
	
	@Override
	public ListCellPhonesBalancesDto getCellPhonesBalances(
			NetworkOperatorSimpleDto operator) throws AnacomException {
		GetCellPhonesBalancesService balanceService = new GetCellPhonesBalancesService(
				operator);
		balanceService.execute();
		return balanceService.getCellPhonesBalances();
	}

	@Override
	public ListCellPhoneSMSDto getCellPhoneSMS(CellPhoneSimpleDto cellPhone)
			throws AnacomException {
		GetCellPhoneSMSService listAllSMSService = new GetCellPhoneSMSService(
				cellPhone);
		listAllSMSService.execute();
		return listAllSMSService.getCellPhonesSMS();
	}

	@Override
	public void createNetworkOperator(NetworkOperatorDetailedDto dto)
			throws AnacomException {
		CreateNetworkOperatorService operatorService = new CreateNetworkOperatorService(
				dto);
		operatorService.execute();
	}

	@Override
	public void changeCellPhoneState(CellPhoneWithStateDto dto)
			throws AnacomException {
		ChangeCellPhoneStateService changeStateService = new ChangeCellPhoneStateService(
				dto);
		changeStateService.execute();
	}
	
	@Override
	public CommunicationDetailsDto getLastCommunicationDetails(
			CellPhoneSimpleDto dto) throws CellPhoneNotExistsException {
		GetLastCommunicationDetailsService service = new GetLastCommunicationDetailsService(dto);
		service.execute();
		return service.getCommunicationDetails();
	}
}
