package pt.ist.anacom.shared.dto;

/**
 * This Dto allows to transport details of a communication.
 */
public class CommunicationDetailsDto extends AnacomDto {
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * Enum with the various communication types.
	 */
	public enum CommunicationType {
		VOICE, VIDEO, SMS, UNKNOWN
	}

	/** Used to simbolize no phone number. */
	public static String NOPHONENUMBER = "-1";

	/** Number of the source cellphone. */
	private String _sourceNumber;
	/** Number of the destination cellphone. */
	private String _destinationNumber;
	/** Cost of the communication. */
	private int _cost;
	/** Size of the communication */
	private int _size;
	/** Communication Type */
	private CommunicationType _commType;

	/**
	 * Constructs a CommunicationDetailsDto.
	 */
	public CommunicationDetailsDto() {
	}

	/**
	 * Constructs a CommunicationDetailsDto.
	 * @param sourceNumber of the source cellphone.
	 * @param destinationNumber of the destination cellphone.
	 * @param cost of the communication.
	 * @param size of the communication.
	 * @param commType type of the communication.
	 */
	public CommunicationDetailsDto(String sourceNumber,
			String destinationNumber, int cost, int size,
			CommunicationType commType) {
		_sourceNumber = sourceNumber;
		_destinationNumber = destinationNumber;
		_cost = cost;
		_size = size;
		_commType = commType;
	}

	/**
	 * Get the number of the source CellPhone.
	 * 
	 * @return The number of the source CellPhone.
	 */
	public String getSourceNumber() {
		return _sourceNumber;
	}

	/**
	 * Get the number of the destination CellPhone.
	 * 
	 * @return The number of the destination CellPhone.
	 */
	public String getDestinationNumber() {
		return _destinationNumber;
	}

	/**
	 * Gets the cost of the communication.
	 * 
	 * @return the cost.
	 */
	public int getCost() {
		return _cost;
	}

	/**
	 * Gets the size of the communication.
	 * 
	 * @return the size.
	 */
	public int getSize() {
		return _size;
	}

	/**
	 * Gets the type of the communication.
	 * 
	 * @return the type.
	 */
	public CommunicationType getType() {
		return _commType;
	}
	
	/**
	 * Compares two instances of CommunicationDetailsDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof CommunicationDetailsDto))
			return false;

		CommunicationDetailsDto dto = (CommunicationDetailsDto) obj;

		return getSourceNumber().equals(dto.getSourceNumber())
				&& getDestinationNumber().equals(dto.getDestinationNumber())
				&& getCost() == dto.getCost()
				&& getType() == dto.getType()
				&& getSize() == dto.getSize();
	}
}
