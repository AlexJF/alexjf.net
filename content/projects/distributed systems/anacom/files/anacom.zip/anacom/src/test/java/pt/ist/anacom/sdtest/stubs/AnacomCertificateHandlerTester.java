package pt.ist.anacom.sdtest.stubs;

import javax.xml.soap.SOAPMessage;

import pt.ist.anacom.security.handlers.anacom.AnacomCertificateHandler;

public class AnacomCertificateHandlerTester extends AnacomCertificateHandler {
    public boolean testHandleIncomingMessage(SOAPMessage message) {
        return handleInboundMessage(message);
    }

    public boolean testHandleOutgoingMessage(SOAPMessage message) {
        return handleOutboundMessage(message);
    }
}
