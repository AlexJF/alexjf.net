package pt.ist.anacom.caserver;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import pt.ist.anacom.security.managers.CASecurityManager;
import pt.ist.anacom.shared.UDDIHelper;
import sun.misc.BASE64Encoder;

/**
 * This class implements the ServletContectListener providing an
 * initialization for a CA web service.
 */

public class CAServiceInitListener implements ServletContextListener {
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// nothing to do here
	}
	
	/**
	 * Performs a CA biding to an UDDI instance.
	 */
	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		ServletContext servletContext = arg0.getServletContext();
		BASE64Encoder b64e = new BASE64Encoder();
		String bindingURI = servletContext.getInitParameter("bindingUrl");
		CASecurityManager sm = CASecurityManager.getInstance();
		UDDIHelper.getSingleton().registerCA(bindingURI, b64e.encode(sm.getPublicKey().getEncoded()));
	}
}
