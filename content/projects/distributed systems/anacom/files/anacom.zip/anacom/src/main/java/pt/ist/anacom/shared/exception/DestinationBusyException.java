package pt.ist.anacom.shared.exception;

public class DestinationBusyException extends IncomingCommunicationException {
	private static final long serialVersionUID = 1L;

    public DestinationBusyException() {
    }

	public DestinationBusyException(String destinationNumber) {
		super(destinationNumber, "Destination cellphone is busy");
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of DestinationBusyException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof DestinationBusyException))
			return false;

		return true;
	}
}
