package pt.ist.anacom.domain;

import pt.ist.anacom.shared.CommunicationVisitor;

/**
 * This class represents a Video communication type.
 */
public class Video extends Video_Base {

	/**
	 * Build an instance of a Video communication type.
	 */
	public Video(String sourceNumber, String destinationNumber) {
		super();
		init(sourceNumber, destinationNumber);
		setDuration(0);
	}

	@Override
	public int calculateCost() {
		return getSourceCellPhone().getNetworkOperator().calculateCost(this);
	}

	@Override
	public void accept(CommunicationVisitor visitor) {
		visitor.visit(this);
	}
}
