package pt.ist.anacom.domain;

import pt.ist.anacom.shared.CommunicationVisitor;

/**
 * This class implements the behavior of a generic communication.
 */
public abstract class Communication extends Communication_Base {

	/**
	 * Build an instance of Communication.
	 */
	public Communication() {
		super();
		setSourceNumber("");
		setDestinationNumber("");
		setCost(0);
	}

	/**
	 * Initializes base attributes of a Communication instance
	 * 
	 * @param sourceNumber
	 *            The source number of this communication.
	 * @param destinationNumber
	 *            The destination number of this communication.
	 */
	protected void init(String sourceNumber, String destinationNumber) {
		setSourceNumber(sourceNumber);
		setDestinationNumber(destinationNumber);
	}

	/**
	 * Calculates the cost for this communication.
	 * 
	 * @return The cost of the communication.
	 */
	public abstract int calculateCost();

	/**
	 * Ends a communication.
	 * 
	 * Ending a communication causes the communication cost to be calculated.
	 */
	public void end() {
		CellPhone sourcePhone = getSourceCellPhone();
		if (sourcePhone != null) {
			int cost = calculateCost();
			setCost(cost);
			sourcePhone.decreaseBalance(cost);
		}
	}

	/**
	 * Accept method for cummuncation visitors.
	 * 
	 * @param Visitor
	 *            for communication
	 */
	public abstract void accept(CommunicationVisitor visitor);
}
