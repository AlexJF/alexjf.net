
package pt.ist.anacom.sdtest.stubs;

import javax.xml.soap.SOAPMessage;

import pt.ist.anacom.security.handlers.anacom.OperatorCertificateHandler;

public class OperatorCertificateHandlerTester extends OperatorCertificateHandler{
	 public boolean testHandleIncomingMessage(SOAPMessage message) {
	        return handleInboundMessage(message);
	    }

	    public boolean testHandleOutgoingMessage(SOAPMessage message) {
	        return handleOutboundMessage(message);
	    }
	    
	    @Override
	    public boolean getParentResult(SOAPMessage message) {
	    	return true;
	    }
}
