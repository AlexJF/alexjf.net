package pt.ist.anacom.sdtest;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import java.security.cert.CertificateException;
import java.security.cert.CRLException;

import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Iterator;
import java.util.UUID;

import javax.crypto.Cipher;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import javax.xml.transform.stream.StreamSource;

import junit.framework.TestCase;

import org.w3c.dom.Node;

import pt.ist.anacom.caserver.CaServiceImpl;
import pt.ist.anacom.caserver.CertificateFactory;
import pt.ist.anacom.estest.AnacomTestCase;

import pt.ist.anacom.shared.stubs.CAException_Exception;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import sun.security.x509.X509CertImpl;
import sun.security.x509.X509CRLImpl;

public class SecurityTestCase extends AnacomTestCase{
	
	protected PublicKey _kp;
	protected PrivateKey _ks;
	
	
	protected SecurityTestCase(String msg) {
		super(msg);
	}

	protected SecurityTestCase() {
		super();
	}
	
	protected void setUp() {
	}
	
    protected KeyPair generateKeyPair() {
		// Generate KeyPair.
		KeyPairGenerator keyGen = null;
		try {
			keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(1024);
            return keyGen.generateKeyPair();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
            fail("Unable to generate key pair");
            return null;
		}
    }

    protected byte[] getMessageDigest(String message, PrivateKey key) {
        try {
			MessageDigest md = MessageDigest.getInstance("SHA");
			md.update(message.getBytes());
			byte[] digest = md.digest();
			Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			return cipher.doFinal(digest);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to calculate message digest");
            return null;
        }
    }

    protected String base64Encode(byte[] data) {
        BASE64Encoder b64e = new BASE64Encoder();
        return b64e.encode(data);
    }

    protected byte[] base64Decode(String data) {
        BASE64Decoder b64d = new BASE64Decoder();
        try {
            return b64d.decodeBuffer(data);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to decode from base64");
            return null;
        }
    }

    protected X509CertImpl getCertificateFromCA(CaServiceImpl ca, String publicKey, String subject) 
        throws CAException_Exception, CertificateException {
        return new X509CertImpl(base64Decode(ca.createCertificate(publicKey, subject)));
    }

    protected X509CRLImpl getBlacklistFromCA(CaServiceImpl ca) 
        throws CRLException, CAException_Exception {
        return new X509CRLImpl(base64Decode(ca.getBlackList()));
    }

    protected byte[] encryptData(byte[] data, Key key) {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return cipher.doFinal(data);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to decrypt data");
            return null;
        }
    }

    protected byte[] decryptData(byte[] data, Key key) {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, key);
            return cipher.doFinal(data);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to decrypt data");
            return null;
        }
    }

    protected SOAPMessage createSoapMessageFromString(String soapText) {
        try {  
            // Create SoapMessage  
            MessageFactory msgFactory     = MessageFactory.newInstance();  
            SOAPMessage message           = msgFactory.createMessage();  
            SOAPPart soapPart             = message.getSOAPPart();  
   
            // Load the SOAP text into a stream source  
            byte[] buffer                 = soapText.getBytes();  
            ByteArrayInputStream stream   = new ByteArrayInputStream(buffer);  
            StreamSource source           = new StreamSource(stream);  
   
            // Set contents of message   
            soapPart.setContent(source);  
   
            return message;
        } catch (Exception e) {  
            e.printStackTrace();
            return null;
        }
    }

    protected String getStringFromSoapMessage(SOAPMessage message) {
        ByteArrayOutputStream expectedOutputStream = new ByteArrayOutputStream();
        try {
            message.writeTo(expectedOutputStream);
            return new String(expectedOutputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Conversion to string from soap message should not have failed");
            return null;
        }
    }

    protected void addCertificateToSoapMessage(SOAPMessage message, X509CertImpl certificate) {
        try {
            SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
            Name name = envelope.createName("certificate", "anacom", "http://pt.ist.utl.anacom");  
            
            if (envelope.getHeader() == null) {
    			envelope.addHeader();
    		}
            
            SOAPElement element = envelope.getHeader().addChildElement(name);
            element.addTextNode(certificateToBase64(certificate));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to add certificate to soap message");
        }
    }

    protected X509CertImpl createCertificate(PublicKey kp, String subject, String issuerName, PrivateKey issuerKs, int serial, long validity) {
        try {
            return CertificateFactory.createCertificate(kp, subject, issuerName, issuerKs, serial, validity);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to create certificate from given data");
            return null;
        }
    }
    
    protected X509CertImpl createCertificate(PublicKey kp, String subject, String issuerName, PrivateKey issuerKs, int serial) {
        try {
            return CertificateFactory.createCertificate(kp, subject, issuerName, issuerKs, serial, 180L);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to create certificate from given data");
            return null;
        }
    }

    protected X509CertImpl getCertificateFromBase64(String certString) {
        try {
            return new X509CertImpl(base64Decode(certString));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to create certificate from base 64 string");
            return null;
        }
    }
    
    protected String getNameFromCertificate(X509CertImpl cert) {
    	return cert.getSubjectDN().getName();
    }

    protected String certificateToBase64(X509CertImpl cert) {
        try {
            return base64Encode(cert.getEncoded());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to transform certificate to base 64 string");
            return null;
        }
    }
    
    protected void addUUIDToSoapMessage(SOAPMessage message, UUID uuid) {
        try {
            SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
            Name name = envelope.createName("messageUUID", "anacom", "http://pt.ist.utl.anacom");  
            
            if (envelope.getHeader() == null) {
    			envelope.addHeader();
    		}
            
            SOAPElement element = envelope.getHeader().addChildElement(name);
            element.addTextNode(uuid.toString());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Unable to add uuid to soap message");
        }
    }
    
    protected Node getHeaderNode(SOAPHeader h, String nodeName) {
    	
    	if (h == null) {
    		return null;
    	}
    	
		 Iterator iterator = h.examineAllHeaderElements();
	     while (iterator.hasNext()) {
	    	 SOAPHeaderElement el = (SOAPHeaderElement) iterator.next();
	    	 if (el.getNodeName().equals(nodeName))
	    		 return (Node)el;
	     }
	     
	     return null;
    }
	
	protected Node getCertificateNode(SOAPHeader h) {
        return getHeaderNode(h, "anacom:certificate");
	}
	
	protected Node getCertificateNode(SOAPMessage m) {
        try {
			return getHeaderNode(m.getSOAPHeader(), "anacom:certificate");
		} catch (SOAPException e) {
			e.printStackTrace();
		}
        
        return null;
	}
}
