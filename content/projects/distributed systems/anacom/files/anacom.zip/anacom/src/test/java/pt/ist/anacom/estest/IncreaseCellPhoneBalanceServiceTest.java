package pt.ist.anacom.estest;

import java.math.BigDecimal;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.service.IncreaseCellPhoneBalanceService;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.BalanceChangeException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.HigherThanMaxBalanceException;

public class IncreaseCellPhoneBalanceServiceTest extends AnacomTestCase {
	private static String OPERATOR_NAME = "ROFLCOPTER";
	private static String OPERATOR_PREFIX = "12";
	private static int OPERATOR_VOICE_COST = 20;
	private static int OPERATOR_VIDEO_COST = 40;
	private static int OPERATOR_SMS_COST = 5;
	private static BigDecimal OPERATOR_TAX = new BigDecimal(1.5);
	private static BigDecimal OPERATOR_BONUS = new BigDecimal(0);

	private static String OPERATOR_NAME2 = "ROFLCOPTER2";
	private static String OPERATOR_PREFIX2 = "13";
	private static BigDecimal OPERATOR_BONUS2 = new BigDecimal(1.5);

	private static String OPERATOR_NAME3 = "ROFLCOPTER3";
	private static String OPERATOR_PREFIX3 = "14";
	private static BigDecimal OPERATOR_BONUS3 = new BigDecimal(4);

	private static String EXISTENT_CELLPHONE_NUMBER = "123456789";
	private static int EXISTENT_CELLPHONE_BALANCE = 50;
	private static String EXISTENT_CELLPHONE_NUMBER2 = "133456789";
	private static int EXISTENT_CELLPHONE_BALANCE2 = 50;
	private static String EXISTENT_CELLPHONE_NUMBER3 = "143456789";
	private static int EXISTENT_CELLPHONE_BALANCE3 = 50;
	private static String NON_EXISTENT_CELLPHONE_NUMBER = "122222222";

	private static int BALANCE_INCREASE = 1000;
	private static int BALANCE_INCREASE2 = 1000;
	private static int BALANCE_INCREASE3 = 1991;
	private static int BALANCE_INCREASE3_2 = 1000;
	private static int MAX_BALANCE_INCREASE = 10001;
	private static int NEGATIVE_INCREASE = -1;

	private static CellPhone existentCellPhone;
	private static CellPhone existentCellPhone2;
	private static CellPhone existentCellPhone3;

	@Override
	public void setUp() {
		super.setUp();

		addOperator(OPERATOR_NAME, OPERATOR_PREFIX, OPERATOR_VOICE_COST,
				OPERATOR_VIDEO_COST, OPERATOR_SMS_COST, OPERATOR_TAX,
				OPERATOR_BONUS);
		NetworkOperator operator = getOperatorByName(OPERATOR_NAME);

		addOperator(OPERATOR_NAME2, OPERATOR_PREFIX2, OPERATOR_VOICE_COST,
				OPERATOR_VIDEO_COST, OPERATOR_SMS_COST, OPERATOR_TAX,
				OPERATOR_BONUS2);

		NetworkOperator operator2 = getOperatorByName(OPERATOR_NAME2);

		addOperator(OPERATOR_NAME3, OPERATOR_PREFIX3, OPERATOR_VOICE_COST,
				OPERATOR_VIDEO_COST, OPERATOR_SMS_COST, OPERATOR_TAX,
				OPERATOR_BONUS3);

		NetworkOperator operator3 = getOperatorByName(OPERATOR_NAME3);

		existentCellPhone = addCellPhone2G(operator, EXISTENT_CELLPHONE_NUMBER,
				EXISTENT_CELLPHONE_BALANCE);
		existentCellPhone2 = addCellPhone2G(operator2,
				EXISTENT_CELLPHONE_NUMBER2, EXISTENT_CELLPHONE_BALANCE2);
		existentCellPhone3 = addCellPhone2G(operator3,
				EXISTENT_CELLPHONE_NUMBER3, EXISTENT_CELLPHONE_BALANCE3);
	}

	public void testIncreaseBalanceExistentCellPhone() {
		// Arrange
		ChangeCellPhoneBalanceDto dto = new ChangeCellPhoneBalanceDto(
				EXISTENT_CELLPHONE_NUMBER, BALANCE_INCREASE);
		IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
				dto);

		// Act
		try {
			service.execute();
		} catch (BalanceChangeException e) {
			fail("Valid increase so it shouldn't throw an exception.");
		} catch (HigherThanMaxBalanceException e) {
			fail("The increase of the balance didn't reach the max, so it shouldn't throw an exception.");
		} catch (CellPhoneNotExistsException e) {
			fail("CellPhone exists so it should increase its balance.");
		} catch (AnacomException e) {
			fail("Some exception besides CellPhoneNotExistsException, HigherThanMaxBalanceException, "
					+ "BalanceChangeException was thrown and it shouldn't.");
		}

		// Assert
		assertEquals("The balance should be increased.",
				getCellPhoneBalance(existentCellPhone),
				EXISTENT_CELLPHONE_BALANCE + BALANCE_INCREASE);
	}

	public void testIncreaseBalanceNonExistentCellPhone() {
		// Arrange
		ChangeCellPhoneBalanceDto dto = new ChangeCellPhoneBalanceDto(
				NON_EXISTENT_CELLPHONE_NUMBER, BALANCE_INCREASE);
		IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
				dto);

		// Act
		try {
			service.execute();
			fail("CellPhone does not exist so it should throw an exception.");
		} catch (CellPhoneNotExistsException e) {
			// If we get here everything is fine!
		} catch (AnacomException e) {
			fail("Wrong exception thrown! It should throw CellPhoneNotExistsException.");
		}
	}

	public void testIncreaseBalanceCellPhoneAboveMax() {
		// Arrange
		ChangeCellPhoneBalanceDto dto = new ChangeCellPhoneBalanceDto(
				EXISTENT_CELLPHONE_NUMBER, MAX_BALANCE_INCREASE);
		IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
				dto);

		// Act
		try {
			service.execute();
			fail("An exception should have been thrown. A CellPhone can't have a balance bigger than 100 euros.");
		} catch (HigherThanMaxBalanceException e) {
			// If we get here everything is fine!
		} catch (AnacomException e) {
			fail("Wrong exception thrown! It should throw HigherThanMaxBalanceException.");
		}
	}

	public void testIncreaseNegativeAmount() {
		// Arrange
		ChangeCellPhoneBalanceDto dto = new ChangeCellPhoneBalanceDto(
				EXISTENT_CELLPHONE_NUMBER, NEGATIVE_INCREASE);
		IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
				dto);

		// Act
		try {
			service.execute();
			fail("An exception should have been thrown. A CellPhone can't have it's balance increased"
					+ " by a negative value.");
		} catch (BalanceChangeException e) {
			// If we get here everything is fine!
		} catch (AnacomException e) {
			fail("Wrong exception thrown! It should throw AnacomException.");
		}
	}

	public void testZeroBonusIncrease() {
		// Arrange
		ChangeCellPhoneBalanceDto dto = new ChangeCellPhoneBalanceDto(
				EXISTENT_CELLPHONE_NUMBER, BALANCE_INCREASE);
		IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
				dto);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("There was an exception thrown that should't happend.");
		}

		// Assert
		assertEquals("The balance should be increased.",
				getCellPhoneBalance(existentCellPhone),
				EXISTENT_CELLPHONE_BALANCE + BALANCE_INCREASE * (0 + 1));
	}

	public void testDecimalBonusIncrease() {
		// Arrange
		ChangeCellPhoneBalanceDto dto = new ChangeCellPhoneBalanceDto(
				EXISTENT_CELLPHONE_NUMBER2, BALANCE_INCREASE2);
		IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
				dto);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("There was an exception thrown and that should't happend.");
		}

		// Assert
		assertEquals(
				"The balance should be increased.",
				getCellPhoneBalance(existentCellPhone2),
				EXISTENT_CELLPHONE_BALANCE2
						+ (new BigDecimal(BALANCE_INCREASE2)
								.multiply(OPERATOR_BONUS2
										.add(new BigDecimal(1)))).intValue());
	}

	public void testIncreaseBalanceCellPhoneAboveMaxWithBonus() {
		// Arrange
		ChangeCellPhoneBalanceDto dto = new ChangeCellPhoneBalanceDto(
				EXISTENT_CELLPHONE_NUMBER3, BALANCE_INCREASE3);
		IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
				dto);

		// Act
		try {
			service.execute();
			fail("An exception should have been thrown. A CellPhone can't have a balance bigger than 100 euros.");
		} catch (HigherThanMaxBalanceException e) {
			// If we get here everything is fine!
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should thrown HigherThanMaxBalanceException");
		}
	}

	public void testIntegerBonusIncrease() {
		// Arrange
		ChangeCellPhoneBalanceDto dto = new ChangeCellPhoneBalanceDto(
				EXISTENT_CELLPHONE_NUMBER3, BALANCE_INCREASE3_2);
		IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
				dto);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("There was an exception thrown and that should't happend.");
		}

		// Assert
		assertEquals(
				"The balance should be increased.",
				getCellPhoneBalance(existentCellPhone3),
				EXISTENT_CELLPHONE_BALANCE3
						+ (new BigDecimal(BALANCE_INCREASE3_2)
								.multiply(OPERATOR_BONUS3
										.add(new BigDecimal(1)))).intValue());
	}
}
