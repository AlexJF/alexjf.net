package pt.ist.anacom.domain;

import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.OperatorAlreadyExistsException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;

/**
 * This class represents an anacom network and maintains information about
 * existing network operators.
 * 
 * Each network operator registered with an AnacomNetwork instance must have an
 * unique prefix and name.
 */
public class AnacomNetwork extends AnacomNetwork_Base {

	/**
	 * Build an instance of AnacomNetwork.
	 */
	public AnacomNetwork() {
		super();
	}

	/**
	 * Returns the network operator associated with this network that has the
	 * specified prefix.
	 * 
	 * @param prefix
	 *            The prefix of the network operator we wish to obtain
	 * @return The NetworkOperator instance with the specified prefix or null if
	 *         no such operator exists on this network.
	 */
	public NetworkOperator getNetworkOperatorByPrefix(String prefix) {
		if (prefix != null) {
			for (NetworkOperator operator : getNetworkOperatorSet()) {
				if (operator.getPrefix().equals(prefix)) {
					return operator;
				}
			}
		}

		return null;
	}

	/**
	 * Returns the network operator associated with this network that has the
	 * specified prefix or throws an exception if no such operator exists.
	 * 
	 * @param prefix
	 *            The prefix of the network operator we wish to obtain
	 * @return The NetworkOperator instance with the specified prefix or null if
	 *         no such operator exists on this network.
	 */
	public NetworkOperator getNetworkOperatorByPrefixOrException(String prefix) {
        NetworkOperator op = getNetworkOperatorByPrefix(prefix);

        if (op == null) {
            throw new OperatorNotExistsException("", prefix);
        }

        return op;
	}

	/**
	 * Returns the network operator associated with this network that has the
	 * specified name.
	 * 
	 * @param name
	 *            The name of the network operator we wish to obtain
	 * @return The NetworkOperator instance with the specified name or null if
	 *         no such operator exists on this network.
	 */
	public NetworkOperator getNetworkOperatorByName(String name) {
		if (name != null) {
			for (NetworkOperator operator : getNetworkOperatorSet()) {
				if (operator.getName().equals(name)) {
					return operator;
				}
			}
		}

		return null;
	}

	/**
	 * Returns the network operator associated with this network that has the
	 * specified name or throws an exception if no such operator exists.
	 * 
	 * @param name
	 *            The name of the network operator we wish to obtain
	 * @return The NetworkOperator instance with the specified name or null if
	 *         no such operator exists on this network.
	 */
	public NetworkOperator getNetworkOperatorByNameOrException(String name) {
        NetworkOperator op = getNetworkOperatorByName(name);

        if (op == null) {
            throw new OperatorNotExistsException(name);
        }

        return op;
	}

	/**
	 * Returns the cellphone associated with an operator of this network with
	 * the specified number.
	 * 
	 * @param number
	 *            The number of the cellphone to retrieve.
	 * @return The CellPhone instance with the specified number or null if no
	 *         such cellphone exists on this network.
	 */
	public CellPhone getCellPhone(String number) {
		if (number != null) {
			String prefix = number.substring(0, 2);

			NetworkOperator operator = getNetworkOperatorByPrefix(prefix);

			if (operator != null) {
				return operator.getCellPhone(number);
			}
		}

		return null;
	}

    /**
     * Returns the cellphone associated with the specified number on this 
     * network or throws an exception if no cellphone with that number exists.
     *
     * @param number The number of the cellphone to retrieve.
     * @return The CellPhone instance with the specified number.
     */
    public CellPhone getCellPhoneOrException(String number) {
        CellPhone cell = getCellPhone(number);

        if (cell == null) {
            throw new CellPhoneNotExistsException(number);
        }

        return cell;
    }

	/**
	 * Adds a new network operator to this network.
	 * 
	 * @param networkOperator
	 *            The network operator to add to the network.
	 * @throws OperatorAlreadyExistsException
	 *             If this network already has a network operator with the same
	 *             prefix or name as the NetworkOperator in the parameter.
	 */
	@Override
	public void addNetworkOperator(NetworkOperator networkOperator) {
		for (NetworkOperator operator : getNetworkOperatorSet()) {
			if (operator.getName().equals(networkOperator.getName())) {
				throw new OperatorAlreadyExistsException(
						networkOperator.getName());
			}

			if (operator.getPrefix().equals(networkOperator.getPrefix())) {
				throw new OperatorAlreadyExistsException(
						networkOperator.getName(), networkOperator.getPrefix());
			}
		}

		super.addNetworkOperator(networkOperator);
	}

	/**
	 * Find the {@link NetworkOperator} of the given {@link CellPhone} number.
	 * 
	 * @param cellNr
	 *            the CellPhone number from which to find the NetworkOperator
	 * @return the found NetworkOperator
	 */
	public NetworkOperator getNetworkOperatorByCellPhoneNumber(String cellNr) {
		return getNetworkOperatorByPrefix(CellPhone.getPrefixFromNumber(cellNr));
	}

	/**
	 * Find the {@link NetworkOperator} of the given {@link CellPhone} number
     * or throw an exception if no such cellphone exists.
	 * 
	 * @param cellNr
	 *            the CellPhone number from which to find the NetworkOperator
	 * @return the found NetworkOperator
	 */
	public NetworkOperator getNetworkOperatorByCellPhoneNumberOrException(String cellNr) {
		NetworkOperator op = getNetworkOperatorByPrefix(CellPhone.getPrefixFromNumber(cellNr));

        if (op == null) {
            throw new CellPhoneNotExistsException(cellNr);
        }

        return op;
	}
}
