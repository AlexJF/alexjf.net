package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to an incoming communication not
 * being supported by the destination cellphone.
 */
public class IncomingCommunicationNotSupportedException extends
		IncomingCommunicationException {
	private static final long serialVersionUID = 1L;

	private String _phoneType;
	private String _commType;

	public IncomingCommunicationNotSupportedException() {
	}

	public IncomingCommunicationNotSupportedException(String destinationNumber,
			String phoneType, String commType) {
		super(destinationNumber, phoneType + " cannot receive incoming "
				+ commType + " communications.");
		_commType = commType;
		_phoneType = phoneType;
	}

	public String getPhoneType() {
		return _phoneType;
	}

	public String getCommunicationType() {
		return _commType;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of IncomingCommunicationNotSupportedException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof CellPhoneNotExistsException))
			return false;

		IncomingCommunicationNotSupportedException exception = (IncomingCommunicationNotSupportedException) obj;

		return getPhoneType().equals(exception.getPhoneType())
				&& getCommunicationType().equals(exception.getCommunicationType());
	}
}
