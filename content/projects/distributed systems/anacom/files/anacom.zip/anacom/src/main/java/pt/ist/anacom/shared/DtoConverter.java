package pt.ist.anacom.shared;

import pt.ist.anacom.shared.stubs.AnacomDto;
import pt.ist.anacom.shared.stubs.CallDto;
import pt.ist.anacom.shared.stubs.CallWithDurationDto;
import pt.ist.anacom.shared.stubs.CellPhoneState;
import pt.ist.anacom.shared.stubs.CellPhoneWithStateDto;
import pt.ist.anacom.shared.stubs.BalanceDto;
import pt.ist.anacom.shared.stubs.CellPhoneDetailedDto;
import pt.ist.anacom.shared.stubs.CellPhoneSimpleDto;
import pt.ist.anacom.shared.stubs.CellPhoneType;
import pt.ist.anacom.shared.stubs.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.stubs.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.stubs.CommunicationDetailsDto;
import pt.ist.anacom.shared.stubs.CommunicationType;
import pt.ist.anacom.shared.stubs.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.stubs.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.stubs.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.stubs.SmsDto;

/**
 * This class provides methods to convert from a local Dto to a generated Dto
 * for using on the remote communication and vice-versa.
 */
public class DtoConverter {
	/*
	 * ######################## # Normal DTO -> WS DTO #
	 * ########################
	 */
	
    protected static void convertToWebServiceDto(AnacomDto wsdto, pt.ist.anacom.shared.dto.AnacomDto dto) {
        wsdto.setTimestamp(dto.getTimestamp());
    }

    static public AnacomDto convertToWebServiceDto(pt.ist.anacom.shared.dto.AnacomDto dto) {
        AnacomDto wsdto = new AnacomDto();
        convertToWebServiceDto(wsdto, dto);
        return wsdto;
    }

	/**
	 * Converts a local CellPhoneSimple Dto to a remote CellPhoneSimple Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public CellPhoneSimpleDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.CellPhoneSimpleDto dto) {
		CellPhoneSimpleDto wsdto = new CellPhoneSimpleDto();
		wsdto.setNumber(dto.getNumber());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local CellPhoneWithOperator Dto to a remote
	 * CellPhoneWithOperator Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public CellPhoneWithOperatorDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto dto) {
		CellPhoneWithOperatorDto wsdto = new CellPhoneWithOperatorDto();
		wsdto.setOperatorName(dto.getOperatorName());
		wsdto.setNumber(dto.getNumber());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local CellPhoneDetailed Dto to a remote CellPhoneDetailed Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public CellPhoneDetailedDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.CellPhoneDetailedDto dto) {
		CellPhoneDetailedDto wsdto = new CellPhoneDetailedDto();
		wsdto.setOperatorName(dto.getOperatorName());
		wsdto.setNumber(dto.getNumber());
		wsdto.setType(CellPhoneType.values()[dto.getType().ordinal()]);
		wsdto.setBalance(dto.getBalance());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local CellPhoneWithState Dto to a remote CellPhoneWithState Dto.
	 * @param dto The local dto we want to convert.
	 * @return The converted dto.
	 */
	static public CellPhoneWithStateDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.CellPhoneWithStateDto dto) {
		CellPhoneWithStateDto wsdto = new CellPhoneWithStateDto();
		wsdto.setState(CellPhoneState.values()[dto.getState().ordinal()]);
		wsdto.setNumber(dto.getNumber());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local NetworkOperatorSimple Dto to a remote
	 * NetworkOperatorSimple Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public NetworkOperatorSimpleDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto dto) {
		NetworkOperatorSimpleDto wsdto = new NetworkOperatorSimpleDto();
		wsdto.setName(dto.getName());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local Balance Dto to a remote Balance Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public BalanceDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.BalanceDto dto) {
		BalanceDto wsdto = new BalanceDto();
		wsdto.setBalance(dto.getBalance());
		wsdto.setPhoneNumber(dto.getPhoneNumber());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local ChangeCellPhoneBalance Dto to a remote
	 * ChangeCellPhoneBalance Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public ChangeCellPhoneBalanceDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto dto) {
		ChangeCellPhoneBalanceDto wsdto = new ChangeCellPhoneBalanceDto();
		wsdto.setAmount(dto.getAmount());
		wsdto.setPhoneNumber(dto.getPhoneNumber());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local ListCellPhonesBalances Dto to a remote
	 * ListCellPhonesBalances Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public ListCellPhonesBalancesDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto dto) {
		ListCellPhonesBalancesDto wsdto = new ListCellPhonesBalancesDto();

		for (pt.ist.anacom.shared.dto.BalanceDto bdto : dto
				.getCellPhonesBalances()) {
			wsdto.getCellPhonesBalances().add(convertToWebServiceDto(bdto));
		}
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local ListCellPhoneSMS dto to a remote version.
	 * 
	 * @param dto
	 *            The local dto we want to convert.
	 * @return The converted dto.
	 */
	static public ListCellPhoneSMSDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.ListCellPhoneSMSDto dto) {
		ListCellPhoneSMSDto wsdto = new ListCellPhoneSMSDto();

		for (pt.ist.anacom.shared.dto.SMSDto smsdto : dto.getCellPhonesSMS()) {
			wsdto.getCellPhonesSMS().add(convertToWebServiceDto(smsdto));
		}
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local Sms Dto to a remote Sms Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public SmsDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.SMSDto dto) {
		SmsDto wsdto = new SmsDto();
		wsdto.setSourceNumber(dto.getSourceNumber());
		wsdto.setDestinationNumber(dto.getDestinationNumber());
		wsdto.setMessage(dto.getMessage());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Convert a local Call dto to a remote Call dto.
	 * 
	 * @þaram dto The local dto we want to convert.
	 * @return The conveted dto.
	 */
	static public CallDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.CallDto dto) {
		CallDto wsdto = new CallDto();
		wsdto.setSourceNumber(dto.getSourceNumber());
		wsdto.setDestinationNumber(dto.getDestinationNumber());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Convert a local Call with duration dto to a remote Call with duration dto.
	 * 
	 * @þaram dto
	 * 			  The local dto we want to convert.
	 * @return The conveted dto.
	 */
	static public CallWithDurationDto convertToWebServiceDto(pt.ist.anacom.shared.dto.CallWithDurationDto dto) {
		CallWithDurationDto wsdto = new CallWithDurationDto();
		wsdto.setSourceNumber(dto.getSourceNumber());
		wsdto.setDestinationNumber(dto.getDestinationNumber());
		wsdto.setDuration(dto.getDuration());
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/**
	 * Converts a local CommunicationDetails Dto to a remote
	 * CommunicationDetails Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public CommunicationDetailsDto convertToWebServiceDto(
			pt.ist.anacom.shared.dto.CommunicationDetailsDto dto) {
		CommunicationDetailsDto wsdto = new CommunicationDetailsDto();
		wsdto.setSourceNumber(dto.getSourceNumber());
		wsdto.setDestinationNumber(dto.getDestinationNumber());
		wsdto.setCost(dto.getCost());
		wsdto.setSize(dto.getSize());
		wsdto.setCommType(CommunicationType.values()[dto.getType().ordinal()]);
		convertToWebServiceDto(wsdto, dto);
		
		return wsdto;
	}

	/*
	 * ######################## # WS DTO -> Normal DTO #
	 * ########################
	 */
	
	protected static void convertFromWebServiceDto(pt.ist.anacom.shared.dto.AnacomDto dto, AnacomDto wsdto) {
        dto.setTimestamp(wsdto.getTimestamp());
    }

    static public pt.ist.anacom.shared.dto.AnacomDto convertFromWebServiceDto(AnacomDto wsdto) {
        pt.ist.anacom.shared.dto.AnacomDto dto = new pt.ist.anacom.shared.dto.AnacomDto();
        convertFromWebServiceDto(dto, wsdto);
        return dto;
    }
	
	/**
	 * Converts a remote CellPhoneSimple Dto to a local CellPhoneSimple Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public pt.ist.anacom.shared.dto.CellPhoneSimpleDto convertFromWebServiceDto(
			CellPhoneSimpleDto wsdto) {
		pt.ist.anacom.shared.dto.CellPhoneSimpleDto dto = 
				new pt.ist.anacom.shared.dto.CellPhoneSimpleDto(wsdto.getNumber());
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;
	}

	/**
	 * Converts a remote CellPhoneWithOperator Dto to a local
	 * CellPhoneWithOperator Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto convertFromWebServiceDto(
			CellPhoneWithOperatorDto wsdto) {
		pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto dto = 
				new pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto(wsdto.getOperatorName(), wsdto.getNumber());
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;
	}

	/**
	 * Converts a remote CellPhoneDetailed Dto to a local CellPhoneDetailed Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public pt.ist.anacom.shared.dto.CellPhoneDetailedDto convertFromWebServiceDto(
			CellPhoneDetailedDto wsdto) {
		
		pt.ist.anacom.shared.dto.CellPhoneDetailedDto dto = 
				new pt.ist.anacom.shared.dto.CellPhoneDetailedDto(
						wsdto.getOperatorName(), wsdto.getNumber(),
						pt.ist.anacom.shared.dto.CellPhoneDetailedDto.CellPhoneType
								.values()[wsdto.getType().ordinal()],
						wsdto.getBalance());
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;
	}

	/**
	 * Converts a remote CellPhoneWithState Dto to a local CellPhoneWithState
	 * Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public pt.ist.anacom.shared.dto.CellPhoneWithStateDto convertFromWebServiceDto(
			CellPhoneWithStateDto wsdto) {
		
		pt.ist.anacom.shared.dto.CellPhoneWithStateDto dto = 
				new pt.ist.anacom.shared.dto.CellPhoneWithStateDto(
						wsdto.getNumber(),
						pt.ist.anacom.shared.dto.CellPhoneWithStateDto.CellPhoneStates
								.values()[wsdto.getState().ordinal()]);
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;
	}

	/**
	 * Converts a remote NetworkOperatorSimple Dto to a local
	 * NetworkOperatorSimple Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto convertFromWebServiceDto(
			NetworkOperatorSimpleDto wsdto) {
		
		pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto dto = 
				new pt.ist.anacom.shared.dto.NetworkOperatorSimpleDto(
						wsdto.getName());
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;
	}

	/**
	 * Converts a remote Balance Dto to a local Balance Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public pt.ist.anacom.shared.dto.BalanceDto convertFromWebServiceDto(
			BalanceDto wsdto) {
		
		pt.ist.anacom.shared.dto.BalanceDto dto = 
				new pt.ist.anacom.shared.dto.BalanceDto(
						wsdto.getPhoneNumber(),
						wsdto.getBalance());
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;
	}

	/**
	 * Converts a remote ChangeCellPhoneBalance Dto to a local
	 * ChangeCellPhoneBalance Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto convertFromWebServiceDto(
			ChangeCellPhoneBalanceDto wsdto) {
		
		pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto dto = 
				new pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto(
						wsdto.getPhoneNumber(), wsdto.getAmount());
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;
	}

	/**
	 * Converts a remote ListCellPhonesBalances Dto to a local
	 * ListCellPhonesBalances Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto convertFromWebServiceDto(
			ListCellPhonesBalancesDto wsdto) {
		pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto dto = new pt.ist.anacom.shared.dto.ListCellPhonesBalancesDto();

		for (BalanceDto bdto : wsdto.getCellPhonesBalances()) {
			dto.addCellPhoneBalance(convertFromWebServiceDto(bdto));
		}
	
		convertFromWebServiceDto(dto, wsdto);

		return dto;
	}

	/**
	 * Converts a remote ListCellPhoneSMS dto to a local version.
	 * 
	 * @param dto
	 *            The local dto we want to convert.
	 * @return The converted dto.
	 */
	static public pt.ist.anacom.shared.dto.ListCellPhoneSMSDto convertFromWebServiceDto(
			ListCellPhoneSMSDto wsdto) {
		pt.ist.anacom.shared.dto.ListCellPhoneSMSDto dto = new pt.ist.anacom.shared.dto.ListCellPhoneSMSDto();

		for (SmsDto bdto : wsdto.getCellPhonesSMS()) {
			pt.ist.anacom.shared.dto.SMSDto smsDto = convertFromWebServiceDto(bdto);
			dto.addCellPhoneSMS(smsDto.getSourceNumber(),
					smsDto.getDestinationNumber(), smsDto.getMessage());
		}

		convertFromWebServiceDto(dto, wsdto);

		return dto;
	}

	/**
	 * Converts a remote Sms Dto to a local Sms Dto.
	 * 
	 * @param dto
	 *            The local Dto we want to convert.
	 * @return The converted Dto.
	 */
	static public pt.ist.anacom.shared.dto.SMSDto convertFromWebServiceDto(
			SmsDto wsdto) {
			
		pt.ist.anacom.shared.dto.SMSDto dto = 
				new pt.ist.anacom.shared.dto.SMSDto(
						wsdto.getSourceNumber(),
						wsdto.getDestinationNumber(), wsdto.getMessage());
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;
	}

	/**
	 * Convert a remote Call dto to a local Call dto.
	 * 
	 * @param dto The remote dto we want to convert.
	 * @return The converted dto.
	 */
	static public pt.ist.anacom.shared.dto.CallDto convertFromWebServiceDto(
			CallDto wsdto) {

		pt.ist.anacom.shared.dto.CallDto dto = 
				new pt.ist.anacom.shared.dto.CallDto(
						wsdto.getSourceNumber(),
						wsdto.getDestinationNumber());
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;
	}

	/**
	 * Convert a remote Communication Details Dto to a local Communication Details Dto.
	 * 
	 * @param wsdto The remote dto we want to convert.
	 * @return The converted dto.
	 */
	public static pt.ist.anacom.shared.dto.CommunicationDetailsDto convertFromWebServiceDto(
			CommunicationDetailsDto wsdto) {		

		pt.ist.anacom.shared.dto.CommunicationDetailsDto dto = 
				new pt.ist.anacom.shared.dto.CommunicationDetailsDto(
						wsdto.getSourceNumber(), wsdto.getDestinationNumber(), wsdto.getCost(), wsdto.getSize(),
						pt.ist.anacom.shared.dto.CommunicationDetailsDto.CommunicationType.values()[wsdto.getCommType().ordinal()]);
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;				
	}
	
	/**
	 * Convert a remote Call with duration dto to a local Call with duration dto.
	 * 
	 * @þaram dto
	 * 			  The local dto we want to convert.
	 * @return The converted dto.
	 */
	static public pt.ist.anacom.shared.dto.CallWithDurationDto convertFromWebServiceDto(CallWithDurationDto wsdto) {
		

		pt.ist.anacom.shared.dto.CallWithDurationDto dto = 
				new pt.ist.anacom.shared.dto.CallWithDurationDto(
						wsdto.getSourceNumber(),
						wsdto.getDestinationNumber(), wsdto.getDuration());
		convertFromWebServiceDto(dto, wsdto);
		
		return dto;	
	}
}
