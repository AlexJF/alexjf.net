package pt.ist.anacom.operatorserver;

import java.security.Key;

import javax.annotation.Resource;
import javax.crypto.Cipher;

import javax.servlet.ServletContext;

import javax.xml.ws.handler.MessageContext;

import javax.xml.ws.WebServiceContext;

import pt.ist.anacom.caserver.CAServer;
import pt.ist.anacom.replication.OperatorReplicationManager;
import pt.ist.anacom.replication.OperatorServiceFunction;

import pt.ist.anacom.security.managers.AnacomSecurityManager;

import pt.ist.anacom.service.*;
import pt.ist.anacom.shared.DtoConverter;
import pt.ist.anacom.shared.ExceptionConverter;
import pt.ist.anacom.shared.UDDIHelper;
import pt.ist.anacom.shared.exception.BalanceChangeException;
import pt.ist.anacom.shared.exception.BusyStateException;
import pt.ist.anacom.shared.exception.CellPhoneAlreadyExistsException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.DestinationBusyException;
import pt.ist.anacom.shared.exception.DestinationOffException;
import pt.ist.anacom.shared.exception.DestinationSilenceException;
import pt.ist.anacom.shared.exception.HigherThanMaxBalanceException;
import pt.ist.anacom.shared.exception.IncomingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.InvalidCellPhoneNumberException;
import pt.ist.anacom.shared.exception.InvalidCellPhonePrefixException;
import pt.ist.anacom.shared.exception.NegativeBalanceException;
import pt.ist.anacom.shared.exception.NotAStateException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;
import pt.ist.anacom.shared.exception.OutgoingCommunicationNotSupportedException;
import pt.ist.anacom.shared.exception.SourceBusyException;
import pt.ist.anacom.shared.exception.SourceOffException;
import pt.ist.anacom.shared.exception.WrongTimestampException;
import pt.ist.anacom.shared.stubs.AnacomDto;
import pt.ist.anacom.shared.stubs.BalanceChangeException_Exception;
import pt.ist.anacom.shared.stubs.BalanceDto;
import pt.ist.anacom.shared.stubs.BusyStateException_Exception;
import pt.ist.anacom.shared.stubs.CallDto;
import pt.ist.anacom.shared.stubs.CallWithDurationDto;
import pt.ist.anacom.shared.stubs.CellPhoneAlreadyExistsException_Exception;
import pt.ist.anacom.shared.stubs.CellPhoneDetailedDto;
import pt.ist.anacom.shared.stubs.CellPhoneNotExistsException_Exception;
import pt.ist.anacom.shared.stubs.CellPhoneSimpleDto;
import pt.ist.anacom.shared.stubs.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.stubs.CellPhoneWithStateDto;
import pt.ist.anacom.shared.stubs.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.stubs.CommunicationDetailsDto;
import pt.ist.anacom.shared.stubs.DestinationBusyException_Exception;
import pt.ist.anacom.shared.stubs.DestinationOffException_Exception;
import pt.ist.anacom.shared.stubs.DestinationSilenceException_Exception;
import pt.ist.anacom.shared.stubs.HigherThanMaxBalanceException_Exception;
import pt.ist.anacom.shared.stubs.IncomingCommunicationNotSupportedException_Exception;
import pt.ist.anacom.shared.stubs.InvalidCellPhoneNumberException_Exception;
import pt.ist.anacom.shared.stubs.InvalidCellPhonePrefixException_Exception;
import pt.ist.anacom.shared.stubs.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.stubs.ListCellPhonesBalancesDto;
import pt.ist.anacom.shared.stubs.NegativeBalanceException_Exception;
import pt.ist.anacom.shared.stubs.NetworkOperatorSimpleDto;
import pt.ist.anacom.shared.stubs.NotAStateException_Exception;
import pt.ist.anacom.shared.stubs.OperatorNotExistsException_Exception;
import pt.ist.anacom.shared.stubs.OperatorPortType;
import pt.ist.anacom.shared.stubs.OutgoingCommunicationNotSupportedException_Exception;
import pt.ist.anacom.shared.stubs.SmsDto;
import pt.ist.anacom.shared.stubs.SourceBusyException_Exception;
import pt.ist.anacom.shared.stubs.SourceOffException_Exception;
import pt.ist.anacom.shared.stubs.WrongTimestampException_Exception;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import sun.security.x509.X509CRLImpl;
import sun.security.x509.X509CertImpl;

@javax.jws.WebService(endpointInterface = "pt.ist.anacom.shared.stubs.OperatorPortType", wsdlLocation = "/anacom.wsdl", name = "OperatorPortType", portName = "OperatorPort", targetNamespace = "http://operator.anacom.ist.pt/", serviceName = "OperatorService")
@javax.jws.HandlerChain(file = "handler-chain.xml")
public class OperatorServiceImpl implements OperatorPortType {

	@Resource
	private WebServiceContext wsCtx;

	protected OperatorReplicationManager getReplicationManager() {
		ServletContext servletContext = (ServletContext) wsCtx
				.getMessageContext().get(MessageContext.SERVLET_CONTEXT);

		return (OperatorReplicationManager) servletContext
				.getAttribute("replicationManager");
	}

	@Override
    public void testCommand(String command) {
        System.out.println("Received test command: " + command);
        if (command.equals("clear")) {
            System.out.println("Clearing operator server");
            ResetService resetSvc = new ResetService();
            resetSvc.execute();
            getReplicationManager().resetTimestamp();
            AnacomSecurityManager.getInstance().getNewCertificate();
        } else if (command.equals("create")) {
			System.out.println("Creating new certificate");
			AnacomSecurityManager.getInstance().getNewCertificate();
			BASE64Decoder b64d = new BASE64Decoder();
			try {
				X509CertImpl cert = new X509CertImpl(b64d.decodeBuffer(AnacomSecurityManager.getInstance().getCertificate()));
				System.out.println(cert);
			} catch (Exception e) {
				e.printStackTrace();
			}			
		} else if (command.equals("revoke")) {
			System.out.println("Revoke certificate");
			BASE64Encoder b64e = new BASE64Encoder();
			String challenge = "ZOMG TEH LEGIT!!!";
			challenge = b64e.encode(encryptData(challenge.getBytes(), AnacomSecurityManager.getInstance().getPrivateKey()));
			CAServer ca = UDDIHelper.getSingleton().getCA();
			ca.revokeCertificate(AnacomSecurityManager.getInstance().getCertificate(), challenge);
		} else if (command.equals("updateBL")) {
			System.out.println("Getting Black List");
			X509CRLImpl blacklist = AnacomSecurityManager.getInstance().getBlackList();
			System.out.println(blacklist);
		}	
    };

	@Override
	public AnacomDto getTimestamp(AnacomDto dto) {
		OperatorServiceFunction<AnacomDto, AnacomDto> serviceFunction = new OperatorServiceFunction<AnacomDto, AnacomDto>() {
			@Override
			public AnacomDto execute(AnacomDto dto) {
				return new AnacomDto();
			}
		};

		return getReplicationManager().handleRequest(dto, serviceFunction);
	}

	@Override
	public AnacomDto registerCellPhone(CellPhoneDetailedDto dto)
			throws OperatorNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			InvalidCellPhonePrefixException_Exception,
			CellPhoneAlreadyExistsException_Exception,
			WrongTimestampException_Exception,
			HigherThanMaxBalanceException_Exception {
		OperatorServiceFunction<CellPhoneDetailedDto, AnacomDto> serviceFunction = new OperatorServiceFunction<CellPhoneDetailedDto, AnacomDto>() {
			@Override
			public AnacomDto execute(CellPhoneDetailedDto dto) {
				RegisterCellPhoneService service = new RegisterCellPhoneService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};

		try {
			return getReplicationManager().handleRequest(dto, serviceFunction);
		} catch (OperatorNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (InvalidCellPhonePrefixException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneAlreadyExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (HigherThanMaxBalanceException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto removeCellPhone(CellPhoneWithOperatorDto dto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception,
			OperatorNotExistsException_Exception {
		OperatorServiceFunction<CellPhoneWithOperatorDto, AnacomDto> serviceFunction = new OperatorServiceFunction<CellPhoneWithOperatorDto, AnacomDto>() {
			@Override
			public AnacomDto execute(CellPhoneWithOperatorDto dto) {
				RemoveCellPhoneService service = new RemoveCellPhoneService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(dto, serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (OperatorNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto receiveSMS(SmsDto smsDto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception,
			IncomingCommunicationNotSupportedException_Exception {
		OperatorServiceFunction<SmsDto, AnacomDto> serviceFunction = new OperatorServiceFunction<SmsDto, AnacomDto>() {
			@Override
			public AnacomDto execute(SmsDto dto) {
				ReceiveSMSService service = new ReceiveSMSService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(smsDto,
					serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (IncomingCommunicationNotSupportedException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto sendSMS(SmsDto smsDto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			NegativeBalanceException_Exception,
			WrongTimestampException_Exception,
			OutgoingCommunicationNotSupportedException_Exception,
			SourceOffException_Exception, SourceBusyException_Exception {
		OperatorServiceFunction<SmsDto, AnacomDto> serviceFunction = new OperatorServiceFunction<SmsDto, AnacomDto>() {
			@Override
			public AnacomDto execute(SmsDto dto) {
				SendSMSService service = new SendSMSService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(smsDto,
					serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (NegativeBalanceException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (OutgoingCommunicationNotSupportedException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (SourceOffException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (SourceBusyException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public BalanceDto getCellPhoneBalance(CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception {
		OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto> serviceFunction = new OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto>() {
			@Override
			public BalanceDto execute(CellPhoneSimpleDto dto) {
				GetCellPhoneBalanceService service = new GetCellPhoneBalanceService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return DtoConverter.convertToWebServiceDto(service
						.getCellPhoneBalance());
			}
		};
		try {
			return getReplicationManager().handleRequest(dto, serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public CellPhoneWithStateDto getCellPhoneState(CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception {
		OperatorServiceFunction<CellPhoneSimpleDto, CellPhoneWithStateDto> serviceFunction = new OperatorServiceFunction<CellPhoneSimpleDto, CellPhoneWithStateDto>() {
			@Override
			public CellPhoneWithStateDto execute(CellPhoneSimpleDto dto) {
				GetCellPhoneStateService service = new GetCellPhoneStateService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return DtoConverter.convertToWebServiceDto(service
						.getCellPhoneState());
			}
		};
		try {
			return getReplicationManager().handleRequest(dto, serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto changeCellPhoneState(CellPhoneWithStateDto dto)
			throws NotAStateException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception, BusyStateException_Exception {
		OperatorServiceFunction<CellPhoneWithStateDto, AnacomDto> serviceFunction = new OperatorServiceFunction<CellPhoneWithStateDto, AnacomDto>() {
			@Override
			public AnacomDto execute(CellPhoneWithStateDto dto) {
				ChangeCellPhoneStateService service = new ChangeCellPhoneStateService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(dto, serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (NotAStateException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (BusyStateException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public ListCellPhonesBalancesDto getCellPhonesBalances(
			NetworkOperatorSimpleDto dto)
			throws OperatorNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception {
		OperatorServiceFunction<NetworkOperatorSimpleDto, ListCellPhonesBalancesDto> serviceFunction = new OperatorServiceFunction<NetworkOperatorSimpleDto, ListCellPhonesBalancesDto>() {
			@Override
			public ListCellPhonesBalancesDto execute(
					NetworkOperatorSimpleDto dto) {
				GetCellPhonesBalancesService service = new GetCellPhonesBalancesService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return DtoConverter.convertToWebServiceDto(service
						.getCellPhonesBalances());
			}
		};
		try {
			return getReplicationManager().handleRequest(dto, serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (OperatorNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public CommunicationDetailsDto getLastCommunicationDetails(
			CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception {
		OperatorServiceFunction<CellPhoneSimpleDto, CommunicationDetailsDto> serviceFunction = new OperatorServiceFunction<CellPhoneSimpleDto, CommunicationDetailsDto>() {
			@Override
			public CommunicationDetailsDto execute(CellPhoneSimpleDto dto) {
				GetLastCommunicationDetailsService service = new GetLastCommunicationDetailsService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return DtoConverter.convertToWebServiceDto(service
						.getCommunicationDetails());
			}
		};
		try {
			return getReplicationManager().handleRequest(dto, serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public ListCellPhoneSMSDto getCellPhoneSMS(CellPhoneSimpleDto dto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception {
		OperatorServiceFunction<CellPhoneSimpleDto, ListCellPhoneSMSDto> serviceFunction = new OperatorServiceFunction<CellPhoneSimpleDto, ListCellPhoneSMSDto>() {
			@Override
			public ListCellPhoneSMSDto execute(CellPhoneSimpleDto dto) {
				GetCellPhoneSMSService service = new GetCellPhoneSMSService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return DtoConverter.convertToWebServiceDto(service
						.getCellPhonesSMS());
			}
		};
		try {
			return getReplicationManager().handleRequest(dto, serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto increaseCellPhoneBalance(
			ChangeCellPhoneBalanceDto changeBalanceDto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			BalanceChangeException_Exception,
			WrongTimestampException_Exception,
			HigherThanMaxBalanceException_Exception {
		OperatorServiceFunction<ChangeCellPhoneBalanceDto, AnacomDto> serviceFunction = new OperatorServiceFunction<ChangeCellPhoneBalanceDto, AnacomDto>() {
			@Override
			public AnacomDto execute(ChangeCellPhoneBalanceDto dto) {
				IncreaseCellPhoneBalanceService service = new IncreaseCellPhoneBalanceService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(changeBalanceDto,
					serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (BalanceChangeException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (HigherThanMaxBalanceException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto establishVideoCommunication(CallDto callDto)
			throws SourceBusyException_Exception,
			InvalidCellPhoneNumberException_Exception,
			SourceOffException_Exception, WrongTimestampException_Exception,
			OutgoingCommunicationNotSupportedException_Exception,
			NegativeBalanceException_Exception,
			CellPhoneNotExistsException_Exception {
		OperatorServiceFunction<CallDto, AnacomDto> serviceFunction = new OperatorServiceFunction<CallDto, AnacomDto>() {
			@Override
			public AnacomDto execute(CallDto dto) {
				EstablishVideoCommunicationService service = new EstablishVideoCommunicationService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(callDto,
					serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (NegativeBalanceException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (OutgoingCommunicationNotSupportedException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (SourceOffException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (SourceBusyException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto establishVoiceCommunication(CallDto callDto)
			throws SourceBusyException_Exception, SourceOffException_Exception,
			InvalidCellPhoneNumberException_Exception,
			OutgoingCommunicationNotSupportedException_Exception,
			WrongTimestampException_Exception,
			NegativeBalanceException_Exception,
			CellPhoneNotExistsException_Exception {
		OperatorServiceFunction<CallDto, AnacomDto> serviceFunction = new OperatorServiceFunction<CallDto, AnacomDto>() {
			@Override
			public AnacomDto execute(CallDto dto) {
				EstablishVoiceCommunicationService service = new EstablishVoiceCommunicationService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(callDto,
					serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (NegativeBalanceException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (OutgoingCommunicationNotSupportedException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (SourceOffException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (SourceBusyException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto receiveVideoCommunication(CallDto callDto)
			throws DestinationBusyException_Exception,
			DestinationOffException_Exception,
			DestinationSilenceException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception,
			IncomingCommunicationNotSupportedException_Exception,
			CellPhoneNotExistsException_Exception {
		OperatorServiceFunction<CallDto, AnacomDto> serviceFunction = new OperatorServiceFunction<CallDto, AnacomDto>() {
			@Override
			public AnacomDto execute(CallDto dto) {
				ReceiveVideoCommunicationService service = new ReceiveVideoCommunicationService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(callDto,
					serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (IncomingCommunicationNotSupportedException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (DestinationOffException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (DestinationBusyException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (DestinationSilenceException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto receiveVoiceCommunication(CallDto callDto)
			throws DestinationBusyException_Exception,
			DestinationOffException_Exception,
			DestinationSilenceException_Exception,
			InvalidCellPhoneNumberException_Exception,
			IncomingCommunicationNotSupportedException_Exception,
			WrongTimestampException_Exception,
			CellPhoneNotExistsException_Exception {
		OperatorServiceFunction<CallDto, AnacomDto> serviceFunction = new OperatorServiceFunction<CallDto, AnacomDto>() {
			@Override
			public AnacomDto execute(CallDto dto) {
				ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(callDto,
					serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (IncomingCommunicationNotSupportedException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (DestinationOffException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (DestinationBusyException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (DestinationSilenceException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto terminateActiveIncomingCommunication(
			CallWithDurationDto callDto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception {
		OperatorServiceFunction<CallWithDurationDto, AnacomDto> serviceFunction = new OperatorServiceFunction<CallWithDurationDto, AnacomDto>() {
			@Override
			public AnacomDto execute(CallWithDurationDto dto) {
				TerminateActiveIncomingCommService service = new TerminateActiveIncomingCommService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(callDto,
					serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}

	@Override
	public AnacomDto terminateActiveOutgoingCommunication(
			CallWithDurationDto callDto)
			throws CellPhoneNotExistsException_Exception,
			InvalidCellPhoneNumberException_Exception,
			WrongTimestampException_Exception {
		OperatorServiceFunction<CallWithDurationDto, AnacomDto> serviceFunction = new OperatorServiceFunction<CallWithDurationDto, AnacomDto>() {
			@Override
			public AnacomDto execute(CallWithDurationDto dto) {
				TerminateActiveOutgoingCommService service = new TerminateActiveOutgoingCommService(
						DtoConverter.convertFromWebServiceDto(dto));
				service.execute();
				return new AnacomDto();
			}
		};
		try {
			return getReplicationManager().handleRequest(callDto,
					serviceFunction);
		} catch (InvalidCellPhoneNumberException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (CellPhoneNotExistsException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		} catch (WrongTimestampException e) {
			throw ExceptionConverter.convertToWebServiceException(e);
		}
	}
	
	private byte[] encryptData(byte[] data, Key key) {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return cipher.doFinal(data);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
