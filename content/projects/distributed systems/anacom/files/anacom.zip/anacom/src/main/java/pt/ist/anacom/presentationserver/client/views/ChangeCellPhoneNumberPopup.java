package pt.ist.anacom.presentationserver.client.views;

import com.google.gwt.user.client.Window;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;

import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;

import pt.ist.anacom.presentationserver.client.Anacom;

public class ChangeCellPhoneNumberPopup extends DialogBox {
	public ChangeCellPhoneNumberPopup(final Anacom parent) {
		super();

		setGlassEnabled(true);
		setAnimationEnabled(true);

		setText("Change CellPhone Number");

		HorizontalPanel horizontalPanel = new HorizontalPanel();
		setWidget(horizontalPanel);

		Label lblPhoneNumber = new Label("Phone Number: ");
		horizontalPanel.add(lblPhoneNumber);

		final TextBox txtPhoneNumber = new TextBox();
		txtPhoneNumber.setText(parent.getCurrentPhoneNumber());
		horizontalPanel.add(txtPhoneNumber);

		Button btnOk = new Button("OK", new ClickHandler() {
			public void onClick(ClickEvent event) {
				String number = txtPhoneNumber.getText();
				if (number.length() != 9) {
					Window.alert("Cellphone number must have exactly 9 digits");
					return;
				}
				parent.setCurrentPhoneNumber(number);
				hide();
			}
		});

		Button btnCancel = new Button("Cancel", new ClickHandler() {
			public void onClick(ClickEvent event) {
				hide();
			}
		});

		horizontalPanel.add(btnOk);
		horizontalPanel.add(btnCancel);
	}
}
