package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.Communication;
import pt.ist.anacom.domain.SMS;
import pt.ist.anacom.shared.CommunicationVisitor;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.ListCellPhoneSMSDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.fenixframework.FenixFramework;

/**
 * This class provides a service to retrieve all SMS from a certain cell phone.
 *
 * It also implements Communication Visitor in order to differentiate between
 * the different communication types maintained on a cellphone.
 */
public class GetCellPhoneSMSService extends AnacomService {
	/** Dto returned by the service. */
	private ListCellPhoneSMSDto _result;
	/** Dto received by the service. */
	private CellPhoneSimpleDto _cellPhone;

	/**
	 * Build an instance of GetCellPhoneSMSService.
	 * 
	 * @param dto
	 *            that the service will use.
	 */
	public GetCellPhoneSMSService(CellPhoneSimpleDto cellPhone) {
		_result = new ListCellPhoneSMSDto();
		_cellPhone = cellPhone;
	}

	@Override
	public void dispatch() throws AnacomException {
		AnacomNetwork network = FenixFramework.getRoot();
		CellPhone cellPhone = network.getCellPhoneOrException(_cellPhone.getNumber());
        SMSVisitor visitor = this.new SMSVisitor();

		for (Communication inCommunication : cellPhone
				.getIncomingCommunication()) {
			inCommunication.accept(visitor);
		}
	}

	/**
	 * Retrieve a dto containing a list of cellphone sms.
	 * 
	 * @return A DTO containing a list of cellphone sms retrieved by the
	 *         service.
	 */
	public final ListCellPhoneSMSDto getCellPhonesSMS() {
		return _result;
	}

    private class SMSVisitor extends CommunicationVisitor {
        /**
         * Implementation of the visit method for sms communication.
         */
        @Override
        public void visit(SMS sms) {
            _result.addCellPhoneSMS(sms.getSourceNumber(),
                    sms.getDestinationNumber(), sms.getData());
        }
    }
}
