package pt.ist.anacom.presentationserver.client.views;

import com.google.gwt.core.client.GWT;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;

import com.google.gwt.user.client.rpc.AsyncCallback;

import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.ListBox;

import com.google.gwt.user.client.ui.TextBox;

import com.google.gwt.user.client.Window;

import pt.ist.anacom.presentationserver.client.Anacom;

import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.dto.CallWithDurationDto;

public class EstablishCallPopup extends DialogBox {
	final private TextBox txtDestinationNumber = new TextBox();
    final private TextBox txtDuration = new TextBox();
	final private ListBox lstType = new ListBox();
    final private Anacom parent;
    final private FlexTable establishTable;
    final private FlexTable terminateTable;
    private CallDto currentCall;

	public EstablishCallPopup(final Anacom parent) {
		super();

        this.parent = parent;
        currentCall = null;

		setText("Establish Communication");
		setGlassEnabled(true);
		setAnimationEnabled(true);

		establishTable = new FlexTable();

		establishTable.setHTML(0, 0, "Destination Number:");
		establishTable.setWidget(0, 1, txtDestinationNumber);

		establishTable.setHTML(1, 0, "Type:");
		establishTable.setWidget(1, 1, lstType);

        lstType.addItem("Voice");
        lstType.addItem("Video");

		Button btnEstablish = new Button("Establish", new ClickHandler() {
			public void onClick(ClickEvent event) {
                establishCommunication();
			}
		});

		Button btnCancelEstablish = new Button("Cancel", new ClickHandler() {
			public void onClick(ClickEvent event) {
				hide();
			}
		});

		establishTable.setWidget(4, 0, btnEstablish);
		establishTable.setWidget(4, 1, btnCancelEstablish);

		terminateTable = new FlexTable();

		terminateTable.setHTML(0, 0, "Active Call To:");
		terminateTable.setHTML(0, 1, "Unknown");

		terminateTable.setHTML(1, 0, "Duration");
		terminateTable.setWidget(1, 1, txtDuration);

		Button btnTerminate = new Button("Terminate", new ClickHandler() {
			public void onClick(ClickEvent event) {
                terminateCommunication();
			}
		});

		Button btnCancelTerminate = new Button("Cancel", new ClickHandler() {
			public void onClick(ClickEvent event) {
				hide();
			}
		});

		terminateTable.setWidget(4, 0, btnTerminate);
		terminateTable.setWidget(4, 1, btnCancelTerminate);

		setWidget(establishTable);
	}

	@Override
	public void show() {
        if (currentCall == null) {
            txtDestinationNumber.setText("");
            txtDuration.setText("");
            setWidget(establishTable);
            setText("Establish Communication");
        } else {
            setWidget(terminateTable);
            setText("Terminate Communication");
        }

		super.show();
	}

	public final void establishCommunication() {
        currentCall = new CallDto(parent.getCurrentPhoneNumber(), txtDestinationNumber.getText());
        AsyncCallback<Void> callback = new AsyncCallback<Void>() {
            public void onSuccess(Void response) {
                terminateTable.setHTML(0, 1, currentCall.getDestinationNumber());
                setWidget(terminateTable);
                parent.refreshState();
            }

            public void onFailure(Throwable caught) {
                currentCall = null;
                GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.registerCellPhone");
                GWT.log("-- Throwable: '" + caught.getClass().getName()
                        + "'");
                Window.alert("ERROR: Cannot establish communication: "
                        + caught.getMessage());
            }
        };

		if (lstType.getItemText(lstType.getSelectedIndex()).equals("Voice")) {
            parent.getRpcService().establishVoiceCommunication(currentCall, callback);
		}
        else if (lstType.getItemText(lstType.getSelectedIndex()).equals("Video")) {
            parent.getRpcService().establishVideoCommunication(currentCall, callback);
		}
	}

	public final void terminateCommunication() {
        CallWithDurationDto dto = new CallWithDurationDto(currentCall.getSourceNumber(),
                currentCall.getDestinationNumber(), Integer.parseInt(txtDuration.getText()));

        parent.getRpcService().terminateActiveCommunication(dto, new AsyncCallback<Void>() {
            public void onSuccess(Void response) {
                currentCall = null;
                parent.refreshState();
                parent.refreshBalance();
                hide();
            }

            public void onFailure(Throwable caught) {
                GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.registerCellPhone");
                GWT.log("-- Throwable: '" + caught.getClass().getName()
                        + "'");
                Window.alert("ERROR: Cannot terminate communication: "
                        + caught.getMessage());
            }
        });
	}
}
