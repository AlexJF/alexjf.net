package pt.ist.anacom.service;

import pt.ist.anacom.shared.exception.AnacomException;
import jvstm.Atomic;

/**
 * This class is an abstract implementation of a generic service.
 */
public abstract class AnacomService {

	/**
	 * This method calls the dispatch function in an atomic environment.
	 * 
	 * @throws AnacomException
	 */
	@Atomic
	public void execute() throws AnacomException {
		dispatch();
	}

	/**
	 * This method implements the service itself.
	 * 
	 * @throws AnacomException
	 */
	public abstract void dispatch() throws AnacomException;
}
