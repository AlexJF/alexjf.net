package pt.ist.anacom.sdtest;

import java.security.KeyPair;

import javax.xml.soap.SOAPMessage;

import pt.ist.anacom.sdtest.stubs.OperatorCertificateHandlerTester;
import pt.ist.anacom.security.managers.CASecurityManager;
import sun.security.x509.X509CertImpl;

public class OperatorCertificateHandlerTest extends SecurityTestCase {
	 KeyPair kPair = generateKeyPair();
	    
	 public static final String SOAP_MESSAGE_RESET= 
			"<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
			"<soap:Body><ns2:revoke xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
			"</soap:Envelope>";
	    
	public static final String SOAP_MESSAGE_CREATE = 
	        "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
	        "<soap:Body><ns2:createCertificate xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
	        "</soap:Envelope>";
	
	public static final String SOAP_MESSAGE_GETBLACKLIST = 
	        "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
	        "<soap:Body><ns2:getBlackList xmlns:ns2=\"http://ca.anacom.ist.pt/\"/></soap:Body>" + 
	        "</soap:Envelope>";
	
	private OperatorCertificateHandlerTester handler;
	 
	/* When a certain operator or replica receives a message it will only consider it
	 * if the messages comes from CA or Presentation Server. Otherwise it will only 
	 * validate messages that have the commands createCertificate or getBlackList.
	 * This properties are what we are testing here. 
	 */
	 
	private SOAPMessage prepareIncomingMessage(String message, KeyPair pair, X509CertImpl sourceCertificate) {
	       SOAPMessage outgoingMessage = createSoapMessageFromString(message);
	       
	       addCertificateToSoapMessage(outgoingMessage, sourceCertificate);
	       return outgoingMessage;
	}
	 
	public OperatorCertificateHandlerTest() {
	}
	
	@Override
	public void setUp() {
		super.setUp();
		handler = new OperatorCertificateHandlerTester();
	} 
	 
	/* This tests a message sent from PS with the command reset.
	 * It should pass, therefore it should return true.
	 */
	public void testResetPS() {
		final KeyPair kPairCA = generateKeyPair();
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
					"PS", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15); 
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_RESET, kPairCA, sourceCertificate);
		
		Boolean result = handler.testHandleIncomingMessage(msg);
		
		//Assert
		assertTrue("Message error", result);
	}
	
	/* This tests a message sent from CA with the command reset.
	 * It should pass, therefore it should return true.
	 */
	public void testResetCA() {
		final KeyPair kPairCA = generateKeyPair();
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
					"CA", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15); 
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_RESET, kPairCA, sourceCertificate);
		
		Boolean result = handler.testHandleIncomingMessage(msg);
		
		//Assert
		assertTrue("Message error", result);
	}
	
	/* This tests a message sent from other source with the command reset.
	 * It should pass, therefore it should return true.
	 */
	public void testResetOther() {
		final KeyPair kPairCA = generateKeyPair();
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
					"AS", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15); 
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_RESET, kPairCA, sourceCertificate);
		
		Boolean result = handler.testHandleIncomingMessage(msg);
		
		//Assert
		assertFalse("Message error", result);
	}
	
	/* This tests a message sent from PS with the command create.
	 * It should pass, therefore it should return true.
	 */
	public void testCreatePS() {
		final KeyPair kPairCA = generateKeyPair();
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
					"PS", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15); 
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_CREATE, kPairCA, sourceCertificate);
		
		Boolean result = handler.testHandleIncomingMessage(msg);
		
		//Assert
		assertTrue("Message error", result);
	}
	
	/* This tests a message sent from CA with the command create.
	 * It should pass, therefore it should return true.
	 */
	public void testCreateCA() {
		final KeyPair kPairCA = generateKeyPair();
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
					"CA", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15); 
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_CREATE, kPairCA, sourceCertificate);
		
		Boolean result = handler.testHandleIncomingMessage(msg);
		
		//Assert
		assertTrue("Message error", result);
	}
	
	/* This tests a message sent from other source with the command create.
	 * It should pass, therefore it should return true.
	 */
	public void testCreateOther() {
		final KeyPair kPairCA = generateKeyPair();
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
					"AS", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15); 
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_CREATE, kPairCA, sourceCertificate);
		
		Boolean result = handler.testHandleIncomingMessage(msg);
		
		//Assert
		assertTrue("Message error", result);
	}
	
	/* This tests a message sent from PS with the command getBlackList.
	 * It should pass, therefore it should return true.
	 */
	public void testGetBlackListPS() {
		final KeyPair kPairCA = generateKeyPair();
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
					"PS", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15); 
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_GETBLACKLIST, kPairCA, sourceCertificate);
		
		Boolean result = handler.testHandleIncomingMessage(msg);
		
		//Assert
		assertTrue("Message error", result);
	}
	
	/* This tests a message sent from CA with the command getBlackList.
	 * It should pass, therefore it should return true.
	 */
	public void testGetBlackListCA() {
		final KeyPair kPairCA = generateKeyPair();
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
					"CA", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15); 
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_GETBLACKLIST, kPairCA, sourceCertificate);
		
		Boolean result = handler.testHandleIncomingMessage(msg);
		
		//Assert
		assertTrue("Message error", result);
	}
	
	/* This tests a message sent from other with the command getBlackList.
	 * It should pass, therefore it should return true.
	 */
	public void testGetBlackListOther() {
		final KeyPair kPairCA = generateKeyPair();
		X509CertImpl sourceCertificate = createCertificate(CASecurityManager.getInstance().getPublicKey(),
					"AS", "CA", CASecurityManager.getInstance().getPrivateKey(), 1, 15); 
		
		SOAPMessage msg = prepareIncomingMessage(SOAP_MESSAGE_GETBLACKLIST, kPairCA, sourceCertificate);
		
		Boolean result = handler.testHandleIncomingMessage(msg);
		
		//Assert
		assertTrue("Message error", result);
	}
}
