package pt.ist.anacom.sdtest.stubs;

import pt.ist.anacom.security.managers.CASecurityManager;

public class CASecurityManagerTester extends CASecurityManager {
    public CASecurityManagerTester() {
        super();
    }

    public void clearBlacklist() {
        _blacklist.clear();
    }
}
