package pt.ist.anacom.estest;

import java.math.BigDecimal;

import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.service.ReceiveVoiceCommunicationService;
import pt.ist.anacom.shared.dto.CallDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.CellPhoneNotExistsException;
import pt.ist.anacom.shared.exception.DestinationBusyException;
import pt.ist.anacom.shared.exception.DestinationOffException;
import pt.ist.anacom.shared.exception.DestinationSilenceException;

public class ReceiveVoiceCommunicationServiceTest extends AnacomTestCase {
	private static String OPERATOR_NAME = "ROFLCOPTER";
	private static String OPERATOR_PREFIX = "12";
	private static int OPERATOR_VOICE_COST = 20;
	private static int OPERATOR_VIDEO_COST = 40;
	private static int OPERATOR_Voice_COST = 5;
	private static BigDecimal OPERATOR_TAX = new BigDecimal(1.5);

	private static String CELL_NON_EXISTING_NUMBER = "123434343";

	private static String CELL_2G_ON_NUMBER = "123456700";
	private static String CELL_2G_SILENT_NUMBER = "123456701";
	private static String CELL_2G_BUSY_NUMBER = "123456702";
	private static String CELL_2G_OFF_NUMBER = "123456703";

	private static String CELL_3G_ON_NUMBER = "123456710";
	private static String CELL_3G_SILENT_NUMBER = "123456711";
	private static String CELL_3G_BUSY_NUMBER = "123456712";
	private static String CELL_3G_OFF_NUMBER = "123456713";

	private static String CELL_DEST_DIFFOPER_NUMBER = "912122121";
	private static String CELL_DEST_SAMEOPER_NUMBER = "123456789";

	private static int CELL_BALANCE = 100;

	private CellPhone cell2GOn;
	private CellPhone cell2GSilent;
	private CellPhone cell2GBusy;
	private CellPhone cell2GOff;
	private CellPhone cell3GOn;
	private CellPhone cell3GSilent;
	private CellPhone cell3GBusy;
	private CellPhone cell3GOff;
	private NetworkOperator operator;

	public ReceiveVoiceCommunicationServiceTest(String msg) {
		super(msg);
	}

	public ReceiveVoiceCommunicationServiceTest() {
		super();
	}

	@Override
	public void setUp() {
		super.setUp();

		operator = addOperator(OPERATOR_NAME, OPERATOR_PREFIX,
				OPERATOR_VOICE_COST, OPERATOR_VIDEO_COST, OPERATOR_Voice_COST,
				OPERATOR_TAX);

		cell2GOn = addCellPhone2G(operator, CELL_2G_ON_NUMBER, CELL_BALANCE);
		cell2GSilent = addCellPhone2G(operator, CELL_2G_SILENT_NUMBER,
				CELL_BALANCE);
		turnCellPhoneSilent(cell2GSilent);
		cell2GBusy = addCellPhone2G(operator, CELL_2G_BUSY_NUMBER, CELL_BALANCE);
		turnCellPhoneBusy(cell2GBusy);
		cell2GOff = addCellPhone2G(operator, CELL_2G_OFF_NUMBER, CELL_BALANCE);
		turnCellPhoneOff(cell2GOff);

		cell3GOn = addCellPhone3G(operator, CELL_3G_ON_NUMBER, CELL_BALANCE);
		cell3GSilent = addCellPhone3G(operator, CELL_3G_SILENT_NUMBER,
				CELL_BALANCE);
		turnCellPhoneSilent(cell3GSilent);
		cell3GBusy = addCellPhone3G(operator, CELL_3G_BUSY_NUMBER, CELL_BALANCE);
		turnCellPhoneBusy(cell3GBusy);
		cell3GOff = addCellPhone3G(operator, CELL_3G_OFF_NUMBER, CELL_BALANCE);
		turnCellPhoneOff(cell3GOff);
	}

	public void testReceiveVoiceInNonExisting() {
		// Arrange
		CallDto dto = new CallDto(CELL_DEST_DIFFOPER_NUMBER,
				CELL_NON_EXISTING_NUMBER);
		ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(dto);

		// Act
		try {
			service.execute();
			fail("CellPhone does not exist. Voice comm receival should fail");
		} catch (CellPhoneNotExistsException e) {
            // All is well
		} catch (AnacomException e) {
			fail("Wrong exception thrown. It should throw CellPhoneNotExistsException.");
		}
	}

	public void testReceiveVoiceOn2GOn() {
		// Arrange
		CallDto dto = new CallDto(CELL_DEST_SAMEOPER_NUMBER, CELL_2G_ON_NUMBER);
		ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell2GOn);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is on. Voice comm receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell2GOn,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell2GOn));
	}

	public void testReceiveVoiceOn2GSilent() {
		// Arrange
		CallDto dto = new CallDto(CELL_DEST_SAMEOPER_NUMBER, CELL_2G_SILENT_NUMBER);
		ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(dto);

		// Act
		try {
			service.execute();
			fail("CellPhone exists and is silent. Voice comm should fail");
        } catch (DestinationSilenceException e) {
            // All is well
		} catch (AnacomException e) {
            fail("Wrong exception thrown. It should throw DestinationSilenceException.");
		}
	}

	public void testReceiveVoiceOn2GBusy() {
		// Arrange
		CallDto dto = new CallDto(CELL_DEST_SAMEOPER_NUMBER, CELL_2G_BUSY_NUMBER);
		ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(dto);

		// Act
		try {
			service.execute();
			fail("CellPhone exists and is busy. Voice comm receival should fail");
        } catch (DestinationBusyException e) {
            // All is well
		} catch (AnacomException e) {
            fail("Wrong exception thrown. It should throw DestinationBusyException.");
		}
	}

	public void testReceiveVoiceOn2GOff() {
		// Arrange
		CallDto dto = new CallDto(CELL_DEST_SAMEOPER_NUMBER, CELL_2G_OFF_NUMBER);
		ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(dto);
        
		// Act
		try {
			service.execute();
			fail("CellPhone exists and is off. Voice comm receival should fail");
        } catch (DestinationOffException e) {
            // All is well
		} catch (AnacomException e) {
            fail("Wrong exception thrown. It should throw DestinationOffException.");
		}

	}

	public void testReceiveVoiceOn3GOn() {
		// Arrange
		CallDto dto = new CallDto(CELL_DEST_SAMEOPER_NUMBER, CELL_3G_ON_NUMBER);
		ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(dto);
		int initialIncomingCommunicationCount = getNumberOfIncomingCommunications(cell3GOn);

		// Act
		try {
			service.execute();
		} catch (AnacomException e) {
			fail("CellPhone exists and is on. Voice comm receival should be successful");
		}

		// Assert
		assertTrue(
				"Last communication received should have been made from "
						+ CELL_DEST_SAMEOPER_NUMBER,
				checkHasIncomingCommunicationTo(cell3GOn,
						CELL_DEST_SAMEOPER_NUMBER));
		assertEquals(
				"The number of incoming communications should be increased by one.",
				initialIncomingCommunicationCount + 1,
				getNumberOfIncomingCommunications(cell3GOn));
	}

	public void testReceiveVoiceOn3GSilent() {
		// Arrange
		CallDto dto = new CallDto(CELL_DEST_SAMEOPER_NUMBER, CELL_3G_SILENT_NUMBER);
		ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(dto);

		// Act
		try {
			service.execute();
			fail("CellPhone exists and is silent. Voice comm receival should fail");
        } catch (DestinationSilenceException e) {
            // All is well
		} catch (AnacomException e) {
            fail("Wrong exception thrown. It should throw DestinationSilenceException.");
		}
	}

	public void testReceiveVoiceOn3GBusy() {
		// Arrange
		CallDto dto = new CallDto(CELL_DEST_SAMEOPER_NUMBER, CELL_3G_BUSY_NUMBER);
		ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(dto);

		// Act
		try {
			service.execute();
			fail("CellPhone exists and is busy. Voice comm receival should fail");
        } catch (DestinationBusyException e) {
            // All is well
		} catch (AnacomException e) {
            fail("Wrong exception thrown. It should throw DestinationBusyException.");
		}
	}

	public void testReceiveVoiceOn3GOff() {
		// Arrange
		CallDto dto = new CallDto(CELL_DEST_SAMEOPER_NUMBER, CELL_3G_OFF_NUMBER);
		ReceiveVoiceCommunicationService service = new ReceiveVoiceCommunicationService(dto);
        
		// Act
		try {
			service.execute();
			fail("CellPhone exists and is off. Voice comm receival should fail");
        } catch (DestinationOffException e) {
            // All is well
		} catch (AnacomException e) {
            fail("Wrong exception thrown. It should throw DestinationOffException.");
		}

	}
}
