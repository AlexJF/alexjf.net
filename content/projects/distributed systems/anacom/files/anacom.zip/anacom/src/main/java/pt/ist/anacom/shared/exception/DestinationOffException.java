package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to the destination cellphone of a
 * communication being off.
 */
public class DestinationOffException extends IncomingCommunicationException {
	private static final long serialVersionUID = 1L;

    public DestinationOffException() {
    }

	public DestinationOffException(String destinationNumber) {
		super(destinationNumber, "Destination cellphone is off");
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of DestinationOffException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof DestinationOffException))
			return false;

		return true;
	}
}
