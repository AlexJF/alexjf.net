package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.CellPhone2G;
import pt.ist.anacom.domain.CellPhone3G;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto;
import pt.ist.anacom.shared.dto.CellPhoneDetailedDto.CellPhoneType;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.anacom.shared.exception.OperatorNotExistsException;
import pt.ist.fenixframework.FenixFramework;

/**
 * This class represents a service that allows to register a CellPhone.
 */
public class RegisterCellPhoneService extends AnacomService {

	/** The Dto received by the service */
	private CellPhoneDetailedDto _dto;

	/**
	 * Build an instance of RegisterCellPhoneService.
	 * 
	 * @param dto
	 *            that the service will use.
	 */
	public RegisterCellPhoneService(CellPhoneDetailedDto dto) {
		_dto = dto;
	}

	@Override
	public void dispatch() throws AnacomException {
		AnacomNetwork network = FenixFramework.getRoot();
		String cellPhoneNumber = _dto.getNumber();
		CellPhoneType cellPhoneType = _dto.getType();
		int cellPhoneBalance = _dto.getBalance();
		CellPhone cellPhone;

		NetworkOperator operator = network.getNetworkOperatorByName(_dto
				.getOperatorName());
		if (operator == null) {
			throw new OperatorNotExistsException(_dto.getOperatorName());
		}

		if (cellPhoneType == CellPhoneType.TwoG) {
			cellPhone = new CellPhone2G(cellPhoneNumber, cellPhoneBalance);
		} else {
			cellPhone = new CellPhone3G(cellPhoneNumber, cellPhoneBalance);
		}

		operator.addCellPhone(cellPhone);
	}
}
