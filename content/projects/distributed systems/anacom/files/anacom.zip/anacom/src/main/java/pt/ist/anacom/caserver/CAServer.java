package pt.ist.anacom.caserver;

import java.security.PublicKey;

import pt.ist.anacom.shared.exception.CAException;
import sun.security.x509.X509CRLImpl;

/**
 * This class describes an interface that all Certification Authorities
 * must follow.
 */

public interface CAServer {
	/**
	 * Create a new certificate for a given issuer with a given public key.
	 * 
	 * @param publicKey Public Key that will be certificate.
	 * @param issuer Entity that ask for the certificate.
	 * @return Return a string with the new certificate.
	 * @throws CAException
	 */
	public String createCertificate(String publicKey, String issuer) throws CAException;
	
	/**
	 * Returns an X509CRLImpl object containing ids to all revoked certificates.
	 * 
	 * @return An object with id to all revoked certificates.
	 * @throws CAException
	 */
	public X509CRLImpl getBlackList() throws CAException;
	
	/**
	 * Revokes a given certificate.
	 * 
	 * @param certificate The certificate to be revoked.
	 * @param challenge An answer to a challenge to certify who ask for revoking.
	 * @throws CAException
	 */
	public void revokeCertificate(String certificate, String challenge) throws CAException;
	
	/**
	 * Execute a test command on the CA.
	 */
    public void testCommand(String command);
	
    /**
     * Obtains CA public key.
     * 
     * @return CA's public key.
     */
	public PublicKey getPublicKey();
}
