package pt.ist.anacom.sdtest;

import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

import pt.ist.anacom.replication.OperatorReplicationManager;
import pt.ist.anacom.replication.OperatorServiceFunction;

import pt.ist.anacom.shared.exception.WrongTimestampException;

import pt.ist.anacom.shared.stubs.BalanceDto;
import pt.ist.anacom.shared.stubs.CellPhoneSimpleDto;

public class OperatorReplicationTest extends ReplicationTestCase {
    private final String CELL_NUMBER = "912495153";
    private final int BALANCE = 300;
    private final int STARTING_TIMESTAMP = 12;

	public OperatorReplicationTest() {
	}

	@Override
	public void setUp() {
		super.setUp();
	}

	public void testRequestWithNoTimestamp() {
        // Arrange
        OperatorReplicationManager replicationManager = new OperatorReplicationManager();
        CellPhoneSimpleDto inputDto = new CellPhoneSimpleDto();
        inputDto.setNumber(CELL_NUMBER);
        BalanceDto outputDto = null;
        final BalanceDto expectedOutputDto = new BalanceDto();
        expectedOutputDto.setPhoneNumber(CELL_NUMBER);
        expectedOutputDto.setBalance(BALANCE);

        OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto> serviceFunction = new OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto>() {
            @Override
            public BalanceDto execute(CellPhoneSimpleDto dto) {
                return expectedOutputDto;
            }
        };

        // Act
        try {
            outputDto = replicationManager.handleRequest(inputDto, serviceFunction);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Request handling should not have failed");
        }

        // Assert
        assertEquals(expectedOutputDto, outputDto);
	}

	public void testRequestWithCorrectTimestamp() {
        // Arrange
        OperatorReplicationManager replicationManager = new OperatorReplicationManager(STARTING_TIMESTAMP);
        CellPhoneSimpleDto inputDto = new CellPhoneSimpleDto();
        inputDto.setNumber(CELL_NUMBER);
        inputDto.setTimestamp(STARTING_TIMESTAMP + 1);
        BalanceDto outputDto = null;
        final BalanceDto expectedOutputDto = new BalanceDto();
        expectedOutputDto.setPhoneNumber(CELL_NUMBER);
        expectedOutputDto.setBalance(BALANCE);

        OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto> serviceFunction = new OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto>() {
            @Override
            public BalanceDto execute(CellPhoneSimpleDto dto) {
                return expectedOutputDto;
            }
        };

        // Act
        try {
            outputDto = replicationManager.handleRequest(inputDto, serviceFunction);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Request handling should not have failed");
        }

        // Assert
        assertEquals(expectedOutputDto, outputDto);
        assertEquals(outputDto.getTimestamp(), new Integer(STARTING_TIMESTAMP + 1));
	}

	public void testRequestWithLowerTimestamp() {
        // Arrange
        OperatorReplicationManager replicationManager = new OperatorReplicationManager(STARTING_TIMESTAMP);
        CellPhoneSimpleDto inputDto = new CellPhoneSimpleDto();
        inputDto.setNumber(CELL_NUMBER);
        inputDto.setTimestamp(STARTING_TIMESTAMP - 1);
        final BalanceDto expectedOutputDto = new BalanceDto();
        expectedOutputDto.setPhoneNumber(CELL_NUMBER);
        expectedOutputDto.setBalance(BALANCE);
        WrongTimestampException resultException = null;

        OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto> serviceFunction = new OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto>() {
            @Override
            public BalanceDto execute(CellPhoneSimpleDto dto) {
                return expectedOutputDto;
            }
        };

        // Act
        try {
            replicationManager.handleRequest(inputDto, serviceFunction);
            fail("Request handling should have failed with WrongTimestampException.");
        } catch (WrongTimestampException e) {
            // All is well
            resultException = e;
        } catch (Exception e) {
            e.printStackTrace();
            fail("Request handling should have failed with WrongTimestampException.");
        }

        // Assert
        assertEquals(new Integer(STARTING_TIMESTAMP), resultException.getTimestamp());
	}

	public void testRequestWithHigherTimestampFollowedByPrevious() {
        // Arrange
        final OperatorReplicationManager replicationManager = new OperatorReplicationManager(STARTING_TIMESTAMP);

        final CellPhoneSimpleDto input1Dto = new CellPhoneSimpleDto();
        input1Dto.setNumber(CELL_NUMBER);
        input1Dto.setTimestamp(STARTING_TIMESTAMP + 2);

        final CellPhoneSimpleDto input2Dto = new CellPhoneSimpleDto();
        input2Dto.setNumber(CELL_NUMBER);
        input2Dto.setTimestamp(STARTING_TIMESTAMP + 1);

        final BalanceDto expectedOutputDto = new BalanceDto();
        expectedOutputDto.setPhoneNumber(CELL_NUMBER);
        expectedOutputDto.setBalance(BALANCE);

        BalanceDto output1Dto = null;
        BalanceDto output2Dto = null;

        final OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto> serviceFunction = new OperatorServiceFunction<CellPhoneSimpleDto, BalanceDto>() {
            @Override
            public BalanceDto execute(CellPhoneSimpleDto dto) {
                BalanceDto returnDto = new BalanceDto();
                returnDto.setPhoneNumber(CELL_NUMBER);
                returnDto.setBalance(BALANCE);
                return returnDto;
            }
        };

        FutureTask<BalanceDto> future = new FutureTask<BalanceDto>(new Callable<BalanceDto>() {
            @Override
            public BalanceDto call() {
                return replicationManager.handleRequest(input1Dto, serviceFunction);
            }
        });

        ExecutorService executor = Executors.newFixedThreadPool(3);

        // Act
        executor.execute(future);

        try {
            output1Dto = future.get(2, TimeUnit.SECONDS);
            fail("First caller shouldn't have gotten a response since it has a future timestamp");
        } catch (Exception e) {
            // All is well
        }

        try {
            output2Dto = replicationManager.handleRequest(input2Dto, serviceFunction);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Request handling should not have failed");
        }

        try {
            output1Dto = future.get(2, TimeUnit.SECONDS);
        } catch (Exception e) {
            fail("After having handled the second request, the first request should have been executed and the result returned.");
        }

        // Assert
        assertEquals(expectedOutputDto.getPhoneNumber(), output1Dto.getPhoneNumber());
        assertEquals(expectedOutputDto.getBalance(), output1Dto.getBalance());
        assertEquals(expectedOutputDto.getPhoneNumber(), output2Dto.getPhoneNumber());
        assertEquals(expectedOutputDto.getBalance(), output2Dto.getBalance());
        assertEquals(new Integer(STARTING_TIMESTAMP + 2), output1Dto.getTimestamp());
        assertEquals(new Integer(STARTING_TIMESTAMP + 1), output2Dto.getTimestamp());
	}
}
