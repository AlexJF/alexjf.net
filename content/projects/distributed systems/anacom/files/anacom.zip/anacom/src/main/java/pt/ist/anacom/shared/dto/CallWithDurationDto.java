package pt.ist.anacom.shared.dto;

/**
 * This Dto allows to transport information of a call with
 * a duration.
 */
public class CallWithDurationDto extends CallDto {
	static final long serialVersionUID = 1L;

	/** Duration of the call */
    private int _duration;

    /**
     * Constructs a CallWithDurationDto.
     */
	public CallWithDurationDto() {
	}

	/**
	 * Creates a new instance of VoiceDto.
	 * 
	 * @param sourceNumber
	 *            The number of the cellphone where the call originated from.
	 * @param destinationNumber
	 *            The number of the cellphone to which the call is directed.
     * @param duration
     *            The duration of the call in seconds.
	 */
	public CallWithDurationDto(String sourceNumber, String destinationNumber, int duration) {
        super(sourceNumber, destinationNumber);
        _duration = duration;
	}

    /**
     * Get the duration of the call.
     *
     * @return The duration of the call (in seconds).
     */
    public int getDuration() {
        return _duration;
    }
    
	/**
	 * Compares two instances of CallWithDurationDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof CallWithDurationDto))
			return false;

		CallWithDurationDto dto = (CallWithDurationDto) obj;

		return getDuration() == dto.getDuration();
	}
}
