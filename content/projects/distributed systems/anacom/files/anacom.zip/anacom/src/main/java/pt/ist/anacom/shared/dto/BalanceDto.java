package pt.ist.anacom.shared.dto;

/**
 * This Dto allows to transport information needed
 * to get the balance of a cellphone.
 */
public class BalanceDto extends AnacomDto {

	private static final long serialVersionUID = 1L;

	/** The number of the CellPhone. */
	private String _number;

	/** The balance of the CellPhone */
	private int _balance;

	/**
	 * Constructs a balance dto.
	 */
	public BalanceDto() {
		super();
	}

	/**
	 * Constructs a balance dto with a given phone number
	 * and balance.
	 * @param phoneNumber of the cellphone.
	 * @param balance of the cellphone.
	 */
	public BalanceDto(String phoneNumber, int balance) {
		_number = phoneNumber;
		_balance = balance;
	}

	/**
	 * Returns the CellPhone's number.
	 * 
	 * @return CellPhone's number
	 */
	public String getPhoneNumber() {
		return _number;
	}

	/**
	 * Returns the CellPhone's balance.
	 * 
	 * @return CellPhone's balance in cents.
	 */
	public int getBalance() {
		return _balance;
	}

	/**
	 * Compares two instances of BalanceDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof BalanceDto))
			return false;

		BalanceDto dto = (BalanceDto) obj;

		return getPhoneNumber().equals(dto.getPhoneNumber())
				&& getBalance() == dto.getBalance();
	}
}
