package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to a nonexistent operator.
 */
public class OperatorNotExistsException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _name;
	private String _prefix;

	public OperatorNotExistsException() {
	}

	public OperatorNotExistsException(String name) {
		super("An operator with the name \"" + name
				+ "\" does not exist on the network");
		_name = name;
		_prefix = "";
	}

	public OperatorNotExistsException(String name, String prefix) {
		super("An operator with the prefix \"" + prefix
				+ "\" does not exist on the network");
		_name = name;
		_prefix = prefix;
	}

	public String getName() {
		return _name;
	}

	public String getPrefix() {
		return _prefix;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of OperatorNotExistsException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof OperatorNotExistsException))
			return false;

		OperatorNotExistsException exception = (OperatorNotExistsException) obj;

		return getName().equals(exception.getName())
				&& getPrefix().equals(exception.getPrefix());
	}
}
