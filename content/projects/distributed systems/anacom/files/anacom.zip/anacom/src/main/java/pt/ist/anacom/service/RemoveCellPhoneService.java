package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.CellPhone;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.shared.dto.CellPhoneWithOperatorDto;
import pt.ist.anacom.shared.exception.AnacomException;
import pt.ist.fenixframework.FenixFramework;

public class RemoveCellPhoneService extends AnacomService {

	/** The service Dto */
	private CellPhoneWithOperatorDto _dto;

	/**
	 * Creates a new instance of this service.
	 * 
	 * @param dto
	 *            Element with information about the cellPhone to remove.
	 */
	public RemoveCellPhoneService(CellPhoneWithOperatorDto dto) {
		_dto = dto;
	}

	@Override
	public void dispatch() throws AnacomException {
		AnacomNetwork network = FenixFramework.getRoot();

		NetworkOperator operator = network.getNetworkOperatorByNameOrException(_dto
				.getOperatorName());

		CellPhone cell = operator.getCellPhoneOrException(_dto.getNumber());

        operator.removeCellPhone(cell);
	}
}
