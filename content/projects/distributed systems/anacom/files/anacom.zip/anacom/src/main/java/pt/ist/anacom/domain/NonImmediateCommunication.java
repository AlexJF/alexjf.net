package pt.ist.anacom.domain;

public abstract class NonImmediateCommunication extends NonImmediateCommunication_Base {
    
    public NonImmediateCommunication() {
        super();
        setActive(true);
    }

	public void end(int duration) {
        if (!getActive()) {
            return;
        }
		setDuration(duration);
		super.end();
        setActive(false);
	}
}
