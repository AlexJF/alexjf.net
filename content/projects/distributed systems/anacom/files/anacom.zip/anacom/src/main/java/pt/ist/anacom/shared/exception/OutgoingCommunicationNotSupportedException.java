package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to an outgoing communication not
 * being supported by the source cellphone.
 */
public class OutgoingCommunicationNotSupportedException extends
		OutgoingCommunicationException {
	private static final long serialVersionUID = 1L;

	private String _phoneType;
	private String _commType;

	public OutgoingCommunicationNotSupportedException() {
	}

	public OutgoingCommunicationNotSupportedException(String sourceNumber,
			String phoneType, String commType) {
		super(sourceNumber, phoneType + " cannot make outgoing " + commType
				+ " communications.");
		_commType = commType;
		_phoneType = phoneType;
	}

	public String getPhoneType() {
		return _phoneType;
	}

	public String getCommunicationType() {
		return _commType;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of OutgoingCommunicationNotSupportedException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof OutgoingCommunicationNotSupportedException))
			return false;

		OutgoingCommunicationNotSupportedException exception = (OutgoingCommunicationNotSupportedException) obj;

		return getPhoneType().equals(exception.getPhoneType())
				&& getCommunicationType().equals(exception.getCommunicationType());
	}
}
