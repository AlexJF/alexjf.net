package pt.ist.anacom.service;

import pt.ist.anacom.domain.AnacomNetwork;
import pt.ist.anacom.domain.NetworkOperator;
import pt.ist.anacom.domain.SMS;

import pt.ist.anacom.shared.dto.SMSDto;
import pt.ist.anacom.shared.exception.AnacomException;

import pt.ist.fenixframework.FenixFramework;

/**
 * This class implements the send SMS service.
 */
public class SendSMSService extends AnacomService {

	/** The service Dto */
	private SMSDto _dto;

	/**
	 * Creates a new instance of this service with information about the sms
	 * communication.
	 * 
	 * @param dto
	 *            Element with information about the sms communication we wish
	 *            to send.
	 */
	public SendSMSService(SMSDto dto) {
		_dto = dto;
	}

	@Override
	public void dispatch() throws AnacomException {
		AnacomNetwork network = FenixFramework.getRoot();
		NetworkOperator op = network.getNetworkOperatorByCellPhoneNumberOrException(_dto
				.getSourceNumber());

		SMS outgoingSMS = new SMS(_dto.getSourceNumber(),
				_dto.getDestinationNumber(), _dto.getMessage());
		op.establishCommunication(outgoingSMS);
	}
}
