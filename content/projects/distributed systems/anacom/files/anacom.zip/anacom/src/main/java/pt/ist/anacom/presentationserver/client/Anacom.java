package pt.ist.anacom.presentationserver.client;

import java.util.ArrayList;
import java.util.List;

import pt.ist.anacom.presentationserver.client.views.ChangeCellPhoneNumberPopup;
import pt.ist.anacom.presentationserver.client.views.ChangeCellPhoneStatePopup;
import pt.ist.anacom.presentationserver.client.views.EstablishCallPopup;
import pt.ist.anacom.presentationserver.client.views.GetLastCommunicationDetailsPopup;
import pt.ist.anacom.presentationserver.client.views.IncreaseCellPhoneBalancePopup;
import pt.ist.anacom.presentationserver.client.views.RegisterCellPhonePopup;
import pt.ist.anacom.presentationserver.client.views.SendSMSPopup;
import pt.ist.anacom.shared.dto.BalanceDto;
import pt.ist.anacom.shared.dto.CellPhoneSimpleDto;
import pt.ist.anacom.shared.dto.CellPhoneWithStateDto;
import pt.ist.anacom.shared.dto.ChangeCellPhoneBalanceDto;
import pt.ist.anacom.shared.dto.SMSDto;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.NumberFormat;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlexTable.FlexCellFormatter;
import com.google.gwt.user.client.ui.HTMLTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;

public class Anacom implements EntryPoint {
	private final AnacomServiceAsync rpcService = GWT
			.create(AnacomService.class);

	private final CellTable<SMSDto> tblSMS = new CellTable<SMSDto>();
	private final Label lblPhoneNumber = new Label("None");
	private final Label lblBalance = new Label("Unknown");
	private final Label lblState = new Label("Unknown");

	private String currentPhoneNumber = "";

	public void onModuleLoad() {
		GWT.log("presentationserver.client.Anacom::onModuleLoad() - begin");

		String serverType; // depends on type of running
		if (RootPanel.get("essd") != null) {
			GWT.log("presentationserver.client.Anacom::onModuleLoad() running on remote mode");
			serverType = "essd";
		} 
        else if (RootPanel.get("essd-security") != null) {
			GWT.log("presentationserver.client.Anacom::onModuleLoad() running on security remote mode");
			serverType = "essd-security";
        }
        else if (RootPanel.get("essd-replicated") != null) {
			GWT.log("presentationserver.client.Anacom::onModuleLoad() running on replicated remote mode");
			serverType = "essd-replicated";
        }
        else if (RootPanel.get("essd-replicated-security") != null) {
			GWT.log("presentationserver.client.Anacom::onModuleLoad() running on replicated security remote mode");
			serverType = "essd-replicated-security";
        }
        else { // default: local - even if it is misspelled
			GWT.log("presentationserver.client.Anacom::onModuleLoad() running on local mode");
			serverType = "es";
		}

		final ChangeCellPhoneNumberPopup changeCellPhoneNumberPopup = new ChangeCellPhoneNumberPopup(
				this);
		final RegisterCellPhonePopup registerCellPhonePopup = new RegisterCellPhonePopup(
				this);
		final IncreaseCellPhoneBalancePopup increaseCellPhoneBalancePopup = new IncreaseCellPhoneBalancePopup(
				this);
		final GetLastCommunicationDetailsPopup getLastCommunicationDetailsPopup = new GetLastCommunicationDetailsPopup(
				this);
		final ChangeCellPhoneStatePopup changeCellPhoneStatePopup = new ChangeCellPhoneStatePopup(
				this);
		final SendSMSPopup sendSMSPopup = new SendSMSPopup(this);
		final EstablishCallPopup establishCallPopup = new EstablishCallPopup(this);

		RootPanel typeRootPanel = RootPanel.get(serverType);

		FlexTable infoTable = new FlexTable();
		typeRootPanel.add(infoTable);
		infoTable.getElement().setId("infoTable");

		HTMLTable.ColumnFormatter colFormatter = infoTable.getColumnFormatter();
		colFormatter.setStyleName(0, "col0");
		colFormatter.setStyleName(1, "col1");
		colFormatter.setStyleName(2, "col2");
		FlexCellFormatter cellFormatter = infoTable.getFlexCellFormatter();

		infoTable.setHTML(0, 0,
				"<h1>CellPhone Management - " + serverType.toUpperCase()
						+ "</h1>");
		cellFormatter.setColSpan(0, 0, 3);
		cellFormatter.setHorizontalAlignment(0, 0,
				HasHorizontalAlignment.ALIGN_CENTER);

		Button btnChangeNumber = new Button("Change", new ClickHandler() {
			public void onClick(ClickEvent sender) {
				changeCellPhoneNumberPopup.center();
				changeCellPhoneNumberPopup.show();
			}
		});

		infoTable.setHTML(1, 0, "Number:");
		infoTable.setWidget(1, 1, lblPhoneNumber);
		infoTable.setWidget(1, 2, btnChangeNumber);

		Button btnIncreaseBalance = new Button("Increase", new ClickHandler() {
			public void onClick(ClickEvent sender) {
				increaseCellPhoneBalancePopup.center();
				increaseCellPhoneBalancePopup.show();
			}
		});

		infoTable.setHTML(2, 0, "Balance:");
		infoTable.setWidget(2, 1, lblBalance);
		infoTable.setWidget(2, 2, btnIncreaseBalance);

		Button btnChangeState = new Button("Change", new ClickHandler() {
			public void onClick(ClickEvent sender) {
				changeCellPhoneStatePopup.center();
				changeCellPhoneStatePopup.show();
			}
		});

		infoTable.setHTML(3, 0, "State:");
		infoTable.setWidget(3, 1, lblState);
		infoTable.setWidget(3, 2, btnChangeState);

		infoTable.setHTML(4, 0, "Received SMS:");
		cellFormatter.setColSpan(4, 0, 3);

		TextColumn<SMSDto> sourceColumn = new TextColumn<SMSDto>() {
			@Override
			public String getValue(SMSDto sms) {
				return sms.getSourceNumber();
			}
		};

		TextColumn<SMSDto> destinationColumn = new TextColumn<SMSDto>() {
			@Override
			public String getValue(SMSDto sms) {
				return sms.getDestinationNumber();
			}
		};

		TextColumn<SMSDto> messageColumn = new TextColumn<SMSDto>() {
			@Override
			public String getValue(SMSDto sms) {
				return sms.getMessage();
			}
		};

		tblSMS.addColumn(sourceColumn, "Source Number");
		tblSMS.addColumn(destinationColumn, "Destination Number");
		tblSMS.addColumn(messageColumn, "SMS Content");

		tblSMS.setRowData(new ArrayList<SMSDto>());
		tblSMS.getElement().setId("SMSTable");
		tblSMS.setEmptyTableWidget(new Label("No sms to show :("));

		infoTable.setWidget(5, 0, tblSMS);
		cellFormatter.setColSpan(5, 0, 3);
		cellFormatter.setHorizontalAlignment(5, 0,
				HasHorizontalAlignment.ALIGN_CENTER);

		infoTable.setHTML(6, 0, "Actions:");

		Button btnSendSMS = new Button("Send SMS", new ClickHandler() {
			public void onClick(ClickEvent event) {
				sendSMSPopup.center();
				sendSMSPopup.show();
			}
		});

		infoTable.setWidget(6, 1, btnSendSMS);

		Button btnRefresh = new Button("Refresh Info", new ClickHandler() {
			public void onClick(ClickEvent event) {
				refreshAll();
			}
		});

		Button btnRegister = new Button("Register CellPhone",
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						registerCellPhonePopup.center();
						registerCellPhonePopup.show();
					}
				});
		
		Button btnCommuDetails = new Button("Last Comm Details",
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						getLastCommunicationDetailsPopup.center();
						getLastCommunicationDetailsPopup.show();
					}
				});

		Button btnEstablishCall = new Button("Make Call",
				new ClickHandler() {
					public void onClick(ClickEvent event) {
						establishCallPopup.center();
						establishCallPopup.show();
					}
				});

		infoTable.setWidget(6, 2, btnEstablishCall);
		infoTable.setWidget(7, 1, btnCommuDetails);
		infoTable.setWidget(7, 2, btnRegister);
		infoTable.setWidget(8, 2, btnRefresh);

		this.rpcService.initBridge(serverType, new AsyncCallback<Void>() {
			@Override
			public void onSuccess(Void result) {
				// Do something
			}

			@Override
			public void onFailure(Throwable caught) {
				GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.initBridge");
				GWT.log("-- Throwable: '" + caught.getClass().getName() + "'");
				Window.alert("Not able to init aplication server bridge: "
						+ caught.getMessage());

			}
		});
		GWT.log("presentationserver.client.Anacom::onModuleLoad() - done!");
	}

	public final void refreshBalance() {
		rpcService.getCellPhoneBalance(new CellPhoneSimpleDto(
				currentPhoneNumber), new AsyncCallback<BalanceDto>() {
			public void onSuccess(BalanceDto response) {
				NumberFormat fmt = NumberFormat.getCurrencyFormat("EUR");
				lblBalance.setText(fmt.format(((float) response.getBalance()) / 100f));
			}

			public void onFailure(Throwable caught) {
				lblBalance.setText("Unknown");
				GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.getCellPhoneBalance");
				GWT.log("-- Throwable: '" + caught.getClass().getName() + "'");
				Window.alert("ERROR: Cannot get balance: "
						+ caught.getMessage());
			}
		});
	}
	

	public final void refreshState() {
		rpcService.getCellPhoneState(
				new CellPhoneSimpleDto(currentPhoneNumber),
				new AsyncCallback<CellPhoneWithStateDto>() {
					public void onSuccess(CellPhoneWithStateDto response) {
						lblState.setText(response.getState().toString());
					}

					public void onFailure(Throwable caught) {
						lblState.setText("Unknown");
						GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.getCellPhoneState");
						GWT.log("-- Throwable: '" + caught.getClass().getName()
								+ "'");
						Window.alert("ERROR: Cannot get state: "
								+ caught.getMessage());
					}
				});
	}

	public final void refreshSMSList() {
		rpcService.listSMS(new CellPhoneSimpleDto(currentPhoneNumber),
				new AsyncCallback<List<SMSDto>>() {
					public void onSuccess(List<SMSDto> response) {
						tblSMS.setRowData(response);
					}

					public void onFailure(Throwable caught) {
						tblSMS.setRowData(new ArrayList<SMSDto>());
						GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.listSMS");
						GWT.log("-- Throwable: '" + caught.getClass().getName()
								+ "'");
						Window.alert("ERROR: Cannot list sms: "
								+ caught.getMessage());
					}
				});
	}

	public final void refreshAll() {
		refreshBalance();
		refreshState();
		refreshSMSList();
	}

	/**
	 * Gets the rpcService for this instance.
	 * 
	 * @return The rpcService.
	 */
	public AnacomServiceAsync getRpcService() {
		return this.rpcService;
	}

	/**
	 * Gets the currentPhoneNumber for this instance.
	 * 
	 * @return The currentPhoneNumber.
	 */
	public String getCurrentPhoneNumber() {
		return this.currentPhoneNumber;
	}

	/**
	 * Sets the currentPhoneNumber for this instance.
	 * 
	 * @param currentPhoneNumber
	 *            The currentPhoneNumber.
	 */
	public void setCurrentPhoneNumber(String currentPhoneNumber) {
		this.currentPhoneNumber = currentPhoneNumber;
		lblPhoneNumber.setText(currentPhoneNumber);
		refreshAll();
	}

	/**
	 * Sets the state of the current phone.
	 * 
	 * @param state
	 *            The state to set the phone to.
	 */
	public void setCurrentPhoneState(CellPhoneWithStateDto.CellPhoneStates state) {
		rpcService.changeCellPhoneState(new CellPhoneWithStateDto(
				currentPhoneNumber, state), new AsyncCallback<Void>() {
			public void onSuccess(Void response) {
				refreshState();
			}

			public void onFailure(Throwable caught) {
				GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.changeCellPhoneState");
				GWT.log("-- Throwable: '" + caught.getClass().getName() + "'");
				Window.alert("ERROR: Cannot change state: "
						+ caught.getMessage());
			}
		});
	}

	public void increasePhoneBalance(int amount) {
		rpcService.increaseCellPhoneBalance(new ChangeCellPhoneBalanceDto(
				currentPhoneNumber, amount), new AsyncCallback<Void>() {
			public void onSuccess(Void response) {
				refreshBalance();
			}

			public void onFailure(Throwable caught) {
				GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.increaseCellPhoneBalance");
				GWT.log("-- Throwable: '" + caught.getClass().getName() + "'");
				Window.alert("ERROR: Cannot increase balance: "
						+ caught.getMessage());
			}
		});
	}
	

	public void sendSMS(String destinationNumber, String message) {
		rpcService.sendSMS(new SMSDto(currentPhoneNumber, destinationNumber,
				message), new AsyncCallback<Void>() {
			public void onSuccess(Void response) {
				refreshSMSList();
				refreshBalance();
			}

			public void onFailure(Throwable caught) {
				GWT.log("presentationserver.client.Anacom::onModuleLoad()::rpcService.sendSMS");
				GWT.log("-- Throwable: '" + caught.getClass().getName() + "'");
				Window.alert("ERROR: Cannot send sms: " + caught.getMessage());
			}
		});
	}
}
