package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to an invalid operator prefix.
 */
public class InvalidOperatorPrefixException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _prefix;
	private String _causeMessage;

	public InvalidOperatorPrefixException() {
	}

	public InvalidOperatorPrefixException(String prefix, String cause) {
		super("Specified operator prefix \"" + prefix + "\" is invalid: "
				+ cause);
		_prefix = prefix;
		_causeMessage = cause;
	}

	public String getPrefix() {
		return _prefix;
	}

	public String getCauseMessage() {
		return _causeMessage;
	}

    public void throwYourself() {
        throw this;
    }
    
	/**
	 * Compares two instances of InvalidOperatorPrefixException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof InvalidOperatorPrefixException))
			return false;

		InvalidOperatorPrefixException exception = (InvalidOperatorPrefixException) obj;

		return getPrefix().equals(exception.getPrefix())
				&& getCauseMessage().equals(exception.getCauseMessage());
	}
}
