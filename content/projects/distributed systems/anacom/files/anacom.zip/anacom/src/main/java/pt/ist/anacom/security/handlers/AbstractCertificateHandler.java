package pt.ist.anacom.security.handlers;

import java.io.IOException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.X509CRL;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Node;

import pt.ist.anacom.security.managers.AbstractSecurityManager;

import sun.security.x509.X509CertImpl;

/**
 * This class extends from Abstract Handler and implements the generic behavior
 * for handlers which goal is to validate a received a certificate.
 */

public abstract class AbstractCertificateHandler extends AbstractHandler {

	@Override
	protected boolean handleInboundMessage(SOAPMessage message) {
        System.out.println("Handling Inbound Message - Certification Handler");
		try {
            Node certificateNode = getCertificateNode(getHeader(getSoapEnvelope(message)));
            String certString;
            certString = getCertString(certificateNode);
            X509CertImpl cert;
            cert = new X509CertImpl(b64d.decodeBuffer(certString));
            return checkCertificate(cert);
		} catch (Exception e) {
			e.printStackTrace();
            return false;
		}
	}

	/**
	 * This function must be implemented by all classes that extend this one
	 * on order to retrieve a specific security manager for a certain server.
	 * @return Returns an instance of a security manager.
	 */
    protected abstract AbstractSecurityManager getSecurityManager();
	
    @Override
	protected boolean handleOutboundMessage(SOAPMessage message) {
        System.out.println("Handling Outbound Message - Certification Handler");
		try {
			SOAPEnvelope soapEnvelope = getSoapEnvelope(message);
			SOAPHeader soapHeader = getHeader(soapEnvelope);
            String cert = getCertificate();

            if (cert != null) {
                SOAPElement element = addCertificateNameToHeader(soapEnvelope, soapHeader);
                element.addTextNode(cert);
            }
		} catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * Fetch a certificate from the associated security manager.
	 * @return
	 */
	protected String getCertificate() {
        return getSecurityManager().getCertificate();
    }
	
	/**
	 * Adds an header node for a certificate to a given SOAP header that
	 * will resides in the given SOAP Envelope.
	 * @param soapEnvelope The SOAP Envelope that will contain the SOAP Header.
	 * @param soapHeader The SOAP Header that will contain a certificate header.
	 * @return Returns a SOAP Element made of an SOAP Header with a certificate header.
	 * @throws SOAPException
	 */
	protected SOAPElement addCertificateNameToHeader(SOAPEnvelope soapEnvelope,
			SOAPHeader soapHeader) throws SOAPException {
		Name name = soapEnvelope.createName("certificate", "anacom",
				"http://pt.ist.utl.anacom");

		SOAPElement element = soapHeader.addChildElement(name);
		return element;
	}
	
	/**
	 * Retrieves a certificate from a header node.
	 * @param headerNode Heather node with certificate.
	 * @return Returns a string containing a certificate.
	 * @throws IOException
	 */
	protected String getCertString(Node headerNode) throws IOException {
		String certString;
		certString = headerNode.getTextContent();
		return certString;
	}
	
    /**
     * Retrieves the common name from a DN string.
     * @param dn The common name.
     * @return
     */
	private String getCommonNameFromDN(String dn) {
		String cn = dn.substring(dn.indexOf('=') + 1, dn.indexOf(','));
		return cn;
	}
	
	/**
	 * This function test the certificate in order to see if it is a
	 * valid and well signed certificate.
	 * @param cert Certificate to evaluate.
	 * @return Returns a boolean saying if it is or not a valid and well signed certificate.
	 */
	protected boolean checkCertificate(X509CertImpl cert) {
        System.out.println("Checking certificate...");
		try {
			cert.checkValidity();
			System.out.println("Cert is valid");
			cert.verify(getSecurityManager().getCAPublicKey());
			System.out.println("Signature is valid");
            
			if (getCommonNameFromDN(cert.getSubjectDN().getName()).equals("CA")) {
                return true;
            } else {
                return !isOnBlackList(cert);
            }
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * Verifies if a given certificate is on the black list.
	 * @param cert Certificate to evaluate.
	 * @return Returns a boolean saying it the certificate is on the black list.
	 * @throws CertificateExpiredException
	 * @throws CertificateEncodingException
	 */
	protected boolean isOnBlackList(X509CertImpl cert)
			throws CertificateExpiredException, CertificateEncodingException {
		X509CRL _blackList = getBlackList();
		return _blackList.isRevoked(cert);
	}
	
	/**
	 * This function must be implemented by all classes that extends from this one,
	 * and the goal is to retrieve a blacklist.
	 * @return
	 */
	protected X509CRL getBlackList() {
		// TODO: remove this.
		System.out.println("Obtaining blacklist");
		return getSecurityManager().getBlackList();
	}

    @Override
    protected String getFaultString(boolean incoming) {
        if (incoming) {
            return "Incoming certificate not valid";
        } else {
            return "Unable to add certificate to outgoing message";
        }
    }
}
