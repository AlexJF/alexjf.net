package pt.ist.anacom.shared.exception;

/**
 * This class represents an exception related to an outgoing communication.
 */
public abstract class OutgoingCommunicationException extends AnacomException {
	private static final long serialVersionUID = 1L;

	private String _sourceNumber;

	public OutgoingCommunicationException() {
	}

	public OutgoingCommunicationException(String sourceNumber, String cause) {
		super("Cannot establish outgoing communication from \"" + sourceNumber
				+ "\": " + cause);
		_sourceNumber = sourceNumber;
	}

	public String getSourceNumber() {
		return _sourceNumber;
	}

    public void setSourceNumber(String number) {
        _sourceNumber = number;
    }
    
	/**
	 * Compares two instances of OutgoingCommunicationException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
	public boolean equals(Object obj) {
		boolean b = super.equals(obj);
		
		if (b == false)
			return false;
		if (!(obj instanceof OutgoingCommunicationException))
			return false;

		OutgoingCommunicationException exception = (OutgoingCommunicationException) obj;

		return getSourceNumber().equals(exception.getSourceNumber());
	}
}
