package pt.ist.anacom.shared.dto;

import java.util.LinkedList;
import java.util.List;

/**
 * This dto allows to transport the SMSs
 * of a cellphone.
 */
public class ListCellPhoneSMSDto extends AnacomDto {
	
	static final long serialVersionUID = 1L;

	/** List of SMSDto of the CellPhone. */
	private List<SMSDto> _cellPhoneSMS;

	/**
	 * Constructs a ListCellPhoneSMSDto
	 */
	public ListCellPhoneSMSDto() {
		_cellPhoneSMS = new LinkedList<SMSDto>();
	}

	/**
	 * Adds a sms.
	 * @param sourceNumber of the source cellphone.
	 * @param destinationNumber of the destination cellphone.
	 * @param message of the SMS.
	 */
	public void addCellPhoneSMS(String sourceNumber, String destinationNumber,
			String message) {
		_cellPhoneSMS.add(new SMSDto(sourceNumber, destinationNumber, message));
	}

	/**
	 * Allows to get the list of SMSDtos.
	 * @return the list of SMSDtos.
	 */
	public List<SMSDto> getCellPhonesSMS() {
		return _cellPhoneSMS;
	}
	
	/**
	 * Compares two instances of ListCellPhoneSMSDto.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	boolean b = super.equals(obj);
    	
    	if (b == false)
    		return false;
		if (!(obj instanceof ListCellPhoneSMSDto))
			return false;

		ListCellPhoneSMSDto dto = (ListCellPhoneSMSDto) obj;

		return getCellPhonesSMS().equals(dto.getCellPhonesSMS());
	}
}
