package pt.ist.anacom.shared.exception;

import pt.ist.anacom.shared.Timestamped;

/**
 * This class implements a generic AnacomException.
 */
public abstract class AnacomException extends RuntimeException implements Timestamped {
	static final long serialVersionUID = 1;

    private Integer _timestamp;

	public AnacomException() {
		super();
	}

	/**
	 * Create an instance of AnacomException.
	 * 
	 * @param cause
	 *            The reason for the exception.
	 */
	public AnacomException(String cause) {
		super(cause);
	}

    public Integer getTimestamp() {
        return _timestamp;
    }

    public void setTimestamp(Integer timestamp) {
        _timestamp = timestamp;
    }
    
	/**
	 * Compares two instances of AnacomException.
	 * 
	 * @return true if they have the same values, false otherwise.
	 */
    @Override
	public boolean equals(Object obj) {
    	if (obj == null)
    		return false;
		if (!(obj instanceof AnacomException))
			return false;

		AnacomException exception = (AnacomException) obj;

		return getTimestamp() == null ? exception.getTimestamp() == null : getTimestamp().equals(exception.getTimestamp());
	}

    public abstract void throwYourself();
}
