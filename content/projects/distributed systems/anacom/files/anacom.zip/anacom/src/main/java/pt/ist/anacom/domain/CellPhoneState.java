package pt.ist.anacom.domain;

import pt.ist.anacom.shared.exception.AnacomException;

/**
 * This class represents a generic CellPhone State. According to its state, a
 * CellPhone can or can't establish a communication.
 */
public abstract class CellPhoneState extends CellPhoneState_Base {

	public CellPhoneState() {
		super();
	}

	/**
	 * Checks if the CellPhone's state allows an incoming Video communication.
	 * 
	 * @param commType
	 *            The video communication.
	 * 
	 * @throws AnacomException
	 *             If the CellPhone's state does't allow an incoming Video
	 *             communication.
	 */
	public abstract void handleIncomingCommunication(Video commType)
			throws AnacomException;

	/**
	 * Checks if the CellPhone's state allows an incoming SMS communication.
	 * 
	 * @param commType
	 *            The video communication.
	 * 
	 * @throws AnacomException
	 *             If the CellPhone's state does't allow an incoming SMS
	 *             communication.
	 */
	public abstract void handleIncomingCommunication(SMS commType)
			throws AnacomException;

	/**
	 * Checks if the CellPhone's state allows an incoming Voice communication.
	 * 
	 * @param commType
	 *            The video communication.
	 * 
	 * @throws AnacomException
	 *             If the CellPhone's state does't allow an incoming Voice
	 *             communication.
	 */
	public abstract void handleIncomingCommunication(Voice commType)
			throws AnacomException;

	/**
	 * Checks if the CellPhone's state allows an outgoing Video communication.
	 * 
	 * @param commType
	 *            The video communication.
	 * 
	 * @throws AnacomException
	 *             If the CellPhone's state does't allow an incoming Video
	 *             communication.
	 */
	public abstract void handleOutgoingCommunication(Video commType)
			throws AnacomException;

	/**
	 * Checks if the CellPhone's state allows an outgoing SMS communication.
	 * 
	 * @param commType
	 *            The video communication.
	 * 
	 * @throws AnacomException
	 *             If the CellPhone's state does't allow an incoming SMS
	 *             communication.
	 */
	public abstract void handleOutgoingCommunication(SMS commType)
			throws AnacomException;

	/**
	 * Checks if the CellPhone's state allows an outgoing Voice communication.
	 * 
	 * @param commType
	 *            The video communication.
	 * 
	 * @throws AnacomException
	 *             If the CellPhone's state does't allow an incoming Voice
	 *             communication.
	 */
	public abstract void handleOutgoingCommunication(Voice commType)
			throws AnacomException;

	/**
	 * Change the CellPhone to On.
	 */
	public abstract void turnOn();

	/**
	 * Change the CellPhone to Off.
	 */
	public abstract void turnOff();

	/**
	 * Change the CellPhone to Silence.
	 */
	public abstract void turnSilence();

	/**
	 * Change the CellPhone to Busy.
	 */
	public abstract void turnBusy();
}
