/*-------------------------------------------------------------

Copyright (C) 2000 Peter Clote. 
All Rights Reserved.

Permission to use, copy, modify, and distribute this
software and its documentation for NON-COMMERCIAL purposes
and without fee is hereby granted provided that this
copyright notice appears in all copies.


THE AUTHOR AND PUBLISHER MAKE NO REPRESENTATIONS OR
WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED
BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
THIS SOFTWARE OR ITS DERIVATIVES.

-------------------------------------------------------------*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include "debug.h"
#include "timer.h"
#include "mpi.h"

#define N 12000         // size of protein arrays

#define AA 20           // number of amino acids
#define MAX2(x,y)     ((x)<(y) ? (y) : (x))
#define MAX3(x,y,z)   (MAX2(x,y)<(z) ? (z) : MAX2(x,y))

#define VAL(a, i, j, cols) (a[(i)*(cols) + (j)])

// Prototypes
short char2AA(char ch);
void readSequenceFile(const char *file, int *sequence);
void swap(int *array, int i, int j);

main(int argc, char *argv[]) {
    int *a, *b;
    int *h, *sim, delta;
    int nproc, rank;
    int j, i;
    MPI_Status status;
    int size;
    int numMessages = 1000;
    char sectionName[255];

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &nproc);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    srand(time(NULL));

    // Read input data
    a = (int*) malloc(sizeof(int) * N);

    if (rank == 0) {
        readSequenceFile("a_500k", a);
    }

    sscanf(argv[1], "%d", &size);

    if (rank == 0) {
        START_TIMER();
        sprintf(sectionName, "Size %d over %d messages", size, numMessages);
        START_TIMER_SECTION(sectionName);
        for (j = 0; j < numMessages; j++) {
            MPI_Send(a, size, MPI_INT, 1, 0, MPI_COMM_WORLD);
        }
        END_TIMER_SECTION();
        END_TIMER();
    } else {
        for (j = 0; j < numMessages; j++) {
            MPI_Recv(a, N, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        }
    }

    free(a);

    MPI_Finalize();

    return 0;
}

void readSequenceFile(const char *file, int *sequence) {
    FILE *fp = fopen(file, "r");
    int i;
    char ch;

    // Skip first line
    do {
        ch=fgetc(fp);
    } while (ch != '\n' && ch != '\r');	

    i = 0;
    while ((ch = fgetc(fp)) != EOF && (i + 1) < N) {
        // Skip over anything that isn't a character
        if (!isalpha(ch)) {
            continue;
        }

        sequence[++i] = char2AA(toupper(ch));
    }

    sequence[0] = i;

    fclose(fp);
}

short char2AA(char ch){
    switch (ch) {
        case 'C': return 0;
        case 'G': return 1;
        case 'P': return 2;
        case 'S': return 3;
        case 'A': return 4;
        case 'T': return 5;
        case 'D': return 6;
        case 'E': return 7;
        case 'N': return 8;
        case 'Q': return 9;
        case 'H': return 10;
        case 'K': return 11;
        case 'R': return 12;
        case 'V': return 13;
        case 'M': return 14;
        case 'I': return 15;
        case 'L': return 16;
        case 'F': return 17;
        case 'Y': return 18;
        case 'W': return 19;
        default: 
            error("Nonstandard amino acid code: %d %c\n", ch, ch);
    }
}

void swap(int *array, int i, int j) {
    int temp = array[i];
    array[i] = array[j];
    array[j] = temp;
}
