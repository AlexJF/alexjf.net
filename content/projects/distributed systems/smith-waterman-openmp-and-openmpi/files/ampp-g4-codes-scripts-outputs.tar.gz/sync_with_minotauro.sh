#! /bin/sh

rsync -ritl ../ampp ampp01004@mt1.bsc.es:
