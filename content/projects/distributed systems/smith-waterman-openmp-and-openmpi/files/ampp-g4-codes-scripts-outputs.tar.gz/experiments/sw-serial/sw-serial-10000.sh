#! /bin/bash
# @ job_name = sw-serial-10000
# @ initialdir = .
# @ output = sw-serial-10000.out
# @ error = sw-serial-10000.err
# @ total_tasks = 1
# @ tasks_per_node = 1
# @ wall_clock_limit = 0:5:0

for i in {1..5}
do
    srun ./sw-serial 10000
done
