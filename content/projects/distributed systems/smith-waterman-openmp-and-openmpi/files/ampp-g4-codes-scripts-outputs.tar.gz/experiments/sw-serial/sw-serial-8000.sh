#! /bin/bash
# @ job_name = sw-serial-8000
# @ initialdir = .
# @ output = sw-serial-8000.out
# @ error = sw-serial-8000.err
# @ total_tasks = 1
# @ tasks_per_node = 1
# @ wall_clock_limit = 0:5:0

for i in {1..5}
do
    srun ./sw-serial 8000
done
