#! /bin/bash
# @ job_name = sw-mpi-10-500-100-1
# @ initialdir = .
# @ output = sw-mpi-10-500-100-1.out
# @ error = sw-mpi-10-500-100-1.err
# @ total_tasks = 10
# @ tasks_per_node = 1
# @ wall_clock_limit = 0:5:0

for i in {1..5}
do
    srun ./sw-mpi 500 100 1
done
