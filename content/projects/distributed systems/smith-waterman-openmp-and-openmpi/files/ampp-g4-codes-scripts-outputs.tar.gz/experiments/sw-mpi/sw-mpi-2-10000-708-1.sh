#! /bin/bash
# @ job_name = sw-mpi-2-10000-708-1
# @ initialdir = .
# @ output = sw-mpi-2-10000-708-1.out
# @ error = sw-mpi-2-10000-708-1.err
# @ total_tasks = 2
# @ cpus_per_task = 1
# @ tasks_per_node = 1
# @ wall_clock_limit = 0:5:0

for i in {1..5}
do
    srun ./sw-mpi 10000 708 1
done
