#! /bin/bash
# @ job_name = sw-mpi-10000-625-1
# @ initialdir = .
# @ output = sw-mpi-10000-625-1.out
# @ error = sw-mpi-10000-625-1.err
# @ total_tasks = 5
# @ tasks_per_node = 1
# @ wall_clock_limit = 0:5:0

for i in {1..5}
do
    srun ./sw-mpi 10000 625 1
done
