#! /bin/bash
# @ job_name = sw-mpi-interleaved-10000-1000-20
# @ initialdir = .
# @ output = sw-mpi-interleaved-10000-1000-20.out
# @ error = sw-mpi-interleaved-10000-1000-20.err
# @ total_tasks = 5
# @ tasks_per_node = 1
# @ wall_clock_limit = 0:5:0

for i in {1..5}
do
    srun ./sw-mpi-interleaved 10000 1000 20
done
