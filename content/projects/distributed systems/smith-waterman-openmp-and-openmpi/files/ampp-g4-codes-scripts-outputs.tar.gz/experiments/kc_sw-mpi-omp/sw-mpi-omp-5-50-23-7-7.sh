#! /bin/bash
# @ job_name = sw-mpi-omp-5-50-23-7-7
# @ initialdir = .
# @ output = sw-mpi-omp-5-50-23-7-7.out
# @ error = sw-mpi-omp-5-50-23-7-7.err
# @ total_tasks = 25
# @ tasks_per_node = 5
# @ wall_clock_limit = 0:5:0

for i in {1..5}
do
    srun ./sw-mpi-omp 50 23 7 7
done
