#! /bin/bash
# @ job_name = sw-mpi-omp-5-8000-22-8-8
# @ initialdir = .
# @ output = sw-mpi-omp-5-8000-22-8-8.out
# @ error = sw-mpi-omp-5-8000-22-8-8.err
# @ total_tasks = 25
# @ tasks_per_node = 5
# @ wall_clock_limit = 0:5:0

for i in {1..5}
do
    srun ./sw-mpi-omp 8000 22 8 8
done
