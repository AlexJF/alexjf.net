#! /bin/bash
# @ job_name = sw-omp-5-23-8-5
# @ initialdir = .
# @ output = sw-omp-5-23-8-5.out
# @ error = sw-omp-5-23-8-5.err
# @ total_tasks = 5
# @ tasks_per_node = 5
# @ wall_clock_limit = 0:5:0

for i in {1..5}
do
    srun ./sw-omp 23 8 5
done
