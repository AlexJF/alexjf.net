from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import matplotlib.pyplot as plt
import numpy as np
from scipy import interpolate
import fileinput

RESOLUTION = 1000

xLabel = ""
yLabel = ""
xData = []
yData = []
customXLimits = [None, None]
customYLimits = [None, None]
polyfit = 0
showDataPoints = False

numLine = 0

for line in fileinput.input():
    if len(line) == 0 or line[0] == "#":
        continue
    label, sep, value = line.partition(":")
    if label == "d":
        xValue, sep, yValue = value.partition(" ")
        xData.append(float(xValue))
        yData.append(float(yValue))
    elif label == "xlabel":
        xLabel = value.strip()
    elif label == "ylabel":
        yLabel = value.strip()
    elif label == "xmin":
        customXLimits[0] = float(value)
    elif label == "xmax":
        customXLimits[1] = float(value)
    elif label == "ymin":
        customYLimits[0] = float(value)
    elif label == "ymax":
        customYLimits[1] = float(value)
    elif label == "polyfit":
        polyfit = int(value)
    elif label == "datapoints":
        showDataPoints = bool(value)
    numLine += 1

xMin = min(xData) if customXLimits[0] is None else customXLimits[0]
xMax = max(xData) if customXLimits[1] is None else customXLimits[1]
yMin = min(yData) if customYLimits[0] is None else customYLimits[0]
yMax = max(yData) if customYLimits[1] is None else customYLimits[1]

plt.figure()

legend = []

if polyfit > 0:
    z = np.polyfit(xData, yData, polyfit)
    p = np.poly1d(z)
    x = np.linspace(xMin, xMax, 1000)
    plt.plot(x, p(x),"r--")
    legend.append("%d-Poly fit\ny=%Ex+(%E)" % (polyfit, z[0], z[1]))

plt.plot(xData, yData, 'bx', xData, yData, 'b')
legend.append("Data")

if showDataPoints:
    for i in range(len(xData)):
        plt.annotate("(%.2f, %.2f)" % (xData[i], yData[i]), xy=(xData[i], yData[i]), xytext=(-10,0), textcoords='offset points')

if len(legend) > 1:
    plt.legend(legend, 'lower right')

plt.xlim(xMin, xMax)
plt.ylim(yMin, yMax)

plt.xlabel(xLabel)
plt.ylabel(yLabel)
plt.show()
