/*-------------------------------------------------------------

Copyright (C) 2000 Peter Clote. 
All Rights Reserved.

Permission to use, copy, modify, and distribute this
software and its documentation for NON-COMMERCIAL purposes
and without fee is hereby granted provided that this
copyright notice appears in all copies.


THE AUTHOR AND PUBLISHER MAKE NO REPRESENTATIONS OR
WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED
BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
THIS SOFTWARE OR ITS DERIVATIVES.

-------------------------------------------------------------*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "debug.h"
#include "timer.h"
#include <omp.h>

#define AA 20           // number of amino acids
#define MAX2(x,y)     ((x)<(y) ? (y) : (x))
#define MAX3(x,y,z)   (MAX2(x,y)<(z) ? (z) : MAX2(x,y))

#define VAL(a, i, j, cols) (a[(i)*(cols) + (j)])

#define VOID 0
#define CREATED 1
#define DONE 2

static int N = 5000;
static int BX = 100;
static int BY = 100;
static int NUM_BLOCKS_X = 0;
static int NUM_BLOCKS_Y = 0;

// Prototypes
short char2AA(char ch);
char AA2char(int aa);
void error(const char *message, ...);
void readPamFile(const char *file, int *pamMatrix);
void readSequenceFile(const char *file, short *sequence);
void computeBlock(short *a, short *b, int *h, int *sim, int delta, int
        iBlock, int jBlock, int nRowsInBlock, int nColumnsInBlock, short *block_status);
void printResult(short *a, short *b, int *h, int *sim, int delta);

main(int argc, char *argv[]) {
    short *a, *b;
    int *h, *sim, delta;
    short *block_status;
    int i;

    if (argc > 1) {
        sscanf(argv[1], "%d", &N);
    }

    if (argc > 2) {
        sscanf(argv[2], "%d", &BX);
    }

    if (argc > 3) {
        sscanf(argv[3], "%d", &BY);
    }

    NUM_BLOCKS_X = (N - 1) / BX;
    NUM_BLOCKS_Y = (N - 1) / BX;

    // Read input data
    a = (short*) malloc(sizeof(short) * N);
    readSequenceFile("a_500k", a);
    b = (short*) malloc(sizeof(short) * N);
    readSequenceFile("b_500k", b);
    sim = (int*) malloc(sizeof(int) * AA * AA);
    readPamFile("data.score", sim);
    delta = 3;

    h = (int*) malloc(sizeof(int) * N * N);
    memset(h, 0, sizeof(int) * N * N);
    block_status = (short *) malloc(sizeof(short) * NUM_BLOCKS_X * NUM_BLOCKS_Y);
    memset(block_status, VOID, sizeof(short) * NUM_BLOCKS_X * NUM_BLOCKS_Y);

    int nRowsInBlock = NUM_BLOCKS_Y > 1 ? BY : N - 1;
    int nColumnsInBlock = NUM_BLOCKS_X > 1 ? BX : N - 1;
    START_TIMER();
#pragma omp parallel
    {
#pragma omp single 
        computeBlock(a, b, h, sim, delta, 0, 0, nRowsInBlock, nColumnsInBlock, block_status);
    }
    END_TIMER();

    DEBUG_PRINTINTARRAY(h, N, N);
    printResult(a, b, h, sim, delta);

    free(a);
    free(b);
    free(h);
    free(sim);
    free(block_status);

    return 0;
}

void error(const char *format, ...) {
    va_list argp;
    va_start(argp, format);
    vfprintf(stderr, format, argp);
    exit(1);
}

short char2AA(char ch){
    switch (ch) {
        case 'C': return 0;
        case 'G': return 1;
        case 'P': return 2;
        case 'S': return 3;
        case 'A': return 4;
        case 'T': return 5;
        case 'D': return 6;
        case 'E': return 7;
        case 'N': return 8;
        case 'Q': return 9;
        case 'H': return 10;
        case 'K': return 11;
        case 'R': return 12;
        case 'V': return 13;
        case 'M': return 14;
        case 'I': return 15;
        case 'L': return 16;
        case 'F': return 17;
        case 'Y': return 18;
        case 'W': return 19;
        default: 
            error("Nonstandard amino acid code: %d %c\n", ch, ch);
    }
}

char AA2char(int x){
    switch (x) {
        case 0 : return 'C';
        case 1 : return 'G';
        case 2 : return 'P';
        case 3 : return 'S';
        case 4 : return 'A';
        case 5 : return 'T';
        case 6 : return 'D';
        case 7 : return 'E';
        case 8 : return 'N';
        case 9 : return 'Q';
        case 10: return 'H';
        case 11: return 'K';
        case 12: return 'R';
        case 13: return 'V';
        case 14: return 'M';
        case 15: return 'I';
        case 16: return 'L';
        case 17: return 'F';
        case 18: return 'Y';
        case 19: return 'W';
        default: 
            error("Bad integer representation of AA: %d\n", x);
    }
}

void readSequenceFile(const char *file, short *sequence) {
    FILE *fp = fopen(file, "r");
    int i;
    char ch;

    // Skip first line
    do {
        ch=fgetc(fp);
    } while (ch != '\n' && ch != '\r');	

    i = 0;
    while ((ch = fgetc(fp)) != EOF && (i + 1) < N) {
        // Skip over anything that isn't a character
        if (!isalpha(ch)) {
            continue;
        }

        sequence[++i] = char2AA(toupper(ch));
    }

    sequence[0] = i;

    fclose(fp);
}

void readPamFile(const char *file, int *pamMatrix) {
    FILE *fp = fopen(file, "r");
    int i, j;
    int value;

    // Ignore first line with amino acids header
    fscanf(fp,"%*s"); 

    for (i = 0; i < AA; i++) {
        for (j = 0 ; j <= i; j++) {
            if (fscanf(fp, "%d ", &value) == EOF) {
                fclose(fp);
                error("[Pam reading] Unexpected error while trying to read int\n");
            }

            VAL(pamMatrix, i, j, AA) = value;
        }
    }

    fclose(fp);

    // Simmetrify
    for (i = 0; i < AA; i++) {
        for (j = i + 1; j < AA; j++) {
            VAL(pamMatrix, i, j, AA) = VAL(pamMatrix, j, i, AA);
        }
    }
}

void computeBlock(short *a, short *b, int *h, int *sim, int delta, int
        iBlock, int jBlock, int nRowsInBlock, int nColumnsInBlock,
        short *block_status) {
    int i, j, diag, down, right, max = 0;

    int blockStartRow = iBlock * BY + 1;
    int blockEndRow = blockStartRow + nRowsInBlock - 1;
    int blockStartCol = jBlock * BX + 1;
    int blockEndCol = blockStartCol + nColumnsInBlock - 1;
    
    DEBUG_PRINT("Entered ComputeBlock\n");
    DEBUG_PRINT("blockStartRow = %d\n", blockStartRow);
    DEBUG_PRINT("blockEndRow = %d\n", blockEndRow);
    DEBUG_PRINT("blockStartCol = %d\n", blockStartCol);
    DEBUG_PRINT("blockEndCol = %d\n", blockEndCol);

    // START PARALLELIZATION
    for (i = blockStartRow; i <= blockEndRow; i++) {
        for (j = blockStartCol; j <= blockEndCol; j++) {
            diag = VAL(h, i - 1, j - 1, N) + VAL(sim, a[i], b[j], AA);
            down = VAL(h, i - 1, j, N) + delta;
            right = VAL(h, i, j - 1, N) + delta;

            max=MAX3(diag,down,right);

            if (max <= 0)  {
                VAL(h, i, j, N) = 0;
            }
            else {
                VAL(h, i, j, N) = max;
            }
        }
    }

    DEBUG_PRINTINTARRAY(h, N, N);
    #pragma omp critical 
    {
    VAL(block_status, iBlock, jBlock, NUM_BLOCKS_X) = DONE;
    }
    DEBUG_PRINT("Left ComputeBlock\n");

    // Check if we need to start right block
    if (jBlock + 1 < NUM_BLOCKS_X) {
        short prevVerticalBlockStatus = DONE;

        if (iBlock - 1 >= 0) {
            prevVerticalBlockStatus = VAL(block_status, iBlock - 1, jBlock + 1, NUM_BLOCKS_X);
        }

        if (prevVerticalBlockStatus == DONE) {
            short rightBlockStatus;

            #pragma omp critical
            {
                rightBlockStatus = VAL(block_status, iBlock, jBlock + 1, NUM_BLOCKS_X);
                if (rightBlockStatus == VOID) {
                    VAL(block_status, iBlock, jBlock + 1, NUM_BLOCKS_X) = CREATED;
                }
            }

            if (rightBlockStatus == VOID) {
                int newNColumnsInBlock = nColumnsInBlock;

                if (jBlock + 1 == NUM_BLOCKS_X - 1) {
                    newNColumnsInBlock += (N - 1) % BX;
                }

                #pragma omp task
                computeBlock(a, b, h, sim, delta, iBlock, jBlock + 1, 
                        nRowsInBlock, newNColumnsInBlock, block_status);
            }
        }
    }

    // Check if we need to start block below
    if (iBlock + 1 < NUM_BLOCKS_Y) {
        short prevHorizontalBlockStatus = DONE;

        if (jBlock - 1 >= 0) {
            prevHorizontalBlockStatus = VAL(block_status, iBlock + 1, jBlock - 1, NUM_BLOCKS_X);
        }

        if (prevHorizontalBlockStatus == DONE) {
            short belowBlockStatus;

            #pragma omp critical
            {
                belowBlockStatus = VAL(block_status, iBlock + 1, jBlock, NUM_BLOCKS_X);
                if (belowBlockStatus == VOID) {
                    VAL(block_status, iBlock + 1, jBlock, NUM_BLOCKS_X) = CREATED;
                }
            }

            if (belowBlockStatus == VOID) {
                int newNRowsInBlock = nRowsInBlock;

                if (iBlock + 1 == NUM_BLOCKS_Y - 1) {
                    newNRowsInBlock += (N - 1) % BY;
                }

                #pragma omp task
                computeBlock(a, b, h, sim, delta, iBlock + 1, jBlock, 
                        newNRowsInBlock, nColumnsInBlock, block_status);
            }
        }
    }
}

void printResult(short *a, short *b, int *h, int *sim, int delta) {
    char *aout, *bout;
    int Max, xMax, yMax, max;
    int i, j;
    int x, y;
    int topskip, bottomskip;
    int tempi, tempj;
    int diag, down, right;
    int *xTraceback, *yTraceback;

    aout = (char *) malloc(sizeof(char) * 2 * N);
    memset(aout, 0, sizeof(char) * 2 * N);
    bout = (char *) malloc(sizeof(char) * 2 * N);
    memset(bout, 0, sizeof(char) * 2 * N);

    xTraceback = (int *) malloc(sizeof(int) * N * N);
    yTraceback = (int *) malloc(sizeof(int) * N * N);

    // Initialize traceback arrays
    for (i = 0; i <= a[0]; i++) {
        for (j = 0; j <= b[0]; j++) {
            VAL(xTraceback, i, j, N) = -1;
            VAL(yTraceback, i, j, N) = -1;
        }
    }

    // Find maximum calculated value
    Max = xMax = yMax = 0;
    for (i = 1; i <= a[0]; i++) {
        for (j = 1; j <= b[0]; j++) {
            diag = VAL(h, i - 1, j - 1, N) + VAL(sim, a[i], b[j], AA);
            down = VAL(h, i - 1, j, N) + delta;
            right = VAL(h, i, j - 1, N) + delta;

            max = MAX3(diag,down,right);

            if (max == diag) {
                VAL(xTraceback, i, j, N) = i - 1;
                VAL(yTraceback, i, j, N) = j - 1;
            }
            else if (max == down) {
                VAL(xTraceback, i, j, N) = i - 1;
                VAL(yTraceback, i, j, N) = j;
            }
            else if (max == right) {
                VAL(xTraceback, i, j, N) = i;
                VAL(yTraceback, i, j, N) = j - 1;
            }
            
            if (max > Max) {
                Max = max;
                xMax = i;
                yMax = j;
            }
        }
    }

    // reset to max point to do alignment
    i = xMax; j = yMax;
    x = y = 0;
    topskip = bottomskip = 1;
    while (i > 0 && j > 0 && VAL(h, i, j, N) > 0){
        if (topskip && bottomskip) {
            aout[x++] = AA2char(a[i]);
            bout[y++] = AA2char(b[j]);
        }
        else if (topskip) {
            aout[x++] = '-';
            bout[y++] = AA2char(b[j]);
        }
        else if (bottomskip) {
            aout[x++] = AA2char(a[i]);
            bout[y++] = '-';
        }
        topskip = (j > VAL(yTraceback, i, j, N));
        bottomskip = (i > VAL(xTraceback, i, j, N));
        tempi = i; 
        tempj = j;
        i = VAL(xTraceback, tempi, tempj, N);
        j = VAL(yTraceback, tempi, tempj, N);
    }

    printf("\n");
    printf("\n");
    for (i= x - 1; i >= 0 ;i--) printf("%c", aout[i]);	
    printf("\n");
    for (j= y - 1; j>=0; j--) printf("%c", bout[j]);	
    printf("\n");
    printf("\n");

    free(aout);
    free(bout);
    free(xTraceback);
    free(yTraceback);
}

