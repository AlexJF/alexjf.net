#! /bin/sh

rsync -ritl ampp01004@mt1.bsc.es:ampp/experiments ./
