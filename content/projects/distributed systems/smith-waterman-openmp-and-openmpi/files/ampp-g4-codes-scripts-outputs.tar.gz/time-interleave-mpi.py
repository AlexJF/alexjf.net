from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import matplotlib.pyplot as plt
import numpy as np
import sys

numSteps = 50

N = 10000.
P = 5.
C = 1.819719166e-8
W = 3.65e-9
S = 9.116667e-6
S = 9.11e-3
B = None
I = None

tInitial = 3 * S * np.log(P) + W * (N**2/P + N/P)*(P-1) + \
           W * N * np.log(P)

def time(B, I):
    X = 0
    Y = 0

    if P >= N / B or I == 1:
        Y = N / B
        X = P
    else:
        Y = P
        X = N / B

    return tInitial + \
            N/(P*I)*B*C*(I*X+Y) + \
            (S + B * W) * (I * X + Y)

vfunc = np.vectorize(time)

fig = plt.figure()
if len(sys.argv) > 1 and sys.argv[1] != '?':
    B = int(sys.argv[1])
if len(sys.argv) > 2 and sys.argv[2] != '?':
    I = int(sys.argv[2])

if B is None and I is None:
    plot = sys.argv[3] == "plot" if len(sys.argv) > 3 else False

    if not plot:
        B = np.arange(1., N / 2, 1.)
        I = np.arange(1., N/P, 1.)
    else:
        B = np.linspace(1, N, numSteps)
        I = np.linspace(1, N/P, numSteps)

    #B = np.linspace(2, N, numSteps)
    #I = np.linspace(1., 20., numSteps)

    B, I = np.meshgrid(B, I)
    T = vfunc(B, I)

    minT = -1
    minimums = []
    for index, t in np.ndenumerate(T):
        if t < minT or minT == -1:
            minT = t
            minimums = [index]
        elif t == minT:
            minimums.append(index)

    print(minT)

    for m in minimums:
        print("(%f, %f) - %f" % (B[m[0]][m[1]], I[m[0]][m[1]], T[m[0]][m[1]]))

    if plot:
        ax = fig.gca(projection='3d')
        surf = ax.plot_surface(B, I, T, rstride=1, cstride=1, cmap=cm.jet,
                linewidth=0, antialiased=True)
        ax.zaxis.set_major_locator(LinearLocator(10))
        ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

        ax.set_xlabel(r'B')
        ax.set_ylabel(r'I')
        ax.set_zlabel(r'T')

        fig.colorbar(surf, shrink=0.5, aspect=5)

        plt.show()

else:
    if B is None:
        B = np.arange(1., N, 1.)
        T = vfunc(B, I)
        plt.plot(B, T)
        plt.xlabel("B")
        plt.ylabel("T")
        minB = T.argmin()
        print("Min: B = %f, T = %f" % (B[minB], T[minB]))
        plt.plot(B[minB], T[minB], 'bx')
        plt.annotate("(%.2f, %.2f)" % (B[minB], T[minB]), xy=(B[minB],
            T[minB]), xytext=(5,-5), textcoords='offset points')
        plt.show()
    elif I is None:
        I = np.arange(1., N/P, 1.)
        T = vfunc(B, I)
        plt.plot(I, T)
        plt.xlabel("I")
        plt.ylabel("T")
        minI = T.argmin()
        print("Min: I = %f, T = %f" % (I[minI], T[minI]))
        plt.show()
    else:
        T = vfunc(B, I)
        print("Time: %f" % (T))
