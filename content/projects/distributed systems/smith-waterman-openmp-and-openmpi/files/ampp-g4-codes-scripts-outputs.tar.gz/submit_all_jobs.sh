#! /bin/sh

find . -name "*.sh" -exec mnsubmit \{\} \;
