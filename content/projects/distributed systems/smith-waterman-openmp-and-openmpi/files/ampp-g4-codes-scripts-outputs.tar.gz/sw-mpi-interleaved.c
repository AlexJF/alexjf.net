/*-------------------------------------------------------------

Copyright (C) 2000 Peter Clote. 
All Rights Reserved.

Permission to use, copy, modify, and distribute this
software and its documentation for NON-COMMERCIAL purposes
and without fee is hereby granted provided that this
copyright notice appears in all copies.


THE AUTHOR AND PUBLISHER MAKE NO REPRESENTATIONS OR
WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHORS
AND PUBLISHER SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED
BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
THIS SOFTWARE OR ITS DERIVATIVES.

-------------------------------------------------------------*/


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "mpi.h"
#include "debug.h"
#include "timer.h"

#define AA 20           // number of amino acids

#define MIN(x, y)     ((x)<(y) ? (x) : (y))
#define MAX2(x,y)     ((x)<(y) ? (y) : (x))
#define MAX3(x,y,z)   (MAX2(x,y)<(z) ? (z) : MAX2(x,y))

#define VAL(a, i, j, cols) (a[(i)*(cols) + (j)])
#define CEILDIV(x, y) (((x) % (y)) ? (x) / (y) + 1 : (x) / (y))

static int N = 5000;
static int B = 200;
static int I = 2;

// Prototypes
short char2AA(char ch);
char AA2char(int aa);
void error(const char *message, ...);
void readPamFile(const char *file, int *pamMatrix);
void readSequenceFile(const char *file, short *sequence);
void computeBlock(short *a, short *b, int *h, int *sim, int delta, int
        iBlock, int startingRow, int nRowsInBlock, int nColumnsInBlock, int colsH,
        int rowsSkipped);
void printResult(short *a, short *b, int *h, int *sim, int delta);

void reorder_interleave(void *in, void *out, int elemBytes, int *numRowsNodeIsResponsibleFor, int numRowsPerPart, int numCols, int nproc);
void reorder_interleave_inverse(void *in, void *out, int elemBytes, int *numRowsNodeIsResponsibleFor, int numRowsPerPart, int numCols, int nproc);
void remove_intermediate_rows(int *h, int numRowsResponsibleFor, int numRowsPerPart, 
        int numColsPerRow,
        int numPartsResponsibleFor);

main(int argc, char *argv[]) {
    short *a, *a_reordered, *b;
    short *localA;
    int *h, *h_reordered;
    int *localH;
    int *sim;
    int delta;
    int nproc, rank;
    int *displs;
    int *counts;
    int i;
    int sizes[2];
    int iPart, iBlock;
    int rowsMissing;
    int rowsH, colsH;
    MPI_Status status;
    int numRowsPerNode, numPartsPerNode, numRowsPerPart, numTotalParts,
        numMissingRows, numMissingParts, numRowsImResponsibleFor, numPartsImResponsibleFor,
        *numRowsNodeIsResponsibleFor, numBlocksPerPart;
    int currentRow, startJBlock;
    int maxParts;

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &nproc);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (argc > 1) {
        sscanf(argv[1], "%d", &N);
    }

    if (argc > 2) {
        sscanf(argv[2], "%d", &B);
    }

    if (argc > 3) {
        sscanf(argv[3], "%d", &I);
    }

    if (I > (N - 1) / nproc) {
        printf("I must be less or equal to N / P\n");
        return 1;
    }

    if (B > (N - 1)) {
        printf("B cannot be greather than N\n");
        return 1;
    }

    DEBUG_PRINT("nproc = %d\n", nproc);

    b = (short*) malloc(sizeof(short) * N);
    sim = (int*) malloc(sizeof(int) * AA * AA);

    if (rank == 0) {
        // Read input data
        a = (short*) malloc(sizeof(short) * N);
        a_reordered = (short*) malloc(sizeof(short) * N);
        readSequenceFile("a_500k", a);
        readSequenceFile("b_500k", b);
        readPamFile("data.score", sim);
        delta = 3;
        h = (int*) malloc(sizeof(int) * N * N);
    }

    MPI_Bcast(&delta, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(sim, AA*AA, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        sizes[0] = a[0];
        sizes[1] = b[0];
    }

    MPI_Bcast(sizes, 2, MPI_INT, 0, MPI_COMM_WORLD);
    DEBUG_PRINT("sizes = (%d, %d)\n", sizes[0], sizes[1]);

    displs = (int *) malloc(nproc * sizeof(int));
    counts = (int *) malloc(nproc * sizeof(int));
    numRowsNodeIsResponsibleFor = (int *) malloc(nproc * sizeof(int));

    numRowsPerNode = sizes[0] / nproc;
    numPartsPerNode = I;
    numRowsPerPart = numRowsPerNode / I;
    numTotalParts = nproc * I;
    numMissingRows = numRowsPerNode * nproc - numTotalParts * numRowsPerPart;
    numMissingParts = CEILDIV(numMissingRows, numRowsPerPart);

    DEBUG_PRINT("numRowsPerNode = %d\n", numRowsPerNode);
    DEBUG_PRINT("numPartsPerNode = %d\n", numPartsPerNode);
    DEBUG_PRINT("numRowsPerPart = %d\n", numRowsPerPart);
    DEBUG_PRINT("numTotalParts = %d\n", numTotalParts);
    DEBUG_PRINT("numMissingRows = %d\n", numMissingRows);
    DEBUG_PRINT("numMissingParts = %d\n", numMissingParts);

    // Calculate maximum number of parts any node is responsible for
    // and numRows each node is responsible for
    maxParts = 0;
    for (i = 0; i < nproc; i++) {
        int numPartsResponsibleFor;
        numRowsNodeIsResponsibleFor[i] = numPartsPerNode * numRowsPerPart;

        if (i < numMissingParts - 1) {
            numRowsNodeIsResponsibleFor[i] += numRowsPerPart;
        }
        else if (i == numMissingParts - 1) {
            numRowsNodeIsResponsibleFor[i] += numMissingRows - i * numRowsPerPart;
        }
        
        numPartsResponsibleFor = CEILDIV(numRowsNodeIsResponsibleFor[i], numRowsPerPart);
        
        if (numPartsResponsibleFor > maxParts) {
            maxParts = numPartsResponsibleFor;
        }
    }

    DEBUG_PRINTINTARRAY(numRowsNodeIsResponsibleFor, nproc, 1);

    // What am I responsible for?
    numRowsImResponsibleFor = numRowsNodeIsResponsibleFor[rank];
    numPartsImResponsibleFor = CEILDIV(numRowsImResponsibleFor, numRowsPerPart);
    
    DEBUG_PRINT("numRowsImResponsibleFor = %d\n", numRowsImResponsibleFor);
    DEBUG_PRINT("numPartsImResponsibleFor = %d\n", numPartsImResponsibleFor);

    // Create local A and H
    localA = (short *) malloc((numRowsImResponsibleFor + 1) * sizeof(short));
    rowsH = numRowsImResponsibleFor + numPartsImResponsibleFor;
    colsH = sizes[1] + 1;
    localH = (int *) malloc(rowsH * colsH * sizeof(int));

    for (i = 0; i < rowsH * colsH; i++) {
        localH[i] = -1;
    }

    if (rank == 0) {
        for (i = 0; i <= sizes[1]; i++) localH[i] = 0;
    }

    for (i = 0; i < rowsH; i++) VAL(localH, i, 0, colsH) = 0;

    START_TIMER();
    // Reorder a to facilitate scattering because of interleave
    // MPI_Scatterv doesn't support multiple areas per node so put all areas
    // of a node together (later we'll have to undo this)
    if (rank == 0) {
        DEBUG_PRINT("a = \n");
        DEBUG_PRINTSHORTARRAY(a, 1, N);
        reorder_interleave(a + 1, a_reordered + 1, sizeof(short), numRowsNodeIsResponsibleFor, numRowsPerPart, 1, nproc);
        a_reordered[0] = a[0];
        DEBUG_PRINT("a_reordered = \n");
        DEBUG_PRINTSHORTARRAY(a_reordered, 1, N);
    }

    START_TIMER_SECTION("Scatter A");
    for (i = 0, currentRow = 1; i < nproc; i++) {
        displs[i] = currentRow;
        counts[i] = numRowsNodeIsResponsibleFor[i];
        currentRow += numRowsNodeIsResponsibleFor[i];
    }

    DEBUG_PRINT("Scattering A\n");
    MPI_Scatterv(a_reordered, counts, displs, MPI_SHORT, localA + 1, numRowsImResponsibleFor, MPI_SHORT, 0, MPI_COMM_WORLD);
    localA[0] = numRowsImResponsibleFor;

    DEBUG_PRINT("localA = \n");
    DEBUG_PRINTSHORTARRAY(localA, 1, numRowsImResponsibleFor + 1);

    DEBUG_PRINT("Broadcasting B\n");
    START_TIMER_SECTION("Bcast B");
    MPI_Bcast(b + 1, sizes[1], MPI_SHORT, 0, MPI_COMM_WORLD);
    b[0] = sizes[1]; // just broadcast the whole b instead?
    
    numBlocksPerPart = sizes[1] / B;
    END_TIMER_SECTION();
    DEBUG_PRINT("numBlocksPerPart = %d\n", numBlocksPerPart);

    DEBUG_PRINT("Start of computation\n");

    START_TIMER_SECTION("Computation");
    // Consider column partitions of up to nproc blocks, one partition at a
    // time
    for (startJBlock = 0; startJBlock < numBlocksPerPart; startJBlock += nproc) {
        int numBlocksInIteration = MIN(nproc, numBlocksPerPart - startJBlock);
        DEBUG_PRINT("%d - startJBlock = %d\n", rank, startJBlock);
        DEBUG_PRINT("numBlocksInIteration = %d\n", numBlocksInIteration);

        // For each vertical part in the partition (set of consecutive rows a
        // process is responsible for)
        for (iPart = 0; iPart < numPartsImResponsibleFor; iPart++) {
            int startingRow = iPart * (numRowsPerPart + 1);
            int numRowsInPart = MIN(numRowsPerPart, numRowsImResponsibleFor - iPart * numRowsPerPart);
            int endingRow = startingRow + numRowsInPart;
            DEBUG_PRINT("rank = %d\n", rank);
            DEBUG_PRINT("iPart = %d\n", iPart);
            DEBUG_PRINT("startingRow = %d\n", startingRow);
            DEBUG_PRINT("numRowsInPart = %d\n", numRowsInPart);
            DEBUG_PRINT("endingRow = %d\n", endingRow);

            // Compute blocks of that part
            for (iBlock = startJBlock; iBlock < startJBlock + numBlocksInIteration; iBlock++) {
                int nColumnsInBlock;
                int blockStart = iBlock * B;

                DEBUG_PRINT("%d - iBlock = %d\n", rank, iBlock);

                // We should wait for the row from the previous node either if
                // we have a rank > 0 or if we have rank == 0 and are computing
                // a part different from the first 1 (where there is no
                // dependency)
                if (rank > 0 || iPart > 0) {
                    DEBUG_PRINT("%d - Waiting for block border from previous process\n", rank);
                    DEBUG_PRINT("%d - Waiting in iBlock = %d, iPart = %d, startJBlock = %d\n",
                            rank, iBlock, iPart, startJBlock);
                    int senderRank = (rank > 0) ? rank - 1 : (rank + nproc - 1) % nproc;
                    MPI_Recv(&VAL(localH, startingRow, blockStart + 1, colsH), 2*B, MPI_INT, senderRank, iBlock, MPI_COMM_WORLD, &status);
                    MPI_Get_count(&status, MPI_INT, &nColumnsInBlock);
                    DEBUG_PRINT("%d - Received block border from previous process\n", rank);
                    DEBUG_PRINTINTARRAY(localH, rowsH, colsH);
                } else {
                    if (iBlock == numBlocksPerPart - 1) {
                        nColumnsInBlock = B + sizes[1] - B * numBlocksPerPart;
                    } else {
                        nColumnsInBlock = B;
                    }
                }

                DEBUG_PRINT("blockStart = %d\n", blockStart);
                DEBUG_PRINT("nColumnsInBlock = %d\n", nColumnsInBlock);

                computeBlock(localA, b, localH, sim, delta, iBlock, startingRow, numRowsInPart, nColumnsInBlock, colsH, iPart);

                DEBUG_PRINTINTARRAY(localH, rowsH, colsH);

                // Sending only if our succeeding process need the info
                int receiverRank = (rank + 1) % nproc;
                int numRowsReceiverResponsibleFor = numRowsNodeIsResponsibleFor[receiverRank];
                int numPartsReceiverResponsibleFor = CEILDIV(numRowsReceiverResponsibleFor, numRowsPerPart);
                short extra = 0;
                // If we are the last node, next part will be iPart + 1
                if (rank == nproc - 1) {
                    extra = 1;
                }
                if (iPart + extra < numPartsReceiverResponsibleFor) {
                    DEBUG_PRINT("%d - Sending block border to next process\n", rank);
                    MPI_Send(&VAL(localH, endingRow, blockStart + 1, colsH), nColumnsInBlock, MPI_INT, receiverRank, iBlock, MPI_COMM_WORLD);
                    DEBUG_PRINT("%d - Sent block border to next process\n", rank);
                }
            }
        }
    }

    START_TIMER_SECTION("Gather V");
    // Remove intermediate rows of the h matrix that correspond to rows
    // received from other nodes (we can let the first node be there since
    // we'll just skip it on the gather).
    DEBUG_PRINT("localH (before removal of intermediate rows) =\n");
    DEBUG_PRINTINTARRAY(localH, rowsH, colsH);
    remove_intermediate_rows(localH, numRowsImResponsibleFor, numRowsPerPart, colsH, numPartsImResponsibleFor);
    DEBUG_PRINT("\n");
    DEBUG_PRINT("localH (after removal of intermediate rows) =\n");
    DEBUG_PRINTINTARRAY(localH, rowsH, colsH);

    DEBUG_PRINT("Starting displacement and count calculation\n");
    // Send all rows of the localH matrix besides the first.
    for (i = 0, currentRow = 1; i < nproc; i++) {
        DEBUG_PRINT("i = %d\n", i);
        DEBUG_PRINT("currentRow = %d\n", currentRow);
        displs[i] = currentRow * colsH;
        counts[i] = numRowsNodeIsResponsibleFor[i] * colsH;
        currentRow += numRowsNodeIsResponsibleFor[i];
    }

    DEBUG_PRINTINTARRAY(displs, 1, nproc);
    DEBUG_PRINTINTARRAY(counts, 1, nproc);

    if (rank == 0) {
        h_reordered = (int *) malloc(sizeof(int) * N * N);
    }

    MPI_Gatherv(&VAL(localH, 1, 0, colsH), numRowsImResponsibleFor * colsH, MPI_INT, h_reordered, counts, displs, MPI_INT, 0, MPI_COMM_WORLD);

    // Return h to natural order (was shuffled because of the a reordering at
    // the beginning)
    if (rank == 0) {
        DEBUG_PRINT("h_reordered =\n");
        DEBUG_PRINTINTARRAY(h_reordered, N, N);
        reorder_interleave_inverse(h_reordered + N, h + N, sizeof(int), numRowsNodeIsResponsibleFor, numRowsPerPart, colsH, nproc);
    }
    
    if (rank == 0) {
        for (i = 0; i < colsH; i++) {
            VAL(h, 0, i, N) = 0;
            VAL(h, i, 0, N) = 0;
        }
        END_TIMER_SECTION();
    } else {
        END_TIMER_SECTION();
    }

    // Just make root do what was missing (in case N wasn't a multiple of P)
    rowsMissing = sizes[0] - numRowsPerNode * nproc;
    DEBUG_PRINT("rowsMissing = %d\n", rowsMissing);
    if (rank == 0 && rowsMissing) {
        START_TIMER_SECTION("Compute missing rows");
        computeBlock(a, b, (int*) h, sim, delta, 0, numRowsPerNode * nproc, rowsMissing, sizes[1], colsH, 0);
        END_TIMER_SECTION();
    }
    END_TIMER();

    if (rank == 0) {
        DEBUG_PRINT("h:\n");
        DEBUG_PRINTINTARRAY(h, N, N);
        printResult(a, b, h, sim, delta);
    }

    MPI_Finalize();

    free(numRowsNodeIsResponsibleFor);
    free(displs);
    free(counts);
    free(localA);
    free(localH);
    free(sim);

    if (rank == 0) {
        free(a_reordered);
        free(h_reordered);
        free(a);
        free(b);
        free(h);
    }

    return 0;
}

void error(const char *format, ...) {
    va_list argp;
    va_start(argp, format);
    vfprintf(stderr, format, argp);
    exit(1);
}

short char2AA(char ch){
    switch (ch) {
        case 'C': return 0;
        case 'G': return 1;
        case 'P': return 2;
        case 'S': return 3;
        case 'A': return 4;
        case 'T': return 5;
        case 'D': return 6;
        case 'E': return 7;
        case 'N': return 8;
        case 'Q': return 9;
        case 'H': return 10;
        case 'K': return 11;
        case 'R': return 12;
        case 'V': return 13;
        case 'M': return 14;
        case 'I': return 15;
        case 'L': return 16;
        case 'F': return 17;
        case 'Y': return 18;
        case 'W': return 19;
        default: 
            error("Nonstandard amino acid code: %d %c\n", ch, ch);
    }
}

char AA2char(int x){
    switch (x) {
        case 0 : return 'C';
        case 1 : return 'G';
        case 2 : return 'P';
        case 3 : return 'S';
        case 4 : return 'A';
        case 5 : return 'T';
        case 6 : return 'D';
        case 7 : return 'E';
        case 8 : return 'N';
        case 9 : return 'Q';
        case 10: return 'H';
        case 11: return 'K';
        case 12: return 'R';
        case 13: return 'V';
        case 14: return 'M';
        case 15: return 'I';
        case 16: return 'L';
        case 17: return 'F';
        case 18: return 'Y';
        case 19: return 'W';
        default: 
            error("Bad integer representation of AA: %d\n", x);
    }
}

void readSequenceFile(const char *file, short *sequence) {
    FILE *fp = fopen(file, "r");
    int i;
    char ch;

    // Skip first line
    do {
        ch=fgetc(fp);
    } while (ch != '\n' && ch != '\r');	

    i = 0;
    while ((ch = fgetc(fp)) != EOF && (i + 1) < N) {
        // Skip over anything that isn't a character
        if (!isalpha(ch)) {
            continue;
        }

        sequence[++i] = char2AA(toupper(ch));
    }

    sequence[0] = i;

    fclose(fp);
}

void readPamFile(const char *file, int *pamMatrix) {
    FILE *fp = fopen(file, "r");
    int i, j;
    int value;

    // Ignore first line with amino acids header
    fscanf(fp,"%*s"); 

    for (i = 0; i < AA; i++) {
        for (j = 0 ; j <= i; j++) {
            if (fscanf(fp, "%d ", &value) == EOF) {
                fclose(fp);
                error("[Pam reading] Unexpected error while trying to read int\n");
            }

            VAL(pamMatrix, i, j, AA) = value;
        }
    }

    fclose(fp);

    // Simmetrify
    for (i = 0; i < AA; i++) {
        for (j = i + 1; j < AA; j++) {
            VAL(pamMatrix, i, j, AA) = VAL(pamMatrix, j, i, AA);
        }
    }
}

void computeBlock(short *a, short *b, int *h, int *sim, int delta, int
        iBlock, int startingRow, int nRowsInBlock, int nColumnsInBlock, int colsH,
        int rowsSkipped) {
    int i, j, diag, down, right, max = 0;
    int blockStartRow = startingRow + 1;
    int blockEndRow = startingRow + nRowsInBlock;
    int blockStartCol = iBlock * B + 1;
    int blockEndCol = blockStartCol + nColumnsInBlock - 1;

    DEBUG_PRINT("Entered ComputeBlock\n");
    DEBUG_PRINT("blockStartRow = %d\n", blockStartRow);
    DEBUG_PRINT("blockEndRow = %d\n", blockEndRow);
    DEBUG_PRINT("blockStartCol = %d\n", blockStartCol);
    DEBUG_PRINT("blockEndCol = %d\n", blockEndCol);

    // START PARALLELIZATION
    for (i = blockStartRow; i <= blockEndRow; i++) {
        for (j = blockStartCol; j <= blockEndCol; j++) {
            // We have to subtract rowsSkipped from i when indexing a because
            // there can now be intermediate rows to hold the borders sent by
            // other processes and if we don't consider this, a[i] WILL go over
            // the allocated space
            diag = VAL(h, i - 1, j - 1, colsH) + VAL(sim, a[i - rowsSkipped], b[j], AA);
            down = VAL(h, i - 1, j, colsH) + delta;
            right = VAL(h, i, j - 1, colsH) + delta;

            max=MAX3(diag,down,right);

            if (max <= 0)  {
                VAL(h, i, j, colsH) = 0;
            }
            else {
                VAL(h, i, j, colsH) = max;
            }
        }
    }
    DEBUG_PRINT("Left ComputeBlock\n");
}

void printResult(short *a, short *b, int *h, int *sim, int delta) {
    char *aout, *bout;
    int Max, xMax, yMax, max;
    int i, j;
    int x, y;
    int topskip, bottomskip;
    int tempi, tempj;
    int diag, down, right;
    int *xTraceback, *yTraceback;

    aout = (char *) malloc(sizeof(char) * 2 * N);
    memset(aout, 0, sizeof(char) * 2 * N);
    bout = (char *) malloc(sizeof(char) * 2 * N);
    memset(bout, 0, sizeof(char) * 2 * N);

    xTraceback = (int *) malloc(sizeof(int) * N * N);
    yTraceback = (int *) malloc(sizeof(int) * N * N);

    // Initialize traceback arrays
    for (i = 0; i <= a[0]; i++) {
        for (j = 0; j <= b[0]; j++) {
            VAL(xTraceback, i, j, N) = -1;
            VAL(yTraceback, i, j, N) = -1;
        }
    }

    // Find maximum calculated value
    Max = xMax = yMax = 0;
    for (i = 1; i <= a[0]; i++) {
        for (j = 1; j <= b[0]; j++) {
            diag = VAL(h, i - 1, j - 1, N) + VAL(sim, a[i], b[j], AA);
            down = VAL(h, i - 1, j, N) + delta;
            right = VAL(h, i, j - 1, N) + delta;

            max = MAX3(diag,down,right);

            if (max == diag) {
                VAL(xTraceback, i, j, N) = i - 1;
                VAL(yTraceback, i, j, N) = j - 1;
            }
            else if (max == down) {
                VAL(xTraceback, i, j, N) = i - 1;
                VAL(yTraceback, i, j, N) = j;
            }
            else if (max == right) {
                VAL(xTraceback, i, j, N) = i;
                VAL(yTraceback, i, j, N) = j - 1;
            }
            
            if (max > Max) {
                Max = max;
                xMax = i;
                yMax = j;
            }
        }
    }

    // reset to max point to do alignment
    i = xMax; j = yMax;
    x = y = 0;
    topskip = bottomskip = 1;
    while (i > 0 && j > 0 && VAL(h, i, j, N) > 0){
        if (topskip && bottomskip) {
            aout[x++] = AA2char(a[i]);
            bout[y++] = AA2char(b[j]);
        }
        else if (topskip) {
            aout[x++] = '-';
            bout[y++] = AA2char(b[j]);
        }
        else if (bottomskip) {
            aout[x++] = AA2char(a[i]);
            bout[y++] = '-';
        }
        topskip = (j > VAL(yTraceback, i, j, N));
        bottomskip = (i > VAL(xTraceback, i, j, N));
        tempi = i; 
        tempj = j;
        i = VAL(xTraceback, tempi, tempj, N);
        j = VAL(yTraceback, tempi, tempj, N);
    }

    printf("\n");
    printf("\n");
    for (i= x - 1; i >= 0 ;i--) printf("%c", aout[i]);	
    printf("\n");
    for (j= y - 1; j>=0; j--) printf("%c", bout[j]);	
    printf("\n");
    printf("\n");

    free(aout);
    free(bout);
    free(xTraceback);
    free(yTraceback);
}

void reorder_interleave(void *in, void *out, int elemBytes, int *numRowsNodeIsResponsibleFor, int numRowsPerPart, int numCols, int nproc) {
    int i, j;
    char *cin = (char *) in, *cout = (char *) out;
    char *originalIn = cin;
    int bytesPerPart = numCols * numRowsPerPart * elemBytes;

    DEBUG_PRINT(">> reoder_interleave\n");
    DEBUG_PRINT("elemBytes = %d\n", elemBytes);
    DEBUG_PRINT("numRowsNodeIsResponsibleFor = \n");
    DEBUG_PRINTINTARRAY(numRowsNodeIsResponsibleFor, 1, nproc);
    DEBUG_PRINT("numRowsPerPart = %d\n", numRowsPerPart);
    DEBUG_PRINT("numCols = %d\n", numCols);
    DEBUG_PRINT("nproc = %d\n", nproc);

    for (i = 0; i < nproc; i++) {
        int rowsRemaining = numRowsNodeIsResponsibleFor[i];
        cin = originalIn + i * bytesPerPart;

        DEBUG_PRINT("i = %d\n", i);
        DEBUG_PRINT("rowsRemaining = %d\n", rowsRemaining);

        while (rowsRemaining) {
            int rowsInPart = MIN(rowsRemaining, numRowsPerPart);

            DEBUG_PRINT("rowsInPart = %d\n", rowsInPart);

            int bytesToCopy = rowsInPart * numCols * elemBytes;
            memcpy(cout, cin, bytesToCopy);
            cout += bytesToCopy;
            cin += bytesToCopy;

            rowsRemaining -= rowsInPart;
            cin += bytesPerPart * (nproc - 1);

            DEBUG_PRINT("rowsRemaining = %d\n", rowsRemaining);
        }
    }
}

void reorder_interleave_inverse(void *in, void *out, int elemBytes, int *numRowsNodeIsResponsibleFor, int numRowsPerPart, int numCols, int nproc) {
    int i, j, k;
    char *cin = (char *) in, *cout = (char *) out;
    char *originalOut = cout;
    int bytesPerPart = numCols * numRowsPerPart * elemBytes;

    for (i = 0; i < nproc; i++) {
        int rowsRemaining = numRowsNodeIsResponsibleFor[i];
        int numParts = CEILDIV(rowsRemaining, numRowsPerPart);

        cout = originalOut + i * bytesPerPart;

        for (j = 0; j < numParts; j++) {
            int rowsInPart = MIN(rowsRemaining, numRowsPerPart);
            int bytesToCopy = rowsInPart * numCols * elemBytes;
            memcpy(cout, cin, bytesToCopy);
            cout += bytesToCopy;
            cin += bytesToCopy;
            rowsRemaining -= rowsInPart;
            cout += bytesPerPart * (nproc - 1);
        }
    }
}

void remove_intermediate_rows(int *h, int numRowsResponsibleFor, int numRowsPerPart, 
        int numColsPerRow,
        int numPartsResponsibleFor) {
    // We skip the first part since we want to maintain the 0s
    int remainingRows = numRowsResponsibleFor - numRowsPerPart;
    int i;
    // To where stuff will be copied to
    int *destination = h + (numRowsPerPart + 1) * numColsPerRow;

    DEBUG_PRINT("Entered remove_intermediate_rows\n");

    for (i = 1; i < numPartsResponsibleFor; i++) {
        int startOfNextIntermediateRow = + i * (numRowsPerPart + 1) * numColsPerRow;
        int numRowsToCopy = MIN(remainingRows, numRowsPerPart);
        DEBUG_PRINT("i = %d\n", i);
        DEBUG_PRINT("remainingRows = %d\n", remainingRows);
        DEBUG_PRINT("startOfNextIntermediateRow (row) = %d\n", i * (numRowsPerPart + 1));
        DEBUG_PRINT("numRowsToCopy = %d\n", numRowsToCopy);
        memmove(destination, 
               h + startOfNextIntermediateRow + numColsPerRow,
               numRowsToCopy * numColsPerRow * sizeof(int));
        remainingRows -= numRowsToCopy;
        destination += numRowsToCopy * numColsPerRow;
    }

    DEBUG_PRINT("Left remove_intermediate_rows\n");
}
